package com.packagename;

public final class Manifest {

    public static final class permission {
        public static final String C2D_MESSAGE = "com.packageName.permission.C2D_MESSAGE";
        public static final String MAPS_RECEIVE = "com.packageName.permission.MAPS_RECEIVE";
    }
}
