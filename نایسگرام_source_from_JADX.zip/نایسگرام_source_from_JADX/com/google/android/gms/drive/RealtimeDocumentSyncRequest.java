package com.google.android.gms.drive;

import android.os.Parcel;
import android.os.Parcelable.Creator;
import com.google.android.gms.common.internal.C0238o;
import com.google.android.gms.common.internal.safeparcel.SafeParcelable;
import java.util.List;

public class RealtimeDocumentSyncRequest implements SafeParcelable {
    public static final Creator<RealtimeDocumentSyncRequest> CREATOR;
    final int BR;
    final List<String> NA;
    final List<String> Nz;

    static {
        CREATOR = new C0257f();
    }

    RealtimeDocumentSyncRequest(int versionCode, List<String> documentsToSync, List<String> documentsToDeleteCache) {
        this.BR = versionCode;
        this.Nz = (List) C0238o.m283i(documentsToSync);
        this.NA = (List) C0238o.m283i(documentsToDeleteCache);
    }

    public int describeContents() {
        return 0;
    }

    public void writeToParcel(Parcel dest, int flags) {
        C0257f.m378a(this, dest, flags);
    }
}
