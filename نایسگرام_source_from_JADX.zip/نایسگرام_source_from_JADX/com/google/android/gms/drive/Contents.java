package com.google.android.gms.drive;

import android.os.Parcel;
import android.os.ParcelFileDescriptor;
import android.os.Parcelable.Creator;
import com.google.android.gms.common.internal.safeparcel.SafeParcelable;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.InputStream;
import java.io.OutputStream;

@Deprecated
public class Contents implements SafeParcelable {
    public static final Creator<Contents> CREATOR;
    final int BR;
    final ParcelFileDescriptor KE;
    final int MV;
    final DriveId MW;
    final boolean MX;
    private boolean MY;
    private boolean MZ;
    private boolean mClosed;
    final int uQ;

    static {
        CREATOR = new C0246a();
    }

    Contents(int versionCode, ParcelFileDescriptor parcelFileDescriptor, int requestId, int mode, DriveId driveId, boolean validForConflictDetection) {
        this.mClosed = false;
        this.MY = false;
        this.MZ = false;
        this.BR = versionCode;
        this.KE = parcelFileDescriptor;
        this.uQ = requestId;
        this.MV = mode;
        this.MW = driveId;
        this.MX = validForConflictDetection;
    }

    public int describeContents() {
        return 0;
    }

    public DriveId getDriveId() {
        return this.MW;
    }

    public InputStream getInputStream() {
        if (this.mClosed) {
            throw new IllegalStateException("Contents have been closed, cannot access the input stream.");
        } else if (this.MV != DriveFile.MODE_READ_ONLY) {
            throw new IllegalStateException("getInputStream() can only be used with contents opened with MODE_READ_ONLY.");
        } else if (this.MY) {
            throw new IllegalStateException("getInputStream() can only be called once per Contents instance.");
        } else {
            this.MY = true;
            return new FileInputStream(this.KE.getFileDescriptor());
        }
    }

    public int getMode() {
        return this.MV;
    }

    public OutputStream getOutputStream() {
        if (this.mClosed) {
            throw new IllegalStateException("Contents have been closed, cannot access the output stream.");
        } else if (this.MV != DriveFile.MODE_WRITE_ONLY) {
            throw new IllegalStateException("getOutputStream() can only be used with contents opened with MODE_WRITE_ONLY.");
        } else if (this.MZ) {
            throw new IllegalStateException("getOutputStream() can only be called once per Contents instance.");
        } else {
            this.MZ = true;
            return new FileOutputStream(this.KE.getFileDescriptor());
        }
    }

    public ParcelFileDescriptor getParcelFileDescriptor() {
        if (!this.mClosed) {
            return this.KE;
        }
        throw new IllegalStateException("Contents have been closed, cannot access the output stream.");
    }

    public int getRequestId() {
        return this.uQ;
    }

    public void hJ() {
        this.mClosed = true;
    }

    public boolean hK() {
        return this.mClosed;
    }

    public boolean hL() {
        return this.MX;
    }

    public void writeToParcel(Parcel dest, int flags) {
        C0246a.m364a(this, dest, flags);
    }
}
