package com.google.android.gms.drive;

import com.google.android.gms.common.api.GoogleApiClient;
import com.google.android.gms.drive.internal.C2398q;

public final class ExecutionOptions {
    public static final int CONFLICT_STRATEGY_KEEP_REMOTE = 1;
    public static final int CONFLICT_STRATEGY_OVERWRITE_REMOTE = 0;
    public static final int MAX_TRACKING_TAG_STRING_LENGTH = 65536;
    private final String Nn;
    private final boolean No;
    private final int Np;

    public static final class Builder {
        private String Nn;
        private boolean No;
        private int Np;

        public Builder() {
            this.Np = ExecutionOptions.CONFLICT_STRATEGY_OVERWRITE_REMOTE;
        }

        public ExecutionOptions build() {
            if (this.Np != ExecutionOptions.CONFLICT_STRATEGY_KEEP_REMOTE || this.No) {
                return new ExecutionOptions(this.No, this.Np, null);
            }
            throw new IllegalStateException("Cannot use CONFLICT_STRATEGY_KEEP_REMOTE without requesting completion notifications");
        }

        public Builder setConflictStrategy(int strategy) {
            if (ExecutionOptions.aW(strategy)) {
                this.Np = strategy;
                return this;
            }
            throw new IllegalArgumentException("Unrecognized value for conflict strategy: " + strategy);
        }

        public Builder setNotifyOnCompletion(boolean notify) {
            this.No = notify;
            return this;
        }

        public Builder setTrackingTag(String trackingTag) {
            if (ExecutionOptions.bh(trackingTag)) {
                this.Nn = trackingTag;
                return this;
            }
            Object[] objArr = new Object[ExecutionOptions.CONFLICT_STRATEGY_KEEP_REMOTE];
            objArr[ExecutionOptions.CONFLICT_STRATEGY_OVERWRITE_REMOTE] = Integer.valueOf(ExecutionOptions.MAX_TRACKING_TAG_STRING_LENGTH);
            throw new IllegalArgumentException(String.format("trackingTag must not be null nor empty, and the length must be <= the maximum length (%s)", objArr));
        }
    }

    private ExecutionOptions(String trackingTag, boolean notifyOnCompletion, int conflictStrategy) {
        this.Nn = trackingTag;
        this.No = notifyOnCompletion;
        this.Np = conflictStrategy;
    }

    public static void m363a(GoogleApiClient googleApiClient, ExecutionOptions executionOptions) {
        C2398q c2398q = (C2398q) googleApiClient.m149a(Drive.CU);
        if (executionOptions.hP() && !c2398q.ib()) {
            throw new IllegalStateException("Application must define an exported DriveEventService subclass in AndroidManifest.xml to be notified on completion");
        }
    }

    public static boolean aV(int i) {
        switch (i) {
            case CONFLICT_STRATEGY_KEEP_REMOTE /*1*/:
                return true;
            default:
                return false;
        }
    }

    public static boolean aW(int i) {
        switch (i) {
            case CONFLICT_STRATEGY_OVERWRITE_REMOTE /*0*/:
            case CONFLICT_STRATEGY_KEEP_REMOTE /*1*/:
                return true;
            default:
                return false;
        }
    }

    public static boolean bh(String str) {
        return (str == null || str.isEmpty() || str.length() > MAX_TRACKING_TAG_STRING_LENGTH) ? false : true;
    }

    public String hO() {
        return this.Nn;
    }

    public boolean hP() {
        return this.No;
    }

    public int hQ() {
        return this.Np;
    }
}
