package com.google.android.gms.drive;

import android.os.Parcel;
import android.os.Parcelable;
import com.google.android.gms.common.internal.C0238o;

/* renamed from: com.google.android.gms.drive.i */
public abstract class C0260i implements Parcelable {
    private volatile transient boolean NL;

    public C0260i() {
        this.NL = false;
    }

    protected abstract void m384I(Parcel parcel, int i);

    public final boolean hT() {
        return this.NL;
    }

    public void writeToParcel(Parcel dest, int flags) {
        C0238o.m275I(!hT());
        this.NL = true;
        m384I(dest, flags);
    }
}
