package com.google.android.gms.drive.events;

import android.os.Parcel;
import android.os.Parcelable.Creator;
import com.google.android.gms.common.internal.safeparcel.SafeParcelable;
import com.google.android.gms.drive.DriveId;
import java.util.Locale;

public final class ChangeEvent implements SafeParcelable, ResourceEvent {
    public static final Creator<ChangeEvent> CREATOR;
    final int BR;
    final DriveId MW;
    final int NM;

    static {
        CREATOR = new C0253a();
    }

    ChangeEvent(int versionCode, DriveId driveId, int changeFlags) {
        this.BR = versionCode;
        this.MW = driveId;
        this.NM = changeFlags;
    }

    public int describeContents() {
        return 0;
    }

    public DriveId getDriveId() {
        return this.MW;
    }

    public int getType() {
        return 1;
    }

    public boolean hasContentChanged() {
        return (this.NM & 2) != 0;
    }

    public boolean hasMetadataChanged() {
        return (this.NM & 1) != 0;
    }

    public String toString() {
        return String.format(Locale.US, "ChangeEvent [id=%s,changeFlags=%x]", new Object[]{this.MW, Integer.valueOf(this.NM)});
    }

    public void writeToParcel(Parcel dest, int flags) {
        C0253a.m373a(this, dest, flags);
    }
}
