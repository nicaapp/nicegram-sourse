package com.google.android.gms.drive.events;

import android.os.IBinder;
import android.os.Parcel;
import android.os.ParcelFileDescriptor;
import android.os.Parcelable.Creator;
import com.google.android.gms.common.internal.safeparcel.C0242a;
import com.google.android.gms.common.internal.safeparcel.C0242a.C0241a;
import com.google.android.gms.common.internal.safeparcel.C0243b;
import com.google.android.gms.drive.DriveId;
import com.google.android.gms.drive.metadata.internal.MetadataBundle;
import com.google.android.gms.games.quest.Quest;
import com.google.android.gms.location.DetectedActivity;
import com.googlecode.mp4parser.boxes.microsoft.XtraBox;
import java.util.ArrayList;
import org.telegram.C0811R;
import org.telegram.android.support.widget.helper.ItemTouchHelper;
import org.telegram.android.time.FastDatePrinter;

/* renamed from: com.google.android.gms.drive.events.b */
public class C0254b implements Creator<CompletionEvent> {
    static void m375a(CompletionEvent completionEvent, Parcel parcel, int i) {
        int D = C0243b.m329D(parcel);
        C0243b.m356c(parcel, 1, completionEvent.BR);
        C0243b.m340a(parcel, 2, completionEvent.MW, i, false);
        C0243b.m344a(parcel, 3, completionEvent.Dd, false);
        C0243b.m340a(parcel, 4, completionEvent.NN, i, false);
        C0243b.m340a(parcel, 5, completionEvent.NO, i, false);
        C0243b.m340a(parcel, 6, completionEvent.NP, i, false);
        C0243b.m355b(parcel, 7, completionEvent.NQ, false);
        C0243b.m356c(parcel, 8, completionEvent.Fa);
        C0243b.m338a(parcel, 9, completionEvent.NR, false);
        C0243b.m332H(parcel, D);
    }

    public CompletionEvent m376U(Parcel parcel) {
        int i = 0;
        IBinder iBinder = null;
        int C = C0242a.m293C(parcel);
        ArrayList arrayList = null;
        MetadataBundle metadataBundle = null;
        ParcelFileDescriptor parcelFileDescriptor = null;
        ParcelFileDescriptor parcelFileDescriptor2 = null;
        String str = null;
        DriveId driveId = null;
        int i2 = 0;
        while (parcel.dataPosition() < C) {
            int B = C0242a.m291B(parcel);
            switch (C0242a.aD(B)) {
                case CompletionEvent.STATUS_FAILURE /*1*/:
                    i2 = C0242a.m309g(parcel, B);
                    break;
                case CompletionEvent.STATUS_CONFLICT /*2*/:
                    driveId = (DriveId) C0242a.m298a(parcel, B, DriveId.CREATOR);
                    break;
                case FastDatePrinter.SHORT /*3*/:
                    str = C0242a.m317o(parcel, B);
                    break;
                case ItemTouchHelper.LEFT /*4*/:
                    parcelFileDescriptor2 = (ParcelFileDescriptor) C0242a.m298a(parcel, B, ParcelFileDescriptor.CREATOR);
                    break;
                case DetectedActivity.TILTING /*5*/:
                    parcelFileDescriptor = (ParcelFileDescriptor) C0242a.m298a(parcel, B, ParcelFileDescriptor.CREATOR);
                    break;
                case Quest.STATE_FAILED /*6*/:
                    metadataBundle = (MetadataBundle) C0242a.m298a(parcel, B, MetadataBundle.CREATOR);
                    break;
                case DetectedActivity.WALKING /*7*/:
                    arrayList = C0242a.m294C(parcel, B);
                    break;
                case XtraBox.MP4_XTRA_BT_UNICODE /*8*/:
                    i = C0242a.m309g(parcel, B);
                    break;
                case C0811R.styleable.WalletFragmentStyle_maskedWalletDetailsLogoTextColor /*9*/:
                    iBinder = C0242a.m318p(parcel, B);
                    break;
                default:
                    C0242a.m302b(parcel, B);
                    break;
            }
        }
        if (parcel.dataPosition() == C) {
            return new CompletionEvent(i2, driveId, str, parcelFileDescriptor2, parcelFileDescriptor, metadataBundle, arrayList, i, iBinder);
        }
        throw new C0241a("Overread allowed size end=" + C, parcel);
    }

    public CompletionEvent[] bb(int i) {
        return new CompletionEvent[i];
    }

    public /* synthetic */ Object createFromParcel(Parcel x0) {
        return m376U(x0);
    }

    public /* synthetic */ Object[] newArray(int x0) {
        return bb(x0);
    }
}
