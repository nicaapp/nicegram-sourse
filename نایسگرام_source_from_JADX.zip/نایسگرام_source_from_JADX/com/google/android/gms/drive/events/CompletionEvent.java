package com.google.android.gms.drive.events;

import android.os.IBinder;
import android.os.Parcel;
import android.os.ParcelFileDescriptor;
import android.os.Parcelable.Creator;
import android.os.RemoteException;
import android.text.TextUtils;
import com.google.android.gms.common.internal.safeparcel.SafeParcelable;
import com.google.android.gms.drive.DriveId;
import com.google.android.gms.drive.MetadataChangeSet;
import com.google.android.gms.drive.internal.C0273v;
import com.google.android.gms.drive.internal.ae.C1720a;
import com.google.android.gms.drive.metadata.internal.MetadataBundle;
import com.google.android.gms.internal.jy;
import java.io.FileInputStream;
import java.io.InputStream;
import java.util.ArrayList;
import java.util.List;
import java.util.Locale;

public final class CompletionEvent implements SafeParcelable, ResourceEvent {
    public static final Creator<CompletionEvent> CREATOR;
    public static final int STATUS_CONFLICT = 2;
    public static final int STATUS_FAILURE = 1;
    public static final int STATUS_SUCCESS = 0;
    final int BR;
    final String Dd;
    final int Fa;
    final DriveId MW;
    final ParcelFileDescriptor NN;
    final ParcelFileDescriptor NO;
    final MetadataBundle NP;
    final ArrayList<String> NQ;
    final IBinder NR;
    private boolean NS;
    private boolean NT;
    private boolean NU;

    static {
        CREATOR = new C0254b();
    }

    CompletionEvent(int versionCode, DriveId driveId, String accountName, ParcelFileDescriptor baseParcelFileDescriptor, ParcelFileDescriptor modifiedParcelFileDescriptor, MetadataBundle modifiedMetadataBundle, ArrayList<String> trackingTags, int status, IBinder releaseCallback) {
        this.NS = false;
        this.NT = false;
        this.NU = false;
        this.BR = versionCode;
        this.MW = driveId;
        this.Dd = accountName;
        this.NN = baseParcelFileDescriptor;
        this.NO = modifiedParcelFileDescriptor;
        this.NP = modifiedMetadataBundle;
        this.NQ = trackingTags;
        this.Fa = status;
        this.NR = releaseCallback;
    }

    private void m4607L(boolean z) {
        hU();
        this.NU = true;
        jy.m1597a(this.NN);
        jy.m1597a(this.NO);
        if (this.NR == null) {
            C0273v.m476q("CompletionEvent", "No callback on " + (z ? "snooze" : "dismiss"));
            return;
        }
        try {
            C1720a.m2571X(this.NR).m433L(z);
        } catch (RemoteException e) {
            C0273v.m476q("CompletionEvent", "RemoteException on " + (z ? "snooze" : "dismiss") + ": " + e);
        }
    }

    private void hU() {
        if (this.NU) {
            throw new IllegalStateException("Event has already been dismissed or snoozed.");
        }
    }

    public int describeContents() {
        return 0;
    }

    public void dismiss() {
        m4607L(false);
    }

    public String getAccountName() {
        hU();
        return this.Dd;
    }

    public InputStream getBaseContentsInputStream() {
        hU();
        if (this.NN == null) {
            return null;
        }
        if (this.NS) {
            throw new IllegalStateException("getBaseInputStream() can only be called once per CompletionEvent instance.");
        }
        this.NS = true;
        return new FileInputStream(this.NN.getFileDescriptor());
    }

    public DriveId getDriveId() {
        hU();
        return this.MW;
    }

    public InputStream getModifiedContentsInputStream() {
        hU();
        if (this.NO == null) {
            return null;
        }
        if (this.NT) {
            throw new IllegalStateException("getModifiedInputStream() can only be called once per CompletionEvent instance.");
        }
        this.NT = true;
        return new FileInputStream(this.NO.getFileDescriptor());
    }

    public MetadataChangeSet getModifiedMetadataChangeSet() {
        hU();
        return this.NP != null ? new MetadataChangeSet(this.NP) : null;
    }

    public int getStatus() {
        hU();
        return this.Fa;
    }

    public List<String> getTrackingTags() {
        hU();
        return new ArrayList(this.NQ);
    }

    public int getType() {
        return STATUS_CONFLICT;
    }

    public void snooze() {
        m4607L(true);
    }

    public String toString() {
        String str = this.NQ == null ? "<null>" : "'" + TextUtils.join("','", this.NQ) + "'";
        return String.format(Locale.US, "CompletionEvent [id=%s, status=%s, trackingTag=%s]", new Object[]{this.MW, Integer.valueOf(this.Fa), str});
    }

    public void writeToParcel(Parcel dest, int flags) {
        C0254b.m375a(this, dest, flags);
    }
}
