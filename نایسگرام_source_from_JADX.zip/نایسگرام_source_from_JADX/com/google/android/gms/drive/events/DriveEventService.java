package com.google.android.gms.drive.events;

import android.app.Service;
import android.content.Intent;
import android.os.Binder;
import android.os.Handler;
import android.os.IBinder;
import android.os.Looper;
import android.os.Message;
import android.os.RemoteException;
import com.google.android.gms.common.GooglePlayServicesUtil;
import com.google.android.gms.common.internal.C0238o;
import com.google.android.gms.drive.internal.C0273v;
import com.google.android.gms.drive.internal.OnEventResponse;
import com.google.android.gms.drive.internal.ad.C1718a;
import java.util.concurrent.CountDownLatch;
import java.util.concurrent.TimeUnit;

public abstract class DriveEventService extends Service implements ChangeListener, CompletionListener {
    public static final String ACTION_HANDLE_EVENT = "com.google.android.gms.drive.events.HANDLE_EVENT";
    private CountDownLatch NV;
    C0252a NW;
    int NX;
    private final String mName;

    /* renamed from: com.google.android.gms.drive.events.DriveEventService.1 */
    class C02511 extends Thread {
        final /* synthetic */ CountDownLatch NY;
        final /* synthetic */ DriveEventService NZ;

        C02511(DriveEventService driveEventService, CountDownLatch countDownLatch) {
            this.NZ = driveEventService;
            this.NY = countDownLatch;
        }

        public void run() {
            try {
                Looper.prepare();
                this.NZ.NW = new C0252a(this.NZ);
                this.NY.countDown();
                C0273v.m474n("DriveEventService", "Bound and starting loop");
                Looper.loop();
                C0273v.m474n("DriveEventService", "Finished loop");
            } finally {
                this.NZ.NV.countDown();
            }
        }
    }

    /* renamed from: com.google.android.gms.drive.events.DriveEventService.a */
    final class C0252a extends Handler {
        final /* synthetic */ DriveEventService NZ;

        C0252a(DriveEventService driveEventService) {
            this.NZ = driveEventService;
        }

        private Message m372b(OnEventResponse onEventResponse) {
            return obtainMessage(1, onEventResponse);
        }

        private Message hW() {
            return obtainMessage(2);
        }

        public void handleMessage(Message msg) {
            C0273v.m474n("DriveEventService", "handleMessage message type:" + msg.what);
            switch (msg.what) {
                case CompletionEvent.STATUS_FAILURE /*1*/:
                    this.NZ.m3831a((OnEventResponse) msg.obj);
                case CompletionEvent.STATUS_CONFLICT /*2*/:
                    getLooper().quit();
                default:
                    C0273v.m475p("DriveEventService", "Unexpected message type:" + msg.what);
            }
        }
    }

    /* renamed from: com.google.android.gms.drive.events.DriveEventService.b */
    final class C2391b extends C1718a {
        final /* synthetic */ DriveEventService NZ;

        C2391b(DriveEventService driveEventService) {
            this.NZ = driveEventService;
        }

        public void m3828c(OnEventResponse onEventResponse) throws RemoteException {
            synchronized (this.NZ) {
                C0273v.m474n("DriveEventService", "onEvent: " + onEventResponse);
                C0238o.m283i(this.NZ.NW);
                this.NZ.hV();
                this.NZ.NW.sendMessage(this.NZ.NW.m372b(onEventResponse));
            }
        }
    }

    protected DriveEventService() {
        this("DriveEventService");
    }

    protected DriveEventService(String name) {
        this.NX = -1;
        this.mName = name;
    }

    private void m3831a(OnEventResponse onEventResponse) {
        DriveEvent ih = onEventResponse.ih();
        C0273v.m474n("DriveEventService", "handleEventMessage: " + ih);
        try {
            switch (ih.getType()) {
                case CompletionEvent.STATUS_FAILURE /*1*/:
                    onChange((ChangeEvent) ih);
                    return;
                case CompletionEvent.STATUS_CONFLICT /*2*/:
                    onCompletion((CompletionEvent) ih);
                    return;
                default:
                    C0273v.m475p(this.mName, "Unhandled event: " + ih);
                    return;
            }
        } catch (Throwable e) {
            C0273v.m472a(this.mName, e, "Error handling event: " + ih);
        }
        C0273v.m472a(this.mName, e, "Error handling event: " + ih);
    }

    private boolean bc(int i) {
        String str = GooglePlayServicesUtil.GOOGLE_PLAY_SERVICES_PACKAGE;
        String[] packagesForUid = getPackageManager().getPackagesForUid(i);
        if (packagesForUid == null) {
            return false;
        }
        for (Object equals : packagesForUid) {
            if (str.equals(equals)) {
                return true;
            }
        }
        return false;
    }

    private void hV() throws SecurityException {
        int callingUid = getCallingUid();
        if (callingUid != this.NX) {
            if (GooglePlayServicesUtil.m137b(getPackageManager(), GooglePlayServicesUtil.GOOGLE_PLAY_SERVICES_PACKAGE) && bc(callingUid)) {
                this.NX = callingUid;
                return;
            }
            throw new SecurityException("Caller is not GooglePlayServices");
        }
    }

    protected int getCallingUid() {
        return Binder.getCallingUid();
    }

    public final synchronized IBinder onBind(Intent intent) {
        IBinder asBinder;
        if (ACTION_HANDLE_EVENT.equals(intent.getAction())) {
            if (this.NW == null) {
                CountDownLatch countDownLatch = new CountDownLatch(1);
                this.NV = new CountDownLatch(1);
                new C02511(this, countDownLatch).start();
                try {
                    countDownLatch.await(5000, TimeUnit.MILLISECONDS);
                } catch (Throwable e) {
                    throw new RuntimeException("Unable to start event handler", e);
                }
            }
            asBinder = new C2391b(this).asBinder();
        } else {
            asBinder = null;
        }
        return asBinder;
    }

    public void onChange(ChangeEvent event) {
        C0273v.m475p(this.mName, "Unhandled change event: " + event);
    }

    public void onCompletion(CompletionEvent event) {
        C0273v.m475p(this.mName, "Unhandled completion event: " + event);
    }

    public synchronized void onDestroy() {
        C0273v.m474n("DriveEventService", "onDestroy");
        if (this.NW != null) {
            this.NW.sendMessage(this.NW.hW());
            this.NW = null;
            try {
                this.NV.await(5000, TimeUnit.MILLISECONDS);
            } catch (InterruptedException e) {
            }
            this.NV = null;
        }
        super.onDestroy();
    }

    public boolean onUnbind(Intent intent) {
        return true;
    }
}
