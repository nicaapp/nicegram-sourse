package com.google.android.gms.drive.events;

import com.google.android.gms.drive.DriveId;

/* renamed from: com.google.android.gms.drive.events.d */
public class C0256d {
    public static boolean m377a(int i, DriveId driveId) {
        return driveId != null || C0256d.bd(i);
    }

    public static boolean bd(int i) {
        return (2 & ((long) (1 << i))) != 0;
    }
}
