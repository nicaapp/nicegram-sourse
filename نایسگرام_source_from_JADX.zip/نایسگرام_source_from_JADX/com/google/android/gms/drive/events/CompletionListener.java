package com.google.android.gms.drive.events;

public interface CompletionListener extends C0255c {
    void onCompletion(CompletionEvent completionEvent);
}
