package com.google.android.gms.drive.realtime.internal.event;

import android.os.Parcel;
import android.os.Parcelable.Creator;
import com.google.android.gms.common.internal.safeparcel.SafeParcelable;
import java.util.List;

public class ParcelableEvent implements SafeParcelable {
    public static final Creator<ParcelableEvent> CREATOR;
    final int BR;
    final ValuesSetDetails RA;
    final ValueChangedDetails RB;
    final ReferenceShiftedDetails RC;
    final ObjectChangedDetails RD;
    final String Rm;
    final String Rp;
    final List<String> Rt;
    final boolean Ru;
    final String Rv;
    final TextInsertedDetails Rw;
    final TextDeletedDetails Rx;
    final ValuesAddedDetails Ry;
    final ValuesRemovedDetails Rz;
    final String vL;

    static {
        CREATOR = new C0305b();
    }

    ParcelableEvent(int versionCode, String sessionId, String userId, List<String> compoundOperationNames, boolean isLocal, String objectId, String objectType, TextInsertedDetails textInsertedDetails, TextDeletedDetails textDeletedDetails, ValuesAddedDetails valuesAddedDetails, ValuesRemovedDetails valuesRemovedDetails, ValuesSetDetails valuesSetDetails, ValueChangedDetails valueChangedDetails, ReferenceShiftedDetails referenceShiftedDetails, ObjectChangedDetails objectChangedDetails) {
        this.BR = versionCode;
        this.vL = sessionId;
        this.Rm = userId;
        this.Rt = compoundOperationNames;
        this.Ru = isLocal;
        this.Rp = objectId;
        this.Rv = objectType;
        this.Rw = textInsertedDetails;
        this.Rx = textDeletedDetails;
        this.Ry = valuesAddedDetails;
        this.Rz = valuesRemovedDetails;
        this.RA = valuesSetDetails;
        this.RB = valueChangedDetails;
        this.RC = referenceShiftedDetails;
        this.RD = objectChangedDetails;
    }

    public int describeContents() {
        return 0;
    }

    public void writeToParcel(Parcel dest, int flags) {
        C0305b.m516a(this, dest, flags);
    }
}
