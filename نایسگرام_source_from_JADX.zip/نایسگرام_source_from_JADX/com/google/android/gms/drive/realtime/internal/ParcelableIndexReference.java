package com.google.android.gms.drive.realtime.internal;

import android.os.Parcel;
import android.os.Parcelable.Creator;
import com.google.android.gms.common.internal.safeparcel.SafeParcelable;

public class ParcelableIndexReference implements SafeParcelable {
    public static final Creator<ParcelableIndexReference> CREATOR;
    final int BR;
    final String Rp;
    final boolean Rq;
    final int mIndex;

    static {
        CREATOR = new C0325q();
    }

    ParcelableIndexReference(int versionCode, String objectId, int index, boolean canBeDeleted) {
        this.BR = versionCode;
        this.Rp = objectId;
        this.mIndex = index;
        this.Rq = canBeDeleted;
    }

    public int describeContents() {
        return 0;
    }

    public void writeToParcel(Parcel dest, int flags) {
        C0325q.m580a(this, dest, flags);
    }
}
