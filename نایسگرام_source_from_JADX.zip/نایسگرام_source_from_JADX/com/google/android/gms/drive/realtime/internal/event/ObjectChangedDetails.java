package com.google.android.gms.drive.realtime.internal.event;

import android.os.Parcel;
import android.os.Parcelable.Creator;
import com.google.android.gms.common.internal.safeparcel.SafeParcelable;

public class ObjectChangedDetails implements SafeParcelable {
    public static final Creator<ObjectChangedDetails> CREATOR;
    final int BR;
    final int Rr;
    final int Rs;

    static {
        CREATOR = new C0304a();
    }

    ObjectChangedDetails(int versionCode, int valueIndex, int valueCount) {
        this.BR = versionCode;
        this.Rr = valueIndex;
        this.Rs = valueCount;
    }

    public int describeContents() {
        return 0;
    }

    public void writeToParcel(Parcel dest, int flags) {
        C0304a.m515a(this, dest, flags);
    }
}
