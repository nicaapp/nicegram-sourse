package com.google.android.gms.drive.realtime.internal;

import android.os.Parcel;
import android.os.Parcelable.Creator;
import com.google.android.gms.common.internal.safeparcel.SafeParcelable;

public class BeginCompoundOperationRequest implements SafeParcelable {
    public static final Creator<BeginCompoundOperationRequest> CREATOR;
    final int BR;
    final boolean Ri;
    final boolean Rj;
    final String mName;

    static {
        CREATOR = new C0299a();
    }

    BeginCompoundOperationRequest(int versionCode, boolean isCreation, String name, boolean isUndoable) {
        this.BR = versionCode;
        this.Ri = isCreation;
        this.mName = name;
        this.Rj = isUndoable;
    }

    public int describeContents() {
        return 0;
    }

    public void writeToParcel(Parcel dest, int flags) {
        C0299a.m507a(this, dest, flags);
    }
}
