package com.google.android.gms.drive.realtime.internal.event;

import android.os.Parcel;
import android.os.Parcelable.Creator;
import com.google.android.gms.common.internal.safeparcel.C0242a;
import com.google.android.gms.common.internal.safeparcel.C0242a.C0241a;
import com.google.android.gms.common.internal.safeparcel.C0243b;
import com.google.android.gms.drive.events.CompletionEvent;
import com.google.android.gms.location.DetectedActivity;
import org.telegram.android.support.widget.helper.ItemTouchHelper;
import org.telegram.android.time.FastDatePrinter;

/* renamed from: com.google.android.gms.drive.realtime.internal.event.d */
public class C0307d implements Creator<ReferenceShiftedDetails> {
    static void m518a(ReferenceShiftedDetails referenceShiftedDetails, Parcel parcel, int i) {
        int D = C0243b.m329D(parcel);
        C0243b.m356c(parcel, 1, referenceShiftedDetails.BR);
        C0243b.m344a(parcel, 2, referenceShiftedDetails.RH, false);
        C0243b.m344a(parcel, 3, referenceShiftedDetails.RI, false);
        C0243b.m356c(parcel, 4, referenceShiftedDetails.RJ);
        C0243b.m356c(parcel, 5, referenceShiftedDetails.RK);
        C0243b.m332H(parcel, D);
    }

    public ReferenceShiftedDetails bb(Parcel parcel) {
        String str = null;
        int i = 0;
        int C = C0242a.m293C(parcel);
        int i2 = 0;
        String str2 = null;
        int i3 = 0;
        while (parcel.dataPosition() < C) {
            int B = C0242a.m291B(parcel);
            switch (C0242a.aD(B)) {
                case CompletionEvent.STATUS_FAILURE /*1*/:
                    i3 = C0242a.m309g(parcel, B);
                    break;
                case CompletionEvent.STATUS_CONFLICT /*2*/:
                    str2 = C0242a.m317o(parcel, B);
                    break;
                case FastDatePrinter.SHORT /*3*/:
                    str = C0242a.m317o(parcel, B);
                    break;
                case ItemTouchHelper.LEFT /*4*/:
                    i2 = C0242a.m309g(parcel, B);
                    break;
                case DetectedActivity.TILTING /*5*/:
                    i = C0242a.m309g(parcel, B);
                    break;
                default:
                    C0242a.m302b(parcel, B);
                    break;
            }
        }
        if (parcel.dataPosition() == C) {
            return new ReferenceShiftedDetails(i3, str2, str, i2, i);
        }
        throw new C0241a("Overread allowed size end=" + C, parcel);
    }

    public ReferenceShiftedDetails[] co(int i) {
        return new ReferenceShiftedDetails[i];
    }

    public /* synthetic */ Object createFromParcel(Parcel x0) {
        return bb(x0);
    }

    public /* synthetic */ Object[] newArray(int x0) {
        return co(x0);
    }
}
