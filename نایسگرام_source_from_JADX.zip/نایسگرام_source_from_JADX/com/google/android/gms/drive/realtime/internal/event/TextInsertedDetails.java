package com.google.android.gms.drive.realtime.internal.event;

import android.os.Parcel;
import android.os.Parcelable.Creator;
import com.google.android.gms.common.internal.safeparcel.SafeParcelable;

public class TextInsertedDetails implements SafeParcelable {
    public static final Creator<TextInsertedDetails> CREATOR;
    final int BR;
    final int RL;
    final int mIndex;

    static {
        CREATOR = new C0309f();
    }

    TextInsertedDetails(int versionCode, int index, int stringDataIndex) {
        this.BR = versionCode;
        this.mIndex = index;
        this.RL = stringDataIndex;
    }

    public int describeContents() {
        return 0;
    }

    public void writeToParcel(Parcel dest, int flags) {
        C0309f.m520a(this, dest, flags);
    }
}
