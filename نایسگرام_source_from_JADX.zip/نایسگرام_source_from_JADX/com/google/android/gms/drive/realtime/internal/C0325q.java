package com.google.android.gms.drive.realtime.internal;

import android.os.Parcel;
import android.os.Parcelable.Creator;
import com.google.android.gms.common.internal.safeparcel.C0242a;
import com.google.android.gms.common.internal.safeparcel.C0242a.C0241a;
import com.google.android.gms.common.internal.safeparcel.C0243b;
import com.google.android.gms.drive.events.CompletionEvent;
import org.telegram.android.support.widget.helper.ItemTouchHelper;
import org.telegram.android.time.FastDatePrinter;

/* renamed from: com.google.android.gms.drive.realtime.internal.q */
public class C0325q implements Creator<ParcelableIndexReference> {
    static void m580a(ParcelableIndexReference parcelableIndexReference, Parcel parcel, int i) {
        int D = C0243b.m329D(parcel);
        C0243b.m356c(parcel, 1, parcelableIndexReference.BR);
        C0243b.m344a(parcel, 2, parcelableIndexReference.Rp, false);
        C0243b.m356c(parcel, 3, parcelableIndexReference.mIndex);
        C0243b.m347a(parcel, 4, parcelableIndexReference.Rq);
        C0243b.m332H(parcel, D);
    }

    public ParcelableIndexReference aX(Parcel parcel) {
        boolean z = false;
        int C = C0242a.m293C(parcel);
        String str = null;
        int i = 0;
        int i2 = 0;
        while (parcel.dataPosition() < C) {
            int B = C0242a.m291B(parcel);
            switch (C0242a.aD(B)) {
                case CompletionEvent.STATUS_FAILURE /*1*/:
                    i2 = C0242a.m309g(parcel, B);
                    break;
                case CompletionEvent.STATUS_CONFLICT /*2*/:
                    str = C0242a.m317o(parcel, B);
                    break;
                case FastDatePrinter.SHORT /*3*/:
                    i = C0242a.m309g(parcel, B);
                    break;
                case ItemTouchHelper.LEFT /*4*/:
                    z = C0242a.m305c(parcel, B);
                    break;
                default:
                    C0242a.m302b(parcel, B);
                    break;
            }
        }
        if (parcel.dataPosition() == C) {
            return new ParcelableIndexReference(i2, str, i, z);
        }
        throw new C0241a("Overread allowed size end=" + C, parcel);
    }

    public ParcelableIndexReference[] ck(int i) {
        return new ParcelableIndexReference[i];
    }

    public /* synthetic */ Object createFromParcel(Parcel x0) {
        return aX(x0);
    }

    public /* synthetic */ Object[] newArray(int x0) {
        return ck(x0);
    }
}
