package com.google.android.gms.drive.realtime.internal;

import android.os.Parcel;
import android.os.Parcelable.Creator;
import com.google.android.gms.common.internal.safeparcel.SafeParcelable;

public class ParcelableCollaborator implements SafeParcelable {
    public static final Creator<ParcelableCollaborator> CREATOR;
    final int BR;
    final String NH;
    final boolean Rk;
    final boolean Rl;
    final String Rm;
    final String Rn;
    final String Ro;
    final String vL;

    static {
        CREATOR = new C0324p();
    }

    ParcelableCollaborator(int versionCode, boolean isMe, boolean isAnonymous, String sessionId, String userId, String displayName, String color, String photoUrl) {
        this.BR = versionCode;
        this.Rk = isMe;
        this.Rl = isAnonymous;
        this.vL = sessionId;
        this.Rm = userId;
        this.NH = displayName;
        this.Rn = color;
        this.Ro = photoUrl;
    }

    public int describeContents() {
        return 0;
    }

    public boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (!(obj instanceof ParcelableCollaborator)) {
            return false;
        }
        return this.vL.equals(((ParcelableCollaborator) obj).vL);
    }

    public int hashCode() {
        return this.vL.hashCode();
    }

    public String toString() {
        return "Collaborator [isMe=" + this.Rk + ", isAnonymous=" + this.Rl + ", sessionId=" + this.vL + ", userId=" + this.Rm + ", displayName=" + this.NH + ", color=" + this.Rn + ", photoUrl=" + this.Ro + "]";
    }

    public void writeToParcel(Parcel dest, int flags) {
        C0324p.m579a(this, dest, flags);
    }
}
