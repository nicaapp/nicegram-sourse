package com.google.android.gms.drive.realtime.internal.event;

import android.os.Parcel;
import android.os.Parcelable.Creator;
import com.google.android.gms.common.internal.safeparcel.C0242a;
import com.google.android.gms.common.internal.safeparcel.C0242a.C0241a;
import com.google.android.gms.common.internal.safeparcel.C0243b;
import com.google.android.gms.drive.events.CompletionEvent;
import com.google.android.gms.games.quest.Quest;
import com.google.android.gms.location.DetectedActivity;
import org.telegram.android.support.widget.helper.ItemTouchHelper;
import org.telegram.android.time.FastDatePrinter;

/* renamed from: com.google.android.gms.drive.realtime.internal.event.i */
public class C0312i implements Creator<ValuesRemovedDetails> {
    static void m523a(ValuesRemovedDetails valuesRemovedDetails, Parcel parcel, int i) {
        int D = C0243b.m329D(parcel);
        C0243b.m356c(parcel, 1, valuesRemovedDetails.BR);
        C0243b.m356c(parcel, 2, valuesRemovedDetails.mIndex);
        C0243b.m356c(parcel, 3, valuesRemovedDetails.Rr);
        C0243b.m356c(parcel, 4, valuesRemovedDetails.Rs);
        C0243b.m344a(parcel, 5, valuesRemovedDetails.RP, false);
        C0243b.m356c(parcel, 6, valuesRemovedDetails.RQ);
        C0243b.m332H(parcel, D);
    }

    public ValuesRemovedDetails bg(Parcel parcel) {
        int i = 0;
        int C = C0242a.m293C(parcel);
        String str = null;
        int i2 = 0;
        int i3 = 0;
        int i4 = 0;
        int i5 = 0;
        while (parcel.dataPosition() < C) {
            int B = C0242a.m291B(parcel);
            switch (C0242a.aD(B)) {
                case CompletionEvent.STATUS_FAILURE /*1*/:
                    i5 = C0242a.m309g(parcel, B);
                    break;
                case CompletionEvent.STATUS_CONFLICT /*2*/:
                    i4 = C0242a.m309g(parcel, B);
                    break;
                case FastDatePrinter.SHORT /*3*/:
                    i3 = C0242a.m309g(parcel, B);
                    break;
                case ItemTouchHelper.LEFT /*4*/:
                    i2 = C0242a.m309g(parcel, B);
                    break;
                case DetectedActivity.TILTING /*5*/:
                    str = C0242a.m317o(parcel, B);
                    break;
                case Quest.STATE_FAILED /*6*/:
                    i = C0242a.m309g(parcel, B);
                    break;
                default:
                    C0242a.m302b(parcel, B);
                    break;
            }
        }
        if (parcel.dataPosition() == C) {
            return new ValuesRemovedDetails(i5, i4, i3, i2, str, i);
        }
        throw new C0241a("Overread allowed size end=" + C, parcel);
    }

    public /* synthetic */ Object createFromParcel(Parcel x0) {
        return bg(x0);
    }

    public ValuesRemovedDetails[] ct(int i) {
        return new ValuesRemovedDetails[i];
    }

    public /* synthetic */ Object[] newArray(int x0) {
        return ct(x0);
    }
}
