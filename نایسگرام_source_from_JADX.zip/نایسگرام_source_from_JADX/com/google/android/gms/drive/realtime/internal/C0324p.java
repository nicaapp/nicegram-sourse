package com.google.android.gms.drive.realtime.internal;

import android.os.Parcel;
import android.os.Parcelable.Creator;
import com.google.android.gms.common.internal.safeparcel.C0242a;
import com.google.android.gms.common.internal.safeparcel.C0242a.C0241a;
import com.google.android.gms.common.internal.safeparcel.C0243b;
import com.google.android.gms.drive.events.CompletionEvent;
import com.google.android.gms.games.quest.Quest;
import com.google.android.gms.location.DetectedActivity;
import com.googlecode.mp4parser.boxes.microsoft.XtraBox;
import org.telegram.android.support.widget.helper.ItemTouchHelper;
import org.telegram.android.time.FastDatePrinter;

/* renamed from: com.google.android.gms.drive.realtime.internal.p */
public class C0324p implements Creator<ParcelableCollaborator> {
    static void m579a(ParcelableCollaborator parcelableCollaborator, Parcel parcel, int i) {
        int D = C0243b.m329D(parcel);
        C0243b.m356c(parcel, 1, parcelableCollaborator.BR);
        C0243b.m347a(parcel, 2, parcelableCollaborator.Rk);
        C0243b.m347a(parcel, 3, parcelableCollaborator.Rl);
        C0243b.m344a(parcel, 4, parcelableCollaborator.vL, false);
        C0243b.m344a(parcel, 5, parcelableCollaborator.Rm, false);
        C0243b.m344a(parcel, 6, parcelableCollaborator.NH, false);
        C0243b.m344a(parcel, 7, parcelableCollaborator.Rn, false);
        C0243b.m344a(parcel, 8, parcelableCollaborator.Ro, false);
        C0243b.m332H(parcel, D);
    }

    public ParcelableCollaborator aW(Parcel parcel) {
        boolean z = false;
        String str = null;
        int C = C0242a.m293C(parcel);
        String str2 = null;
        String str3 = null;
        String str4 = null;
        String str5 = null;
        boolean z2 = false;
        int i = 0;
        while (parcel.dataPosition() < C) {
            int B = C0242a.m291B(parcel);
            switch (C0242a.aD(B)) {
                case CompletionEvent.STATUS_FAILURE /*1*/:
                    i = C0242a.m309g(parcel, B);
                    break;
                case CompletionEvent.STATUS_CONFLICT /*2*/:
                    z2 = C0242a.m305c(parcel, B);
                    break;
                case FastDatePrinter.SHORT /*3*/:
                    z = C0242a.m305c(parcel, B);
                    break;
                case ItemTouchHelper.LEFT /*4*/:
                    str5 = C0242a.m317o(parcel, B);
                    break;
                case DetectedActivity.TILTING /*5*/:
                    str4 = C0242a.m317o(parcel, B);
                    break;
                case Quest.STATE_FAILED /*6*/:
                    str3 = C0242a.m317o(parcel, B);
                    break;
                case DetectedActivity.WALKING /*7*/:
                    str2 = C0242a.m317o(parcel, B);
                    break;
                case XtraBox.MP4_XTRA_BT_UNICODE /*8*/:
                    str = C0242a.m317o(parcel, B);
                    break;
                default:
                    C0242a.m302b(parcel, B);
                    break;
            }
        }
        if (parcel.dataPosition() == C) {
            return new ParcelableCollaborator(i, z2, z, str5, str4, str3, str2, str);
        }
        throw new C0241a("Overread allowed size end=" + C, parcel);
    }

    public ParcelableCollaborator[] cj(int i) {
        return new ParcelableCollaborator[i];
    }

    public /* synthetic */ Object createFromParcel(Parcel x0) {
        return aW(x0);
    }

    public /* synthetic */ Object[] newArray(int x0) {
        return cj(x0);
    }
}
