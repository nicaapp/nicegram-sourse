package com.google.android.gms.drive.realtime.internal;

import android.os.Binder;
import android.os.IBinder;
import android.os.IInterface;
import android.os.Parcel;
import android.os.RemoteException;
import android.support.v4.view.MotionEventCompat;
import com.google.android.gms.common.data.DataHolder;
import com.google.android.gms.drive.events.CompletionEvent;
import com.google.android.gms.drive.realtime.internal.C0301c.C1732a;
import com.google.android.gms.drive.realtime.internal.C0302d.C1734a;
import com.google.android.gms.drive.realtime.internal.C0303e.C1736a;
import com.google.android.gms.drive.realtime.internal.C0314f.C1738a;
import com.google.android.gms.drive.realtime.internal.C0315g.C1740a;
import com.google.android.gms.drive.realtime.internal.C0316h.C1742a;
import com.google.android.gms.drive.realtime.internal.C0317i.C1744a;
import com.google.android.gms.drive.realtime.internal.C0318j.C1746a;
import com.google.android.gms.drive.realtime.internal.C0319k.C1748a;
import com.google.android.gms.drive.realtime.internal.C0320l.C1750a;
import com.google.android.gms.drive.realtime.internal.C0322n.C1754a;
import com.google.android.gms.drive.realtime.internal.C0323o.C1756a;
import com.google.android.gms.games.quest.Quest;
import com.google.android.gms.location.DetectedActivity;
import com.googlecode.mp4parser.authoring.tracks.h265.NalUnitTypes;
import com.googlecode.mp4parser.boxes.microsoft.XtraBox;
import org.telegram.C0811R;
import org.telegram.android.SecretChatHelper;
import org.telegram.android.support.widget.helper.ItemTouchHelper;
import org.telegram.android.time.FastDatePrinter;
import org.telegram.messenger.TLRPC;

/* renamed from: com.google.android.gms.drive.realtime.internal.m */
public interface C0321m extends IInterface {

    /* renamed from: com.google.android.gms.drive.realtime.internal.m.a */
    public static abstract class C1752a extends Binder implements C0321m {

        /* renamed from: com.google.android.gms.drive.realtime.internal.m.a.a */
        private static class C1751a implements C0321m {
            private IBinder lb;

            C1751a(IBinder iBinder) {
                this.lb = iBinder;
            }

            public void m2621a(int i, C0318j c0318j) throws RemoteException {
                Parcel obtain = Parcel.obtain();
                Parcel obtain2 = Parcel.obtain();
                try {
                    obtain.writeInterfaceToken("com.google.android.gms.drive.realtime.internal.IRealtimeService");
                    obtain.writeInt(i);
                    obtain.writeStrongBinder(c0318j != null ? c0318j.asBinder() : null);
                    this.lb.transact(30, obtain, obtain2, 0);
                    obtain2.readException();
                } finally {
                    obtain2.recycle();
                    obtain.recycle();
                }
            }

            public void m2622a(BeginCompoundOperationRequest beginCompoundOperationRequest, C0323o c0323o) throws RemoteException {
                Parcel obtain = Parcel.obtain();
                Parcel obtain2 = Parcel.obtain();
                try {
                    obtain.writeInterfaceToken("com.google.android.gms.drive.realtime.internal.IRealtimeService");
                    if (beginCompoundOperationRequest != null) {
                        obtain.writeInt(1);
                        beginCompoundOperationRequest.writeToParcel(obtain, 0);
                    } else {
                        obtain.writeInt(0);
                    }
                    obtain.writeStrongBinder(c0323o != null ? c0323o.asBinder() : null);
                    this.lb.transact(18, obtain, obtain2, 0);
                    obtain2.readException();
                } finally {
                    obtain2.recycle();
                    obtain.recycle();
                }
            }

            public void m2623a(EndCompoundOperationRequest endCompoundOperationRequest, C0318j c0318j) throws RemoteException {
                Parcel obtain = Parcel.obtain();
                Parcel obtain2 = Parcel.obtain();
                try {
                    obtain.writeInterfaceToken("com.google.android.gms.drive.realtime.internal.IRealtimeService");
                    if (endCompoundOperationRequest != null) {
                        obtain.writeInt(1);
                        endCompoundOperationRequest.writeToParcel(obtain, 0);
                    } else {
                        obtain.writeInt(0);
                    }
                    obtain.writeStrongBinder(c0318j != null ? c0318j.asBinder() : null);
                    this.lb.transact(41, obtain, obtain2, 0);
                    obtain2.readException();
                } finally {
                    obtain2.recycle();
                    obtain.recycle();
                }
            }

            public void m2624a(EndCompoundOperationRequest endCompoundOperationRequest, C0323o c0323o) throws RemoteException {
                Parcel obtain = Parcel.obtain();
                Parcel obtain2 = Parcel.obtain();
                try {
                    obtain.writeInterfaceToken("com.google.android.gms.drive.realtime.internal.IRealtimeService");
                    if (endCompoundOperationRequest != null) {
                        obtain.writeInt(1);
                        endCompoundOperationRequest.writeToParcel(obtain, 0);
                    } else {
                        obtain.writeInt(0);
                    }
                    obtain.writeStrongBinder(c0323o != null ? c0323o.asBinder() : null);
                    this.lb.transact(19, obtain, obtain2, 0);
                    obtain2.readException();
                } finally {
                    obtain2.recycle();
                    obtain.recycle();
                }
            }

            public void m2625a(ParcelableIndexReference parcelableIndexReference, C0322n c0322n) throws RemoteException {
                Parcel obtain = Parcel.obtain();
                Parcel obtain2 = Parcel.obtain();
                try {
                    obtain.writeInterfaceToken("com.google.android.gms.drive.realtime.internal.IRealtimeService");
                    if (parcelableIndexReference != null) {
                        obtain.writeInt(1);
                        parcelableIndexReference.writeToParcel(obtain, 0);
                    } else {
                        obtain.writeInt(0);
                    }
                    obtain.writeStrongBinder(c0322n != null ? c0322n.asBinder() : null);
                    this.lb.transact(26, obtain, obtain2, 0);
                    obtain2.readException();
                } finally {
                    obtain2.recycle();
                    obtain.recycle();
                }
            }

            public void m2626a(C0301c c0301c) throws RemoteException {
                Parcel obtain = Parcel.obtain();
                Parcel obtain2 = Parcel.obtain();
                try {
                    obtain.writeInterfaceToken("com.google.android.gms.drive.realtime.internal.IRealtimeService");
                    obtain.writeStrongBinder(c0301c != null ? c0301c.asBinder() : null);
                    this.lb.transact(2, obtain, obtain2, 0);
                    obtain2.readException();
                } finally {
                    obtain2.recycle();
                    obtain.recycle();
                }
            }

            public void m2627a(C0302d c0302d) throws RemoteException {
                Parcel obtain = Parcel.obtain();
                Parcel obtain2 = Parcel.obtain();
                try {
                    obtain.writeInterfaceToken("com.google.android.gms.drive.realtime.internal.IRealtimeService");
                    obtain.writeStrongBinder(c0302d != null ? c0302d.asBinder() : null);
                    this.lb.transact(32, obtain, obtain2, 0);
                    obtain2.readException();
                } finally {
                    obtain2.recycle();
                    obtain.recycle();
                }
            }

            public void m2628a(C0303e c0303e) throws RemoteException {
                Parcel obtain = Parcel.obtain();
                Parcel obtain2 = Parcel.obtain();
                try {
                    obtain.writeInterfaceToken("com.google.android.gms.drive.realtime.internal.IRealtimeService");
                    obtain.writeStrongBinder(c0303e != null ? c0303e.asBinder() : null);
                    this.lb.transact(31, obtain, obtain2, 0);
                    obtain2.readException();
                } finally {
                    obtain2.recycle();
                    obtain.recycle();
                }
            }

            public void m2629a(C0316h c0316h) throws RemoteException {
                Parcel obtain = Parcel.obtain();
                Parcel obtain2 = Parcel.obtain();
                try {
                    obtain.writeInterfaceToken("com.google.android.gms.drive.realtime.internal.IRealtimeService");
                    obtain.writeStrongBinder(c0316h != null ? c0316h.asBinder() : null);
                    this.lb.transact(36, obtain, obtain2, 0);
                    obtain2.readException();
                } finally {
                    obtain2.recycle();
                    obtain.recycle();
                }
            }

            public void m2630a(C0317i c0317i) throws RemoteException {
                Parcel obtain = Parcel.obtain();
                Parcel obtain2 = Parcel.obtain();
                try {
                    obtain.writeInterfaceToken("com.google.android.gms.drive.realtime.internal.IRealtimeService");
                    obtain.writeStrongBinder(c0317i != null ? c0317i.asBinder() : null);
                    this.lb.transact(34, obtain, obtain2, 0);
                    obtain2.readException();
                } finally {
                    obtain2.recycle();
                    obtain.recycle();
                }
            }

            public void m2631a(C0318j c0318j) throws RemoteException {
                Parcel obtain = Parcel.obtain();
                Parcel obtain2 = Parcel.obtain();
                try {
                    obtain.writeInterfaceToken("com.google.android.gms.drive.realtime.internal.IRealtimeService");
                    obtain.writeStrongBinder(c0318j != null ? c0318j.asBinder() : null);
                    this.lb.transact(22, obtain, obtain2, 0);
                    obtain2.readException();
                } finally {
                    obtain2.recycle();
                    obtain.recycle();
                }
            }

            public void m2632a(C0320l c0320l) throws RemoteException {
                Parcel obtain = Parcel.obtain();
                Parcel obtain2 = Parcel.obtain();
                try {
                    obtain.writeInterfaceToken("com.google.android.gms.drive.realtime.internal.IRealtimeService");
                    obtain.writeStrongBinder(c0320l != null ? c0320l.asBinder() : null);
                    this.lb.transact(40, obtain, obtain2, 0);
                    obtain2.readException();
                } finally {
                    obtain2.recycle();
                    obtain.recycle();
                }
            }

            public void m2633a(C0323o c0323o) throws RemoteException {
                Parcel obtain = Parcel.obtain();
                Parcel obtain2 = Parcel.obtain();
                try {
                    obtain.writeInterfaceToken("com.google.android.gms.drive.realtime.internal.IRealtimeService");
                    obtain.writeStrongBinder(c0323o != null ? c0323o.asBinder() : null);
                    this.lb.transact(3, obtain, obtain2, 0);
                    obtain2.readException();
                } finally {
                    obtain2.recycle();
                    obtain.recycle();
                }
            }

            public void m2634a(String str, int i, int i2, C0315g c0315g) throws RemoteException {
                Parcel obtain = Parcel.obtain();
                Parcel obtain2 = Parcel.obtain();
                try {
                    obtain.writeInterfaceToken("com.google.android.gms.drive.realtime.internal.IRealtimeService");
                    obtain.writeString(str);
                    obtain.writeInt(i);
                    obtain.writeInt(i2);
                    obtain.writeStrongBinder(c0315g != null ? c0315g.asBinder() : null);
                    this.lb.transact(17, obtain, obtain2, 0);
                    obtain2.readException();
                } finally {
                    obtain2.recycle();
                    obtain.recycle();
                }
            }

            public void m2635a(String str, int i, int i2, C0318j c0318j) throws RemoteException {
                Parcel obtain = Parcel.obtain();
                Parcel obtain2 = Parcel.obtain();
                try {
                    obtain.writeInterfaceToken("com.google.android.gms.drive.realtime.internal.IRealtimeService");
                    obtain.writeString(str);
                    obtain.writeInt(i);
                    obtain.writeInt(i2);
                    obtain.writeStrongBinder(c0318j != null ? c0318j.asBinder() : null);
                    this.lb.transact(11, obtain, obtain2, 0);
                    obtain2.readException();
                } finally {
                    obtain2.recycle();
                    obtain.recycle();
                }
            }

            public void m2636a(String str, int i, DataHolder dataHolder, C0315g c0315g) throws RemoteException {
                Parcel obtain = Parcel.obtain();
                Parcel obtain2 = Parcel.obtain();
                try {
                    obtain.writeInterfaceToken("com.google.android.gms.drive.realtime.internal.IRealtimeService");
                    obtain.writeString(str);
                    obtain.writeInt(i);
                    if (dataHolder != null) {
                        obtain.writeInt(1);
                        dataHolder.writeToParcel(obtain, 0);
                    } else {
                        obtain.writeInt(0);
                    }
                    obtain.writeStrongBinder(c0315g != null ? c0315g.asBinder() : null);
                    this.lb.transact(16, obtain, obtain2, 0);
                    obtain2.readException();
                } finally {
                    obtain2.recycle();
                    obtain.recycle();
                }
            }

            public void m2637a(String str, int i, DataHolder dataHolder, C0318j c0318j) throws RemoteException {
                Parcel obtain = Parcel.obtain();
                Parcel obtain2 = Parcel.obtain();
                try {
                    obtain.writeInterfaceToken("com.google.android.gms.drive.realtime.internal.IRealtimeService");
                    obtain.writeString(str);
                    obtain.writeInt(i);
                    if (dataHolder != null) {
                        obtain.writeInt(1);
                        dataHolder.writeToParcel(obtain, 0);
                    } else {
                        obtain.writeInt(0);
                    }
                    obtain.writeStrongBinder(c0318j != null ? c0318j.asBinder() : null);
                    this.lb.transact(15, obtain, obtain2, 0);
                    obtain2.readException();
                } finally {
                    obtain2.recycle();
                    obtain.recycle();
                }
            }

            public void m2638a(String str, int i, C0323o c0323o) throws RemoteException {
                Parcel obtain = Parcel.obtain();
                Parcel obtain2 = Parcel.obtain();
                try {
                    obtain.writeInterfaceToken("com.google.android.gms.drive.realtime.internal.IRealtimeService");
                    obtain.writeString(str);
                    obtain.writeInt(i);
                    obtain.writeStrongBinder(c0323o != null ? c0323o.asBinder() : null);
                    this.lb.transact(28, obtain, obtain2, 0);
                    obtain2.readException();
                } finally {
                    obtain2.recycle();
                    obtain.recycle();
                }
            }

            public void m2639a(String str, int i, String str2, int i2, C0318j c0318j) throws RemoteException {
                Parcel obtain = Parcel.obtain();
                Parcel obtain2 = Parcel.obtain();
                try {
                    obtain.writeInterfaceToken("com.google.android.gms.drive.realtime.internal.IRealtimeService");
                    obtain.writeString(str);
                    obtain.writeInt(i);
                    obtain.writeString(str2);
                    obtain.writeInt(i2);
                    obtain.writeStrongBinder(c0318j != null ? c0318j.asBinder() : null);
                    this.lb.transact(37, obtain, obtain2, 0);
                    obtain2.readException();
                } finally {
                    obtain2.recycle();
                    obtain.recycle();
                }
            }

            public void m2640a(String str, int i, String str2, C0318j c0318j) throws RemoteException {
                Parcel obtain = Parcel.obtain();
                Parcel obtain2 = Parcel.obtain();
                try {
                    obtain.writeInterfaceToken("com.google.android.gms.drive.realtime.internal.IRealtimeService");
                    obtain.writeString(str);
                    obtain.writeInt(i);
                    obtain.writeString(str2);
                    obtain.writeStrongBinder(c0318j != null ? c0318j.asBinder() : null);
                    this.lb.transact(10, obtain, obtain2, 0);
                    obtain2.readException();
                } finally {
                    obtain2.recycle();
                    obtain.recycle();
                }
            }

            public void m2641a(String str, DataHolder dataHolder, C0318j c0318j) throws RemoteException {
                Parcel obtain = Parcel.obtain();
                Parcel obtain2 = Parcel.obtain();
                try {
                    obtain.writeInterfaceToken("com.google.android.gms.drive.realtime.internal.IRealtimeService");
                    obtain.writeString(str);
                    if (dataHolder != null) {
                        obtain.writeInt(1);
                        dataHolder.writeToParcel(obtain, 0);
                    } else {
                        obtain.writeInt(0);
                    }
                    obtain.writeStrongBinder(c0318j != null ? c0318j.asBinder() : null);
                    this.lb.transact(6, obtain, obtain2, 0);
                    obtain2.readException();
                } finally {
                    obtain2.recycle();
                    obtain.recycle();
                }
            }

            public void m2642a(String str, C0314f c0314f) throws RemoteException {
                Parcel obtain = Parcel.obtain();
                Parcel obtain2 = Parcel.obtain();
                try {
                    obtain.writeInterfaceToken("com.google.android.gms.drive.realtime.internal.IRealtimeService");
                    obtain.writeString(str);
                    obtain.writeStrongBinder(c0314f != null ? c0314f.asBinder() : null);
                    this.lb.transact(20, obtain, obtain2, 0);
                    obtain2.readException();
                } finally {
                    obtain2.recycle();
                    obtain.recycle();
                }
            }

            public void m2643a(String str, C0318j c0318j) throws RemoteException {
                Parcel obtain = Parcel.obtain();
                Parcel obtain2 = Parcel.obtain();
                try {
                    obtain.writeInterfaceToken("com.google.android.gms.drive.realtime.internal.IRealtimeService");
                    obtain.writeString(str);
                    obtain.writeStrongBinder(c0318j != null ? c0318j.asBinder() : null);
                    this.lb.transact(7, obtain, obtain2, 0);
                    obtain2.readException();
                } finally {
                    obtain2.recycle();
                    obtain.recycle();
                }
            }

            public void m2644a(String str, C0319k c0319k) throws RemoteException {
                Parcel obtain = Parcel.obtain();
                Parcel obtain2 = Parcel.obtain();
                try {
                    obtain.writeInterfaceToken("com.google.android.gms.drive.realtime.internal.IRealtimeService");
                    obtain.writeString(str);
                    obtain.writeStrongBinder(c0319k != null ? c0319k.asBinder() : null);
                    this.lb.transact(27, obtain, obtain2, 0);
                    obtain2.readException();
                } finally {
                    obtain2.recycle();
                    obtain.recycle();
                }
            }

            public void m2645a(String str, C0320l c0320l) throws RemoteException {
                Parcel obtain = Parcel.obtain();
                Parcel obtain2 = Parcel.obtain();
                try {
                    obtain.writeInterfaceToken("com.google.android.gms.drive.realtime.internal.IRealtimeService");
                    obtain.writeString(str);
                    obtain.writeStrongBinder(c0320l != null ? c0320l.asBinder() : null);
                    this.lb.transact(5, obtain, obtain2, 0);
                    obtain2.readException();
                } finally {
                    obtain2.recycle();
                    obtain.recycle();
                }
            }

            public void m2646a(String str, C0322n c0322n) throws RemoteException {
                Parcel obtain = Parcel.obtain();
                Parcel obtain2 = Parcel.obtain();
                try {
                    obtain.writeInterfaceToken("com.google.android.gms.drive.realtime.internal.IRealtimeService");
                    obtain.writeString(str);
                    obtain.writeStrongBinder(c0322n != null ? c0322n.asBinder() : null);
                    this.lb.transact(1, obtain, obtain2, 0);
                    obtain2.readException();
                } finally {
                    obtain2.recycle();
                    obtain.recycle();
                }
            }

            public void m2647a(String str, C0323o c0323o) throws RemoteException {
                Parcel obtain = Parcel.obtain();
                Parcel obtain2 = Parcel.obtain();
                try {
                    obtain.writeInterfaceToken("com.google.android.gms.drive.realtime.internal.IRealtimeService");
                    obtain.writeString(str);
                    obtain.writeStrongBinder(c0323o != null ? c0323o.asBinder() : null);
                    this.lb.transact(38, obtain, obtain2, 0);
                    obtain2.readException();
                } finally {
                    obtain2.recycle();
                    obtain.recycle();
                }
            }

            public void m2648a(String str, String str2, C0314f c0314f) throws RemoteException {
                Parcel obtain = Parcel.obtain();
                Parcel obtain2 = Parcel.obtain();
                try {
                    obtain.writeInterfaceToken("com.google.android.gms.drive.realtime.internal.IRealtimeService");
                    obtain.writeString(str);
                    obtain.writeString(str2);
                    obtain.writeStrongBinder(c0314f != null ? c0314f.asBinder() : null);
                    this.lb.transact(4, obtain, obtain2, 0);
                    obtain2.readException();
                } finally {
                    obtain2.recycle();
                    obtain.recycle();
                }
            }

            public void m2649a(String str, String str2, C0315g c0315g) throws RemoteException {
                Parcel obtain = Parcel.obtain();
                Parcel obtain2 = Parcel.obtain();
                try {
                    obtain.writeInterfaceToken("com.google.android.gms.drive.realtime.internal.IRealtimeService");
                    obtain.writeString(str);
                    obtain.writeString(str2);
                    obtain.writeStrongBinder(c0315g != null ? c0315g.asBinder() : null);
                    this.lb.transact(21, obtain, obtain2, 0);
                    obtain2.readException();
                } finally {
                    obtain2.recycle();
                    obtain.recycle();
                }
            }

            public void m2650a(String str, String str2, C0318j c0318j) throws RemoteException {
                Parcel obtain = Parcel.obtain();
                Parcel obtain2 = Parcel.obtain();
                try {
                    obtain.writeInterfaceToken("com.google.android.gms.drive.realtime.internal.IRealtimeService");
                    obtain.writeString(str);
                    obtain.writeString(str2);
                    obtain.writeStrongBinder(c0318j != null ? c0318j.asBinder() : null);
                    this.lb.transact(12, obtain, obtain2, 0);
                    obtain2.readException();
                } finally {
                    obtain2.recycle();
                    obtain.recycle();
                }
            }

            public IBinder asBinder() {
                return this.lb;
            }

            public void m2651b(C0301c c0301c) throws RemoteException {
                Parcel obtain = Parcel.obtain();
                Parcel obtain2 = Parcel.obtain();
                try {
                    obtain.writeInterfaceToken("com.google.android.gms.drive.realtime.internal.IRealtimeService");
                    obtain.writeStrongBinder(c0301c != null ? c0301c.asBinder() : null);
                    this.lb.transact(33, obtain, obtain2, 0);
                    obtain2.readException();
                } finally {
                    obtain2.recycle();
                    obtain.recycle();
                }
            }

            public void m2652b(C0318j c0318j) throws RemoteException {
                Parcel obtain = Parcel.obtain();
                Parcel obtain2 = Parcel.obtain();
                try {
                    obtain.writeInterfaceToken("com.google.android.gms.drive.realtime.internal.IRealtimeService");
                    obtain.writeStrongBinder(c0318j != null ? c0318j.asBinder() : null);
                    this.lb.transact(23, obtain, obtain2, 0);
                    obtain2.readException();
                } finally {
                    obtain2.recycle();
                    obtain.recycle();
                }
            }

            public void m2653b(C0320l c0320l) throws RemoteException {
                Parcel obtain = Parcel.obtain();
                Parcel obtain2 = Parcel.obtain();
                try {
                    obtain.writeInterfaceToken("com.google.android.gms.drive.realtime.internal.IRealtimeService");
                    obtain.writeStrongBinder(c0320l != null ? c0320l.asBinder() : null);
                    this.lb.transact(29, obtain, obtain2, 0);
                    obtain2.readException();
                } finally {
                    obtain2.recycle();
                    obtain.recycle();
                }
            }

            public void m2654b(C0323o c0323o) throws RemoteException {
                Parcel obtain = Parcel.obtain();
                Parcel obtain2 = Parcel.obtain();
                try {
                    obtain.writeInterfaceToken("com.google.android.gms.drive.realtime.internal.IRealtimeService");
                    obtain.writeStrongBinder(c0323o != null ? c0323o.asBinder() : null);
                    this.lb.transact(35, obtain, obtain2, 0);
                    obtain2.readException();
                } finally {
                    obtain2.recycle();
                    obtain.recycle();
                }
            }

            public void m2655b(String str, C0314f c0314f) throws RemoteException {
                Parcel obtain = Parcel.obtain();
                Parcel obtain2 = Parcel.obtain();
                try {
                    obtain.writeInterfaceToken("com.google.android.gms.drive.realtime.internal.IRealtimeService");
                    obtain.writeString(str);
                    obtain.writeStrongBinder(c0314f != null ? c0314f.asBinder() : null);
                    this.lb.transact(13, obtain, obtain2, 0);
                    obtain2.readException();
                } finally {
                    obtain2.recycle();
                    obtain.recycle();
                }
            }

            public void m2656b(String str, C0320l c0320l) throws RemoteException {
                Parcel obtain = Parcel.obtain();
                Parcel obtain2 = Parcel.obtain();
                try {
                    obtain.writeInterfaceToken("com.google.android.gms.drive.realtime.internal.IRealtimeService");
                    obtain.writeString(str);
                    obtain.writeStrongBinder(c0320l != null ? c0320l.asBinder() : null);
                    this.lb.transact(8, obtain, obtain2, 0);
                    obtain2.readException();
                } finally {
                    obtain2.recycle();
                    obtain.recycle();
                }
            }

            public void m2657b(String str, C0322n c0322n) throws RemoteException {
                Parcel obtain = Parcel.obtain();
                Parcel obtain2 = Parcel.obtain();
                try {
                    obtain.writeInterfaceToken("com.google.android.gms.drive.realtime.internal.IRealtimeService");
                    obtain.writeString(str);
                    obtain.writeStrongBinder(c0322n != null ? c0322n.asBinder() : null);
                    this.lb.transact(9, obtain, obtain2, 0);
                    obtain2.readException();
                } finally {
                    obtain2.recycle();
                    obtain.recycle();
                }
            }

            public void m2658b(String str, C0323o c0323o) throws RemoteException {
                Parcel obtain = Parcel.obtain();
                Parcel obtain2 = Parcel.obtain();
                try {
                    obtain.writeInterfaceToken("com.google.android.gms.drive.realtime.internal.IRealtimeService");
                    obtain.writeString(str);
                    obtain.writeStrongBinder(c0323o != null ? c0323o.asBinder() : null);
                    this.lb.transact(39, obtain, obtain2, 0);
                    obtain2.readException();
                } finally {
                    obtain2.recycle();
                    obtain.recycle();
                }
            }

            public void m2659c(C0301c c0301c) throws RemoteException {
                Parcel obtain = Parcel.obtain();
                Parcel obtain2 = Parcel.obtain();
                try {
                    obtain.writeInterfaceToken("com.google.android.gms.drive.realtime.internal.IRealtimeService");
                    obtain.writeStrongBinder(c0301c != null ? c0301c.asBinder() : null);
                    this.lb.transact(24, obtain, obtain2, 0);
                    obtain2.readException();
                } finally {
                    obtain2.recycle();
                    obtain.recycle();
                }
            }

            public void m2660c(String str, C0320l c0320l) throws RemoteException {
                Parcel obtain = Parcel.obtain();
                Parcel obtain2 = Parcel.obtain();
                try {
                    obtain.writeInterfaceToken("com.google.android.gms.drive.realtime.internal.IRealtimeService");
                    obtain.writeString(str);
                    obtain.writeStrongBinder(c0320l != null ? c0320l.asBinder() : null);
                    this.lb.transact(14, obtain, obtain2, 0);
                    obtain2.readException();
                } finally {
                    obtain2.recycle();
                    obtain.recycle();
                }
            }

            public void m2661d(C0301c c0301c) throws RemoteException {
                Parcel obtain = Parcel.obtain();
                Parcel obtain2 = Parcel.obtain();
                try {
                    obtain.writeInterfaceToken("com.google.android.gms.drive.realtime.internal.IRealtimeService");
                    obtain.writeStrongBinder(c0301c != null ? c0301c.asBinder() : null);
                    this.lb.transact(25, obtain, obtain2, 0);
                    obtain2.readException();
                } finally {
                    obtain2.recycle();
                    obtain.recycle();
                }
            }
        }

        public static C0321m ai(IBinder iBinder) {
            if (iBinder == null) {
                return null;
            }
            IInterface queryLocalInterface = iBinder.queryLocalInterface("com.google.android.gms.drive.realtime.internal.IRealtimeService");
            return (queryLocalInterface == null || !(queryLocalInterface instanceof C0321m)) ? new C1751a(iBinder) : (C0321m) queryLocalInterface;
        }

        public boolean onTransact(int code, Parcel data, Parcel reply, int flags) throws RemoteException {
            EndCompoundOperationRequest endCompoundOperationRequest = null;
            String readString;
            DataHolder z;
            int readInt;
            switch (code) {
                case CompletionEvent.STATUS_FAILURE /*1*/:
                    data.enforceInterface("com.google.android.gms.drive.realtime.internal.IRealtimeService");
                    m561a(data.readString(), C1754a.aj(data.readStrongBinder()));
                    reply.writeNoException();
                    return true;
                case CompletionEvent.STATUS_CONFLICT /*2*/:
                    data.enforceInterface("com.google.android.gms.drive.realtime.internal.IRealtimeService");
                    m541a(C1732a.m2604Y(data.readStrongBinder()));
                    reply.writeNoException();
                    return true;
                case FastDatePrinter.SHORT /*3*/:
                    data.enforceInterface("com.google.android.gms.drive.realtime.internal.IRealtimeService");
                    m548a(C1756a.ak(data.readStrongBinder()));
                    reply.writeNoException();
                    return true;
                case ItemTouchHelper.LEFT /*4*/:
                    data.enforceInterface("com.google.android.gms.drive.realtime.internal.IRealtimeService");
                    m563a(data.readString(), data.readString(), C1738a.ab(data.readStrongBinder()));
                    reply.writeNoException();
                    return true;
                case DetectedActivity.TILTING /*5*/:
                    data.enforceInterface("com.google.android.gms.drive.realtime.internal.IRealtimeService");
                    m560a(data.readString(), C1750a.ah(data.readStrongBinder()));
                    reply.writeNoException();
                    return true;
                case Quest.STATE_FAILED /*6*/:
                    data.enforceInterface("com.google.android.gms.drive.realtime.internal.IRealtimeService");
                    readString = data.readString();
                    if (data.readInt() != 0) {
                        z = DataHolder.CREATOR.m173z(data);
                    }
                    m556a(readString, z, C1746a.af(data.readStrongBinder()));
                    reply.writeNoException();
                    return true;
                case DetectedActivity.WALKING /*7*/:
                    data.enforceInterface("com.google.android.gms.drive.realtime.internal.IRealtimeService");
                    m558a(data.readString(), C1746a.af(data.readStrongBinder()));
                    reply.writeNoException();
                    return true;
                case XtraBox.MP4_XTRA_BT_UNICODE /*8*/:
                    data.enforceInterface("com.google.android.gms.drive.realtime.internal.IRealtimeService");
                    m571b(data.readString(), C1750a.ah(data.readStrongBinder()));
                    reply.writeNoException();
                    return true;
                case C0811R.styleable.WalletFragmentStyle_maskedWalletDetailsLogoTextColor /*9*/:
                    data.enforceInterface("com.google.android.gms.drive.realtime.internal.IRealtimeService");
                    m572b(data.readString(), C1754a.aj(data.readStrongBinder()));
                    reply.writeNoException();
                    return true;
                case C0811R.styleable.WalletFragmentStyle_maskedWalletDetailsLogoImageType /*10*/:
                    data.enforceInterface("com.google.android.gms.drive.realtime.internal.IRealtimeService");
                    m555a(data.readString(), data.readInt(), data.readString(), C1746a.af(data.readStrongBinder()));
                    reply.writeNoException();
                    return true;
                case C0811R.styleable.MapAttrs_uiZoomGestures /*11*/:
                    data.enforceInterface("com.google.android.gms.drive.realtime.internal.IRealtimeService");
                    m550a(data.readString(), data.readInt(), data.readInt(), C1746a.af(data.readStrongBinder()));
                    reply.writeNoException();
                    return true;
                case C0811R.styleable.MapAttrs_useViewLifecycle /*12*/:
                    data.enforceInterface("com.google.android.gms.drive.realtime.internal.IRealtimeService");
                    m565a(data.readString(), data.readString(), C1746a.af(data.readStrongBinder()));
                    reply.writeNoException();
                    return true;
                case C0811R.styleable.MapAttrs_zOrderOnTop /*13*/:
                    data.enforceInterface("com.google.android.gms.drive.realtime.internal.IRealtimeService");
                    m570b(data.readString(), C1738a.ab(data.readStrongBinder()));
                    reply.writeNoException();
                    return true;
                case NalUnitTypes.NAL_TYPE_RSV_VCL_N14 /*14*/:
                    data.enforceInterface("com.google.android.gms.drive.realtime.internal.IRealtimeService");
                    m575c(data.readString(), C1750a.ah(data.readStrongBinder()));
                    reply.writeNoException();
                    return true;
                case NalUnitTypes.NAL_TYPE_RSV_VCL_R15 /*15*/:
                    data.enforceInterface("com.google.android.gms.drive.realtime.internal.IRealtimeService");
                    readString = data.readString();
                    readInt = data.readInt();
                    if (data.readInt() != 0) {
                        z = DataHolder.CREATOR.m173z(data);
                    }
                    m552a(readString, readInt, z, C1746a.af(data.readStrongBinder()));
                    reply.writeNoException();
                    return true;
                case ItemTouchHelper.START /*16*/:
                    data.enforceInterface("com.google.android.gms.drive.realtime.internal.IRealtimeService");
                    readString = data.readString();
                    readInt = data.readInt();
                    if (data.readInt() != 0) {
                        z = DataHolder.CREATOR.m173z(data);
                    }
                    m551a(readString, readInt, z, C1740a.ac(data.readStrongBinder()));
                    reply.writeNoException();
                    return true;
                case NalUnitTypes.NAL_TYPE_BLA_W_RADL /*17*/:
                    data.enforceInterface("com.google.android.gms.drive.realtime.internal.IRealtimeService");
                    m549a(data.readString(), data.readInt(), data.readInt(), C1740a.ac(data.readStrongBinder()));
                    reply.writeNoException();
                    return true;
                case NalUnitTypes.NAL_TYPE_BLA_N_LP /*18*/:
                    BeginCompoundOperationRequest beginCompoundOperationRequest;
                    data.enforceInterface("com.google.android.gms.drive.realtime.internal.IRealtimeService");
                    if (data.readInt() != 0) {
                        beginCompoundOperationRequest = (BeginCompoundOperationRequest) BeginCompoundOperationRequest.CREATOR.createFromParcel(data);
                    }
                    m537a(beginCompoundOperationRequest, C1756a.ak(data.readStrongBinder()));
                    reply.writeNoException();
                    return true;
                case XtraBox.MP4_XTRA_BT_INT64 /*19*/:
                    data.enforceInterface("com.google.android.gms.drive.realtime.internal.IRealtimeService");
                    if (data.readInt() != 0) {
                        endCompoundOperationRequest = (EndCompoundOperationRequest) EndCompoundOperationRequest.CREATOR.createFromParcel(data);
                    }
                    m539a(endCompoundOperationRequest, C1756a.ak(data.readStrongBinder()));
                    reply.writeNoException();
                    return true;
                case NalUnitTypes.NAL_TYPE_IDR_N_LP /*20*/:
                    data.enforceInterface("com.google.android.gms.drive.realtime.internal.IRealtimeService");
                    m557a(data.readString(), C1738a.ab(data.readStrongBinder()));
                    reply.writeNoException();
                    return true;
                case XtraBox.MP4_XTRA_BT_FILETIME /*21*/:
                    data.enforceInterface("com.google.android.gms.drive.realtime.internal.IRealtimeService");
                    m564a(data.readString(), data.readString(), C1740a.ac(data.readStrongBinder()));
                    reply.writeNoException();
                    return true;
                case NalUnitTypes.NAL_TYPE_RSV_IRAP_VCL22 /*22*/:
                    data.enforceInterface("com.google.android.gms.drive.realtime.internal.IRealtimeService");
                    m546a(C1746a.af(data.readStrongBinder()));
                    reply.writeNoException();
                    return true;
                case SecretChatHelper.CURRENT_SECRET_CHAT_LAYER /*23*/:
                    data.enforceInterface("com.google.android.gms.drive.realtime.internal.IRealtimeService");
                    m567b(C1746a.af(data.readStrongBinder()));
                    reply.writeNoException();
                    return true;
                case NalUnitTypes.NAL_TYPE_RSV_VCL24 /*24*/:
                    data.enforceInterface("com.google.android.gms.drive.realtime.internal.IRealtimeService");
                    m574c(C1732a.m2604Y(data.readStrongBinder()));
                    reply.writeNoException();
                    return true;
                case NalUnitTypes.NAL_TYPE_RSV_VCL25 /*25*/:
                    data.enforceInterface("com.google.android.gms.drive.realtime.internal.IRealtimeService");
                    m576d(C1732a.m2604Y(data.readStrongBinder()));
                    reply.writeNoException();
                    return true;
                case NalUnitTypes.NAL_TYPE_RSV_VCL26 /*26*/:
                    ParcelableIndexReference parcelableIndexReference;
                    data.enforceInterface("com.google.android.gms.drive.realtime.internal.IRealtimeService");
                    if (data.readInt() != 0) {
                        parcelableIndexReference = (ParcelableIndexReference) ParcelableIndexReference.CREATOR.createFromParcel(data);
                    }
                    m540a(parcelableIndexReference, C1754a.aj(data.readStrongBinder()));
                    reply.writeNoException();
                    return true;
                case NalUnitTypes.NAL_TYPE_RSV_VCL27 /*27*/:
                    data.enforceInterface("com.google.android.gms.drive.realtime.internal.IRealtimeService");
                    m559a(data.readString(), C1748a.ag(data.readStrongBinder()));
                    reply.writeNoException();
                    return true;
                case NalUnitTypes.NAL_TYPE_RSV_VCL28 /*28*/:
                    data.enforceInterface("com.google.android.gms.drive.realtime.internal.IRealtimeService");
                    m553a(data.readString(), data.readInt(), C1756a.ak(data.readStrongBinder()));
                    reply.writeNoException();
                    return true;
                case NalUnitTypes.NAL_TYPE_RSV_VCL29 /*29*/:
                    data.enforceInterface("com.google.android.gms.drive.realtime.internal.IRealtimeService");
                    m568b(C1750a.ah(data.readStrongBinder()));
                    reply.writeNoException();
                    return true;
                case NalUnitTypes.NAL_TYPE_RSV_VCL30 /*30*/:
                    data.enforceInterface("com.google.android.gms.drive.realtime.internal.IRealtimeService");
                    m536a(data.readInt(), C1746a.af(data.readStrongBinder()));
                    reply.writeNoException();
                    return true;
                case NalUnitTypes.NAL_TYPE_RSV_VCL31 /*31*/:
                    data.enforceInterface("com.google.android.gms.drive.realtime.internal.IRealtimeService");
                    m543a(C1736a.aa(data.readStrongBinder()));
                    reply.writeNoException();
                    return true;
                case ItemTouchHelper.END /*32*/:
                    data.enforceInterface("com.google.android.gms.drive.realtime.internal.IRealtimeService");
                    m542a(C1734a.m2607Z(data.readStrongBinder()));
                    reply.writeNoException();
                    return true;
                case NalUnitTypes.NAL_TYPE_SPS_NUT /*33*/:
                    data.enforceInterface("com.google.android.gms.drive.realtime.internal.IRealtimeService");
                    m566b(C1732a.m2604Y(data.readStrongBinder()));
                    reply.writeNoException();
                    return true;
                case TLRPC.LAYER /*34*/:
                    data.enforceInterface("com.google.android.gms.drive.realtime.internal.IRealtimeService");
                    m545a(C1744a.ae(data.readStrongBinder()));
                    reply.writeNoException();
                    return true;
                case NalUnitTypes.NAL_TYPE_AUD_NUT /*35*/:
                    data.enforceInterface("com.google.android.gms.drive.realtime.internal.IRealtimeService");
                    m569b(C1756a.ak(data.readStrongBinder()));
                    reply.writeNoException();
                    return true;
                case NalUnitTypes.NAL_TYPE_EOS_NUT /*36*/:
                    data.enforceInterface("com.google.android.gms.drive.realtime.internal.IRealtimeService");
                    m544a(C1742a.ad(data.readStrongBinder()));
                    reply.writeNoException();
                    return true;
                case NalUnitTypes.NAL_TYPE_EOB_NUT /*37*/:
                    data.enforceInterface("com.google.android.gms.drive.realtime.internal.IRealtimeService");
                    m554a(data.readString(), data.readInt(), data.readString(), data.readInt(), C1746a.af(data.readStrongBinder()));
                    reply.writeNoException();
                    return true;
                case NalUnitTypes.NAL_TYPE_FD_NUT /*38*/:
                    data.enforceInterface("com.google.android.gms.drive.realtime.internal.IRealtimeService");
                    m562a(data.readString(), C1756a.ak(data.readStrongBinder()));
                    reply.writeNoException();
                    return true;
                case NalUnitTypes.NAL_TYPE_PREFIX_SEI_NUT /*39*/:
                    data.enforceInterface("com.google.android.gms.drive.realtime.internal.IRealtimeService");
                    m573b(data.readString(), C1756a.ak(data.readStrongBinder()));
                    reply.writeNoException();
                    return true;
                case MotionEventCompat.AXIS_GENERIC_9 /*40*/:
                    data.enforceInterface("com.google.android.gms.drive.realtime.internal.IRealtimeService");
                    m547a(C1750a.ah(data.readStrongBinder()));
                    reply.writeNoException();
                    return true;
                case NalUnitTypes.NAL_TYPE_RSV_NVCL41 /*41*/:
                    data.enforceInterface("com.google.android.gms.drive.realtime.internal.IRealtimeService");
                    if (data.readInt() != 0) {
                        endCompoundOperationRequest = (EndCompoundOperationRequest) EndCompoundOperationRequest.CREATOR.createFromParcel(data);
                    }
                    m538a(endCompoundOperationRequest, C1746a.af(data.readStrongBinder()));
                    reply.writeNoException();
                    return true;
                case 1598968902:
                    reply.writeString("com.google.android.gms.drive.realtime.internal.IRealtimeService");
                    return true;
                default:
                    return super.onTransact(code, data, reply, flags);
            }
        }
    }

    void m536a(int i, C0318j c0318j) throws RemoteException;

    void m537a(BeginCompoundOperationRequest beginCompoundOperationRequest, C0323o c0323o) throws RemoteException;

    void m538a(EndCompoundOperationRequest endCompoundOperationRequest, C0318j c0318j) throws RemoteException;

    void m539a(EndCompoundOperationRequest endCompoundOperationRequest, C0323o c0323o) throws RemoteException;

    void m540a(ParcelableIndexReference parcelableIndexReference, C0322n c0322n) throws RemoteException;

    void m541a(C0301c c0301c) throws RemoteException;

    void m542a(C0302d c0302d) throws RemoteException;

    void m543a(C0303e c0303e) throws RemoteException;

    void m544a(C0316h c0316h) throws RemoteException;

    void m545a(C0317i c0317i) throws RemoteException;

    void m546a(C0318j c0318j) throws RemoteException;

    void m547a(C0320l c0320l) throws RemoteException;

    void m548a(C0323o c0323o) throws RemoteException;

    void m549a(String str, int i, int i2, C0315g c0315g) throws RemoteException;

    void m550a(String str, int i, int i2, C0318j c0318j) throws RemoteException;

    void m551a(String str, int i, DataHolder dataHolder, C0315g c0315g) throws RemoteException;

    void m552a(String str, int i, DataHolder dataHolder, C0318j c0318j) throws RemoteException;

    void m553a(String str, int i, C0323o c0323o) throws RemoteException;

    void m554a(String str, int i, String str2, int i2, C0318j c0318j) throws RemoteException;

    void m555a(String str, int i, String str2, C0318j c0318j) throws RemoteException;

    void m556a(String str, DataHolder dataHolder, C0318j c0318j) throws RemoteException;

    void m557a(String str, C0314f c0314f) throws RemoteException;

    void m558a(String str, C0318j c0318j) throws RemoteException;

    void m559a(String str, C0319k c0319k) throws RemoteException;

    void m560a(String str, C0320l c0320l) throws RemoteException;

    void m561a(String str, C0322n c0322n) throws RemoteException;

    void m562a(String str, C0323o c0323o) throws RemoteException;

    void m563a(String str, String str2, C0314f c0314f) throws RemoteException;

    void m564a(String str, String str2, C0315g c0315g) throws RemoteException;

    void m565a(String str, String str2, C0318j c0318j) throws RemoteException;

    void m566b(C0301c c0301c) throws RemoteException;

    void m567b(C0318j c0318j) throws RemoteException;

    void m568b(C0320l c0320l) throws RemoteException;

    void m569b(C0323o c0323o) throws RemoteException;

    void m570b(String str, C0314f c0314f) throws RemoteException;

    void m571b(String str, C0320l c0320l) throws RemoteException;

    void m572b(String str, C0322n c0322n) throws RemoteException;

    void m573b(String str, C0323o c0323o) throws RemoteException;

    void m574c(C0301c c0301c) throws RemoteException;

    void m575c(String str, C0320l c0320l) throws RemoteException;

    void m576d(C0301c c0301c) throws RemoteException;
}
