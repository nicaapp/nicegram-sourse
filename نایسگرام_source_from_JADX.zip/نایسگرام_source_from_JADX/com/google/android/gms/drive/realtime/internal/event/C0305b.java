package com.google.android.gms.drive.realtime.internal.event;

import android.os.Parcel;
import android.os.Parcelable.Creator;
import com.google.android.gms.common.internal.safeparcel.C0242a;
import com.google.android.gms.common.internal.safeparcel.C0242a.C0241a;
import com.google.android.gms.common.internal.safeparcel.C0243b;
import com.google.android.gms.drive.events.CompletionEvent;
import com.google.android.gms.games.quest.Quest;
import com.google.android.gms.location.DetectedActivity;
import com.googlecode.mp4parser.authoring.tracks.h265.NalUnitTypes;
import com.googlecode.mp4parser.boxes.microsoft.XtraBox;
import java.util.List;
import org.telegram.C0811R;
import org.telegram.android.support.widget.helper.ItemTouchHelper;
import org.telegram.android.time.FastDatePrinter;

/* renamed from: com.google.android.gms.drive.realtime.internal.event.b */
public class C0305b implements Creator<ParcelableEvent> {
    static void m516a(ParcelableEvent parcelableEvent, Parcel parcel, int i) {
        int D = C0243b.m329D(parcel);
        C0243b.m356c(parcel, 1, parcelableEvent.BR);
        C0243b.m344a(parcel, 2, parcelableEvent.vL, false);
        C0243b.m344a(parcel, 3, parcelableEvent.Rm, false);
        C0243b.m355b(parcel, 4, parcelableEvent.Rt, false);
        C0243b.m347a(parcel, 5, parcelableEvent.Ru);
        C0243b.m344a(parcel, 6, parcelableEvent.Rp, false);
        C0243b.m344a(parcel, 7, parcelableEvent.Rv, false);
        C0243b.m340a(parcel, 8, parcelableEvent.Rw, i, false);
        C0243b.m340a(parcel, 9, parcelableEvent.Rx, i, false);
        C0243b.m340a(parcel, 10, parcelableEvent.Ry, i, false);
        C0243b.m340a(parcel, 11, parcelableEvent.Rz, i, false);
        C0243b.m340a(parcel, 12, parcelableEvent.RA, i, false);
        C0243b.m340a(parcel, 13, parcelableEvent.RB, i, false);
        C0243b.m340a(parcel, 14, parcelableEvent.RC, i, false);
        C0243b.m340a(parcel, 15, parcelableEvent.RD, i, false);
        C0243b.m332H(parcel, D);
    }

    public ParcelableEvent aZ(Parcel parcel) {
        int C = C0242a.m293C(parcel);
        int i = 0;
        String str = null;
        String str2 = null;
        List list = null;
        boolean z = false;
        String str3 = null;
        String str4 = null;
        TextInsertedDetails textInsertedDetails = null;
        TextDeletedDetails textDeletedDetails = null;
        ValuesAddedDetails valuesAddedDetails = null;
        ValuesRemovedDetails valuesRemovedDetails = null;
        ValuesSetDetails valuesSetDetails = null;
        ValueChangedDetails valueChangedDetails = null;
        ReferenceShiftedDetails referenceShiftedDetails = null;
        ObjectChangedDetails objectChangedDetails = null;
        while (parcel.dataPosition() < C) {
            int B = C0242a.m291B(parcel);
            switch (C0242a.aD(B)) {
                case CompletionEvent.STATUS_FAILURE /*1*/:
                    i = C0242a.m309g(parcel, B);
                    break;
                case CompletionEvent.STATUS_CONFLICT /*2*/:
                    str = C0242a.m317o(parcel, B);
                    break;
                case FastDatePrinter.SHORT /*3*/:
                    str2 = C0242a.m317o(parcel, B);
                    break;
                case ItemTouchHelper.LEFT /*4*/:
                    list = C0242a.m294C(parcel, B);
                    break;
                case DetectedActivity.TILTING /*5*/:
                    z = C0242a.m305c(parcel, B);
                    break;
                case Quest.STATE_FAILED /*6*/:
                    str3 = C0242a.m317o(parcel, B);
                    break;
                case DetectedActivity.WALKING /*7*/:
                    str4 = C0242a.m317o(parcel, B);
                    break;
                case XtraBox.MP4_XTRA_BT_UNICODE /*8*/:
                    textInsertedDetails = (TextInsertedDetails) C0242a.m298a(parcel, B, TextInsertedDetails.CREATOR);
                    break;
                case C0811R.styleable.WalletFragmentStyle_maskedWalletDetailsLogoTextColor /*9*/:
                    textDeletedDetails = (TextDeletedDetails) C0242a.m298a(parcel, B, TextDeletedDetails.CREATOR);
                    break;
                case C0811R.styleable.WalletFragmentStyle_maskedWalletDetailsLogoImageType /*10*/:
                    valuesAddedDetails = (ValuesAddedDetails) C0242a.m298a(parcel, B, ValuesAddedDetails.CREATOR);
                    break;
                case C0811R.styleable.MapAttrs_uiZoomGestures /*11*/:
                    valuesRemovedDetails = (ValuesRemovedDetails) C0242a.m298a(parcel, B, ValuesRemovedDetails.CREATOR);
                    break;
                case C0811R.styleable.MapAttrs_useViewLifecycle /*12*/:
                    valuesSetDetails = (ValuesSetDetails) C0242a.m298a(parcel, B, ValuesSetDetails.CREATOR);
                    break;
                case C0811R.styleable.MapAttrs_zOrderOnTop /*13*/:
                    valueChangedDetails = (ValueChangedDetails) C0242a.m298a(parcel, B, ValueChangedDetails.CREATOR);
                    break;
                case NalUnitTypes.NAL_TYPE_RSV_VCL_N14 /*14*/:
                    referenceShiftedDetails = (ReferenceShiftedDetails) C0242a.m298a(parcel, B, ReferenceShiftedDetails.CREATOR);
                    break;
                case NalUnitTypes.NAL_TYPE_RSV_VCL_R15 /*15*/:
                    objectChangedDetails = (ObjectChangedDetails) C0242a.m298a(parcel, B, ObjectChangedDetails.CREATOR);
                    break;
                default:
                    C0242a.m302b(parcel, B);
                    break;
            }
        }
        if (parcel.dataPosition() == C) {
            return new ParcelableEvent(i, str, str2, list, z, str3, str4, textInsertedDetails, textDeletedDetails, valuesAddedDetails, valuesRemovedDetails, valuesSetDetails, valueChangedDetails, referenceShiftedDetails, objectChangedDetails);
        }
        throw new C0241a("Overread allowed size end=" + C, parcel);
    }

    public ParcelableEvent[] cm(int i) {
        return new ParcelableEvent[i];
    }

    public /* synthetic */ Object createFromParcel(Parcel x0) {
        return aZ(x0);
    }

    public /* synthetic */ Object[] newArray(int x0) {
        return cm(x0);
    }
}
