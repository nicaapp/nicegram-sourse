package com.google.android.gms.drive.internal;

import android.os.ParcelFileDescriptor;
import android.os.RemoteException;
import com.google.android.gms.common.api.GoogleApiClient;
import com.google.android.gms.common.api.PendingResult;
import com.google.android.gms.common.api.Result;
import com.google.android.gms.common.api.ResultCallback;
import com.google.android.gms.common.api.Status;
import com.google.android.gms.common.internal.C0238o;
import com.google.android.gms.drive.Contents;
import com.google.android.gms.drive.DriveApi.DriveContentsResult;
import com.google.android.gms.drive.DriveContents;
import com.google.android.gms.drive.DriveFile;
import com.google.android.gms.drive.DriveId;
import com.google.android.gms.drive.ExecutionOptions;
import com.google.android.gms.drive.ExecutionOptions.Builder;
import com.google.android.gms.drive.MetadataChangeSet;
import com.google.android.gms.drive.internal.C1721o.C2657d;
import com.google.android.gms.drive.internal.C2600p.C2660a;
import java.io.InputStream;
import java.io.OutputStream;

/* renamed from: com.google.android.gms.drive.internal.r */
public class C1723r implements DriveContents {
    private final Contents Ox;

    /* renamed from: com.google.android.gms.drive.internal.r.2 */
    class C17222 implements ResultCallback<Status> {
        final /* synthetic */ C1723r OL;

        C17222(C1723r c1723r) {
            this.OL = c1723r;
        }

        public void m2573k(Status status) {
            if (status.isSuccess()) {
                C0273v.m474n("DriveContentsImpl", "Contents discarded");
            } else {
                C0273v.m476q("DriveContentsImpl", "Error discarding contents");
            }
        }

        public /* synthetic */ void onResult(Result x0) {
            m2573k((Status) x0);
        }
    }

    /* renamed from: com.google.android.gms.drive.internal.r.1 */
    class C27501 extends C2657d {
        final /* synthetic */ C1723r OL;

        C27501(C1723r c1723r) {
            this.OL = c1723r;
        }

        protected void m5136a(C2398q c2398q) throws RemoteException {
            c2398q.hY().m405a(new OpenContentsRequest(this.OL.getDriveId(), DriveFile.MODE_WRITE_ONLY, this.OL.Ox.getRequestId()), new av(this, null));
        }
    }

    /* renamed from: com.google.android.gms.drive.internal.r.3 */
    class C27513 extends C2660a {
        final /* synthetic */ C1723r OL;

        C27513(C1723r c1723r) {
            this.OL = c1723r;
        }

        protected void m5138a(C2398q c2398q) throws RemoteException {
            c2398q.hY().m395a(new CloseContentsRequest(this.OL.Ox, false), new bb(this));
        }
    }

    /* renamed from: com.google.android.gms.drive.internal.r.4 */
    class C27524 extends C2660a {
        final /* synthetic */ C1723r OL;
        final /* synthetic */ MetadataChangeSet OM;
        final /* synthetic */ ExecutionOptions ON;

        C27524(C1723r c1723r, MetadataChangeSet metadataChangeSet, ExecutionOptions executionOptions) {
            this.OL = c1723r;
            this.OM = metadataChangeSet;
            this.ON = executionOptions;
        }

        protected void m5140a(C2398q c2398q) throws RemoteException {
            this.OM.hS().setContext(c2398q.getContext());
            c2398q.hY().m394a(new CloseContentsAndUpdateMetadataRequest(this.OL.Ox.getDriveId(), this.OM.hS(), this.OL.Ox, this.ON), new bb(this));
        }
    }

    public C1723r(Contents contents) {
        this.Ox = (Contents) C0238o.m283i(contents);
    }

    private PendingResult<Status> m2574a(GoogleApiClient googleApiClient, MetadataChangeSet metadataChangeSet, ExecutionOptions executionOptions) {
        if (this.Ox.getMode() == DriveFile.MODE_READ_ONLY) {
            throw new IllegalStateException("Cannot commit contents opened with MODE_READ_ONLY");
        } else if (!ExecutionOptions.aV(executionOptions.hQ()) || this.Ox.hL()) {
            ExecutionOptions.m363a(googleApiClient, executionOptions);
            if (this.Ox.hK()) {
                throw new IllegalStateException("DriveContents already closed.");
            } else if (getDriveId() == null) {
                throw new IllegalStateException("Only DriveContents obtained through DriveFile.open can be committed.");
            } else {
                if (metadataChangeSet == null) {
                    metadataChangeSet = MetadataChangeSet.Nt;
                }
                this.Ox.hJ();
                return googleApiClient.m152b(new C27524(this, metadataChangeSet, executionOptions));
            }
        } else {
            throw new IllegalStateException("DriveContents must be valid for conflict detection.");
        }
    }

    public PendingResult<Status> commit(GoogleApiClient apiClient, MetadataChangeSet changeSet) {
        return m2574a(apiClient, changeSet, new Builder().build());
    }

    public PendingResult<Status> commit(GoogleApiClient apiClient, MetadataChangeSet changeSet, ExecutionOptions executionOptions) {
        return m2574a(apiClient, changeSet, executionOptions);
    }

    public void discard(GoogleApiClient apiClient) {
        if (this.Ox.hK()) {
            throw new IllegalStateException("DriveContents already closed.");
        }
        this.Ox.hJ();
        ((C27513) apiClient.m152b(new C27513(this))).setResultCallback(new C17222(this));
    }

    public Contents getContents() {
        return this.Ox;
    }

    public DriveId getDriveId() {
        return this.Ox.getDriveId();
    }

    public InputStream getInputStream() {
        return this.Ox.getInputStream();
    }

    public int getMode() {
        return this.Ox.getMode();
    }

    public OutputStream getOutputStream() {
        return this.Ox.getOutputStream();
    }

    public ParcelFileDescriptor getParcelFileDescriptor() {
        return this.Ox.getParcelFileDescriptor();
    }

    public PendingResult<DriveContentsResult> reopenForWrite(GoogleApiClient apiClient) {
        if (this.Ox.hK()) {
            throw new IllegalStateException("DriveContents already closed.");
        } else if (this.Ox.getMode() != DriveFile.MODE_READ_ONLY) {
            throw new IllegalStateException("reopenForWrite can only be used with DriveContents opened with MODE_READ_ONLY.");
        } else {
            this.Ox.hJ();
            return apiClient.m150a(new C27501(this));
        }
    }
}
