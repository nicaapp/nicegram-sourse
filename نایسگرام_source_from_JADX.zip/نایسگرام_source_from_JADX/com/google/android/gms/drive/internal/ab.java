package com.google.android.gms.drive.internal;

import android.content.IntentSender;
import android.os.Binder;
import android.os.IBinder;
import android.os.IInterface;
import android.os.Parcel;
import android.os.RemoteException;
import com.google.android.gms.drive.RealtimeDocumentSyncRequest;
import com.google.android.gms.drive.events.CompletionEvent;
import com.google.android.gms.drive.internal.ac.C1716a;
import com.google.android.gms.drive.internal.ad.C1718a;
import com.google.android.gms.games.quest.Quest;
import com.google.android.gms.location.DetectedActivity;
import com.googlecode.mp4parser.authoring.tracks.h265.NalUnitTypes;
import com.googlecode.mp4parser.boxes.microsoft.XtraBox;
import org.telegram.C0811R;
import org.telegram.android.SecretChatHelper;
import org.telegram.android.support.widget.helper.ItemTouchHelper;
import org.telegram.android.time.FastDatePrinter;
import org.telegram.messenger.TLRPC;

public interface ab extends IInterface {

    /* renamed from: com.google.android.gms.drive.internal.ab.a */
    public static abstract class C1714a extends Binder implements ab {

        /* renamed from: com.google.android.gms.drive.internal.ab.a.a */
        private static class C1713a implements ab {
            private IBinder lb;

            C1713a(IBinder iBinder) {
                this.lb = iBinder;
            }

            public IntentSender m2522a(CreateFileIntentSenderRequest createFileIntentSenderRequest) throws RemoteException {
                Parcel obtain = Parcel.obtain();
                Parcel obtain2 = Parcel.obtain();
                try {
                    obtain.writeInterfaceToken("com.google.android.gms.drive.internal.IDriveService");
                    if (createFileIntentSenderRequest != null) {
                        obtain.writeInt(1);
                        createFileIntentSenderRequest.writeToParcel(obtain, 0);
                    } else {
                        obtain.writeInt(0);
                    }
                    this.lb.transact(11, obtain, obtain2, 0);
                    obtain2.readException();
                    IntentSender intentSender = obtain2.readInt() != 0 ? (IntentSender) IntentSender.CREATOR.createFromParcel(obtain2) : null;
                    obtain2.recycle();
                    obtain.recycle();
                    return intentSender;
                } catch (Throwable th) {
                    obtain2.recycle();
                    obtain.recycle();
                }
            }

            public IntentSender m2523a(OpenFileIntentSenderRequest openFileIntentSenderRequest) throws RemoteException {
                Parcel obtain = Parcel.obtain();
                Parcel obtain2 = Parcel.obtain();
                try {
                    obtain.writeInterfaceToken("com.google.android.gms.drive.internal.IDriveService");
                    if (openFileIntentSenderRequest != null) {
                        obtain.writeInt(1);
                        openFileIntentSenderRequest.writeToParcel(obtain, 0);
                    } else {
                        obtain.writeInt(0);
                    }
                    this.lb.transact(10, obtain, obtain2, 0);
                    obtain2.readException();
                    IntentSender intentSender = obtain2.readInt() != 0 ? (IntentSender) IntentSender.CREATOR.createFromParcel(obtain2) : null;
                    obtain2.recycle();
                    obtain.recycle();
                    return intentSender;
                } catch (Throwable th) {
                    obtain2.recycle();
                    obtain.recycle();
                }
            }

            public void m2524a(RealtimeDocumentSyncRequest realtimeDocumentSyncRequest, ac acVar) throws RemoteException {
                Parcel obtain = Parcel.obtain();
                Parcel obtain2 = Parcel.obtain();
                try {
                    obtain.writeInterfaceToken("com.google.android.gms.drive.internal.IDriveService");
                    if (realtimeDocumentSyncRequest != null) {
                        obtain.writeInt(1);
                        realtimeDocumentSyncRequest.writeToParcel(obtain, 0);
                    } else {
                        obtain.writeInt(0);
                    }
                    obtain.writeStrongBinder(acVar != null ? acVar.asBinder() : null);
                    this.lb.transact(34, obtain, obtain2, 0);
                    obtain2.readException();
                } finally {
                    obtain2.recycle();
                    obtain.recycle();
                }
            }

            public void m2525a(AddEventListenerRequest addEventListenerRequest, ad adVar, String str, ac acVar) throws RemoteException {
                IBinder iBinder = null;
                Parcel obtain = Parcel.obtain();
                Parcel obtain2 = Parcel.obtain();
                try {
                    obtain.writeInterfaceToken("com.google.android.gms.drive.internal.IDriveService");
                    if (addEventListenerRequest != null) {
                        obtain.writeInt(1);
                        addEventListenerRequest.writeToParcel(obtain, 0);
                    } else {
                        obtain.writeInt(0);
                    }
                    obtain.writeStrongBinder(adVar != null ? adVar.asBinder() : null);
                    obtain.writeString(str);
                    if (acVar != null) {
                        iBinder = acVar.asBinder();
                    }
                    obtain.writeStrongBinder(iBinder);
                    this.lb.transact(14, obtain, obtain2, 0);
                    obtain2.readException();
                } finally {
                    obtain2.recycle();
                    obtain.recycle();
                }
            }

            public void m2526a(AuthorizeAccessRequest authorizeAccessRequest, ac acVar) throws RemoteException {
                Parcel obtain = Parcel.obtain();
                Parcel obtain2 = Parcel.obtain();
                try {
                    obtain.writeInterfaceToken("com.google.android.gms.drive.internal.IDriveService");
                    if (authorizeAccessRequest != null) {
                        obtain.writeInt(1);
                        authorizeAccessRequest.writeToParcel(obtain, 0);
                    } else {
                        obtain.writeInt(0);
                    }
                    obtain.writeStrongBinder(acVar != null ? acVar.asBinder() : null);
                    this.lb.transact(12, obtain, obtain2, 0);
                    obtain2.readException();
                } finally {
                    obtain2.recycle();
                    obtain.recycle();
                }
            }

            public void m2527a(CheckResourceIdsExistRequest checkResourceIdsExistRequest, ac acVar) throws RemoteException {
                Parcel obtain = Parcel.obtain();
                Parcel obtain2 = Parcel.obtain();
                try {
                    obtain.writeInterfaceToken("com.google.android.gms.drive.internal.IDriveService");
                    if (checkResourceIdsExistRequest != null) {
                        obtain.writeInt(1);
                        checkResourceIdsExistRequest.writeToParcel(obtain, 0);
                    } else {
                        obtain.writeInt(0);
                    }
                    obtain.writeStrongBinder(acVar != null ? acVar.asBinder() : null);
                    this.lb.transact(30, obtain, obtain2, 0);
                    obtain2.readException();
                } finally {
                    obtain2.recycle();
                    obtain.recycle();
                }
            }

            public void m2528a(CloseContentsAndUpdateMetadataRequest closeContentsAndUpdateMetadataRequest, ac acVar) throws RemoteException {
                Parcel obtain = Parcel.obtain();
                Parcel obtain2 = Parcel.obtain();
                try {
                    obtain.writeInterfaceToken("com.google.android.gms.drive.internal.IDriveService");
                    if (closeContentsAndUpdateMetadataRequest != null) {
                        obtain.writeInt(1);
                        closeContentsAndUpdateMetadataRequest.writeToParcel(obtain, 0);
                    } else {
                        obtain.writeInt(0);
                    }
                    obtain.writeStrongBinder(acVar != null ? acVar.asBinder() : null);
                    this.lb.transact(18, obtain, obtain2, 0);
                    obtain2.readException();
                } finally {
                    obtain2.recycle();
                    obtain.recycle();
                }
            }

            public void m2529a(CloseContentsRequest closeContentsRequest, ac acVar) throws RemoteException {
                Parcel obtain = Parcel.obtain();
                Parcel obtain2 = Parcel.obtain();
                try {
                    obtain.writeInterfaceToken("com.google.android.gms.drive.internal.IDriveService");
                    if (closeContentsRequest != null) {
                        obtain.writeInt(1);
                        closeContentsRequest.writeToParcel(obtain, 0);
                    } else {
                        obtain.writeInt(0);
                    }
                    obtain.writeStrongBinder(acVar != null ? acVar.asBinder() : null);
                    this.lb.transact(8, obtain, obtain2, 0);
                    obtain2.readException();
                } finally {
                    obtain2.recycle();
                    obtain.recycle();
                }
            }

            public void m2530a(CreateContentsRequest createContentsRequest, ac acVar) throws RemoteException {
                Parcel obtain = Parcel.obtain();
                Parcel obtain2 = Parcel.obtain();
                try {
                    obtain.writeInterfaceToken("com.google.android.gms.drive.internal.IDriveService");
                    if (createContentsRequest != null) {
                        obtain.writeInt(1);
                        createContentsRequest.writeToParcel(obtain, 0);
                    } else {
                        obtain.writeInt(0);
                    }
                    obtain.writeStrongBinder(acVar != null ? acVar.asBinder() : null);
                    this.lb.transact(4, obtain, obtain2, 0);
                    obtain2.readException();
                } finally {
                    obtain2.recycle();
                    obtain.recycle();
                }
            }

            public void m2531a(CreateFileRequest createFileRequest, ac acVar) throws RemoteException {
                Parcel obtain = Parcel.obtain();
                Parcel obtain2 = Parcel.obtain();
                try {
                    obtain.writeInterfaceToken("com.google.android.gms.drive.internal.IDriveService");
                    if (createFileRequest != null) {
                        obtain.writeInt(1);
                        createFileRequest.writeToParcel(obtain, 0);
                    } else {
                        obtain.writeInt(0);
                    }
                    obtain.writeStrongBinder(acVar != null ? acVar.asBinder() : null);
                    this.lb.transact(5, obtain, obtain2, 0);
                    obtain2.readException();
                } finally {
                    obtain2.recycle();
                    obtain.recycle();
                }
            }

            public void m2532a(CreateFolderRequest createFolderRequest, ac acVar) throws RemoteException {
                Parcel obtain = Parcel.obtain();
                Parcel obtain2 = Parcel.obtain();
                try {
                    obtain.writeInterfaceToken("com.google.android.gms.drive.internal.IDriveService");
                    if (createFolderRequest != null) {
                        obtain.writeInt(1);
                        createFolderRequest.writeToParcel(obtain, 0);
                    } else {
                        obtain.writeInt(0);
                    }
                    obtain.writeStrongBinder(acVar != null ? acVar.asBinder() : null);
                    this.lb.transact(6, obtain, obtain2, 0);
                    obtain2.readException();
                } finally {
                    obtain2.recycle();
                    obtain.recycle();
                }
            }

            public void m2533a(DeleteResourceRequest deleteResourceRequest, ac acVar) throws RemoteException {
                Parcel obtain = Parcel.obtain();
                Parcel obtain2 = Parcel.obtain();
                try {
                    obtain.writeInterfaceToken("com.google.android.gms.drive.internal.IDriveService");
                    if (deleteResourceRequest != null) {
                        obtain.writeInt(1);
                        deleteResourceRequest.writeToParcel(obtain, 0);
                    } else {
                        obtain.writeInt(0);
                    }
                    obtain.writeStrongBinder(acVar != null ? acVar.asBinder() : null);
                    this.lb.transact(24, obtain, obtain2, 0);
                    obtain2.readException();
                } finally {
                    obtain2.recycle();
                    obtain.recycle();
                }
            }

            public void m2534a(DisconnectRequest disconnectRequest) throws RemoteException {
                Parcel obtain = Parcel.obtain();
                Parcel obtain2 = Parcel.obtain();
                try {
                    obtain.writeInterfaceToken("com.google.android.gms.drive.internal.IDriveService");
                    if (disconnectRequest != null) {
                        obtain.writeInt(1);
                        disconnectRequest.writeToParcel(obtain, 0);
                    } else {
                        obtain.writeInt(0);
                    }
                    this.lb.transact(16, obtain, obtain2, 0);
                    obtain2.readException();
                } finally {
                    obtain2.recycle();
                    obtain.recycle();
                }
            }

            public void m2535a(GetDriveIdFromUniqueIdentifierRequest getDriveIdFromUniqueIdentifierRequest, ac acVar) throws RemoteException {
                Parcel obtain = Parcel.obtain();
                Parcel obtain2 = Parcel.obtain();
                try {
                    obtain.writeInterfaceToken("com.google.android.gms.drive.internal.IDriveService");
                    if (getDriveIdFromUniqueIdentifierRequest != null) {
                        obtain.writeInt(1);
                        getDriveIdFromUniqueIdentifierRequest.writeToParcel(obtain, 0);
                    } else {
                        obtain.writeInt(0);
                    }
                    obtain.writeStrongBinder(acVar != null ? acVar.asBinder() : null);
                    this.lb.transact(29, obtain, obtain2, 0);
                    obtain2.readException();
                } finally {
                    obtain2.recycle();
                    obtain.recycle();
                }
            }

            public void m2536a(GetMetadataRequest getMetadataRequest, ac acVar) throws RemoteException {
                Parcel obtain = Parcel.obtain();
                Parcel obtain2 = Parcel.obtain();
                try {
                    obtain.writeInterfaceToken("com.google.android.gms.drive.internal.IDriveService");
                    if (getMetadataRequest != null) {
                        obtain.writeInt(1);
                        getMetadataRequest.writeToParcel(obtain, 0);
                    } else {
                        obtain.writeInt(0);
                    }
                    obtain.writeStrongBinder(acVar != null ? acVar.asBinder() : null);
                    this.lb.transact(1, obtain, obtain2, 0);
                    obtain2.readException();
                } finally {
                    obtain2.recycle();
                    obtain.recycle();
                }
            }

            public void m2537a(ListParentsRequest listParentsRequest, ac acVar) throws RemoteException {
                Parcel obtain = Parcel.obtain();
                Parcel obtain2 = Parcel.obtain();
                try {
                    obtain.writeInterfaceToken("com.google.android.gms.drive.internal.IDriveService");
                    if (listParentsRequest != null) {
                        obtain.writeInt(1);
                        listParentsRequest.writeToParcel(obtain, 0);
                    } else {
                        obtain.writeInt(0);
                    }
                    obtain.writeStrongBinder(acVar != null ? acVar.asBinder() : null);
                    this.lb.transact(13, obtain, obtain2, 0);
                    obtain2.readException();
                } finally {
                    obtain2.recycle();
                    obtain.recycle();
                }
            }

            public void m2538a(LoadRealtimeRequest loadRealtimeRequest, ac acVar) throws RemoteException {
                Parcel obtain = Parcel.obtain();
                Parcel obtain2 = Parcel.obtain();
                try {
                    obtain.writeInterfaceToken("com.google.android.gms.drive.internal.IDriveService");
                    if (loadRealtimeRequest != null) {
                        obtain.writeInt(1);
                        loadRealtimeRequest.writeToParcel(obtain, 0);
                    } else {
                        obtain.writeInt(0);
                    }
                    obtain.writeStrongBinder(acVar != null ? acVar.asBinder() : null);
                    this.lb.transact(27, obtain, obtain2, 0);
                    obtain2.readException();
                } finally {
                    obtain2.recycle();
                    obtain.recycle();
                }
            }

            public void m2539a(OpenContentsRequest openContentsRequest, ac acVar) throws RemoteException {
                Parcel obtain = Parcel.obtain();
                Parcel obtain2 = Parcel.obtain();
                try {
                    obtain.writeInterfaceToken("com.google.android.gms.drive.internal.IDriveService");
                    if (openContentsRequest != null) {
                        obtain.writeInt(1);
                        openContentsRequest.writeToParcel(obtain, 0);
                    } else {
                        obtain.writeInt(0);
                    }
                    obtain.writeStrongBinder(acVar != null ? acVar.asBinder() : null);
                    this.lb.transact(7, obtain, obtain2, 0);
                    obtain2.readException();
                } finally {
                    obtain2.recycle();
                    obtain.recycle();
                }
            }

            public void m2540a(QueryRequest queryRequest, ac acVar) throws RemoteException {
                Parcel obtain = Parcel.obtain();
                Parcel obtain2 = Parcel.obtain();
                try {
                    obtain.writeInterfaceToken("com.google.android.gms.drive.internal.IDriveService");
                    if (queryRequest != null) {
                        obtain.writeInt(1);
                        queryRequest.writeToParcel(obtain, 0);
                    } else {
                        obtain.writeInt(0);
                    }
                    obtain.writeStrongBinder(acVar != null ? acVar.asBinder() : null);
                    this.lb.transact(2, obtain, obtain2, 0);
                    obtain2.readException();
                } finally {
                    obtain2.recycle();
                    obtain.recycle();
                }
            }

            public void m2541a(RemoveEventListenerRequest removeEventListenerRequest, ad adVar, String str, ac acVar) throws RemoteException {
                IBinder iBinder = null;
                Parcel obtain = Parcel.obtain();
                Parcel obtain2 = Parcel.obtain();
                try {
                    obtain.writeInterfaceToken("com.google.android.gms.drive.internal.IDriveService");
                    if (removeEventListenerRequest != null) {
                        obtain.writeInt(1);
                        removeEventListenerRequest.writeToParcel(obtain, 0);
                    } else {
                        obtain.writeInt(0);
                    }
                    obtain.writeStrongBinder(adVar != null ? adVar.asBinder() : null);
                    obtain.writeString(str);
                    if (acVar != null) {
                        iBinder = acVar.asBinder();
                    }
                    obtain.writeStrongBinder(iBinder);
                    this.lb.transact(15, obtain, obtain2, 0);
                    obtain2.readException();
                } finally {
                    obtain2.recycle();
                    obtain.recycle();
                }
            }

            public void m2542a(SetDrivePreferencesRequest setDrivePreferencesRequest, ac acVar) throws RemoteException {
                Parcel obtain = Parcel.obtain();
                Parcel obtain2 = Parcel.obtain();
                try {
                    obtain.writeInterfaceToken("com.google.android.gms.drive.internal.IDriveService");
                    if (setDrivePreferencesRequest != null) {
                        obtain.writeInt(1);
                        setDrivePreferencesRequest.writeToParcel(obtain, 0);
                    } else {
                        obtain.writeInt(0);
                    }
                    obtain.writeStrongBinder(acVar != null ? acVar.asBinder() : null);
                    this.lb.transact(33, obtain, obtain2, 0);
                    obtain2.readException();
                } finally {
                    obtain2.recycle();
                    obtain.recycle();
                }
            }

            public void m2543a(SetResourceParentsRequest setResourceParentsRequest, ac acVar) throws RemoteException {
                Parcel obtain = Parcel.obtain();
                Parcel obtain2 = Parcel.obtain();
                try {
                    obtain.writeInterfaceToken("com.google.android.gms.drive.internal.IDriveService");
                    if (setResourceParentsRequest != null) {
                        obtain.writeInt(1);
                        setResourceParentsRequest.writeToParcel(obtain, 0);
                    } else {
                        obtain.writeInt(0);
                    }
                    obtain.writeStrongBinder(acVar != null ? acVar.asBinder() : null);
                    this.lb.transact(28, obtain, obtain2, 0);
                    obtain2.readException();
                } finally {
                    obtain2.recycle();
                    obtain.recycle();
                }
            }

            public void m2544a(TrashResourceRequest trashResourceRequest, ac acVar) throws RemoteException {
                Parcel obtain = Parcel.obtain();
                Parcel obtain2 = Parcel.obtain();
                try {
                    obtain.writeInterfaceToken("com.google.android.gms.drive.internal.IDriveService");
                    if (trashResourceRequest != null) {
                        obtain.writeInt(1);
                        trashResourceRequest.writeToParcel(obtain, 0);
                    } else {
                        obtain.writeInt(0);
                    }
                    obtain.writeStrongBinder(acVar != null ? acVar.asBinder() : null);
                    this.lb.transact(17, obtain, obtain2, 0);
                    obtain2.readException();
                } finally {
                    obtain2.recycle();
                    obtain.recycle();
                }
            }

            public void m2545a(UpdateMetadataRequest updateMetadataRequest, ac acVar) throws RemoteException {
                Parcel obtain = Parcel.obtain();
                Parcel obtain2 = Parcel.obtain();
                try {
                    obtain.writeInterfaceToken("com.google.android.gms.drive.internal.IDriveService");
                    if (updateMetadataRequest != null) {
                        obtain.writeInt(1);
                        updateMetadataRequest.writeToParcel(obtain, 0);
                    } else {
                        obtain.writeInt(0);
                    }
                    obtain.writeStrongBinder(acVar != null ? acVar.asBinder() : null);
                    this.lb.transact(3, obtain, obtain2, 0);
                    obtain2.readException();
                } finally {
                    obtain2.recycle();
                    obtain.recycle();
                }
            }

            public void m2546a(ac acVar) throws RemoteException {
                Parcel obtain = Parcel.obtain();
                Parcel obtain2 = Parcel.obtain();
                try {
                    obtain.writeInterfaceToken("com.google.android.gms.drive.internal.IDriveService");
                    obtain.writeStrongBinder(acVar != null ? acVar.asBinder() : null);
                    this.lb.transact(9, obtain, obtain2, 0);
                    obtain2.readException();
                } finally {
                    obtain2.recycle();
                    obtain.recycle();
                }
            }

            public IBinder asBinder() {
                return this.lb;
            }

            public void m2547b(QueryRequest queryRequest, ac acVar) throws RemoteException {
                Parcel obtain = Parcel.obtain();
                Parcel obtain2 = Parcel.obtain();
                try {
                    obtain.writeInterfaceToken("com.google.android.gms.drive.internal.IDriveService");
                    if (queryRequest != null) {
                        obtain.writeInt(1);
                        queryRequest.writeToParcel(obtain, 0);
                    } else {
                        obtain.writeInt(0);
                    }
                    obtain.writeStrongBinder(acVar != null ? acVar.asBinder() : null);
                    this.lb.transact(19, obtain, obtain2, 0);
                    obtain2.readException();
                } finally {
                    obtain2.recycle();
                    obtain.recycle();
                }
            }

            public void m2548b(ac acVar) throws RemoteException {
                Parcel obtain = Parcel.obtain();
                Parcel obtain2 = Parcel.obtain();
                try {
                    obtain.writeInterfaceToken("com.google.android.gms.drive.internal.IDriveService");
                    obtain.writeStrongBinder(acVar != null ? acVar.asBinder() : null);
                    this.lb.transact(20, obtain, obtain2, 0);
                    obtain2.readException();
                } finally {
                    obtain2.recycle();
                    obtain.recycle();
                }
            }

            public void m2549c(ac acVar) throws RemoteException {
                Parcel obtain = Parcel.obtain();
                Parcel obtain2 = Parcel.obtain();
                try {
                    obtain.writeInterfaceToken("com.google.android.gms.drive.internal.IDriveService");
                    obtain.writeStrongBinder(acVar != null ? acVar.asBinder() : null);
                    this.lb.transact(21, obtain, obtain2, 0);
                    obtain2.readException();
                } finally {
                    obtain2.recycle();
                    obtain.recycle();
                }
            }

            public void m2550d(ac acVar) throws RemoteException {
                Parcel obtain = Parcel.obtain();
                Parcel obtain2 = Parcel.obtain();
                try {
                    obtain.writeInterfaceToken("com.google.android.gms.drive.internal.IDriveService");
                    obtain.writeStrongBinder(acVar != null ? acVar.asBinder() : null);
                    this.lb.transact(22, obtain, obtain2, 0);
                    obtain2.readException();
                } finally {
                    obtain2.recycle();
                    obtain.recycle();
                }
            }

            public void m2551e(ac acVar) throws RemoteException {
                Parcel obtain = Parcel.obtain();
                Parcel obtain2 = Parcel.obtain();
                try {
                    obtain.writeInterfaceToken("com.google.android.gms.drive.internal.IDriveService");
                    obtain.writeStrongBinder(acVar != null ? acVar.asBinder() : null);
                    this.lb.transact(23, obtain, obtain2, 0);
                    obtain2.readException();
                } finally {
                    obtain2.recycle();
                    obtain.recycle();
                }
            }

            public void m2552f(ac acVar) throws RemoteException {
                Parcel obtain = Parcel.obtain();
                Parcel obtain2 = Parcel.obtain();
                try {
                    obtain.writeInterfaceToken("com.google.android.gms.drive.internal.IDriveService");
                    obtain.writeStrongBinder(acVar != null ? acVar.asBinder() : null);
                    this.lb.transact(31, obtain, obtain2, 0);
                    obtain2.readException();
                } finally {
                    obtain2.recycle();
                    obtain.recycle();
                }
            }

            public void m2553g(ac acVar) throws RemoteException {
                Parcel obtain = Parcel.obtain();
                Parcel obtain2 = Parcel.obtain();
                try {
                    obtain.writeInterfaceToken("com.google.android.gms.drive.internal.IDriveService");
                    obtain.writeStrongBinder(acVar != null ? acVar.asBinder() : null);
                    this.lb.transact(32, obtain, obtain2, 0);
                    obtain2.readException();
                } finally {
                    obtain2.recycle();
                    obtain.recycle();
                }
            }
        }

        public static ab m2554U(IBinder iBinder) {
            if (iBinder == null) {
                return null;
            }
            IInterface queryLocalInterface = iBinder.queryLocalInterface("com.google.android.gms.drive.internal.IDriveService");
            return (queryLocalInterface == null || !(queryLocalInterface instanceof ab)) ? new C1713a(iBinder) : (ab) queryLocalInterface;
        }

        public boolean onTransact(int code, Parcel data, Parcel reply, int flags) throws RemoteException {
            RealtimeDocumentSyncRequest realtimeDocumentSyncRequest = null;
            QueryRequest queryRequest;
            IntentSender a;
            switch (code) {
                case CompletionEvent.STATUS_FAILURE /*1*/:
                    GetMetadataRequest getMetadataRequest;
                    data.enforceInterface("com.google.android.gms.drive.internal.IDriveService");
                    if (data.readInt() != 0) {
                        getMetadataRequest = (GetMetadataRequest) GetMetadataRequest.CREATOR.createFromParcel(data);
                    }
                    m402a(getMetadataRequest, C1716a.m2567V(data.readStrongBinder()));
                    reply.writeNoException();
                    return true;
                case CompletionEvent.STATUS_CONFLICT /*2*/:
                    data.enforceInterface("com.google.android.gms.drive.internal.IDriveService");
                    if (data.readInt() != 0) {
                        queryRequest = (QueryRequest) QueryRequest.CREATOR.createFromParcel(data);
                    }
                    m406a(queryRequest, C1716a.m2567V(data.readStrongBinder()));
                    reply.writeNoException();
                    return true;
                case FastDatePrinter.SHORT /*3*/:
                    UpdateMetadataRequest updateMetadataRequest;
                    data.enforceInterface("com.google.android.gms.drive.internal.IDriveService");
                    if (data.readInt() != 0) {
                        updateMetadataRequest = (UpdateMetadataRequest) UpdateMetadataRequest.CREATOR.createFromParcel(data);
                    }
                    m411a(updateMetadataRequest, C1716a.m2567V(data.readStrongBinder()));
                    reply.writeNoException();
                    return true;
                case ItemTouchHelper.LEFT /*4*/:
                    CreateContentsRequest createContentsRequest;
                    data.enforceInterface("com.google.android.gms.drive.internal.IDriveService");
                    if (data.readInt() != 0) {
                        createContentsRequest = (CreateContentsRequest) CreateContentsRequest.CREATOR.createFromParcel(data);
                    }
                    m396a(createContentsRequest, C1716a.m2567V(data.readStrongBinder()));
                    reply.writeNoException();
                    return true;
                case DetectedActivity.TILTING /*5*/:
                    CreateFileRequest createFileRequest;
                    data.enforceInterface("com.google.android.gms.drive.internal.IDriveService");
                    if (data.readInt() != 0) {
                        createFileRequest = (CreateFileRequest) CreateFileRequest.CREATOR.createFromParcel(data);
                    }
                    m397a(createFileRequest, C1716a.m2567V(data.readStrongBinder()));
                    reply.writeNoException();
                    return true;
                case Quest.STATE_FAILED /*6*/:
                    CreateFolderRequest createFolderRequest;
                    data.enforceInterface("com.google.android.gms.drive.internal.IDriveService");
                    if (data.readInt() != 0) {
                        createFolderRequest = (CreateFolderRequest) CreateFolderRequest.CREATOR.createFromParcel(data);
                    }
                    m398a(createFolderRequest, C1716a.m2567V(data.readStrongBinder()));
                    reply.writeNoException();
                    return true;
                case DetectedActivity.WALKING /*7*/:
                    OpenContentsRequest openContentsRequest;
                    data.enforceInterface("com.google.android.gms.drive.internal.IDriveService");
                    if (data.readInt() != 0) {
                        openContentsRequest = (OpenContentsRequest) OpenContentsRequest.CREATOR.createFromParcel(data);
                    }
                    m405a(openContentsRequest, C1716a.m2567V(data.readStrongBinder()));
                    reply.writeNoException();
                    return true;
                case XtraBox.MP4_XTRA_BT_UNICODE /*8*/:
                    CloseContentsRequest closeContentsRequest;
                    data.enforceInterface("com.google.android.gms.drive.internal.IDriveService");
                    if (data.readInt() != 0) {
                        closeContentsRequest = (CloseContentsRequest) CloseContentsRequest.CREATOR.createFromParcel(data);
                    }
                    m395a(closeContentsRequest, C1716a.m2567V(data.readStrongBinder()));
                    reply.writeNoException();
                    return true;
                case C0811R.styleable.WalletFragmentStyle_maskedWalletDetailsLogoTextColor /*9*/:
                    data.enforceInterface("com.google.android.gms.drive.internal.IDriveService");
                    m412a(C1716a.m2567V(data.readStrongBinder()));
                    reply.writeNoException();
                    return true;
                case C0811R.styleable.WalletFragmentStyle_maskedWalletDetailsLogoImageType /*10*/:
                    OpenFileIntentSenderRequest openFileIntentSenderRequest;
                    data.enforceInterface("com.google.android.gms.drive.internal.IDriveService");
                    if (data.readInt() != 0) {
                        openFileIntentSenderRequest = (OpenFileIntentSenderRequest) OpenFileIntentSenderRequest.CREATOR.createFromParcel(data);
                    }
                    a = m389a(openFileIntentSenderRequest);
                    reply.writeNoException();
                    if (a != null) {
                        reply.writeInt(1);
                        a.writeToParcel(reply, 1);
                    } else {
                        reply.writeInt(0);
                    }
                    return true;
                case C0811R.styleable.MapAttrs_uiZoomGestures /*11*/:
                    CreateFileIntentSenderRequest createFileIntentSenderRequest;
                    data.enforceInterface("com.google.android.gms.drive.internal.IDriveService");
                    if (data.readInt() != 0) {
                        createFileIntentSenderRequest = (CreateFileIntentSenderRequest) CreateFileIntentSenderRequest.CREATOR.createFromParcel(data);
                    }
                    a = m388a(createFileIntentSenderRequest);
                    reply.writeNoException();
                    if (a != null) {
                        reply.writeInt(1);
                        a.writeToParcel(reply, 1);
                    } else {
                        reply.writeInt(0);
                    }
                    return true;
                case C0811R.styleable.MapAttrs_useViewLifecycle /*12*/:
                    AuthorizeAccessRequest authorizeAccessRequest;
                    data.enforceInterface("com.google.android.gms.drive.internal.IDriveService");
                    if (data.readInt() != 0) {
                        authorizeAccessRequest = (AuthorizeAccessRequest) AuthorizeAccessRequest.CREATOR.createFromParcel(data);
                    }
                    m392a(authorizeAccessRequest, C1716a.m2567V(data.readStrongBinder()));
                    reply.writeNoException();
                    return true;
                case C0811R.styleable.MapAttrs_zOrderOnTop /*13*/:
                    ListParentsRequest listParentsRequest;
                    data.enforceInterface("com.google.android.gms.drive.internal.IDriveService");
                    if (data.readInt() != 0) {
                        listParentsRequest = (ListParentsRequest) ListParentsRequest.CREATOR.createFromParcel(data);
                    }
                    m403a(listParentsRequest, C1716a.m2567V(data.readStrongBinder()));
                    reply.writeNoException();
                    return true;
                case NalUnitTypes.NAL_TYPE_RSV_VCL_N14 /*14*/:
                    AddEventListenerRequest addEventListenerRequest;
                    data.enforceInterface("com.google.android.gms.drive.internal.IDriveService");
                    if (data.readInt() != 0) {
                        addEventListenerRequest = (AddEventListenerRequest) AddEventListenerRequest.CREATOR.createFromParcel(data);
                    }
                    m391a(addEventListenerRequest, C1718a.m2569W(data.readStrongBinder()), data.readString(), C1716a.m2567V(data.readStrongBinder()));
                    reply.writeNoException();
                    return true;
                case NalUnitTypes.NAL_TYPE_RSV_VCL_R15 /*15*/:
                    RemoveEventListenerRequest removeEventListenerRequest;
                    data.enforceInterface("com.google.android.gms.drive.internal.IDriveService");
                    if (data.readInt() != 0) {
                        removeEventListenerRequest = (RemoveEventListenerRequest) RemoveEventListenerRequest.CREATOR.createFromParcel(data);
                    }
                    m407a(removeEventListenerRequest, C1718a.m2569W(data.readStrongBinder()), data.readString(), C1716a.m2567V(data.readStrongBinder()));
                    reply.writeNoException();
                    return true;
                case ItemTouchHelper.START /*16*/:
                    DisconnectRequest disconnectRequest;
                    data.enforceInterface("com.google.android.gms.drive.internal.IDriveService");
                    if (data.readInt() != 0) {
                        disconnectRequest = (DisconnectRequest) DisconnectRequest.CREATOR.createFromParcel(data);
                    }
                    m400a(disconnectRequest);
                    reply.writeNoException();
                    return true;
                case NalUnitTypes.NAL_TYPE_BLA_W_RADL /*17*/:
                    TrashResourceRequest trashResourceRequest;
                    data.enforceInterface("com.google.android.gms.drive.internal.IDriveService");
                    if (data.readInt() != 0) {
                        trashResourceRequest = (TrashResourceRequest) TrashResourceRequest.CREATOR.createFromParcel(data);
                    }
                    m410a(trashResourceRequest, C1716a.m2567V(data.readStrongBinder()));
                    reply.writeNoException();
                    return true;
                case NalUnitTypes.NAL_TYPE_BLA_N_LP /*18*/:
                    CloseContentsAndUpdateMetadataRequest closeContentsAndUpdateMetadataRequest;
                    data.enforceInterface("com.google.android.gms.drive.internal.IDriveService");
                    if (data.readInt() != 0) {
                        closeContentsAndUpdateMetadataRequest = (CloseContentsAndUpdateMetadataRequest) CloseContentsAndUpdateMetadataRequest.CREATOR.createFromParcel(data);
                    }
                    m394a(closeContentsAndUpdateMetadataRequest, C1716a.m2567V(data.readStrongBinder()));
                    reply.writeNoException();
                    return true;
                case XtraBox.MP4_XTRA_BT_INT64 /*19*/:
                    data.enforceInterface("com.google.android.gms.drive.internal.IDriveService");
                    if (data.readInt() != 0) {
                        queryRequest = (QueryRequest) QueryRequest.CREATOR.createFromParcel(data);
                    }
                    m413b(queryRequest, C1716a.m2567V(data.readStrongBinder()));
                    reply.writeNoException();
                    return true;
                case NalUnitTypes.NAL_TYPE_IDR_N_LP /*20*/:
                    data.enforceInterface("com.google.android.gms.drive.internal.IDriveService");
                    m414b(C1716a.m2567V(data.readStrongBinder()));
                    reply.writeNoException();
                    return true;
                case XtraBox.MP4_XTRA_BT_FILETIME /*21*/:
                    data.enforceInterface("com.google.android.gms.drive.internal.IDriveService");
                    m415c(C1716a.m2567V(data.readStrongBinder()));
                    reply.writeNoException();
                    return true;
                case NalUnitTypes.NAL_TYPE_RSV_IRAP_VCL22 /*22*/:
                    data.enforceInterface("com.google.android.gms.drive.internal.IDriveService");
                    m416d(C1716a.m2567V(data.readStrongBinder()));
                    reply.writeNoException();
                    return true;
                case SecretChatHelper.CURRENT_SECRET_CHAT_LAYER /*23*/:
                    data.enforceInterface("com.google.android.gms.drive.internal.IDriveService");
                    m417e(C1716a.m2567V(data.readStrongBinder()));
                    reply.writeNoException();
                    return true;
                case NalUnitTypes.NAL_TYPE_RSV_VCL24 /*24*/:
                    DeleteResourceRequest deleteResourceRequest;
                    data.enforceInterface("com.google.android.gms.drive.internal.IDriveService");
                    if (data.readInt() != 0) {
                        deleteResourceRequest = (DeleteResourceRequest) DeleteResourceRequest.CREATOR.createFromParcel(data);
                    }
                    m399a(deleteResourceRequest, C1716a.m2567V(data.readStrongBinder()));
                    reply.writeNoException();
                    return true;
                case NalUnitTypes.NAL_TYPE_RSV_VCL27 /*27*/:
                    LoadRealtimeRequest loadRealtimeRequest;
                    data.enforceInterface("com.google.android.gms.drive.internal.IDriveService");
                    if (data.readInt() != 0) {
                        loadRealtimeRequest = (LoadRealtimeRequest) LoadRealtimeRequest.CREATOR.createFromParcel(data);
                    }
                    m404a(loadRealtimeRequest, C1716a.m2567V(data.readStrongBinder()));
                    reply.writeNoException();
                    return true;
                case NalUnitTypes.NAL_TYPE_RSV_VCL28 /*28*/:
                    SetResourceParentsRequest setResourceParentsRequest;
                    data.enforceInterface("com.google.android.gms.drive.internal.IDriveService");
                    if (data.readInt() != 0) {
                        setResourceParentsRequest = (SetResourceParentsRequest) SetResourceParentsRequest.CREATOR.createFromParcel(data);
                    }
                    m409a(setResourceParentsRequest, C1716a.m2567V(data.readStrongBinder()));
                    reply.writeNoException();
                    return true;
                case NalUnitTypes.NAL_TYPE_RSV_VCL29 /*29*/:
                    GetDriveIdFromUniqueIdentifierRequest getDriveIdFromUniqueIdentifierRequest;
                    data.enforceInterface("com.google.android.gms.drive.internal.IDriveService");
                    if (data.readInt() != 0) {
                        getDriveIdFromUniqueIdentifierRequest = (GetDriveIdFromUniqueIdentifierRequest) GetDriveIdFromUniqueIdentifierRequest.CREATOR.createFromParcel(data);
                    }
                    m401a(getDriveIdFromUniqueIdentifierRequest, C1716a.m2567V(data.readStrongBinder()));
                    reply.writeNoException();
                    return true;
                case NalUnitTypes.NAL_TYPE_RSV_VCL30 /*30*/:
                    CheckResourceIdsExistRequest checkResourceIdsExistRequest;
                    data.enforceInterface("com.google.android.gms.drive.internal.IDriveService");
                    if (data.readInt() != 0) {
                        checkResourceIdsExistRequest = (CheckResourceIdsExistRequest) CheckResourceIdsExistRequest.CREATOR.createFromParcel(data);
                    }
                    m393a(checkResourceIdsExistRequest, C1716a.m2567V(data.readStrongBinder()));
                    reply.writeNoException();
                    return true;
                case NalUnitTypes.NAL_TYPE_RSV_VCL31 /*31*/:
                    data.enforceInterface("com.google.android.gms.drive.internal.IDriveService");
                    m418f(C1716a.m2567V(data.readStrongBinder()));
                    reply.writeNoException();
                    return true;
                case ItemTouchHelper.END /*32*/:
                    data.enforceInterface("com.google.android.gms.drive.internal.IDriveService");
                    m419g(C1716a.m2567V(data.readStrongBinder()));
                    reply.writeNoException();
                    return true;
                case NalUnitTypes.NAL_TYPE_SPS_NUT /*33*/:
                    SetDrivePreferencesRequest setDrivePreferencesRequest;
                    data.enforceInterface("com.google.android.gms.drive.internal.IDriveService");
                    if (data.readInt() != 0) {
                        setDrivePreferencesRequest = (SetDrivePreferencesRequest) SetDrivePreferencesRequest.CREATOR.createFromParcel(data);
                    }
                    m408a(setDrivePreferencesRequest, C1716a.m2567V(data.readStrongBinder()));
                    reply.writeNoException();
                    return true;
                case TLRPC.LAYER /*34*/:
                    data.enforceInterface("com.google.android.gms.drive.internal.IDriveService");
                    if (data.readInt() != 0) {
                        realtimeDocumentSyncRequest = (RealtimeDocumentSyncRequest) RealtimeDocumentSyncRequest.CREATOR.createFromParcel(data);
                    }
                    m390a(realtimeDocumentSyncRequest, C1716a.m2567V(data.readStrongBinder()));
                    reply.writeNoException();
                    return true;
                case 1598968902:
                    reply.writeString("com.google.android.gms.drive.internal.IDriveService");
                    return true;
                default:
                    return super.onTransact(code, data, reply, flags);
            }
        }
    }

    IntentSender m388a(CreateFileIntentSenderRequest createFileIntentSenderRequest) throws RemoteException;

    IntentSender m389a(OpenFileIntentSenderRequest openFileIntentSenderRequest) throws RemoteException;

    void m390a(RealtimeDocumentSyncRequest realtimeDocumentSyncRequest, ac acVar) throws RemoteException;

    void m391a(AddEventListenerRequest addEventListenerRequest, ad adVar, String str, ac acVar) throws RemoteException;

    void m392a(AuthorizeAccessRequest authorizeAccessRequest, ac acVar) throws RemoteException;

    void m393a(CheckResourceIdsExistRequest checkResourceIdsExistRequest, ac acVar) throws RemoteException;

    void m394a(CloseContentsAndUpdateMetadataRequest closeContentsAndUpdateMetadataRequest, ac acVar) throws RemoteException;

    void m395a(CloseContentsRequest closeContentsRequest, ac acVar) throws RemoteException;

    void m396a(CreateContentsRequest createContentsRequest, ac acVar) throws RemoteException;

    void m397a(CreateFileRequest createFileRequest, ac acVar) throws RemoteException;

    void m398a(CreateFolderRequest createFolderRequest, ac acVar) throws RemoteException;

    void m399a(DeleteResourceRequest deleteResourceRequest, ac acVar) throws RemoteException;

    void m400a(DisconnectRequest disconnectRequest) throws RemoteException;

    void m401a(GetDriveIdFromUniqueIdentifierRequest getDriveIdFromUniqueIdentifierRequest, ac acVar) throws RemoteException;

    void m402a(GetMetadataRequest getMetadataRequest, ac acVar) throws RemoteException;

    void m403a(ListParentsRequest listParentsRequest, ac acVar) throws RemoteException;

    void m404a(LoadRealtimeRequest loadRealtimeRequest, ac acVar) throws RemoteException;

    void m405a(OpenContentsRequest openContentsRequest, ac acVar) throws RemoteException;

    void m406a(QueryRequest queryRequest, ac acVar) throws RemoteException;

    void m407a(RemoveEventListenerRequest removeEventListenerRequest, ad adVar, String str, ac acVar) throws RemoteException;

    void m408a(SetDrivePreferencesRequest setDrivePreferencesRequest, ac acVar) throws RemoteException;

    void m409a(SetResourceParentsRequest setResourceParentsRequest, ac acVar) throws RemoteException;

    void m410a(TrashResourceRequest trashResourceRequest, ac acVar) throws RemoteException;

    void m411a(UpdateMetadataRequest updateMetadataRequest, ac acVar) throws RemoteException;

    void m412a(ac acVar) throws RemoteException;

    void m413b(QueryRequest queryRequest, ac acVar) throws RemoteException;

    void m414b(ac acVar) throws RemoteException;

    void m415c(ac acVar) throws RemoteException;

    void m416d(ac acVar) throws RemoteException;

    void m417e(ac acVar) throws RemoteException;

    void m418f(ac acVar) throws RemoteException;

    void m419g(ac acVar) throws RemoteException;
}
