package com.google.android.gms.drive.internal;

import android.os.Parcel;
import android.os.Parcelable.Creator;
import com.google.android.gms.common.internal.C0238o;
import com.google.android.gms.common.internal.safeparcel.SafeParcelable;
import com.google.android.gms.drive.Contents;
import com.google.android.gms.drive.DriveId;
import com.google.android.gms.drive.ExecutionOptions;
import com.google.android.gms.drive.metadata.internal.MetadataBundle;

public class CreateFileRequest implements SafeParcelable {
    public static final Creator<CreateFileRequest> CREATOR;
    final int BR;
    final String Nn;
    final Contents Of;
    final MetadataBundle Ol;
    final Integer Om;
    final DriveId On;
    final boolean Oo;
    final int Op;
    final int Oq;

    static {
        CREATOR = new C0269j();
    }

    CreateFileRequest(int versionCode, DriveId parentDriveId, MetadataBundle metadata, Contents contentsReference, Integer fileType, boolean sendEventOnCompletion, String trackingTag, int createStrategy, int openContentsRequestId) {
        if (!(contentsReference == null || openContentsRequestId == 0)) {
            C0238o.m281b(contentsReference.getRequestId() == openContentsRequestId, (Object) "inconsistent contents reference");
        }
        if ((fileType == null || fileType.intValue() == 0) && contentsReference == null && openContentsRequestId == 0) {
            throw new IllegalArgumentException("Need a valid contents");
        }
        this.BR = versionCode;
        this.On = (DriveId) C0238o.m283i(parentDriveId);
        this.Ol = (MetadataBundle) C0238o.m283i(metadata);
        this.Of = contentsReference;
        this.Om = fileType;
        this.Nn = trackingTag;
        this.Op = createStrategy;
        this.Oo = sendEventOnCompletion;
        this.Oq = openContentsRequestId;
    }

    public CreateFileRequest(DriveId parentDriveId, MetadataBundle metadata, int openContentsRequestId, int fileType, ExecutionOptions executionOptions) {
        this(2, parentDriveId, metadata, null, Integer.valueOf(fileType), executionOptions.hP(), executionOptions.hO(), executionOptions.hQ(), openContentsRequestId);
    }

    public int describeContents() {
        return 0;
    }

    public void writeToParcel(Parcel dest, int flags) {
        C0269j.m468a(this, dest, flags);
    }
}
