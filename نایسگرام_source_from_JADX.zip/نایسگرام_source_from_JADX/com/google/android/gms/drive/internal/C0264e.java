package com.google.android.gms.drive.internal;

import android.os.Parcel;
import android.os.Parcelable.Creator;
import com.google.android.gms.common.internal.safeparcel.C0242a;
import com.google.android.gms.common.internal.safeparcel.C0242a.C0241a;
import com.google.android.gms.common.internal.safeparcel.C0243b;
import com.google.android.gms.drive.Contents;
import com.google.android.gms.drive.DriveId;
import com.google.android.gms.drive.events.CompletionEvent;
import com.google.android.gms.drive.metadata.internal.MetadataBundle;
import com.google.android.gms.games.quest.Quest;
import com.google.android.gms.location.DetectedActivity;
import org.telegram.android.support.widget.helper.ItemTouchHelper;
import org.telegram.android.time.FastDatePrinter;

/* renamed from: com.google.android.gms.drive.internal.e */
public class C0264e implements Creator<CloseContentsAndUpdateMetadataRequest> {
    static void m460a(CloseContentsAndUpdateMetadataRequest closeContentsAndUpdateMetadataRequest, Parcel parcel, int i) {
        int D = C0243b.m329D(parcel);
        C0243b.m356c(parcel, 1, closeContentsAndUpdateMetadataRequest.BR);
        C0243b.m340a(parcel, 2, closeContentsAndUpdateMetadataRequest.Od, i, false);
        C0243b.m340a(parcel, 3, closeContentsAndUpdateMetadataRequest.Oe, i, false);
        C0243b.m340a(parcel, 4, closeContentsAndUpdateMetadataRequest.Of, i, false);
        C0243b.m347a(parcel, 5, closeContentsAndUpdateMetadataRequest.No);
        C0243b.m344a(parcel, 6, closeContentsAndUpdateMetadataRequest.Nn, false);
        C0243b.m356c(parcel, 7, closeContentsAndUpdateMetadataRequest.Og);
        C0243b.m332H(parcel, D);
    }

    public CloseContentsAndUpdateMetadataRequest m461Y(Parcel parcel) {
        int i = 0;
        String str = null;
        int C = C0242a.m293C(parcel);
        boolean z = false;
        Contents contents = null;
        MetadataBundle metadataBundle = null;
        DriveId driveId = null;
        int i2 = 0;
        while (parcel.dataPosition() < C) {
            int B = C0242a.m291B(parcel);
            switch (C0242a.aD(B)) {
                case CompletionEvent.STATUS_FAILURE /*1*/:
                    i2 = C0242a.m309g(parcel, B);
                    break;
                case CompletionEvent.STATUS_CONFLICT /*2*/:
                    driveId = (DriveId) C0242a.m298a(parcel, B, DriveId.CREATOR);
                    break;
                case FastDatePrinter.SHORT /*3*/:
                    metadataBundle = (MetadataBundle) C0242a.m298a(parcel, B, MetadataBundle.CREATOR);
                    break;
                case ItemTouchHelper.LEFT /*4*/:
                    contents = (Contents) C0242a.m298a(parcel, B, Contents.CREATOR);
                    break;
                case DetectedActivity.TILTING /*5*/:
                    z = C0242a.m305c(parcel, B);
                    break;
                case Quest.STATE_FAILED /*6*/:
                    str = C0242a.m317o(parcel, B);
                    break;
                case DetectedActivity.WALKING /*7*/:
                    i = C0242a.m309g(parcel, B);
                    break;
                default:
                    C0242a.m302b(parcel, B);
                    break;
            }
        }
        if (parcel.dataPosition() == C) {
            return new CloseContentsAndUpdateMetadataRequest(i2, driveId, metadataBundle, contents, z, str, i);
        }
        throw new C0241a("Overread allowed size end=" + C, parcel);
    }

    public CloseContentsAndUpdateMetadataRequest[] bh(int i) {
        return new CloseContentsAndUpdateMetadataRequest[i];
    }

    public /* synthetic */ Object createFromParcel(Parcel x0) {
        return m461Y(x0);
    }

    public /* synthetic */ Object[] newArray(int x0) {
        return bh(x0);
    }
}
