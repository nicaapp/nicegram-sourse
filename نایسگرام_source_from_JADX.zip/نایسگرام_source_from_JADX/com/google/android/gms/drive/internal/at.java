package com.google.android.gms.drive.internal;

import android.os.Parcel;
import android.os.Parcelable.Creator;
import com.google.android.gms.common.internal.safeparcel.C0242a;
import com.google.android.gms.common.internal.safeparcel.C0242a.C0241a;
import com.google.android.gms.common.internal.safeparcel.C0243b;
import com.google.android.gms.drive.events.CompletionEvent;

public class at implements Creator<OnSyncMoreResponse> {
    static void m447a(OnSyncMoreResponse onSyncMoreResponse, Parcel parcel, int i) {
        int D = C0243b.m329D(parcel);
        C0243b.m356c(parcel, 1, onSyncMoreResponse.BR);
        C0243b.m347a(parcel, 2, onSyncMoreResponse.Oz);
        C0243b.m332H(parcel, D);
    }

    public OnSyncMoreResponse av(Parcel parcel) {
        boolean z = false;
        int C = C0242a.m293C(parcel);
        int i = 0;
        while (parcel.dataPosition() < C) {
            int B = C0242a.m291B(parcel);
            switch (C0242a.aD(B)) {
                case CompletionEvent.STATUS_FAILURE /*1*/:
                    i = C0242a.m309g(parcel, B);
                    break;
                case CompletionEvent.STATUS_CONFLICT /*2*/:
                    z = C0242a.m305c(parcel, B);
                    break;
                default:
                    C0242a.m302b(parcel, B);
                    break;
            }
        }
        if (parcel.dataPosition() == C) {
            return new OnSyncMoreResponse(i, z);
        }
        throw new C0241a("Overread allowed size end=" + C, parcel);
    }

    public OnSyncMoreResponse[] bH(int i) {
        return new OnSyncMoreResponse[i];
    }

    public /* synthetic */ Object createFromParcel(Parcel x0) {
        return av(x0);
    }

    public /* synthetic */ Object[] newArray(int x0) {
        return bH(x0);
    }
}
