package com.google.android.gms.drive.internal;

import android.content.IntentSender;
import com.google.android.gms.common.api.GoogleApiClient;
import com.google.android.gms.common.internal.C0238o;
import com.google.android.gms.drive.Drive;
import com.google.android.gms.drive.DriveId;
import com.google.android.gms.drive.MetadataChangeSet;

/* renamed from: com.google.android.gms.drive.internal.h */
public class C0267h {
    private String Nw;
    private DriveId Ny;
    protected MetadataChangeSet Oi;
    private Integer Oj;
    private final int Ok;

    public C0267h(int i) {
        this.Ok = i;
    }

    public void m465a(DriveId driveId) {
        this.Ny = (DriveId) C0238o.m283i(driveId);
    }

    public void m466a(MetadataChangeSet metadataChangeSet) {
        this.Oi = (MetadataChangeSet) C0238o.m283i(metadataChangeSet);
    }

    public void bi(String str) {
        this.Nw = (String) C0238o.m283i(str);
    }

    public void bk(int i) {
        this.Oj = Integer.valueOf(i);
    }

    public IntentSender build(GoogleApiClient apiClient) {
        C0238o.m279b(this.Oi, (Object) "Must provide initial metadata to CreateFileActivityBuilder.");
        C0238o.m277a(apiClient.isConnected(), "Client must be connected");
        C2398q c2398q = (C2398q) apiClient.m149a(Drive.CU);
        this.Oi.hS().setContext(c2398q.getContext());
        try {
            return c2398q.hY().m388a(new CreateFileIntentSenderRequest(this.Oi.hS(), this.Oj == null ? -1 : this.Oj.intValue(), this.Nw, this.Ny, this.Ok));
        } catch (Throwable e) {
            throw new RuntimeException("Unable to connect Drive Play Service", e);
        }
    }
}
