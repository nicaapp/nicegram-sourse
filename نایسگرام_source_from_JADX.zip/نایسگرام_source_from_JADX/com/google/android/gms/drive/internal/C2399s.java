package com.google.android.gms.drive.internal;

import android.os.RemoteException;
import com.google.android.gms.common.api.BaseImplementation.C0191b;
import com.google.android.gms.common.api.C0198c;
import com.google.android.gms.common.api.C0198c.C0197b;
import com.google.android.gms.common.api.GoogleApiClient;
import com.google.android.gms.common.api.PendingResult;
import com.google.android.gms.common.api.Status;
import com.google.android.gms.drive.Contents;
import com.google.android.gms.drive.Drive;
import com.google.android.gms.drive.DriveApi.ContentsResult;
import com.google.android.gms.drive.DriveApi.DriveContentsResult;
import com.google.android.gms.drive.DriveFile;
import com.google.android.gms.drive.DriveFile.DownloadProgressListener;
import com.google.android.gms.drive.DriveId;
import com.google.android.gms.drive.MetadataChangeSet;
import com.google.android.gms.drive.internal.C1721o.C2394a;
import com.google.android.gms.drive.internal.C1721o.C2656b;
import com.google.android.gms.drive.internal.C1721o.C2657d;

/* renamed from: com.google.android.gms.drive.internal.s */
public class C2399s extends C1727w implements DriveFile {

    /* renamed from: com.google.android.gms.drive.internal.s.a */
    private static class C1725a implements DownloadProgressListener {
        private final C0198c<DownloadProgressListener> OQ;

        /* renamed from: com.google.android.gms.drive.internal.s.a.1 */
        class C17241 implements C0197b<DownloadProgressListener> {
            final /* synthetic */ long OR;
            final /* synthetic */ long OS;
            final /* synthetic */ C1725a OT;

            C17241(C1725a c1725a, long j, long j2) {
                this.OT = c1725a;
                this.OR = j;
                this.OS = j2;
            }

            public void m2576a(DownloadProgressListener downloadProgressListener) {
                downloadProgressListener.onProgress(this.OR, this.OS);
            }

            public /* synthetic */ void m2577d(Object obj) {
                m2576a((DownloadProgressListener) obj);
            }

            public void gr() {
            }
        }

        public C1725a(C0198c<DownloadProgressListener> c0198c) {
            this.OQ = c0198c;
        }

        public void onProgress(long bytesDownloaded, long bytesExpected) {
            this.OQ.m162a(new C17241(this, bytesDownloaded, bytesExpected));
        }
    }

    /* renamed from: com.google.android.gms.drive.internal.s.b */
    private static class C2601b extends C2392c {
        private final C0191b<ContentsResult> De;
        private final DownloadProgressListener OU;

        public C2601b(C0191b<ContentsResult> c0191b, DownloadProgressListener downloadProgressListener) {
            this.De = c0191b;
            this.OU = downloadProgressListener;
        }

        public void m4621a(OnContentsResponse onContentsResponse) throws RemoteException {
            this.De.m147b(new C2394a(onContentsResponse.ie() ? new Status(-1) : Status.Jv, onContentsResponse.id()));
        }

        public void m4622a(OnDownloadProgressResponse onDownloadProgressResponse) throws RemoteException {
            if (this.OU != null) {
                this.OU.onProgress(onDownloadProgressResponse.m2519if(), onDownloadProgressResponse.ig());
            }
        }

        public void m4623o(Status status) throws RemoteException {
            this.De.m147b(new C2394a(status, null));
        }
    }

    /* renamed from: com.google.android.gms.drive.internal.s.1 */
    class C27531 extends C2656b {
        final /* synthetic */ DownloadProgressListener OO;
        final /* synthetic */ C2399s OP;
        final /* synthetic */ int Ou;

        C27531(C2399s c2399s, int i, DownloadProgressListener downloadProgressListener) {
            this.OP = c2399s;
            this.Ou = i;
            this.OO = downloadProgressListener;
        }

        protected void m5142a(C2398q c2398q) throws RemoteException {
            c2398q.hY().m405a(new OpenContentsRequest(this.OP.getDriveId(), this.Ou, 0), new C2601b(this, this.OO));
        }
    }

    /* renamed from: com.google.android.gms.drive.internal.s.2 */
    class C27542 extends C2657d {
        final /* synthetic */ DownloadProgressListener OO;
        final /* synthetic */ C2399s OP;
        final /* synthetic */ int Ou;

        C27542(C2399s c2399s, int i, DownloadProgressListener downloadProgressListener) {
            this.OP = c2399s;
            this.Ou = i;
            this.OO = downloadProgressListener;
        }

        protected void m5144a(C2398q c2398q) throws RemoteException {
            c2398q.hY().m405a(new OpenContentsRequest(this.OP.getDriveId(), this.Ou, 0), new av(this, this.OO));
        }
    }

    public C2399s(DriveId driveId) {
        super(driveId);
    }

    private static DownloadProgressListener m3859a(GoogleApiClient googleApiClient, DownloadProgressListener downloadProgressListener) {
        return downloadProgressListener == null ? null : new C1725a(googleApiClient.m153c(downloadProgressListener));
    }

    public PendingResult<Status> commitAndCloseContents(GoogleApiClient client, Contents contents) {
        return new C1723r(contents).commit(client, null);
    }

    public PendingResult<Status> commitAndCloseContents(GoogleApiClient client, Contents contents, MetadataChangeSet changeSet) {
        return new C1723r(contents).commit(client, changeSet);
    }

    public PendingResult<Status> discardContents(GoogleApiClient apiClient, Contents contents) {
        return Drive.DriveApi.discardContents(apiClient, contents);
    }

    public PendingResult<DriveContentsResult> open(GoogleApiClient apiClient, int mode, DownloadProgressListener listener) {
        if (mode == DriveFile.MODE_READ_ONLY || mode == DriveFile.MODE_WRITE_ONLY || mode == DriveFile.MODE_READ_WRITE) {
            return apiClient.m150a(new C27542(this, mode, C2399s.m3859a(apiClient, listener)));
        }
        throw new IllegalArgumentException("Invalid mode provided.");
    }

    public PendingResult<ContentsResult> openContents(GoogleApiClient apiClient, int mode, DownloadProgressListener listener) {
        if (mode == DriveFile.MODE_READ_ONLY || mode == DriveFile.MODE_WRITE_ONLY || mode == DriveFile.MODE_READ_WRITE) {
            return apiClient.m150a(new C27531(this, mode, C2399s.m3859a(apiClient, listener)));
        }
        throw new IllegalArgumentException("Invalid mode provided.");
    }
}
