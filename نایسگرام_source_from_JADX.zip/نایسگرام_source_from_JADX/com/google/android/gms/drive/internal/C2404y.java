package com.google.android.gms.drive.internal;

import android.content.Context;
import android.os.Handler;
import android.os.Looper;
import android.os.Message;
import android.os.RemoteException;
import android.util.Pair;
import com.google.android.gms.common.internal.C0238o;
import com.google.android.gms.drive.events.C0255c;
import com.google.android.gms.drive.events.ChangeEvent;
import com.google.android.gms.drive.events.ChangeListener;
import com.google.android.gms.drive.events.CompletionEvent;
import com.google.android.gms.drive.events.CompletionListener;
import com.google.android.gms.drive.events.DriveEvent;
import com.google.android.gms.drive.events.DriveEvent.Listener;
import com.google.android.gms.drive.internal.ad.C1718a;
import java.util.ArrayList;
import java.util.List;

/* renamed from: com.google.android.gms.drive.internal.y */
public class C2404y extends C1718a {
    private final int Oa;
    private final C0255c Pe;
    private final C0275a Pf;
    private final List<Integer> Pg;

    /* renamed from: com.google.android.gms.drive.internal.y.a */
    private static class C0275a extends Handler {
        private final Context mContext;

        private C0275a(Looper looper, Context context) {
            super(looper);
            this.mContext = context;
        }

        public void m477a(C0255c c0255c, DriveEvent driveEvent) {
            sendMessage(obtainMessage(1, new Pair(c0255c, driveEvent)));
        }

        public void handleMessage(Message msg) {
            switch (msg.what) {
                case CompletionEvent.STATUS_FAILURE /*1*/:
                    Pair pair = (Pair) msg.obj;
                    C0255c c0255c = (C0255c) pair.first;
                    DriveEvent driveEvent = (DriveEvent) pair.second;
                    switch (driveEvent.getType()) {
                        case CompletionEvent.STATUS_FAILURE /*1*/:
                            if (c0255c instanceof Listener) {
                                ((Listener) c0255c).onEvent((ChangeEvent) driveEvent);
                            } else {
                                ((ChangeListener) c0255c).onChange((ChangeEvent) driveEvent);
                            }
                        case CompletionEvent.STATUS_CONFLICT /*2*/:
                            ((CompletionListener) c0255c).onCompletion((CompletionEvent) driveEvent);
                        default:
                            C0273v.m475p("EventCallback", "Unexpected event: " + driveEvent);
                    }
                default:
                    C0273v.m473e(this.mContext, "EventCallback", "Don't know how to handle this event");
            }
        }
    }

    public C2404y(Looper looper, Context context, int i, C0255c c0255c) {
        this.Pg = new ArrayList();
        this.Oa = i;
        this.Pe = c0255c;
        this.Pf = new C0275a(context, null);
    }

    public void bq(int i) {
        this.Pg.add(Integer.valueOf(i));
    }

    public boolean br(int i) {
        return this.Pg.contains(Integer.valueOf(i));
    }

    public void m3862c(OnEventResponse onEventResponse) throws RemoteException {
        DriveEvent ih = onEventResponse.ih();
        C0238o.m275I(this.Oa == ih.getType());
        C0238o.m275I(this.Pg.contains(Integer.valueOf(ih.getType())));
        this.Pf.m477a(this.Pe, ih);
    }
}
