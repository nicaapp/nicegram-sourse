package com.google.android.gms.drive.internal;

import android.os.RemoteException;
import com.google.android.gms.common.api.Status;
import com.google.android.gms.drive.internal.ac.C1716a;
import com.google.android.gms.drive.realtime.internal.C0321m;

/* renamed from: com.google.android.gms.drive.internal.c */
public class C2392c extends C1716a {
    public void m3838a(OnContentsResponse onContentsResponse) throws RemoteException {
    }

    public void m3839a(OnDownloadProgressResponse onDownloadProgressResponse) throws RemoteException {
    }

    public void m3840a(OnDriveIdResponse onDriveIdResponse) throws RemoteException {
    }

    public void m3841a(OnDrivePreferencesResponse onDrivePreferencesResponse) throws RemoteException {
    }

    public void m3842a(OnListEntriesResponse onListEntriesResponse) throws RemoteException {
    }

    public void m3843a(OnListParentsResponse onListParentsResponse) throws RemoteException {
    }

    public void m3844a(OnLoadRealtimeResponse onLoadRealtimeResponse, C0321m c0321m) throws RemoteException {
    }

    public void m3845a(OnMetadataResponse onMetadataResponse) throws RemoteException {
    }

    public void m3846a(OnResourceIdSetResponse onResourceIdSetResponse) throws RemoteException {
    }

    public void m3847a(OnStorageStatsResponse onStorageStatsResponse) throws RemoteException {
    }

    public void m3848a(OnSyncMoreResponse onSyncMoreResponse) throws RemoteException {
    }

    public void m3849o(Status status) throws RemoteException {
    }

    public void onSuccess() throws RemoteException {
    }
}
