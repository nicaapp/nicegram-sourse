package com.google.android.gms.drive.internal;

import android.content.Context;
import com.google.android.gms.common.internal.C0230i;

/* renamed from: com.google.android.gms.drive.internal.v */
public final class C0273v {
    private static final C0230i Pa;

    static {
        Pa = new C0230i("GmsDrive");
    }

    public static void m472a(String str, Throwable th, String str2) {
        Pa.m225c(str, str2, th);
    }

    public static void m473e(Context context, String str, String str2) {
        Pa.m222a(context, str, str2, new Throwable());
    }

    public static void m474n(String str, String str2) {
        Pa.m226n(str, str2);
    }

    public static void m475p(String str, String str2) {
        Pa.m228p(str, str2);
    }

    public static void m476q(String str, String str2) {
        Pa.m229q(str, str2);
    }
}
