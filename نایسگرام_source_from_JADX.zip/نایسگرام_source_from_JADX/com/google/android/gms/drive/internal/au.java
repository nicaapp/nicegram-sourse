package com.google.android.gms.drive.internal;

import android.os.Parcel;
import android.os.Parcelable.Creator;
import com.google.android.gms.common.internal.safeparcel.C0242a;
import com.google.android.gms.common.internal.safeparcel.C0242a.C0241a;
import com.google.android.gms.common.internal.safeparcel.C0243b;
import com.google.android.gms.drive.DriveId;
import com.google.android.gms.drive.events.CompletionEvent;
import org.telegram.android.support.widget.helper.ItemTouchHelper;
import org.telegram.android.time.FastDatePrinter;

public class au implements Creator<OpenContentsRequest> {
    static void m448a(OpenContentsRequest openContentsRequest, Parcel parcel, int i) {
        int D = C0243b.m329D(parcel);
        C0243b.m356c(parcel, 1, openContentsRequest.BR);
        C0243b.m340a(parcel, 2, openContentsRequest.Od, i, false);
        C0243b.m356c(parcel, 3, openContentsRequest.MV);
        C0243b.m356c(parcel, 4, openContentsRequest.Px);
        C0243b.m332H(parcel, D);
    }

    public OpenContentsRequest aw(Parcel parcel) {
        int i = 0;
        int C = C0242a.m293C(parcel);
        DriveId driveId = null;
        int i2 = 0;
        int i3 = 0;
        while (parcel.dataPosition() < C) {
            DriveId driveId2;
            int g;
            int B = C0242a.m291B(parcel);
            int i4;
            switch (C0242a.aD(B)) {
                case CompletionEvent.STATUS_FAILURE /*1*/:
                    i4 = i;
                    i = i2;
                    driveId2 = driveId;
                    g = C0242a.m309g(parcel, B);
                    B = i4;
                    break;
                case CompletionEvent.STATUS_CONFLICT /*2*/:
                    g = i3;
                    i4 = i2;
                    driveId2 = (DriveId) C0242a.m298a(parcel, B, DriveId.CREATOR);
                    B = i;
                    i = i4;
                    break;
                case FastDatePrinter.SHORT /*3*/:
                    driveId2 = driveId;
                    g = i3;
                    i4 = i;
                    i = C0242a.m309g(parcel, B);
                    B = i4;
                    break;
                case ItemTouchHelper.LEFT /*4*/:
                    B = C0242a.m309g(parcel, B);
                    i = i2;
                    driveId2 = driveId;
                    g = i3;
                    break;
                default:
                    C0242a.m302b(parcel, B);
                    B = i;
                    i = i2;
                    driveId2 = driveId;
                    g = i3;
                    break;
            }
            i3 = g;
            driveId = driveId2;
            i2 = i;
            i = B;
        }
        if (parcel.dataPosition() == C) {
            return new OpenContentsRequest(i3, driveId, i2, i);
        }
        throw new C0241a("Overread allowed size end=" + C, parcel);
    }

    public OpenContentsRequest[] bI(int i) {
        return new OpenContentsRequest[i];
    }

    public /* synthetic */ Object createFromParcel(Parcel x0) {
        return aw(x0);
    }

    public /* synthetic */ Object[] newArray(int x0) {
        return bI(x0);
    }
}
