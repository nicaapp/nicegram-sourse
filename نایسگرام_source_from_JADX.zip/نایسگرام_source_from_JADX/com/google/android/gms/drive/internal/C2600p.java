package com.google.android.gms.drive.internal;

import com.google.android.gms.common.api.BaseImplementation.C2381a;
import com.google.android.gms.common.api.Result;
import com.google.android.gms.common.api.Status;
import com.google.android.gms.drive.Drive;

/* renamed from: com.google.android.gms.drive.internal.p */
abstract class C2600p<R extends Result> extends C2381a<R, C2398q> {

    /* renamed from: com.google.android.gms.drive.internal.p.a */
    static abstract class C2660a extends C2600p<Status> {
        C2660a() {
        }

        protected /* synthetic */ Result m4850c(Status status) {
            return m4851d(status);
        }

        protected Status m4851d(Status status) {
            return status;
        }
    }

    public C2600p() {
        super(Drive.CU);
    }
}
