package com.google.android.gms.drive.internal;

import android.os.Parcel;
import android.os.Parcelable.Creator;
import com.google.android.gms.common.internal.safeparcel.C0242a;
import com.google.android.gms.common.internal.safeparcel.C0242a.C0241a;
import com.google.android.gms.common.internal.safeparcel.C0243b;
import com.google.android.gms.drive.Contents;
import com.google.android.gms.drive.events.CompletionEvent;
import org.telegram.android.time.FastDatePrinter;

/* renamed from: com.google.android.gms.drive.internal.f */
public class C0265f implements Creator<CloseContentsRequest> {
    static void m462a(CloseContentsRequest closeContentsRequest, Parcel parcel, int i) {
        int D = C0243b.m329D(parcel);
        C0243b.m356c(parcel, 1, closeContentsRequest.BR);
        C0243b.m340a(parcel, 2, closeContentsRequest.Of, i, false);
        C0243b.m341a(parcel, 3, closeContentsRequest.Oh, false);
        C0243b.m332H(parcel, D);
    }

    public CloseContentsRequest m463Z(Parcel parcel) {
        Boolean bool = null;
        int C = C0242a.m293C(parcel);
        int i = 0;
        Contents contents = null;
        while (parcel.dataPosition() < C) {
            Contents contents2;
            int g;
            Boolean bool2;
            int B = C0242a.m291B(parcel);
            switch (C0242a.aD(B)) {
                case CompletionEvent.STATUS_FAILURE /*1*/:
                    Boolean bool3 = bool;
                    contents2 = contents;
                    g = C0242a.m309g(parcel, B);
                    bool2 = bool3;
                    break;
                case CompletionEvent.STATUS_CONFLICT /*2*/:
                    g = i;
                    Contents contents3 = (Contents) C0242a.m298a(parcel, B, Contents.CREATOR);
                    bool2 = bool;
                    contents2 = contents3;
                    break;
                case FastDatePrinter.SHORT /*3*/:
                    bool2 = C0242a.m306d(parcel, B);
                    contents2 = contents;
                    g = i;
                    break;
                default:
                    C0242a.m302b(parcel, B);
                    bool2 = bool;
                    contents2 = contents;
                    g = i;
                    break;
            }
            i = g;
            contents = contents2;
            bool = bool2;
        }
        if (parcel.dataPosition() == C) {
            return new CloseContentsRequest(i, contents, bool);
        }
        throw new C0241a("Overread allowed size end=" + C, parcel);
    }

    public CloseContentsRequest[] bi(int i) {
        return new CloseContentsRequest[i];
    }

    public /* synthetic */ Object createFromParcel(Parcel x0) {
        return m463Z(x0);
    }

    public /* synthetic */ Object[] newArray(int x0) {
        return bi(x0);
    }
}
