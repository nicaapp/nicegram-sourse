package com.google.android.gms.drive.internal;

import android.os.Parcel;
import android.os.Parcelable.Creator;
import com.google.android.gms.common.internal.safeparcel.SafeParcelable;

public class OnSyncMoreResponse implements SafeParcelable {
    public static final Creator<OnSyncMoreResponse> CREATOR;
    final int BR;
    final boolean Oz;

    static {
        CREATOR = new at();
    }

    OnSyncMoreResponse(int versionCode, boolean moreEntriesMayExist) {
        this.BR = versionCode;
        this.Oz = moreEntriesMayExist;
    }

    public int describeContents() {
        return 0;
    }

    public void writeToParcel(Parcel dest, int flags) {
        at.m447a(this, dest, flags);
    }
}
