package com.google.android.gms.drive.internal;

import android.os.RemoteException;
import com.google.android.gms.common.api.BaseImplementation.C0191b;
import com.google.android.gms.common.api.BaseImplementation.CallbackHandler;
import com.google.android.gms.common.api.GoogleApiClient;
import com.google.android.gms.common.api.PendingResult;
import com.google.android.gms.common.api.Result;
import com.google.android.gms.common.api.Status;
import com.google.android.gms.drive.Contents;
import com.google.android.gms.drive.CreateFileActivityBuilder;
import com.google.android.gms.drive.Drive;
import com.google.android.gms.drive.DriveApi;
import com.google.android.gms.drive.DriveApi.ContentsResult;
import com.google.android.gms.drive.DriveApi.DriveContentsResult;
import com.google.android.gms.drive.DriveApi.DriveIdResult;
import com.google.android.gms.drive.DriveApi.MetadataBufferResult;
import com.google.android.gms.drive.DriveContents;
import com.google.android.gms.drive.DriveFile;
import com.google.android.gms.drive.DriveFolder;
import com.google.android.gms.drive.DriveId;
import com.google.android.gms.drive.MetadataBuffer;
import com.google.android.gms.drive.OpenFileActivityBuilder;
import com.google.android.gms.drive.internal.C2600p.C2660a;
import com.google.android.gms.drive.query.Query;

/* renamed from: com.google.android.gms.drive.internal.o */
public class C1721o implements DriveApi {

    /* renamed from: com.google.android.gms.drive.internal.o.a */
    static class C2394a implements ContentsResult {
        private final Status CM;
        private final Contents Ox;

        public C2394a(Status status, Contents contents) {
            this.CM = status;
            this.Ox = contents;
        }

        public Contents getContents() {
            return this.Ox;
        }

        public Status getStatus() {
            return this.CM;
        }
    }

    /* renamed from: com.google.android.gms.drive.internal.o.c */
    static class C2395c implements DriveContentsResult {
        private final Status CM;
        private final DriveContents Nb;

        public C2395c(Status status, DriveContents driveContents) {
            this.CM = status;
            this.Nb = driveContents;
        }

        public DriveContents getDriveContents() {
            return this.Nb;
        }

        public Status getStatus() {
            return this.CM;
        }
    }

    /* renamed from: com.google.android.gms.drive.internal.o.f */
    private static class C2396f implements DriveIdResult {
        private final Status CM;
        private final DriveId MW;

        public C2396f(Status status, DriveId driveId) {
            this.CM = status;
            this.MW = driveId;
        }

        public DriveId getDriveId() {
            return this.MW;
        }

        public Status getStatus() {
            return this.CM;
        }
    }

    /* renamed from: com.google.android.gms.drive.internal.o.h */
    static class C2397h implements MetadataBufferResult {
        private final Status CM;
        private final MetadataBuffer Oy;
        private final boolean Oz;

        public C2397h(Status status, MetadataBuffer metadataBuffer, boolean z) {
            this.CM = status;
            this.Oy = metadataBuffer;
            this.Oz = z;
        }

        public MetadataBuffer getMetadataBuffer() {
            return this.Oy;
        }

        public Status getStatus() {
            return this.CM;
        }
    }

    /* renamed from: com.google.android.gms.drive.internal.o.e */
    static class C2596e extends C2392c {
        private final C0191b<DriveIdResult> De;

        public C2596e(C0191b<DriveIdResult> c0191b) {
            this.De = c0191b;
        }

        public void m4612a(OnDriveIdResponse onDriveIdResponse) throws RemoteException {
            this.De.m147b(new C2396f(Status.Jv, onDriveIdResponse.getDriveId()));
        }

        public void m4613a(OnMetadataResponse onMetadataResponse) throws RemoteException {
            this.De.m147b(new C2396f(Status.Jv, new C2393l(onMetadataResponse.il()).getDriveId()));
        }

        public void m4614o(Status status) throws RemoteException {
            this.De.m147b(new C2396f(status, null));
        }
    }

    /* renamed from: com.google.android.gms.drive.internal.o.j */
    private static class C2597j extends C2392c {
        private final C0191b<ContentsResult> De;

        public C2597j(C0191b<ContentsResult> c0191b) {
            this.De = c0191b;
        }

        public void m4615a(OnContentsResponse onContentsResponse) throws RemoteException {
            this.De.m147b(new C2394a(Status.Jv, onContentsResponse.id()));
        }

        public void m4616o(Status status) throws RemoteException {
            this.De.m147b(new C2394a(status, null));
        }
    }

    /* renamed from: com.google.android.gms.drive.internal.o.k */
    private static class C2598k extends C2392c {
        private final C0191b<DriveContentsResult> De;

        public C2598k(C0191b<DriveContentsResult> c0191b) {
            this.De = c0191b;
        }

        public void m4617a(OnContentsResponse onContentsResponse) throws RemoteException {
            this.De.m147b(new C2395c(Status.Jv, new C1723r(onContentsResponse.id())));
        }

        public void m4618o(Status status) throws RemoteException {
            this.De.m147b(new C2395c(status, null));
        }
    }

    /* renamed from: com.google.android.gms.drive.internal.o.l */
    private static class C2599l extends C2392c {
        private final C0191b<MetadataBufferResult> De;

        public C2599l(C0191b<MetadataBufferResult> c0191b) {
            this.De = c0191b;
        }

        public void m4619a(OnListEntriesResponse onListEntriesResponse) throws RemoteException {
            this.De.m147b(new C2397h(Status.Jv, new MetadataBuffer(onListEntriesResponse.ii(), null), onListEntriesResponse.ij()));
        }

        public void m4620o(Status status) throws RemoteException {
            this.De.m147b(new C2397h(status, null, false));
        }
    }

    /* renamed from: com.google.android.gms.drive.internal.o.b */
    static abstract class C2656b extends C2600p<ContentsResult> {
        C2656b() {
        }

        public /* synthetic */ Result m4842c(Status status) {
            return m4843p(status);
        }

        public ContentsResult m4843p(Status status) {
            return new C2394a(status, null);
        }
    }

    /* renamed from: com.google.android.gms.drive.internal.o.d */
    static abstract class C2657d extends C2600p<DriveContentsResult> {
        C2657d() {
        }

        public /* synthetic */ Result m4844c(Status status) {
            return m4845q(status);
        }

        public DriveContentsResult m4845q(Status status) {
            return new C2395c(status, null);
        }
    }

    /* renamed from: com.google.android.gms.drive.internal.o.g */
    static abstract class C2658g extends C2600p<DriveIdResult> {
        C2658g() {
        }

        public /* synthetic */ Result m4846c(Status status) {
            return m4847r(status);
        }

        public DriveIdResult m4847r(Status status) {
            return new C2396f(status, null);
        }
    }

    /* renamed from: com.google.android.gms.drive.internal.o.i */
    static abstract class C2659i extends C2600p<MetadataBufferResult> {
        C2659i() {
        }

        public /* synthetic */ Result m4848c(Status status) {
            return m4849s(status);
        }

        public MetadataBufferResult m4849s(Status status) {
            return new C2397h(status, null, false);
        }
    }

    /* renamed from: com.google.android.gms.drive.internal.o.1 */
    class C27391 extends C2659i {
        final /* synthetic */ Query Os;
        final /* synthetic */ C1721o Ot;

        C27391(C1721o c1721o, Query query) {
            this.Ot = c1721o;
            this.Os = query;
        }

        protected void m5114a(C2398q c2398q) throws RemoteException {
            c2398q.hY().m406a(new QueryRequest(this.Os), new C2599l(this));
        }
    }

    /* renamed from: com.google.android.gms.drive.internal.o.2 */
    class C27402 extends C2656b {
        final /* synthetic */ C1721o Ot;

        C27402(C1721o c1721o) {
            this.Ot = c1721o;
        }

        protected void m5116a(C2398q c2398q) throws RemoteException {
            c2398q.hY().m396a(new CreateContentsRequest(DriveFile.MODE_WRITE_ONLY), new C2597j(this));
        }
    }

    /* renamed from: com.google.android.gms.drive.internal.o.3 */
    class C27413 extends C2657d {
        final /* synthetic */ C1721o Ot;
        final /* synthetic */ int Ou;

        C27413(C1721o c1721o, int i) {
            this.Ot = c1721o;
            this.Ou = i;
        }

        protected void m5118a(C2398q c2398q) throws RemoteException {
            c2398q.hY().m396a(new CreateContentsRequest(this.Ou), new C2598k(this));
        }
    }

    /* renamed from: com.google.android.gms.drive.internal.o.4 */
    class C27424 extends C2660a {
        final /* synthetic */ C1721o Ot;
        final /* synthetic */ Contents Ov;

        C27424(C1721o c1721o, Contents contents) {
            this.Ot = c1721o;
            this.Ov = contents;
        }

        protected void m5120a(C2398q c2398q) throws RemoteException {
            c2398q.hY().m395a(new CloseContentsRequest(this.Ov, false), new bb(this));
        }
    }

    /* renamed from: com.google.android.gms.drive.internal.o.5 */
    class C27435 extends C2658g {
        final /* synthetic */ C1721o Ot;
        final /* synthetic */ String Ow;

        C27435(C1721o c1721o, String str) {
            this.Ot = c1721o;
            this.Ow = str;
        }

        protected void m5122a(C2398q c2398q) throws RemoteException {
            c2398q.hY().m402a(new GetMetadataRequest(DriveId.bg(this.Ow)), new C2596e(this));
        }
    }

    /* renamed from: com.google.android.gms.drive.internal.o.6 */
    class C27446 extends C2660a {
        final /* synthetic */ C1721o Ot;

        C27446(C1721o c1721o) {
            this.Ot = c1721o;
        }

        protected void m5124a(C2398q c2398q) throws RemoteException {
            c2398q.hY().m412a(new bb(this));
        }
    }

    /* renamed from: com.google.android.gms.drive.internal.o.m */
    static class C2745m extends C2660a {
        C2745m(GoogleApiClient googleApiClient, Status status) {
            m2386a(new CallbackHandler(((C2398q) googleApiClient.m149a(Drive.CU)).getLooper()));
            m2389b((Result) status);
        }

        protected void m5126a(C2398q c2398q) {
        }
    }

    public PendingResult<DriveContentsResult> m2572a(GoogleApiClient googleApiClient, int i) {
        return googleApiClient.m150a(new C27413(this, i));
    }

    public PendingResult<Status> discardContents(GoogleApiClient apiClient, Contents contents) {
        if (contents.hK()) {
            throw new IllegalStateException("DriveContents already closed.");
        }
        contents.hJ();
        return apiClient.m152b(new C27424(this, contents));
    }

    public PendingResult<DriveIdResult> fetchDriveId(GoogleApiClient apiClient, String resourceId) {
        return apiClient.m150a(new C27435(this, resourceId));
    }

    public DriveFolder getAppFolder(GoogleApiClient apiClient) {
        if (apiClient.isConnected()) {
            DriveId ia = ((C2398q) apiClient.m149a(Drive.CU)).ia();
            return ia != null ? new C2402u(ia) : null;
        } else {
            throw new IllegalStateException("Client must be connected");
        }
    }

    public DriveFile getFile(GoogleApiClient apiClient, DriveId id) {
        if (id == null) {
            throw new IllegalArgumentException("Id must be provided.");
        } else if (apiClient.isConnected()) {
            return new C2399s(id);
        } else {
            throw new IllegalStateException("Client must be connected");
        }
    }

    public DriveFolder getFolder(GoogleApiClient apiClient, DriveId id) {
        if (id == null) {
            throw new IllegalArgumentException("Id must be provided.");
        } else if (apiClient.isConnected()) {
            return new C2402u(id);
        } else {
            throw new IllegalStateException("Client must be connected");
        }
    }

    public DriveFolder getRootFolder(GoogleApiClient apiClient) {
        if (apiClient.isConnected()) {
            return new C2402u(((C2398q) apiClient.m149a(Drive.CU)).hZ());
        }
        throw new IllegalStateException("Client must be connected");
    }

    public PendingResult<ContentsResult> newContents(GoogleApiClient apiClient) {
        return apiClient.m150a(new C27402(this));
    }

    public CreateFileActivityBuilder newCreateFileActivityBuilder() {
        return new CreateFileActivityBuilder();
    }

    public PendingResult<DriveContentsResult> newDriveContents(GoogleApiClient apiClient) {
        return m2572a(apiClient, DriveFile.MODE_WRITE_ONLY);
    }

    public OpenFileActivityBuilder newOpenFileActivityBuilder() {
        return new OpenFileActivityBuilder();
    }

    public PendingResult<MetadataBufferResult> query(GoogleApiClient apiClient, Query query) {
        if (query != null) {
            return apiClient.m150a(new C27391(this, query));
        }
        throw new IllegalArgumentException("Query must be provided.");
    }

    public PendingResult<Status> requestSync(GoogleApiClient apiClient) {
        return apiClient.m152b(new C27446(this));
    }
}
