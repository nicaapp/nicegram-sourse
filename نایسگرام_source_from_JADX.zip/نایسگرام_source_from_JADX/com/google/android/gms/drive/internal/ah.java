package com.google.android.gms.drive.internal;

import com.google.android.gms.internal.pf;
import com.google.android.gms.internal.pg;
import com.google.android.gms.internal.ph;
import com.google.android.gms.internal.pm;
import com.google.android.gms.internal.pn;
import com.googlecode.mp4parser.authoring.tracks.h265.NalUnitTypes;
import com.googlecode.mp4parser.boxes.microsoft.XtraBox;
import java.io.IOException;
import org.telegram.android.support.widget.helper.ItemTouchHelper;
import org.telegram.android.time.FastDatePrinter;
import org.telegram.messenger.BuildConfig;

public final class ah extends ph<ah> {
    public String Pl;
    public long Pm;
    public long Pn;
    public int versionCode;

    public ah() {
        ic();
    }

    public static ah m3833g(byte[] bArr) throws pm {
        return (ah) pn.m1835a(new ah(), bArr);
    }

    public void m3834a(pg pgVar) throws IOException {
        pgVar.m1812s(1, this.versionCode);
        pgVar.m1803b(2, this.Pl);
        pgVar.m1806c(3, this.Pm);
        pgVar.m1806c(4, this.Pn);
        super.m3435a(pgVar);
    }

    public /* synthetic */ pn m3835b(pf pfVar) throws IOException {
        return m3837m(pfVar);
    }

    protected int m3836c() {
        return (((super.m3438c() + pg.m1790u(1, this.versionCode)) + pg.m1787j(2, this.Pl)) + pg.m1784e(3, this.Pm)) + pg.m1784e(4, this.Pn);
    }

    public boolean equals(Object o) {
        if (o == this) {
            return true;
        }
        if (!(o instanceof ah)) {
            return false;
        }
        ah ahVar = (ah) o;
        if (this.versionCode != ahVar.versionCode) {
            return false;
        }
        if (this.Pl == null) {
            if (ahVar.Pl != null) {
                return false;
            }
        } else if (!this.Pl.equals(ahVar.Pl)) {
            return false;
        }
        return (this.Pm == ahVar.Pm && this.Pn == ahVar.Pn) ? m3437a((ph) ahVar) : false;
    }

    public int hashCode() {
        return (((((((this.Pl == null ? 0 : this.Pl.hashCode()) + ((this.versionCode + 527) * 31)) * 31) + ((int) (this.Pm ^ (this.Pm >>> 32)))) * 31) + ((int) (this.Pn ^ (this.Pn >>> 32)))) * 31) + qz();
    }

    public ah ic() {
        this.versionCode = 1;
        this.Pl = BuildConfig.FLAVOR;
        this.Pm = -1;
        this.Pn = -1;
        this.awJ = null;
        this.awU = -1;
        return this;
    }

    public ah m3837m(pf pfVar) throws IOException {
        while (true) {
            int qi = pfVar.qi();
            switch (qi) {
                case FastDatePrinter.FULL /*0*/:
                    break;
                case XtraBox.MP4_XTRA_BT_UNICODE /*8*/:
                    this.versionCode = pfVar.ql();
                    continue;
                case NalUnitTypes.NAL_TYPE_BLA_N_LP /*18*/:
                    this.Pl = pfVar.readString();
                    continue;
                case NalUnitTypes.NAL_TYPE_RSV_VCL24 /*24*/:
                    this.Pm = pfVar.qo();
                    continue;
                case ItemTouchHelper.END /*32*/:
                    this.Pn = pfVar.qo();
                    continue;
                default:
                    if (!m3436a(pfVar, qi)) {
                        break;
                    }
                    continue;
            }
            return this;
        }
    }
}
