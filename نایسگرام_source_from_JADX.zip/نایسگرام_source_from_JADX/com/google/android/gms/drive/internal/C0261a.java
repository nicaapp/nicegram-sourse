package com.google.android.gms.drive.internal;

import android.os.Parcel;
import android.os.Parcelable.Creator;
import com.google.android.gms.common.internal.safeparcel.C0242a;
import com.google.android.gms.common.internal.safeparcel.C0242a.C0241a;
import com.google.android.gms.common.internal.safeparcel.C0243b;
import com.google.android.gms.drive.DriveId;
import com.google.android.gms.drive.events.CompletionEvent;
import org.telegram.android.time.FastDatePrinter;

/* renamed from: com.google.android.gms.drive.internal.a */
public class C0261a implements Creator<AddEventListenerRequest> {
    static void m385a(AddEventListenerRequest addEventListenerRequest, Parcel parcel, int i) {
        int D = C0243b.m329D(parcel);
        C0243b.m356c(parcel, 1, addEventListenerRequest.BR);
        C0243b.m340a(parcel, 2, addEventListenerRequest.MW, i, false);
        C0243b.m356c(parcel, 3, addEventListenerRequest.Oa);
        C0243b.m332H(parcel, D);
    }

    public AddEventListenerRequest m386V(Parcel parcel) {
        int i = 0;
        int C = C0242a.m293C(parcel);
        DriveId driveId = null;
        int i2 = 0;
        while (parcel.dataPosition() < C) {
            DriveId driveId2;
            int g;
            int B = C0242a.m291B(parcel);
            switch (C0242a.aD(B)) {
                case CompletionEvent.STATUS_FAILURE /*1*/:
                    int i3 = i;
                    driveId2 = driveId;
                    g = C0242a.m309g(parcel, B);
                    B = i3;
                    break;
                case CompletionEvent.STATUS_CONFLICT /*2*/:
                    g = i2;
                    DriveId driveId3 = (DriveId) C0242a.m298a(parcel, B, DriveId.CREATOR);
                    B = i;
                    driveId2 = driveId3;
                    break;
                case FastDatePrinter.SHORT /*3*/:
                    B = C0242a.m309g(parcel, B);
                    driveId2 = driveId;
                    g = i2;
                    break;
                default:
                    C0242a.m302b(parcel, B);
                    B = i;
                    driveId2 = driveId;
                    g = i2;
                    break;
            }
            i2 = g;
            driveId = driveId2;
            i = B;
        }
        if (parcel.dataPosition() == C) {
            return new AddEventListenerRequest(i2, driveId, i);
        }
        throw new C0241a("Overread allowed size end=" + C, parcel);
    }

    public AddEventListenerRequest[] be(int i) {
        return new AddEventListenerRequest[i];
    }

    public /* synthetic */ Object createFromParcel(Parcel x0) {
        return m386V(x0);
    }

    public /* synthetic */ Object[] newArray(int x0) {
        return be(x0);
    }
}
