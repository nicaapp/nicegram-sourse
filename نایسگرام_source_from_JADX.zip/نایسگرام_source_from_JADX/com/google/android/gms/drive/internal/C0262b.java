package com.google.android.gms.drive.internal;

import android.os.Parcel;
import android.os.Parcelable.Creator;
import com.google.android.gms.common.internal.safeparcel.C0242a;
import com.google.android.gms.common.internal.safeparcel.C0242a.C0241a;
import com.google.android.gms.common.internal.safeparcel.C0243b;
import com.google.android.gms.drive.DriveId;
import com.google.android.gms.drive.events.CompletionEvent;
import org.telegram.android.time.FastDatePrinter;

/* renamed from: com.google.android.gms.drive.internal.b */
public class C0262b implements Creator<AuthorizeAccessRequest> {
    static void m453a(AuthorizeAccessRequest authorizeAccessRequest, Parcel parcel, int i) {
        int D = C0243b.m329D(parcel);
        C0243b.m356c(parcel, 1, authorizeAccessRequest.BR);
        C0243b.m336a(parcel, 2, authorizeAccessRequest.Ob);
        C0243b.m340a(parcel, 3, authorizeAccessRequest.MW, i, false);
        C0243b.m332H(parcel, D);
    }

    public AuthorizeAccessRequest m454W(Parcel parcel) {
        int C = C0242a.m293C(parcel);
        int i = 0;
        long j = 0;
        DriveId driveId = null;
        while (parcel.dataPosition() < C) {
            int B = C0242a.m291B(parcel);
            switch (C0242a.aD(B)) {
                case CompletionEvent.STATUS_FAILURE /*1*/:
                    i = C0242a.m309g(parcel, B);
                    break;
                case CompletionEvent.STATUS_CONFLICT /*2*/:
                    j = C0242a.m311i(parcel, B);
                    break;
                case FastDatePrinter.SHORT /*3*/:
                    driveId = (DriveId) C0242a.m298a(parcel, B, DriveId.CREATOR);
                    break;
                default:
                    C0242a.m302b(parcel, B);
                    break;
            }
        }
        if (parcel.dataPosition() == C) {
            return new AuthorizeAccessRequest(i, j, driveId);
        }
        throw new C0241a("Overread allowed size end=" + C, parcel);
    }

    public AuthorizeAccessRequest[] bf(int i) {
        return new AuthorizeAccessRequest[i];
    }

    public /* synthetic */ Object createFromParcel(Parcel x0) {
        return m454W(x0);
    }

    public /* synthetic */ Object[] newArray(int x0) {
        return bf(x0);
    }
}
