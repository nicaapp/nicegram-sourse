package com.google.android.gms.drive.internal;

import android.os.Parcel;
import android.os.Parcelable.Creator;
import com.google.android.gms.common.internal.safeparcel.SafeParcelable;
import com.google.android.gms.drive.Contents;

public class OnContentsResponse implements SafeParcelable {
    public static final Creator<OnContentsResponse> CREATOR;
    final int BR;
    final Contents Ox;
    final boolean Po;

    static {
        CREATOR = new ai();
    }

    OnContentsResponse(int versionCode, Contents contents, boolean outOfDate) {
        this.BR = versionCode;
        this.Ox = contents;
        this.Po = outOfDate;
    }

    public int describeContents() {
        return 0;
    }

    public Contents id() {
        return this.Ox;
    }

    public boolean ie() {
        return this.Po;
    }

    public void writeToParcel(Parcel dest, int flags) {
        ai.m436a(this, dest, flags);
    }
}
