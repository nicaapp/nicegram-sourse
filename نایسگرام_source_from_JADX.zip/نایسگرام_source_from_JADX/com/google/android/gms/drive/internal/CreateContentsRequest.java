package com.google.android.gms.drive.internal;

import android.os.Parcel;
import android.os.Parcelable.Creator;
import com.google.android.gms.common.internal.C0238o;
import com.google.android.gms.common.internal.safeparcel.SafeParcelable;
import com.google.android.gms.drive.DriveFile;

public class CreateContentsRequest implements SafeParcelable {
    public static final Creator<CreateContentsRequest> CREATOR;
    final int BR;
    final int MV;

    static {
        CREATOR = new C0266g();
    }

    public CreateContentsRequest(int mode) {
        this(1, mode);
    }

    CreateContentsRequest(int versionCode, int mode) {
        this.BR = versionCode;
        boolean z = mode == DriveFile.MODE_WRITE_ONLY || mode == DriveFile.MODE_READ_WRITE;
        C0238o.m281b(z, (Object) "Cannot create a new read-only contents!");
        this.MV = mode;
    }

    public int describeContents() {
        return 0;
    }

    public void writeToParcel(Parcel dest, int flags) {
        C0266g.m464a(this, dest, flags);
    }
}
