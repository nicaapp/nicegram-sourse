package com.google.android.gms.drive.internal;

import com.google.android.gms.drive.Metadata;
import com.google.android.gms.drive.metadata.MetadataField;
import com.google.android.gms.drive.metadata.internal.MetadataBundle;

/* renamed from: com.google.android.gms.drive.internal.l */
public final class C2393l extends Metadata {
    private final MetadataBundle Or;

    public C2393l(MetadataBundle metadataBundle) {
        this.Or = metadataBundle;
    }

    protected <T> T m3850a(MetadataField<T> metadataField) {
        return this.Or.m2588a((MetadataField) metadataField);
    }

    public /* synthetic */ Object freeze() {
        return hR();
    }

    public Metadata hR() {
        return new C2393l(MetadataBundle.m2587a(this.Or));
    }

    public boolean isDataValid() {
        return this.Or != null;
    }

    public String toString() {
        return "Metadata [mImpl=" + this.Or + "]";
    }
}
