package com.google.android.gms.drive.internal;

import android.os.Parcel;
import android.os.Parcelable.Creator;
import com.google.android.gms.common.internal.safeparcel.SafeParcelable;
import com.google.android.gms.drive.DrivePreferences;

public class OnDrivePreferencesResponse implements SafeParcelable {
    public static final Creator<OnDrivePreferencesResponse> CREATOR;
    final int BR;
    DrivePreferences Pr;

    static {
        CREATOR = new al();
    }

    OnDrivePreferencesResponse(int versionCode, DrivePreferences prefs) {
        this.BR = versionCode;
        this.Pr = prefs;
    }

    public int describeContents() {
        return 0;
    }

    public void writeToParcel(Parcel dest, int flags) {
        al.m439a(this, dest, flags);
    }
}
