package com.google.android.gms.drive.internal;

import android.os.RemoteException;
import com.google.android.gms.common.api.BaseImplementation.C0191b;
import com.google.android.gms.common.api.GoogleApiClient;
import com.google.android.gms.common.api.PendingResult;
import com.google.android.gms.common.api.Result;
import com.google.android.gms.common.api.Status;
import com.google.android.gms.drive.Drive;
import com.google.android.gms.drive.DriveApi.MetadataBufferResult;
import com.google.android.gms.drive.DriveId;
import com.google.android.gms.drive.DriveResource;
import com.google.android.gms.drive.DriveResource.MetadataResult;
import com.google.android.gms.drive.Metadata;
import com.google.android.gms.drive.MetadataBuffer;
import com.google.android.gms.drive.MetadataChangeSet;
import com.google.android.gms.drive.events.ChangeEvent;
import com.google.android.gms.drive.events.ChangeListener;
import com.google.android.gms.drive.events.DriveEvent.Listener;
import com.google.android.gms.drive.internal.C1721o.C2397h;
import com.google.android.gms.drive.internal.C1721o.C2659i;
import com.google.android.gms.drive.internal.C2600p.C2660a;
import java.util.ArrayList;
import java.util.List;
import java.util.Set;

/* renamed from: com.google.android.gms.drive.internal.w */
public class C1727w implements DriveResource {
    protected final DriveId MW;

    /* renamed from: com.google.android.gms.drive.internal.w.c */
    private static class C2403c implements MetadataResult {
        private final Status CM;
        private final Metadata Pd;

        public C2403c(Status status, Metadata metadata) {
            this.CM = status;
            this.Pd = metadata;
        }

        public Metadata getMetadata() {
            return this.Pd;
        }

        public Status getStatus() {
            return this.CM;
        }
    }

    /* renamed from: com.google.android.gms.drive.internal.w.a */
    private static class C2604a extends C2392c {
        private final C0191b<MetadataBufferResult> De;

        public C2604a(C0191b<MetadataBufferResult> c0191b) {
            this.De = c0191b;
        }

        public void m4628a(OnListParentsResponse onListParentsResponse) throws RemoteException {
            this.De.m147b(new C2397h(Status.Jv, new MetadataBuffer(onListParentsResponse.ik(), null), false));
        }

        public void m4629o(Status status) throws RemoteException {
            this.De.m147b(new C2397h(status, null, false));
        }
    }

    /* renamed from: com.google.android.gms.drive.internal.w.b */
    private static class C2605b extends C2392c {
        private final C0191b<MetadataResult> De;

        public C2605b(C0191b<MetadataResult> c0191b) {
            this.De = c0191b;
        }

        public void m4630a(OnMetadataResponse onMetadataResponse) throws RemoteException {
            this.De.m147b(new C2403c(Status.Jv, new C2393l(onMetadataResponse.il())));
        }

        public void m4631o(Status status) throws RemoteException {
            this.De.m147b(new C2403c(status, null));
        }
    }

    /* renamed from: com.google.android.gms.drive.internal.w.d */
    private abstract class C2663d extends C2600p<MetadataResult> {
        final /* synthetic */ C1727w Pb;

        private C2663d(C1727w c1727w) {
            this.Pb = c1727w;
        }

        public /* synthetic */ Result m4856c(Status status) {
            return m4857v(status);
        }

        public MetadataResult m4857v(Status status) {
            return new C2403c(status, null);
        }
    }

    /* renamed from: com.google.android.gms.drive.internal.w.1 */
    class C27571 extends C2663d {
        final /* synthetic */ C1727w Pb;

        C27571(C1727w c1727w) {
            this.Pb = c1727w;
            super(null);
        }

        protected void m5150a(C2398q c2398q) throws RemoteException {
            c2398q.hY().m402a(new GetMetadataRequest(this.Pb.MW), new C2605b(this));
        }
    }

    /* renamed from: com.google.android.gms.drive.internal.w.2 */
    class C27582 extends C2659i {
        final /* synthetic */ C1727w Pb;

        C27582(C1727w c1727w) {
            this.Pb = c1727w;
        }

        protected void m5152a(C2398q c2398q) throws RemoteException {
            c2398q.hY().m403a(new ListParentsRequest(this.Pb.MW), new C2604a(this));
        }
    }

    /* renamed from: com.google.android.gms.drive.internal.w.3 */
    class C27593 extends C2660a {
        final /* synthetic */ C1727w Pb;
        final /* synthetic */ List Pc;

        C27593(C1727w c1727w, List list) {
            this.Pb = c1727w;
            this.Pc = list;
        }

        protected void m5154a(C2398q c2398q) throws RemoteException {
            c2398q.hY().m409a(new SetResourceParentsRequest(this.Pb.MW, this.Pc), new bb(this));
        }
    }

    /* renamed from: com.google.android.gms.drive.internal.w.4 */
    class C27604 extends C2663d {
        final /* synthetic */ MetadataChangeSet OV;
        final /* synthetic */ C1727w Pb;

        C27604(C1727w c1727w, MetadataChangeSet metadataChangeSet) {
            this.Pb = c1727w;
            this.OV = metadataChangeSet;
            super(null);
        }

        protected void m5156a(C2398q c2398q) throws RemoteException {
            this.OV.hS().setContext(c2398q.getContext());
            c2398q.hY().m411a(new UpdateMetadataRequest(this.Pb.MW, this.OV.hS()), new C2605b(this));
        }
    }

    protected C1727w(DriveId driveId) {
        this.MW = driveId;
    }

    public PendingResult<Status> addChangeListener(GoogleApiClient apiClient, ChangeListener listener) {
        return ((C2398q) apiClient.m149a(Drive.CU)).m3853a(apiClient, this.MW, 1, listener);
    }

    public PendingResult<Status> addChangeListener(GoogleApiClient apiClient, Listener<ChangeEvent> listener) {
        return ((C2398q) apiClient.m149a(Drive.CU)).m3853a(apiClient, this.MW, 1, listener);
    }

    public PendingResult<Status> addChangeSubscription(GoogleApiClient apiClient) {
        return ((C2398q) apiClient.m149a(Drive.CU)).m3852a(apiClient, this.MW, 1);
    }

    public DriveId getDriveId() {
        return this.MW;
    }

    public PendingResult<MetadataResult> getMetadata(GoogleApiClient apiClient) {
        return apiClient.m150a(new C27571(this));
    }

    public PendingResult<MetadataBufferResult> listParents(GoogleApiClient apiClient) {
        return apiClient.m150a(new C27582(this));
    }

    public PendingResult<Status> removeChangeListener(GoogleApiClient apiClient, ChangeListener listener) {
        return ((C2398q) apiClient.m149a(Drive.CU)).m3857b(apiClient, this.MW, 1, listener);
    }

    public PendingResult<Status> removeChangeListener(GoogleApiClient apiClient, Listener<ChangeEvent> listener) {
        return ((C2398q) apiClient.m149a(Drive.CU)).m3857b(apiClient, this.MW, 1, listener);
    }

    public PendingResult<Status> removeChangeSubscription(GoogleApiClient apiClient) {
        return ((C2398q) apiClient.m149a(Drive.CU)).m3856b(apiClient, this.MW, 1);
    }

    public PendingResult<Status> setParents(GoogleApiClient apiClient, Set<DriveId> parentIds) {
        if (parentIds == null) {
            throw new IllegalArgumentException("ParentIds must be provided.");
        } else if (!parentIds.isEmpty()) {
            return apiClient.m152b(new C27593(this, new ArrayList(parentIds)));
        } else {
            throw new IllegalArgumentException("ParentIds must contain at least one parent.");
        }
    }

    public PendingResult<MetadataResult> updateMetadata(GoogleApiClient apiClient, MetadataChangeSet changeSet) {
        if (changeSet != null) {
            return apiClient.m152b(new C27604(this, changeSet));
        }
        throw new IllegalArgumentException("ChangeSet must be provided.");
    }
}
