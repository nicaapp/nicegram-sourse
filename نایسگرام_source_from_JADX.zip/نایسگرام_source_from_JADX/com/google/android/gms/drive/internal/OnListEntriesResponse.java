package com.google.android.gms.drive.internal;

import android.os.Parcel;
import android.os.Parcelable.Creator;
import com.google.android.gms.common.data.DataHolder;
import com.google.android.gms.common.internal.safeparcel.SafeParcelable;
import com.google.android.gms.drive.C0260i;

public class OnListEntriesResponse extends C0260i implements SafeParcelable {
    public static final Creator<OnListEntriesResponse> CREATOR;
    final int BR;
    final boolean Oz;
    final DataHolder Pu;

    static {
        CREATOR = new an();
    }

    OnListEntriesResponse(int versionCode, DataHolder entries, boolean moreEntriesMayExist) {
        this.BR = versionCode;
        this.Pu = entries;
        this.Oz = moreEntriesMayExist;
    }

    protected void m2520I(Parcel parcel, int i) {
        an.m441a(this, parcel, i);
    }

    public int describeContents() {
        return 0;
    }

    public DataHolder ii() {
        return this.Pu;
    }

    public boolean ij() {
        return this.Oz;
    }
}
