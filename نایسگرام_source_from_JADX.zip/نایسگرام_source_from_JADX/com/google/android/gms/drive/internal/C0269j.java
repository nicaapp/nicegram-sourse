package com.google.android.gms.drive.internal;

import android.os.Parcel;
import android.os.Parcelable.Creator;
import com.google.android.gms.common.internal.safeparcel.C0242a;
import com.google.android.gms.common.internal.safeparcel.C0242a.C0241a;
import com.google.android.gms.common.internal.safeparcel.C0243b;
import com.google.android.gms.drive.Contents;
import com.google.android.gms.drive.DriveId;
import com.google.android.gms.drive.events.CompletionEvent;
import com.google.android.gms.drive.metadata.internal.MetadataBundle;
import com.google.android.gms.games.quest.Quest;
import com.google.android.gms.location.DetectedActivity;
import com.googlecode.mp4parser.boxes.microsoft.XtraBox;
import org.telegram.C0811R;
import org.telegram.android.support.widget.helper.ItemTouchHelper;
import org.telegram.android.time.FastDatePrinter;

/* renamed from: com.google.android.gms.drive.internal.j */
public class C0269j implements Creator<CreateFileRequest> {
    static void m468a(CreateFileRequest createFileRequest, Parcel parcel, int i) {
        int D = C0243b.m329D(parcel);
        C0243b.m356c(parcel, 1, createFileRequest.BR);
        C0243b.m340a(parcel, 2, createFileRequest.On, i, false);
        C0243b.m340a(parcel, 3, createFileRequest.Ol, i, false);
        C0243b.m340a(parcel, 4, createFileRequest.Of, i, false);
        C0243b.m342a(parcel, 5, createFileRequest.Om, false);
        C0243b.m347a(parcel, 6, createFileRequest.Oo);
        C0243b.m344a(parcel, 7, createFileRequest.Nn, false);
        C0243b.m356c(parcel, 8, createFileRequest.Op);
        C0243b.m356c(parcel, 9, createFileRequest.Oq);
        C0243b.m332H(parcel, D);
    }

    public CreateFileRequest ac(Parcel parcel) {
        int i = 0;
        String str = null;
        int C = C0242a.m293C(parcel);
        int i2 = 0;
        boolean z = false;
        Integer num = null;
        Contents contents = null;
        MetadataBundle metadataBundle = null;
        DriveId driveId = null;
        int i3 = 0;
        while (parcel.dataPosition() < C) {
            int B = C0242a.m291B(parcel);
            switch (C0242a.aD(B)) {
                case CompletionEvent.STATUS_FAILURE /*1*/:
                    i3 = C0242a.m309g(parcel, B);
                    break;
                case CompletionEvent.STATUS_CONFLICT /*2*/:
                    driveId = (DriveId) C0242a.m298a(parcel, B, DriveId.CREATOR);
                    break;
                case FastDatePrinter.SHORT /*3*/:
                    metadataBundle = (MetadataBundle) C0242a.m298a(parcel, B, MetadataBundle.CREATOR);
                    break;
                case ItemTouchHelper.LEFT /*4*/:
                    contents = (Contents) C0242a.m298a(parcel, B, Contents.CREATOR);
                    break;
                case DetectedActivity.TILTING /*5*/:
                    num = C0242a.m310h(parcel, B);
                    break;
                case Quest.STATE_FAILED /*6*/:
                    z = C0242a.m305c(parcel, B);
                    break;
                case DetectedActivity.WALKING /*7*/:
                    str = C0242a.m317o(parcel, B);
                    break;
                case XtraBox.MP4_XTRA_BT_UNICODE /*8*/:
                    i2 = C0242a.m309g(parcel, B);
                    break;
                case C0811R.styleable.WalletFragmentStyle_maskedWalletDetailsLogoTextColor /*9*/:
                    i = C0242a.m309g(parcel, B);
                    break;
                default:
                    C0242a.m302b(parcel, B);
                    break;
            }
        }
        if (parcel.dataPosition() == C) {
            return new CreateFileRequest(i3, driveId, metadataBundle, contents, num, z, str, i2, i);
        }
        throw new C0241a("Overread allowed size end=" + C, parcel);
    }

    public CreateFileRequest[] bm(int i) {
        return new CreateFileRequest[i];
    }

    public /* synthetic */ Object createFromParcel(Parcel x0) {
        return ac(x0);
    }

    public /* synthetic */ Object[] newArray(int x0) {
        return bm(x0);
    }
}
