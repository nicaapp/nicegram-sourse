package com.google.android.gms.drive.internal;

import android.os.Parcel;
import android.os.Parcelable.Creator;
import com.google.android.gms.common.internal.safeparcel.C0242a;
import com.google.android.gms.common.internal.safeparcel.C0242a.C0241a;
import com.google.android.gms.common.internal.safeparcel.C0243b;
import com.google.android.gms.drive.Contents;
import com.google.android.gms.drive.events.CompletionEvent;
import org.telegram.android.time.FastDatePrinter;

public class ai implements Creator<OnContentsResponse> {
    static void m436a(OnContentsResponse onContentsResponse, Parcel parcel, int i) {
        int D = C0243b.m329D(parcel);
        C0243b.m356c(parcel, 1, onContentsResponse.BR);
        C0243b.m340a(parcel, 2, onContentsResponse.Ox, i, false);
        C0243b.m347a(parcel, 3, onContentsResponse.Po);
        C0243b.m332H(parcel, D);
    }

    public OnContentsResponse ak(Parcel parcel) {
        boolean z = false;
        int C = C0242a.m293C(parcel);
        Contents contents = null;
        int i = 0;
        while (parcel.dataPosition() < C) {
            Contents contents2;
            int g;
            boolean z2;
            int B = C0242a.m291B(parcel);
            switch (C0242a.aD(B)) {
                case CompletionEvent.STATUS_FAILURE /*1*/:
                    boolean z3 = z;
                    contents2 = contents;
                    g = C0242a.m309g(parcel, B);
                    z2 = z3;
                    break;
                case CompletionEvent.STATUS_CONFLICT /*2*/:
                    g = i;
                    Contents contents3 = (Contents) C0242a.m298a(parcel, B, Contents.CREATOR);
                    z2 = z;
                    contents2 = contents3;
                    break;
                case FastDatePrinter.SHORT /*3*/:
                    z2 = C0242a.m305c(parcel, B);
                    contents2 = contents;
                    g = i;
                    break;
                default:
                    C0242a.m302b(parcel, B);
                    z2 = z;
                    contents2 = contents;
                    g = i;
                    break;
            }
            i = g;
            contents = contents2;
            z = z2;
        }
        if (parcel.dataPosition() == C) {
            return new OnContentsResponse(i, contents, z);
        }
        throw new C0241a("Overread allowed size end=" + C, parcel);
    }

    public OnContentsResponse[] bw(int i) {
        return new OnContentsResponse[i];
    }

    public /* synthetic */ Object createFromParcel(Parcel x0) {
        return ak(x0);
    }

    public /* synthetic */ Object[] newArray(int x0) {
        return bw(x0);
    }
}
