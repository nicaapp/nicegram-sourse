package com.google.android.gms.drive.internal;

import android.os.RemoteException;
import com.google.android.gms.common.api.BaseImplementation.C0191b;
import com.google.android.gms.common.api.GoogleApiClient;
import com.google.android.gms.common.api.PendingResult;
import com.google.android.gms.common.api.Result;
import com.google.android.gms.common.api.Status;
import com.google.android.gms.drive.Contents;
import com.google.android.gms.drive.DriveApi.MetadataBufferResult;
import com.google.android.gms.drive.DriveContents;
import com.google.android.gms.drive.DriveFile;
import com.google.android.gms.drive.DriveFolder;
import com.google.android.gms.drive.DriveFolder.DriveFileResult;
import com.google.android.gms.drive.DriveFolder.DriveFolderResult;
import com.google.android.gms.drive.DriveId;
import com.google.android.gms.drive.ExecutionOptions;
import com.google.android.gms.drive.ExecutionOptions.Builder;
import com.google.android.gms.drive.MetadataChangeSet;
import com.google.android.gms.drive.query.Filters;
import com.google.android.gms.drive.query.Query;
import com.google.android.gms.drive.query.SearchableField;

/* renamed from: com.google.android.gms.drive.internal.u */
public class C2402u extends C1727w implements DriveFolder {

    /* renamed from: com.google.android.gms.drive.internal.u.c */
    private static class C2400c implements DriveFileResult {
        private final Status CM;
        private final DriveFile OY;

        public C2400c(Status status, DriveFile driveFile) {
            this.CM = status;
            this.OY = driveFile;
        }

        public DriveFile getDriveFile() {
            return this.OY;
        }

        public Status getStatus() {
            return this.CM;
        }
    }

    /* renamed from: com.google.android.gms.drive.internal.u.e */
    private static class C2401e implements DriveFolderResult {
        private final Status CM;
        private final DriveFolder OZ;

        public C2401e(Status status, DriveFolder driveFolder) {
            this.CM = status;
            this.OZ = driveFolder;
        }

        public DriveFolder getDriveFolder() {
            return this.OZ;
        }

        public Status getStatus() {
            return this.CM;
        }
    }

    /* renamed from: com.google.android.gms.drive.internal.u.a */
    private static class C2602a extends C2392c {
        private final C0191b<DriveFileResult> De;

        public C2602a(C0191b<DriveFileResult> c0191b) {
            this.De = c0191b;
        }

        public void m4624a(OnDriveIdResponse onDriveIdResponse) throws RemoteException {
            this.De.m147b(new C2400c(Status.Jv, new C2399s(onDriveIdResponse.getDriveId())));
        }

        public void m4625o(Status status) throws RemoteException {
            this.De.m147b(new C2400c(status, null));
        }
    }

    /* renamed from: com.google.android.gms.drive.internal.u.b */
    private static class C2603b extends C2392c {
        private final C0191b<DriveFolderResult> De;

        public C2603b(C0191b<DriveFolderResult> c0191b) {
            this.De = c0191b;
        }

        public void m4626a(OnDriveIdResponse onDriveIdResponse) throws RemoteException {
            this.De.m147b(new C2401e(Status.Jv, new C2402u(onDriveIdResponse.getDriveId())));
        }

        public void m4627o(Status status) throws RemoteException {
            this.De.m147b(new C2401e(status, null));
        }
    }

    /* renamed from: com.google.android.gms.drive.internal.u.d */
    static abstract class C2661d extends C2600p<DriveFileResult> {
        C2661d() {
        }

        public /* synthetic */ Result m4852c(Status status) {
            return m4853t(status);
        }

        public DriveFileResult m4853t(Status status) {
            return new C2400c(status, null);
        }
    }

    /* renamed from: com.google.android.gms.drive.internal.u.f */
    static abstract class C2662f extends C2600p<DriveFolderResult> {
        C2662f() {
        }

        public /* synthetic */ Result m4854c(Status status) {
            return m4855u(status);
        }

        public DriveFolderResult m4855u(Status status) {
            return new C2401e(status, null);
        }
    }

    /* renamed from: com.google.android.gms.drive.internal.u.1 */
    class C27551 extends C2661d {
        final /* synthetic */ ExecutionOptions ON;
        final /* synthetic */ MetadataChangeSet OV;
        final /* synthetic */ int OW;
        final /* synthetic */ C2402u OX;
        final /* synthetic */ Contents Ov;

        C27551(C2402u c2402u, MetadataChangeSet metadataChangeSet, Contents contents, int i, ExecutionOptions executionOptions) {
            this.OX = c2402u;
            this.OV = metadataChangeSet;
            this.Ov = contents;
            this.OW = i;
            this.ON = executionOptions;
        }

        protected void m5146a(C2398q c2398q) throws RemoteException {
            this.OV.hS().setContext(c2398q.getContext());
            c2398q.hY().m397a(new CreateFileRequest(this.OX.getDriveId(), this.OV.hS(), this.Ov == null ? 0 : this.Ov.getRequestId(), this.OW, this.ON), new C2602a(this));
        }
    }

    /* renamed from: com.google.android.gms.drive.internal.u.2 */
    class C27562 extends C2662f {
        final /* synthetic */ MetadataChangeSet OV;
        final /* synthetic */ C2402u OX;

        C27562(C2402u c2402u, MetadataChangeSet metadataChangeSet) {
            this.OX = c2402u;
            this.OV = metadataChangeSet;
        }

        protected void m5148a(C2398q c2398q) throws RemoteException {
            this.OV.hS().setContext(c2398q.getContext());
            c2398q.hY().m398a(new CreateFolderRequest(this.OX.getDriveId(), this.OV.hS()), new C2603b(this));
        }
    }

    public C2402u(DriveId driveId) {
        super(driveId);
    }

    private PendingResult<DriveFileResult> m3860a(GoogleApiClient googleApiClient, MetadataChangeSet metadataChangeSet, Contents contents, int i, ExecutionOptions executionOptions) {
        ExecutionOptions.m363a(googleApiClient, executionOptions);
        if (contents != null) {
            contents.hJ();
        }
        return googleApiClient.m152b(new C27551(this, metadataChangeSet, contents, i, executionOptions));
    }

    private PendingResult<DriveFileResult> m3861a(GoogleApiClient googleApiClient, MetadataChangeSet metadataChangeSet, DriveContents driveContents, ExecutionOptions executionOptions) {
        if (driveContents == null) {
            throw new IllegalArgumentException("DriveContents must be provided.");
        } else if (!(driveContents instanceof C1723r)) {
            throw new IllegalArgumentException("Only DriveContents obtained from the Drive API are accepted.");
        } else if (driveContents.getDriveId() != null) {
            throw new IllegalArgumentException("Only DriveContents obtained through DriveApi.newDriveContents are accepted for file creation.");
        } else if (driveContents.getContents().hK()) {
            throw new IllegalArgumentException("DriveContents are already closed.");
        } else if (metadataChangeSet == null) {
            throw new IllegalArgumentException("MetadataChangeSet must be provided.");
        } else if (DriveFolder.MIME_TYPE.equals(metadataChangeSet.getMimeType())) {
            throw new IllegalArgumentException("May not create folders (mimetype: application/vnd.google-apps.folder) using this method. Use DriveFolder.createFolder() instead.");
        } else {
            return m3860a(googleApiClient, metadataChangeSet, driveContents.getContents(), 0, executionOptions);
        }
    }

    public PendingResult<DriveFileResult> createFile(GoogleApiClient apiClient, MetadataChangeSet changeSet, Contents contents) {
        return createFile(apiClient, changeSet, new C1723r(contents));
    }

    public PendingResult<DriveFileResult> createFile(GoogleApiClient apiClient, MetadataChangeSet changeSet, DriveContents driveContents) {
        return createFile(apiClient, changeSet, driveContents, null);
    }

    public PendingResult<DriveFileResult> createFile(GoogleApiClient apiClient, MetadataChangeSet changeSet, DriveContents driveContents, ExecutionOptions executionOptions) {
        if (executionOptions == null) {
            executionOptions = new Builder().build();
        }
        if (executionOptions.hQ() == 0) {
            return m3861a(apiClient, changeSet, driveContents, executionOptions);
        }
        throw new IllegalStateException("May not set a conflict strategy for calls to createFile.");
    }

    public PendingResult<DriveFolderResult> createFolder(GoogleApiClient apiClient, MetadataChangeSet changeSet) {
        if (changeSet == null) {
            throw new IllegalArgumentException("MetadataChangeSet must be provided.");
        } else if (changeSet.getMimeType() == null || changeSet.getMimeType().equals(DriveFolder.MIME_TYPE)) {
            return apiClient.m152b(new C27562(this, changeSet));
        } else {
            throw new IllegalArgumentException("The mimetype must be of type application/vnd.google-apps.folder");
        }
    }

    public PendingResult<MetadataBufferResult> listChildren(GoogleApiClient apiClient) {
        return queryChildren(apiClient, null);
    }

    public PendingResult<MetadataBufferResult> queryChildren(GoogleApiClient apiClient, Query query) {
        Query.Builder addFilter = new Query.Builder().addFilter(Filters.in(SearchableField.PARENTS, getDriveId()));
        if (query != null) {
            if (query.getFilter() != null) {
                addFilter.addFilter(query.getFilter());
            }
            addFilter.setPageToken(query.getPageToken());
            addFilter.setSortOrder(query.getSortOrder());
        }
        return new C1721o().query(apiClient, addFilter.build());
    }
}
