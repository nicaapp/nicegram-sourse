package com.google.android.gms.drive.internal;

import android.os.Parcel;
import android.os.Parcelable.Creator;
import com.google.android.gms.common.internal.safeparcel.C0242a;
import com.google.android.gms.common.internal.safeparcel.C0242a.C0241a;
import com.google.android.gms.common.internal.safeparcel.C0243b;
import com.google.android.gms.drive.events.CompletionEvent;
import java.util.List;

/* renamed from: com.google.android.gms.drive.internal.d */
public class C0263d implements Creator<CheckResourceIdsExistRequest> {
    static void m458a(CheckResourceIdsExistRequest checkResourceIdsExistRequest, Parcel parcel, int i) {
        int D = C0243b.m329D(parcel);
        C0243b.m356c(parcel, 1, checkResourceIdsExistRequest.getVersionCode());
        C0243b.m355b(parcel, 2, checkResourceIdsExistRequest.hX(), false);
        C0243b.m332H(parcel, D);
    }

    public CheckResourceIdsExistRequest m459X(Parcel parcel) {
        int C = C0242a.m293C(parcel);
        int i = 0;
        List list = null;
        while (parcel.dataPosition() < C) {
            int B = C0242a.m291B(parcel);
            switch (C0242a.aD(B)) {
                case CompletionEvent.STATUS_FAILURE /*1*/:
                    i = C0242a.m309g(parcel, B);
                    break;
                case CompletionEvent.STATUS_CONFLICT /*2*/:
                    list = C0242a.m294C(parcel, B);
                    break;
                default:
                    C0242a.m302b(parcel, B);
                    break;
            }
        }
        if (parcel.dataPosition() == C) {
            return new CheckResourceIdsExistRequest(i, list);
        }
        throw new C0241a("Overread allowed size end=" + C, parcel);
    }

    public CheckResourceIdsExistRequest[] bg(int i) {
        return new CheckResourceIdsExistRequest[i];
    }

    public /* synthetic */ Object createFromParcel(Parcel x0) {
        return m459X(x0);
    }

    public /* synthetic */ Object[] newArray(int x0) {
        return bg(x0);
    }
}
