package com.google.android.gms.drive.internal;

import android.os.RemoteException;
import com.google.android.gms.common.api.BaseImplementation.C0191b;
import com.google.android.gms.common.api.Status;
import com.google.android.gms.drive.DriveApi.DriveContentsResult;
import com.google.android.gms.drive.DriveFile.DownloadProgressListener;
import com.google.android.gms.drive.internal.C1721o.C2395c;

class av extends C2392c {
    private final C0191b<DriveContentsResult> De;
    private final DownloadProgressListener OU;

    av(C0191b<DriveContentsResult> c0191b, DownloadProgressListener downloadProgressListener) {
        this.De = c0191b;
        this.OU = downloadProgressListener;
    }

    public void m4608a(OnContentsResponse onContentsResponse) throws RemoteException {
        this.De.m147b(new C2395c(onContentsResponse.ie() ? new Status(-1) : Status.Jv, new C1723r(onContentsResponse.id())));
    }

    public void m4609a(OnDownloadProgressResponse onDownloadProgressResponse) throws RemoteException {
        if (this.OU != null) {
            this.OU.onProgress(onDownloadProgressResponse.m2519if(), onDownloadProgressResponse.ig());
        }
    }

    public void m4610o(Status status) throws RemoteException {
        this.De.m147b(new C2395c(status, null));
    }
}
