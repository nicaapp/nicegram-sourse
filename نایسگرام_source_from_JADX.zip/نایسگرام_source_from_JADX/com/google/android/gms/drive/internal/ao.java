package com.google.android.gms.drive.internal;

import android.os.Parcel;
import android.os.Parcelable.Creator;
import com.google.android.gms.common.data.DataHolder;
import com.google.android.gms.common.internal.safeparcel.C0242a;
import com.google.android.gms.common.internal.safeparcel.C0242a.C0241a;
import com.google.android.gms.common.internal.safeparcel.C0243b;
import com.google.android.gms.drive.events.CompletionEvent;

public class ao implements Creator<OnListParentsResponse> {
    static void m442a(OnListParentsResponse onListParentsResponse, Parcel parcel, int i) {
        int D = C0243b.m329D(parcel);
        C0243b.m356c(parcel, 1, onListParentsResponse.BR);
        C0243b.m340a(parcel, 2, onListParentsResponse.Pv, i, false);
        C0243b.m332H(parcel, D);
    }

    public OnListParentsResponse aq(Parcel parcel) {
        int C = C0242a.m293C(parcel);
        int i = 0;
        DataHolder dataHolder = null;
        while (parcel.dataPosition() < C) {
            int B = C0242a.m291B(parcel);
            switch (C0242a.aD(B)) {
                case CompletionEvent.STATUS_FAILURE /*1*/:
                    i = C0242a.m309g(parcel, B);
                    break;
                case CompletionEvent.STATUS_CONFLICT /*2*/:
                    dataHolder = (DataHolder) C0242a.m298a(parcel, B, DataHolder.CREATOR);
                    break;
                default:
                    C0242a.m302b(parcel, B);
                    break;
            }
        }
        if (parcel.dataPosition() == C) {
            return new OnListParentsResponse(i, dataHolder);
        }
        throw new C0241a("Overread allowed size end=" + C, parcel);
    }

    public OnListParentsResponse[] bC(int i) {
        return new OnListParentsResponse[i];
    }

    public /* synthetic */ Object createFromParcel(Parcel x0) {
        return aq(x0);
    }

    public /* synthetic */ Object[] newArray(int x0) {
        return bC(x0);
    }
}
