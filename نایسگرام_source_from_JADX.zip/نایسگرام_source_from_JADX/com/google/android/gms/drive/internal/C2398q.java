package com.google.android.gms.drive.internal;

import android.content.Context;
import android.content.Intent;
import android.content.pm.ResolveInfo;
import android.content.pm.ServiceInfo;
import android.os.Bundle;
import android.os.IBinder;
import android.os.IInterface;
import android.os.Looper;
import android.os.RemoteException;
import com.google.android.gms.common.GooglePlayServicesUtil;
import com.google.android.gms.common.api.GoogleApiClient;
import com.google.android.gms.common.api.GoogleApiClient.ConnectionCallbacks;
import com.google.android.gms.common.api.GoogleApiClient.OnConnectionFailedListener;
import com.google.android.gms.common.api.PendingResult;
import com.google.android.gms.common.api.Status;
import com.google.android.gms.common.internal.C0232k;
import com.google.android.gms.common.internal.C0233l;
import com.google.android.gms.common.internal.C0238o;
import com.google.android.gms.common.internal.C1702e;
import com.google.android.gms.common.internal.C1702e.C2386e;
import com.google.android.gms.common.internal.ClientSettings;
import com.google.android.gms.drive.DriveId;
import com.google.android.gms.drive.events.C0255c;
import com.google.android.gms.drive.events.C0256d;
import com.google.android.gms.drive.events.CompletionEvent;
import com.google.android.gms.drive.events.DriveEventService;
import com.google.android.gms.drive.internal.C1721o.C2745m;
import com.google.android.gms.drive.internal.C2600p.C2660a;
import com.google.android.gms.drive.internal.ab.C1714a;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import org.telegram.android.time.FastDatePrinter;

/* renamed from: com.google.android.gms.drive.internal.q */
public class C2398q extends C1702e<ab> {
    private final String Dd;
    private final String IM;
    private final Bundle OA;
    private final boolean OB;
    private DriveId OC;
    private DriveId OD;
    final ConnectionCallbacks OE;
    final Map<DriveId, Map<C0255c, C2404y>> OF;

    /* renamed from: com.google.android.gms.drive.internal.q.1 */
    class C27461 extends C2660a {
        final /* synthetic */ DriveId OG;
        final /* synthetic */ int OH;
        final /* synthetic */ C2404y OI;
        final /* synthetic */ C2398q OJ;

        C27461(C2398q c2398q, DriveId driveId, int i, C2404y c2404y) {
            this.OJ = c2398q;
            this.OG = driveId;
            this.OH = i;
            this.OI = c2404y;
        }

        protected void m5128a(C2398q c2398q) throws RemoteException {
            c2398q.hY().m391a(new AddEventListenerRequest(this.OG, this.OH), this.OI, null, new bb(this));
        }
    }

    /* renamed from: com.google.android.gms.drive.internal.q.2 */
    class C27472 extends C2660a {
        final /* synthetic */ DriveId OG;
        final /* synthetic */ int OH;
        final /* synthetic */ C2398q OJ;
        final /* synthetic */ C2404y OK;

        C27472(C2398q c2398q, DriveId driveId, int i, C2404y c2404y) {
            this.OJ = c2398q;
            this.OG = driveId;
            this.OH = i;
            this.OK = c2404y;
        }

        protected void m5130a(C2398q c2398q) throws RemoteException {
            c2398q.hY().m407a(new RemoveEventListenerRequest(this.OG, this.OH), this.OK, null, new bb(this));
        }
    }

    /* renamed from: com.google.android.gms.drive.internal.q.3 */
    class C27483 extends C2660a {
        final /* synthetic */ DriveId OG;
        final /* synthetic */ int OH;
        final /* synthetic */ C2398q OJ;

        C27483(C2398q c2398q, DriveId driveId, int i) {
            this.OJ = c2398q;
            this.OG = driveId;
            this.OH = i;
        }

        protected void m5132a(C2398q c2398q) throws RemoteException {
            c2398q.hY().m391a(new AddEventListenerRequest(this.OG, this.OH), null, null, new bb(this));
        }
    }

    /* renamed from: com.google.android.gms.drive.internal.q.4 */
    class C27494 extends C2660a {
        final /* synthetic */ DriveId OG;
        final /* synthetic */ int OH;
        final /* synthetic */ C2398q OJ;

        C27494(C2398q c2398q, DriveId driveId, int i) {
            this.OJ = c2398q;
            this.OG = driveId;
            this.OH = i;
        }

        protected void m5134a(C2398q c2398q) throws RemoteException {
            c2398q.hY().m407a(new RemoveEventListenerRequest(this.OG, this.OH), null, null, new bb(this));
        }
    }

    public C2398q(Context context, Looper looper, ClientSettings clientSettings, ConnectionCallbacks connectionCallbacks, OnConnectionFailedListener onConnectionFailedListener, String[] strArr, Bundle bundle) {
        super(context, looper, connectionCallbacks, onConnectionFailedListener, strArr);
        this.OF = new HashMap();
        this.Dd = (String) C0238o.m279b(clientSettings.getAccountNameOrDefault(), (Object) "Must call Api.ClientBuilder.setAccountName()");
        this.IM = clientSettings.getRealClientPackageName();
        this.OE = connectionCallbacks;
        this.OA = bundle;
        Intent intent = new Intent(DriveEventService.ACTION_HANDLE_EVENT);
        intent.setPackage(context.getPackageName());
        List queryIntentServices = context.getPackageManager().queryIntentServices(intent, 0);
        switch (queryIntentServices.size()) {
            case FastDatePrinter.FULL /*0*/:
                this.OB = false;
            case CompletionEvent.STATUS_FAILURE /*1*/:
                ServiceInfo serviceInfo = ((ResolveInfo) queryIntentServices.get(0)).serviceInfo;
                if (serviceInfo.exported) {
                    this.OB = true;
                    return;
                }
                throw new IllegalStateException("Drive event service " + serviceInfo.name + " must be exported in AndroidManifest.xml");
            default:
                throw new IllegalStateException("AndroidManifest.xml can only define one service that handles the " + intent.getAction() + " action");
        }
    }

    protected ab m3851T(IBinder iBinder) {
        return C1714a.m2554U(iBinder);
    }

    PendingResult<Status> m3852a(GoogleApiClient googleApiClient, DriveId driveId, int i) {
        C0238o.m281b(C0256d.m377a(i, driveId), (Object) "id");
        C0238o.m283i("eventService");
        C0238o.m277a(isConnected(), "Client must be connected");
        if (this.OB) {
            return googleApiClient.m152b(new C27483(this, driveId, i));
        }
        throw new IllegalStateException("Application must define an exported DriveEventService subclass in AndroidManifest.xml to add event subscriptions");
    }

    PendingResult<Status> m3853a(GoogleApiClient googleApiClient, DriveId driveId, int i, C0255c c0255c) {
        PendingResult<Status> c2745m;
        C0238o.m281b(C0256d.m377a(i, driveId), (Object) "id");
        C0238o.m279b((Object) c0255c, (Object) "listener");
        C0238o.m277a(isConnected(), "Client must be connected");
        synchronized (this.OF) {
            Map map;
            Map map2 = (Map) this.OF.get(driveId);
            if (map2 == null) {
                HashMap hashMap = new HashMap();
                this.OF.put(driveId, hashMap);
                map = hashMap;
            } else {
                map = map2;
            }
            C2404y c2404y = (C2404y) map.get(c0255c);
            if (c2404y == null) {
                c2404y = new C2404y(getLooper(), getContext(), i, c0255c);
                map.put(c0255c, c2404y);
            } else if (c2404y.br(i)) {
                c2745m = new C2745m(googleApiClient, Status.Jv);
            }
            c2404y.bq(i);
            c2745m = googleApiClient.m152b(new C27461(this, driveId, i, c2404y));
        }
        return c2745m;
    }

    protected void m3854a(int i, IBinder iBinder, Bundle bundle) {
        if (bundle != null) {
            bundle.setClassLoader(getClass().getClassLoader());
            this.OC = (DriveId) bundle.getParcelable("com.google.android.gms.drive.root_id");
            this.OD = (DriveId) bundle.getParcelable("com.google.android.gms.drive.appdata_id");
        }
        super.m2458a(i, iBinder, bundle);
    }

    protected void m3855a(C0233l c0233l, C2386e c2386e) throws RemoteException {
        String packageName = getContext().getPackageName();
        C0238o.m283i(c2386e);
        C0238o.m283i(packageName);
        C0238o.m283i(gR());
        Bundle bundle = new Bundle();
        if (!packageName.equals(this.IM)) {
            bundle.putString("proxy_package_name", this.IM);
        }
        bundle.putAll(this.OA);
        c0233l.m241a((C0232k) c2386e, (int) GooglePlayServicesUtil.GOOGLE_PLAY_SERVICES_VERSION_CODE, packageName, gR(), this.Dd, bundle);
    }

    PendingResult<Status> m3856b(GoogleApiClient googleApiClient, DriveId driveId, int i) {
        C0238o.m281b(C0256d.m377a(i, driveId), (Object) "id");
        C0238o.m283i("eventService");
        C0238o.m277a(isConnected(), "Client must be connected");
        return googleApiClient.m152b(new C27494(this, driveId, i));
    }

    PendingResult<Status> m3857b(GoogleApiClient googleApiClient, DriveId driveId, int i, C0255c c0255c) {
        PendingResult<Status> c2745m;
        C0238o.m281b(C0256d.m377a(i, driveId), (Object) "id");
        C0238o.m277a(isConnected(), "Client must be connected");
        C0238o.m279b((Object) c0255c, (Object) "listener");
        synchronized (this.OF) {
            Map map = (Map) this.OF.get(driveId);
            if (map == null) {
                c2745m = new C2745m(googleApiClient, Status.Jv);
            } else {
                C2404y c2404y = (C2404y) map.remove(c0255c);
                if (c2404y == null) {
                    c2745m = new C2745m(googleApiClient, Status.Jv);
                } else {
                    if (map.isEmpty()) {
                        this.OF.remove(driveId);
                    }
                    c2745m = googleApiClient.m152b(new C27472(this, driveId, i, c2404y));
                }
            }
        }
        return c2745m;
    }

    public void disconnect() {
        ab abVar = (ab) gS();
        if (abVar != null) {
            try {
                abVar.m400a(new DisconnectRequest());
            } catch (RemoteException e) {
            }
        }
        super.disconnect();
        this.OF.clear();
    }

    protected String getServiceDescriptor() {
        return "com.google.android.gms.drive.internal.IDriveService";
    }

    protected String getStartServiceAction() {
        return "com.google.android.gms.drive.ApiService.START";
    }

    public ab hY() {
        return (ab) gS();
    }

    public DriveId hZ() {
        return this.OC;
    }

    public DriveId ia() {
        return this.OD;
    }

    public boolean ib() {
        return this.OB;
    }

    protected /* synthetic */ IInterface m3858j(IBinder iBinder) {
        return m3851T(iBinder);
    }
}
