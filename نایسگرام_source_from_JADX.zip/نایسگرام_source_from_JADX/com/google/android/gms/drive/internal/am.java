package com.google.android.gms.drive.internal;

import android.os.Parcel;
import android.os.Parcelable.Creator;
import com.google.android.gms.common.internal.safeparcel.C0242a;
import com.google.android.gms.common.internal.safeparcel.C0242a.C0241a;
import com.google.android.gms.common.internal.safeparcel.C0243b;
import com.google.android.gms.drive.events.ChangeEvent;
import com.google.android.gms.drive.events.CompletionEvent;
import com.google.android.gms.location.DetectedActivity;
import org.telegram.android.time.FastDatePrinter;

public class am implements Creator<OnEventResponse> {
    static void m440a(OnEventResponse onEventResponse, Parcel parcel, int i) {
        int D = C0243b.m329D(parcel);
        C0243b.m356c(parcel, 1, onEventResponse.BR);
        C0243b.m356c(parcel, 2, onEventResponse.Oa);
        C0243b.m340a(parcel, 3, onEventResponse.Ps, i, false);
        C0243b.m340a(parcel, 5, onEventResponse.Pt, i, false);
        C0243b.m332H(parcel, D);
    }

    public OnEventResponse ao(Parcel parcel) {
        CompletionEvent completionEvent = null;
        int i = 0;
        int C = C0242a.m293C(parcel);
        ChangeEvent changeEvent = null;
        int i2 = 0;
        while (parcel.dataPosition() < C) {
            ChangeEvent changeEvent2;
            int i3;
            CompletionEvent completionEvent2;
            int B = C0242a.m291B(parcel);
            CompletionEvent completionEvent3;
            switch (C0242a.aD(B)) {
                case CompletionEvent.STATUS_FAILURE /*1*/:
                    completionEvent3 = completionEvent;
                    changeEvent2 = changeEvent;
                    i3 = i;
                    i = C0242a.m309g(parcel, B);
                    completionEvent2 = completionEvent3;
                    break;
                case CompletionEvent.STATUS_CONFLICT /*2*/:
                    i = i2;
                    ChangeEvent changeEvent3 = changeEvent;
                    i3 = C0242a.m309g(parcel, B);
                    completionEvent2 = completionEvent;
                    changeEvent2 = changeEvent3;
                    break;
                case FastDatePrinter.SHORT /*3*/:
                    i3 = i;
                    i = i2;
                    completionEvent3 = completionEvent;
                    changeEvent2 = (ChangeEvent) C0242a.m298a(parcel, B, ChangeEvent.CREATOR);
                    completionEvent2 = completionEvent3;
                    break;
                case DetectedActivity.TILTING /*5*/:
                    completionEvent2 = (CompletionEvent) C0242a.m298a(parcel, B, CompletionEvent.CREATOR);
                    changeEvent2 = changeEvent;
                    i3 = i;
                    i = i2;
                    break;
                default:
                    C0242a.m302b(parcel, B);
                    completionEvent2 = completionEvent;
                    changeEvent2 = changeEvent;
                    i3 = i;
                    i = i2;
                    break;
            }
            i2 = i;
            i = i3;
            changeEvent = changeEvent2;
            completionEvent = completionEvent2;
        }
        if (parcel.dataPosition() == C) {
            return new OnEventResponse(i2, i, changeEvent, completionEvent);
        }
        throw new C0241a("Overread allowed size end=" + C, parcel);
    }

    public OnEventResponse[] bA(int i) {
        return new OnEventResponse[i];
    }

    public /* synthetic */ Object createFromParcel(Parcel x0) {
        return ao(x0);
    }

    public /* synthetic */ Object[] newArray(int x0) {
        return bA(x0);
    }
}
