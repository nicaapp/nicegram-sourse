package com.google.android.gms.drive.internal;

import android.os.Parcel;
import android.os.Parcelable.Creator;
import com.google.android.gms.common.internal.safeparcel.C0242a;
import com.google.android.gms.common.internal.safeparcel.C0242a.C0241a;
import com.google.android.gms.common.internal.safeparcel.C0243b;
import com.google.android.gms.drive.DriveId;
import com.google.android.gms.drive.events.CompletionEvent;
import com.google.android.gms.drive.metadata.internal.MetadataBundle;
import org.telegram.android.time.FastDatePrinter;

/* renamed from: com.google.android.gms.drive.internal.k */
public class C0270k implements Creator<CreateFolderRequest> {
    static void m469a(CreateFolderRequest createFolderRequest, Parcel parcel, int i) {
        int D = C0243b.m329D(parcel);
        C0243b.m356c(parcel, 1, createFolderRequest.BR);
        C0243b.m340a(parcel, 2, createFolderRequest.On, i, false);
        C0243b.m340a(parcel, 3, createFolderRequest.Ol, i, false);
        C0243b.m332H(parcel, D);
    }

    public CreateFolderRequest ad(Parcel parcel) {
        MetadataBundle metadataBundle = null;
        int C = C0242a.m293C(parcel);
        int i = 0;
        DriveId driveId = null;
        while (parcel.dataPosition() < C) {
            DriveId driveId2;
            int g;
            MetadataBundle metadataBundle2;
            int B = C0242a.m291B(parcel);
            switch (C0242a.aD(B)) {
                case CompletionEvent.STATUS_FAILURE /*1*/:
                    MetadataBundle metadataBundle3 = metadataBundle;
                    driveId2 = driveId;
                    g = C0242a.m309g(parcel, B);
                    metadataBundle2 = metadataBundle3;
                    break;
                case CompletionEvent.STATUS_CONFLICT /*2*/:
                    g = i;
                    DriveId driveId3 = (DriveId) C0242a.m298a(parcel, B, DriveId.CREATOR);
                    metadataBundle2 = metadataBundle;
                    driveId2 = driveId3;
                    break;
                case FastDatePrinter.SHORT /*3*/:
                    metadataBundle2 = (MetadataBundle) C0242a.m298a(parcel, B, MetadataBundle.CREATOR);
                    driveId2 = driveId;
                    g = i;
                    break;
                default:
                    C0242a.m302b(parcel, B);
                    metadataBundle2 = metadataBundle;
                    driveId2 = driveId;
                    g = i;
                    break;
            }
            i = g;
            driveId = driveId2;
            metadataBundle = metadataBundle2;
        }
        if (parcel.dataPosition() == C) {
            return new CreateFolderRequest(i, driveId, metadataBundle);
        }
        throw new C0241a("Overread allowed size end=" + C, parcel);
    }

    public CreateFolderRequest[] bn(int i) {
        return new CreateFolderRequest[i];
    }

    public /* synthetic */ Object createFromParcel(Parcel x0) {
        return ad(x0);
    }

    public /* synthetic */ Object[] newArray(int x0) {
        return bn(x0);
    }
}
