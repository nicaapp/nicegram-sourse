package com.google.android.gms.drive.internal;

import android.os.Parcel;
import android.os.Parcelable.Creator;
import com.google.android.gms.common.internal.safeparcel.SafeParcelable;

public class OnDownloadProgressResponse implements SafeParcelable {
    public static final Creator<OnDownloadProgressResponse> CREATOR;
    final int BR;
    final long Pp;
    final long Pq;

    static {
        CREATOR = new aj();
    }

    OnDownloadProgressResponse(int versionCode, long bytesLoaded, long bytesExpected) {
        this.BR = versionCode;
        this.Pp = bytesLoaded;
        this.Pq = bytesExpected;
    }

    public int describeContents() {
        return 0;
    }

    public long m2519if() {
        return this.Pp;
    }

    public long ig() {
        return this.Pq;
    }

    public void writeToParcel(Parcel dest, int flags) {
        aj.m437a(this, dest, flags);
    }
}
