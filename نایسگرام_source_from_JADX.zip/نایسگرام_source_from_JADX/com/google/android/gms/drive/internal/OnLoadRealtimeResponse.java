package com.google.android.gms.drive.internal;

import android.os.Parcel;
import android.os.Parcelable.Creator;
import com.google.android.gms.common.internal.safeparcel.SafeParcelable;

public class OnLoadRealtimeResponse implements SafeParcelable {
    public static final Creator<OnLoadRealtimeResponse> CREATOR;
    final int BR;
    final boolean vR;

    static {
        CREATOR = new aq();
    }

    OnLoadRealtimeResponse(int versionCode, boolean isInitialized) {
        this.BR = versionCode;
        this.vR = isInitialized;
    }

    public int describeContents() {
        return 0;
    }

    public void writeToParcel(Parcel dest, int flags) {
        aq.m444a(this, dest, flags);
    }
}
