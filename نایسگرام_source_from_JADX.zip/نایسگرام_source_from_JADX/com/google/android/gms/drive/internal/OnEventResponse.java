package com.google.android.gms.drive.internal;

import android.os.Parcel;
import android.os.Parcelable.Creator;
import com.google.android.gms.common.internal.safeparcel.SafeParcelable;
import com.google.android.gms.drive.events.ChangeEvent;
import com.google.android.gms.drive.events.CompletionEvent;
import com.google.android.gms.drive.events.DriveEvent;

public class OnEventResponse implements SafeParcelable {
    public static final Creator<OnEventResponse> CREATOR;
    final int BR;
    final int Oa;
    final ChangeEvent Ps;
    final CompletionEvent Pt;

    static {
        CREATOR = new am();
    }

    OnEventResponse(int versionCode, int eventType, ChangeEvent changeEvent, CompletionEvent completionEvent) {
        this.BR = versionCode;
        this.Oa = eventType;
        this.Ps = changeEvent;
        this.Pt = completionEvent;
    }

    public int describeContents() {
        return 0;
    }

    public DriveEvent ih() {
        switch (this.Oa) {
            case CompletionEvent.STATUS_FAILURE /*1*/:
                return this.Ps;
            case CompletionEvent.STATUS_CONFLICT /*2*/:
                return this.Pt;
            default:
                throw new IllegalStateException("Unexpected event type " + this.Oa);
        }
    }

    public void writeToParcel(Parcel dest, int flags) {
        am.m440a(this, dest, flags);
    }
}
