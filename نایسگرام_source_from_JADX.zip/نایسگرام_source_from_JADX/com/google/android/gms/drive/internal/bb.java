package com.google.android.gms.drive.internal;

import android.os.RemoteException;
import com.google.android.gms.common.api.BaseImplementation.C0191b;
import com.google.android.gms.common.api.Status;

public class bb extends C2392c {
    private final C0191b<Status> De;

    public bb(C0191b<Status> c0191b) {
        this.De = c0191b;
    }

    public void m4611o(Status status) throws RemoteException {
        this.De.m147b(status);
    }

    public void onSuccess() throws RemoteException {
        this.De.m147b(Status.Jv);
    }
}
