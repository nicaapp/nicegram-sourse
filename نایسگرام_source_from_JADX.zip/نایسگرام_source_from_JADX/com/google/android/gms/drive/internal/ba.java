package com.google.android.gms.drive.internal;

import android.os.Parcel;
import android.os.Parcelable.Creator;
import com.google.android.gms.common.internal.safeparcel.C0242a;
import com.google.android.gms.common.internal.safeparcel.C0242a.C0241a;
import com.google.android.gms.common.internal.safeparcel.C0243b;
import com.google.android.gms.drive.DriveId;
import com.google.android.gms.drive.events.CompletionEvent;
import java.util.ArrayList;
import java.util.List;
import org.telegram.android.time.FastDatePrinter;

public class ba implements Creator<SetResourceParentsRequest> {
    static void m455a(SetResourceParentsRequest setResourceParentsRequest, Parcel parcel, int i) {
        int D = C0243b.m329D(parcel);
        C0243b.m356c(parcel, 1, setResourceParentsRequest.BR);
        C0243b.m340a(parcel, 2, setResourceParentsRequest.Pz, i, false);
        C0243b.m357c(parcel, 3, setResourceParentsRequest.PA, false);
        C0243b.m332H(parcel, D);
    }

    public SetResourceParentsRequest aB(Parcel parcel) {
        List list = null;
        int C = C0242a.m293C(parcel);
        int i = 0;
        DriveId driveId = null;
        while (parcel.dataPosition() < C) {
            DriveId driveId2;
            int g;
            ArrayList c;
            int B = C0242a.m291B(parcel);
            List list2;
            switch (C0242a.aD(B)) {
                case CompletionEvent.STATUS_FAILURE /*1*/:
                    List list3 = list;
                    driveId2 = driveId;
                    g = C0242a.m309g(parcel, B);
                    list2 = list3;
                    break;
                case CompletionEvent.STATUS_CONFLICT /*2*/:
                    g = i;
                    DriveId driveId3 = (DriveId) C0242a.m298a(parcel, B, DriveId.CREATOR);
                    list2 = list;
                    driveId2 = driveId3;
                    break;
                case FastDatePrinter.SHORT /*3*/:
                    c = C0242a.m304c(parcel, B, DriveId.CREATOR);
                    driveId2 = driveId;
                    g = i;
                    break;
                default:
                    C0242a.m302b(parcel, B);
                    c = list;
                    driveId2 = driveId;
                    g = i;
                    break;
            }
            i = g;
            driveId = driveId2;
            Object obj = c;
        }
        if (parcel.dataPosition() == C) {
            return new SetResourceParentsRequest(i, driveId, list);
        }
        throw new C0241a("Overread allowed size end=" + C, parcel);
    }

    public SetResourceParentsRequest[] bN(int i) {
        return new SetResourceParentsRequest[i];
    }

    public /* synthetic */ Object createFromParcel(Parcel x0) {
        return aB(x0);
    }

    public /* synthetic */ Object[] newArray(int x0) {
        return bN(x0);
    }
}
