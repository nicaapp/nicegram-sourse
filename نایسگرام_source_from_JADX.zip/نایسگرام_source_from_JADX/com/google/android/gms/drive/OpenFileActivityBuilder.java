package com.google.android.gms.drive;

import android.content.IntentSender;
import com.google.android.gms.common.api.GoogleApiClient;
import com.google.android.gms.common.internal.C0238o;
import com.google.android.gms.drive.internal.C2398q;
import com.google.android.gms.drive.internal.OpenFileIntentSenderRequest;

public class OpenFileActivityBuilder {
    public static final String EXTRA_RESPONSE_DRIVE_ID = "response_drive_id";
    private String Nw;
    private String[] Nx;
    private DriveId Ny;

    public IntentSender build(GoogleApiClient apiClient) {
        C0238o.m277a(apiClient.isConnected(), "Client must be connected");
        if (this.Nx == null) {
            this.Nx = new String[0];
        }
        try {
            return ((C2398q) apiClient.m149a(Drive.CU)).hY().m389a(new OpenFileIntentSenderRequest(this.Nw, this.Nx, this.Ny));
        } catch (Throwable e) {
            throw new RuntimeException("Unable to connect Drive Play Service", e);
        }
    }

    public OpenFileActivityBuilder setActivityStartFolder(DriveId folder) {
        this.Ny = (DriveId) C0238o.m283i(folder);
        return this;
    }

    public OpenFileActivityBuilder setActivityTitle(String title) {
        this.Nw = (String) C0238o.m283i(title);
        return this;
    }

    public OpenFileActivityBuilder setMimeType(String[] mimeTypes) {
        C0238o.m281b(mimeTypes != null, (Object) "mimeTypes may not be null");
        this.Nx = mimeTypes;
        return this;
    }
}
