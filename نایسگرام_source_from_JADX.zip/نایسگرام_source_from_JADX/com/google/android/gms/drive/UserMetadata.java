package com.google.android.gms.drive;

import android.os.Parcel;
import android.os.Parcelable.Creator;
import com.google.android.gms.common.internal.safeparcel.SafeParcelable;

public class UserMetadata implements SafeParcelable {
    public static final Creator<UserMetadata> CREATOR;
    final int BR;
    final String NG;
    final String NH;
    final String NI;
    final boolean NJ;
    final String NK;

    static {
        CREATOR = new C0259h();
    }

    UserMetadata(int versionCode, String permissionId, String displayName, String pictureUrl, boolean isAuthenticatedUser, String emailAddress) {
        this.BR = versionCode;
        this.NG = permissionId;
        this.NH = displayName;
        this.NI = pictureUrl;
        this.NJ = isAuthenticatedUser;
        this.NK = emailAddress;
    }

    public UserMetadata(String permissionId, String displayName, String pictureUrl, boolean isAuthenticatedUser, String emailAddress) {
        this(1, permissionId, displayName, pictureUrl, isAuthenticatedUser, emailAddress);
    }

    public int describeContents() {
        return 0;
    }

    public String toString() {
        return String.format("Permission ID: '%s', Display Name: '%s', Picture URL: '%s', Authenticated User: %b, Email: '%s'", new Object[]{this.NG, this.NH, this.NI, Boolean.valueOf(this.NJ), this.NK});
    }

    public void writeToParcel(Parcel dest, int flags) {
        C0259h.m382a(this, dest, flags);
    }
}
