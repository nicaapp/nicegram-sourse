package com.google.android.gms.drive;

import com.google.android.gms.drive.metadata.internal.AppVisibleCustomProperties.C0279a;
import com.google.android.gms.drive.metadata.internal.MetadataBundle;
import com.google.android.gms.internal.kd;
import com.google.android.gms.internal.kf;
import java.util.Date;

public final class MetadataChangeSet {
    public static final MetadataChangeSet Nt;
    private final MetadataBundle Nu;

    public static class Builder {
        private final MetadataBundle Nu;
        private C0279a Nv;

        public Builder() {
            this.Nu = MetadataBundle.io();
        }

        public MetadataChangeSet build() {
            if (this.Nv != null) {
                this.Nu.m2589b(kd.PO, this.Nv.im());
            }
            return new MetadataChangeSet(this.Nu);
        }

        public Builder setDescription(String description) {
            this.Nu.m2589b(kd.PP, description);
            return this;
        }

        public Builder setIndexableText(String text) {
            this.Nu.m2589b(kd.PU, text);
            return this;
        }

        public Builder setLastViewedByMeDate(Date date) {
            this.Nu.m2589b(kf.Qu, date);
            return this;
        }

        public Builder setMimeType(String mimeType) {
            this.Nu.m2589b(kd.Qd, mimeType);
            return this;
        }

        public Builder setPinned(boolean pinned) {
            this.Nu.m2589b(kd.PY, Boolean.valueOf(pinned));
            return this;
        }

        public Builder setStarred(boolean starred) {
            this.Nu.m2589b(kd.Qk, Boolean.valueOf(starred));
            return this;
        }

        public Builder setTitle(String title) {
            this.Nu.m2589b(kd.Qm, title);
            return this;
        }

        public Builder setViewed(boolean viewed) {
            this.Nu.m2589b(kd.Qc, Boolean.valueOf(viewed));
            return this;
        }
    }

    static {
        Nt = new MetadataChangeSet(MetadataBundle.io());
    }

    public MetadataChangeSet(MetadataBundle bag) {
        this.Nu = MetadataBundle.m2587a(bag);
    }

    public String getDescription() {
        return (String) this.Nu.m2588a(kd.PP);
    }

    public String getIndexableText() {
        return (String) this.Nu.m2588a(kd.PU);
    }

    public Date getLastViewedByMeDate() {
        return (Date) this.Nu.m2588a(kf.Qu);
    }

    public String getMimeType() {
        return (String) this.Nu.m2588a(kd.Qd);
    }

    public String getTitle() {
        return (String) this.Nu.m2588a(kd.Qm);
    }

    public MetadataBundle hS() {
        return this.Nu;
    }

    public Boolean isPinned() {
        return (Boolean) this.Nu.m2588a(kd.PY);
    }

    public Boolean isStarred() {
        return (Boolean) this.Nu.m2588a(kd.Qk);
    }

    public Boolean isViewed() {
        return (Boolean) this.Nu.m2588a(kd.Qc);
    }
}
