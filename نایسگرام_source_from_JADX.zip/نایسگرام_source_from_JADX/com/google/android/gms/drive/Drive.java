package com.google.android.gms.drive;

import android.content.Context;
import android.os.Bundle;
import android.os.Looper;
import com.google.android.gms.common.Scopes;
import com.google.android.gms.common.api.Api;
import com.google.android.gms.common.api.Api.ApiOptions;
import com.google.android.gms.common.api.Api.ApiOptions.NoOptions;
import com.google.android.gms.common.api.Api.ApiOptions.Optional;
import com.google.android.gms.common.api.Api.C0189b;
import com.google.android.gms.common.api.Api.C0190c;
import com.google.android.gms.common.api.GoogleApiClient.ConnectionCallbacks;
import com.google.android.gms.common.api.GoogleApiClient.OnConnectionFailedListener;
import com.google.android.gms.common.api.Scope;
import com.google.android.gms.common.internal.ClientSettings;
import com.google.android.gms.drive.internal.C1721o;
import com.google.android.gms.drive.internal.C1726t;
import com.google.android.gms.drive.internal.C1728x;
import com.google.android.gms.drive.internal.C2398q;
import java.util.List;
import org.telegram.messenger.ConnectionsManager;

public final class Drive {
    public static final Api<NoOptions> API;
    public static final C0190c<C2398q> CU;
    public static final DriveApi DriveApi;
    public static final Scope Nc;
    public static final Scope Nd;
    public static final Api<C2595b> Ne;
    public static final C0247b Nf;
    public static final C0250e Ng;
    public static final Scope SCOPE_APPFOLDER;
    public static final Scope SCOPE_FILE;

    /* renamed from: com.google.android.gms.drive.Drive.a */
    public static abstract class C1712a<O extends ApiOptions> implements C0189b<C2398q, O> {
        protected abstract Bundle m2514a(O o);

        public C2398q m2516a(Context context, Looper looper, ClientSettings clientSettings, O o, ConnectionCallbacks connectionCallbacks, OnConnectionFailedListener onConnectionFailedListener) {
            List scopes = clientSettings.getScopes();
            return new C2398q(context, looper, clientSettings, connectionCallbacks, onConnectionFailedListener, (String[]) scopes.toArray(new String[scopes.size()]), m2514a(o));
        }

        public int getPriority() {
            return ConnectionsManager.DEFAULT_DATACENTER_ID;
        }
    }

    /* renamed from: com.google.android.gms.drive.Drive.1 */
    static class C23881 extends C1712a<NoOptions> {
        C23881() {
        }

        protected Bundle m3822a(NoOptions noOptions) {
            return new Bundle();
        }
    }

    /* renamed from: com.google.android.gms.drive.Drive.2 */
    static class C23892 extends C1712a<C2595b> {
        C23892() {
        }

        protected Bundle m3825a(C2595b c2595b) {
            return c2595b == null ? new Bundle() : c2595b.hM();
        }
    }

    /* renamed from: com.google.android.gms.drive.Drive.b */
    public static class C2595b implements Optional {
        private final Bundle Nh;

        private C2595b() {
            this(new Bundle());
        }

        private C2595b(Bundle bundle) {
            this.Nh = bundle;
        }

        public Bundle hM() {
            return this.Nh;
        }
    }

    static {
        CU = new C0190c();
        SCOPE_FILE = new Scope(Scopes.DRIVE_FILE);
        SCOPE_APPFOLDER = new Scope(Scopes.DRIVE_APPFOLDER);
        Nc = new Scope("https://www.googleapis.com/auth/drive");
        Nd = new Scope("https://www.googleapis.com/auth/drive.apps");
        API = new Api(new C23881(), CU, new Scope[0]);
        Ne = new Api(new C23892(), CU, new Scope[0]);
        DriveApi = new C1721o();
        Nf = new C1726t();
        Ng = new C1728x();
    }

    private Drive() {
    }
}
