package com.google.android.gms.drive.metadata.internal;

import android.os.Bundle;
import android.os.Parcelable;
import com.google.android.gms.drive.metadata.C2405b;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Collections;

/* renamed from: com.google.android.gms.drive.metadata.internal.i */
public class C2607i<T extends Parcelable> extends C2405b<T> {
    public C2607i(String str, int i) {
        super(str, Collections.emptySet(), Collections.singleton(str), i);
    }

    protected void m4639a(Bundle bundle, Collection<T> collection) {
        bundle.putParcelableArrayList(getName(), new ArrayList(collection));
    }

    protected /* synthetic */ Object m4640g(Bundle bundle) {
        return m4641l(bundle);
    }

    protected Collection<T> m4641l(Bundle bundle) {
        return bundle.getParcelableArrayList(getName());
    }
}
