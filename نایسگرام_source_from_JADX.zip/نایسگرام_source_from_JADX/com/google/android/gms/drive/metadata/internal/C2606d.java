package com.google.android.gms.drive.metadata.internal;

import android.os.Bundle;
import com.google.android.gms.common.data.DataHolder;
import com.google.android.gms.drive.metadata.C2406d;
import java.util.Date;

/* renamed from: com.google.android.gms.drive.metadata.internal.d */
public class C2606d extends C2406d<Date> {
    public C2606d(String str, int i) {
        super(str, i);
    }

    protected void m4633a(Bundle bundle, Date date) {
        bundle.putLong(getName(), date.getTime());
    }

    protected /* synthetic */ Object m4634c(DataHolder dataHolder, int i, int i2) {
        return m4635f(dataHolder, i, i2);
    }

    protected Date m4635f(DataHolder dataHolder, int i, int i2) {
        return new Date(dataHolder.m2425a(getName(), i, i2));
    }

    protected /* synthetic */ Object m4636g(Bundle bundle) {
        return m4637i(bundle);
    }

    protected Date m4637i(Bundle bundle) {
        return new Date(bundle.getLong(getName()));
    }
}
