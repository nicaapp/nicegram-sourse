package com.google.android.gms.drive.metadata.internal;

import com.google.android.gms.common.data.DataHolder;
import com.google.android.gms.drive.UserMetadata;
import java.util.Arrays;
import java.util.Collection;
import java.util.Collections;

/* renamed from: com.google.android.gms.drive.metadata.internal.m */
public class C2609m extends C2410j<UserMetadata> {
    public C2609m(String str, int i) {
        super(str, C2609m.bm(str), Collections.emptyList(), i);
    }

    private String bl(String str) {
        return C2609m.m4648r(getName(), str);
    }

    private static Collection<String> bm(String str) {
        return Arrays.asList(new String[]{C2609m.m4648r(str, "permissionId"), C2609m.m4648r(str, "displayName"), C2609m.m4648r(str, "picture"), C2609m.m4648r(str, "isAuthenticatedUser"), C2609m.m4648r(str, "emailAddress")});
    }

    private static String m4648r(String str, String str2) {
        return "." + str2;
    }

    protected boolean m4649b(DataHolder dataHolder, int i, int i2) {
        return !dataHolder.m2434h(bl("permissionId"), i, i2);
    }

    protected /* synthetic */ Object m4650c(DataHolder dataHolder, int i, int i2) {
        return m4651j(dataHolder, i, i2);
    }

    protected UserMetadata m4651j(DataHolder dataHolder, int i, int i2) {
        String c = dataHolder.m2428c(bl("permissionId"), i, i2);
        if (c == null) {
            return null;
        }
        String c2 = dataHolder.m2428c(bl("displayName"), i, i2);
        String c3 = dataHolder.m2428c(bl("picture"), i, i2);
        Boolean valueOf = Boolean.valueOf(dataHolder.m2429d(bl("isAuthenticatedUser"), i, i2));
        return new UserMetadata(c, c2, c3, valueOf.booleanValue(), dataHolder.m2428c(bl("emailAddress"), i, i2));
    }
}
