package com.google.android.gms.drive.metadata.internal;

import com.google.android.gms.drive.metadata.MetadataField;
import com.google.android.gms.internal.kd;
import com.google.android.gms.internal.kf;
import com.google.android.gms.internal.kh;
import java.util.Collection;
import java.util.Collections;
import java.util.HashMap;
import java.util.Map;

/* renamed from: com.google.android.gms.drive.metadata.internal.e */
public final class C0282e {
    private static Map<String, MetadataField<?>> PK;

    static {
        PK = new HashMap();
        C0282e.m486b(kd.PM);
        C0282e.m486b(kd.Qm);
        C0282e.m486b(kd.Qd);
        C0282e.m486b(kd.Qk);
        C0282e.m486b(kd.Qn);
        C0282e.m486b(kd.PX);
        C0282e.m486b(kd.PY);
        C0282e.m486b(kd.PV);
        C0282e.m486b(kd.Qa);
        C0282e.m486b(kd.Qi);
        C0282e.m486b(kd.PN);
        C0282e.m486b(kd.Qf);
        C0282e.m486b(kd.PP);
        C0282e.m486b(kd.PW);
        C0282e.m486b(kd.PQ);
        C0282e.m486b(kd.PR);
        C0282e.m486b(kd.PS);
        C0282e.m486b(kd.Qc);
        C0282e.m486b(kd.PZ);
        C0282e.m486b(kd.Qe);
        C0282e.m486b(kd.Qg);
        C0282e.m486b(kd.Qh);
        C0282e.m486b(kd.Qj);
        C0282e.m486b(kd.Qo);
        C0282e.m486b(kd.Qp);
        C0282e.m486b(kd.PU);
        C0282e.m486b(kd.PT);
        C0282e.m486b(kd.Ql);
        C0282e.m486b(kd.Qb);
        C0282e.m486b(kd.PO);
        C0282e.m486b(kd.Qq);
        C0282e.m486b(kd.Qr);
        C0282e.m486b(kd.Qs);
        C0282e.m486b(kf.Qt);
        C0282e.m486b(kf.Qv);
        C0282e.m486b(kf.Qw);
        C0282e.m486b(kf.Qx);
        C0282e.m486b(kf.Qu);
        C0282e.m486b(kh.Qz);
        C0282e.m486b(kh.QA);
    }

    private static void m486b(MetadataField<?> metadataField) {
        if (PK.containsKey(metadataField.getName())) {
            throw new IllegalArgumentException("Duplicate field name registered: " + metadataField.getName());
        }
        PK.put(metadataField.getName(), metadataField);
    }

    public static MetadataField<?> bj(String str) {
        return (MetadataField) PK.get(str);
    }

    public static Collection<MetadataField<?>> in() {
        return Collections.unmodifiableCollection(PK.values());
    }
}
