package com.google.android.gms.drive.metadata;

import com.google.android.gms.common.data.DataHolder;
import java.util.Collection;

/* renamed from: com.google.android.gms.drive.metadata.b */
public abstract class C2405b<T> extends C1729a<Collection<T>> {
    protected C2405b(String str, Collection<String> collection, Collection<String> collection2, int i) {
        super(str, collection, collection2, i);
    }

    protected /* synthetic */ Object m3863c(DataHolder dataHolder, int i, int i2) {
        return m3864d(dataHolder, i, i2);
    }

    protected Collection<T> m3864d(DataHolder dataHolder, int i, int i2) {
        throw new UnsupportedOperationException("Cannot read collections from a dataHolder.");
    }
}
