package com.google.android.gms.drive.metadata.internal;

import android.os.Bundle;
import com.google.android.gms.common.data.DataHolder;
import com.google.android.gms.drive.metadata.C1729a;

/* renamed from: com.google.android.gms.drive.metadata.internal.g */
public class C2409g extends C1729a<Long> {
    public C2409g(String str, int i) {
        super(str, i);
    }

    protected void m3877a(Bundle bundle, Long l) {
        bundle.putLong(getName(), l.longValue());
    }

    protected /* synthetic */ Object m3879c(DataHolder dataHolder, int i, int i2) {
        return m3881h(dataHolder, i, i2);
    }

    protected /* synthetic */ Object m3880g(Bundle bundle) {
        return m3882k(bundle);
    }

    protected Long m3881h(DataHolder dataHolder, int i, int i2) {
        return Long.valueOf(dataHolder.m2425a(getName(), i, i2));
    }

    protected Long m3882k(Bundle bundle) {
        return Long.valueOf(bundle.getLong(getName()));
    }
}
