package com.google.android.gms.drive.metadata.internal;

import android.os.Parcel;
import android.os.Parcelable.Creator;
import com.google.android.gms.common.internal.safeparcel.C0242a;
import com.google.android.gms.common.internal.safeparcel.C0242a.C0241a;
import com.google.android.gms.common.internal.safeparcel.C0243b;
import com.google.android.gms.drive.events.CompletionEvent;
import java.util.Collection;

/* renamed from: com.google.android.gms.drive.metadata.internal.a */
public class C0280a implements Creator<AppVisibleCustomProperties> {
    static void m484a(AppVisibleCustomProperties appVisibleCustomProperties, Parcel parcel, int i) {
        int D = C0243b.m329D(parcel);
        C0243b.m356c(parcel, 1, appVisibleCustomProperties.BR);
        C0243b.m357c(parcel, 2, appVisibleCustomProperties.PH, false);
        C0243b.m332H(parcel, D);
    }

    public AppVisibleCustomProperties aF(Parcel parcel) {
        int C = C0242a.m293C(parcel);
        int i = 0;
        Collection collection = null;
        while (parcel.dataPosition() < C) {
            int B = C0242a.m291B(parcel);
            switch (C0242a.aD(B)) {
                case CompletionEvent.STATUS_FAILURE /*1*/:
                    i = C0242a.m309g(parcel, B);
                    break;
                case CompletionEvent.STATUS_CONFLICT /*2*/:
                    collection = C0242a.m304c(parcel, B, CustomProperty.CREATOR);
                    break;
                default:
                    C0242a.m302b(parcel, B);
                    break;
            }
        }
        if (parcel.dataPosition() == C) {
            return new AppVisibleCustomProperties(i, collection);
        }
        throw new C0241a("Overread allowed size end=" + C, parcel);
    }

    public AppVisibleCustomProperties[] bR(int i) {
        return new AppVisibleCustomProperties[i];
    }

    public /* synthetic */ Object createFromParcel(Parcel x0) {
        return aF(x0);
    }

    public /* synthetic */ Object[] newArray(int x0) {
        return bR(x0);
    }
}
