package com.google.android.gms.drive.metadata;

public interface SearchableMetadataField<T> extends MetadataField<T> {
}
