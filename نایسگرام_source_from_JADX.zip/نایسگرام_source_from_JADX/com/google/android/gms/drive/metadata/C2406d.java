package com.google.android.gms.drive.metadata;

/* renamed from: com.google.android.gms.drive.metadata.d */
public abstract class C2406d<T extends Comparable<T>> extends C1729a<T> {
    protected C2406d(String str, int i) {
        super(str, i);
    }
}
