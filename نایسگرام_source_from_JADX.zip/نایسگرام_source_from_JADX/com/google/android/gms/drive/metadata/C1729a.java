package com.google.android.gms.drive.metadata;

import android.os.Bundle;
import com.google.android.gms.common.data.DataHolder;
import com.google.android.gms.common.internal.C0238o;
import com.google.android.gms.drive.metadata.internal.MetadataBundle;
import java.util.Collection;
import java.util.Collections;
import java.util.HashSet;
import java.util.Set;

/* renamed from: com.google.android.gms.drive.metadata.a */
public abstract class C1729a<T> implements MetadataField<T> {
    private final String PB;
    private final Set<String> PC;
    private final Set<String> PD;
    private final int PE;

    protected C1729a(String str, int i) {
        this.PB = (String) C0238o.m279b((Object) str, (Object) "fieldName");
        this.PC = Collections.singleton(str);
        this.PD = Collections.emptySet();
        this.PE = i;
    }

    protected C1729a(String str, Collection<String> collection, Collection<String> collection2, int i) {
        this.PB = (String) C0238o.m279b((Object) str, (Object) "fieldName");
        this.PC = Collections.unmodifiableSet(new HashSet(collection));
        this.PD = Collections.unmodifiableSet(new HashSet(collection2));
        this.PE = i;
    }

    public final T m2578a(DataHolder dataHolder, int i, int i2) {
        return m2582b(dataHolder, i, i2) ? m2583c(dataHolder, i, i2) : null;
    }

    protected abstract void m2579a(Bundle bundle, T t);

    public final void m2580a(DataHolder dataHolder, MetadataBundle metadataBundle, int i, int i2) {
        C0238o.m279b((Object) dataHolder, (Object) "dataHolder");
        C0238o.m279b((Object) metadataBundle, (Object) "bundle");
        metadataBundle.m2589b(this, m2578a(dataHolder, i, i2));
    }

    public final void m2581a(T t, Bundle bundle) {
        C0238o.m279b((Object) bundle, (Object) "bundle");
        if (t == null) {
            bundle.putString(getName(), null);
        } else {
            m2579a(bundle, (Object) t);
        }
    }

    protected boolean m2582b(DataHolder dataHolder, int i, int i2) {
        for (String h : this.PC) {
            if (dataHolder.m2434h(h, i, i2)) {
                return false;
            }
        }
        return true;
    }

    protected abstract T m2583c(DataHolder dataHolder, int i, int i2);

    public final T m2584f(Bundle bundle) {
        C0238o.m279b((Object) bundle, (Object) "bundle");
        return bundle.get(getName()) != null ? m2585g(bundle) : null;
    }

    protected abstract T m2585g(Bundle bundle);

    public final String getName() {
        return this.PB;
    }

    public String toString() {
        return this.PB;
    }
}
