package com.google.android.gms.drive.metadata;

import android.os.Parcel;
import android.os.Parcelable.Creator;
import com.google.android.gms.common.internal.C0238o;
import com.google.android.gms.common.internal.safeparcel.SafeParcelable;
import java.util.regex.Pattern;

public class CustomPropertyKey implements SafeParcelable {
    public static final Creator<CustomPropertyKey> CREATOR;
    private static final Pattern PF;
    final int BR;
    final String JO;
    final int mVisibility;

    static {
        CREATOR = new C0277c();
        PF = Pattern.compile("[\\w.!@$%^&*()/-]+");
    }

    CustomPropertyKey(int versionCode, String key, int visibility) {
        boolean z = true;
        C0238o.m279b((Object) key, (Object) "key");
        C0238o.m281b(PF.matcher(key).matches(), (Object) "key name characters must be alphanumeric or one of .!@$%^&*()-_/");
        if (!(visibility == 0 || visibility == 1)) {
            z = false;
        }
        C0238o.m281b(z, (Object) "visibility must be either PUBLIC or PRIVATE");
        this.BR = versionCode;
        this.JO = key;
        this.mVisibility = visibility;
    }

    public int describeContents() {
        return 0;
    }

    public boolean equals(Object obj) {
        boolean z = true;
        if (obj == null) {
            return false;
        }
        if (obj == this) {
            return true;
        }
        if (!(obj instanceof CustomPropertyKey)) {
            return false;
        }
        CustomPropertyKey customPropertyKey = (CustomPropertyKey) obj;
        if (!(customPropertyKey.getKey().equals(this.JO) && customPropertyKey.getVisibility() == this.mVisibility)) {
            z = false;
        }
        return z;
    }

    public String getKey() {
        return this.JO;
    }

    public int getVisibility() {
        return this.mVisibility;
    }

    public int hashCode() {
        return (this.JO + this.mVisibility).hashCode();
    }

    public String toString() {
        return "CustomPropertyKey(" + this.JO + "," + this.mVisibility + ")";
    }

    public void writeToParcel(Parcel dest, int flags) {
        C0277c.m483a(this, dest, flags);
    }
}
