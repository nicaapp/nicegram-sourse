package com.google.android.gms.drive.metadata;

import android.os.Bundle;
import com.google.android.gms.common.data.DataHolder;
import com.google.android.gms.drive.metadata.internal.MetadataBundle;

public interface MetadataField<T> {
    T m479a(DataHolder dataHolder, int i, int i2);

    void m480a(DataHolder dataHolder, MetadataBundle metadataBundle, int i, int i2);

    void m481a(T t, Bundle bundle);

    T m482f(Bundle bundle);

    String getName();
}
