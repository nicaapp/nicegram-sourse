package com.google.android.gms.drive.metadata.internal;

import android.content.Context;
import android.os.Bundle;
import android.os.Parcel;
import android.os.Parcelable.Creator;
import com.google.android.gms.common.data.C1693a;
import com.google.android.gms.common.internal.C0237n;
import com.google.android.gms.common.internal.C0238o;
import com.google.android.gms.common.internal.safeparcel.SafeParcelable;
import com.google.android.gms.drive.internal.C0273v;
import com.google.android.gms.drive.metadata.MetadataField;
import com.google.android.gms.internal.kd;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

public final class MetadataBundle implements SafeParcelable {
    public static final Creator<MetadataBundle> CREATOR;
    final int BR;
    final Bundle PL;

    static {
        CREATOR = new C0283h();
    }

    MetadataBundle(int versionCode, Bundle valueBundle) {
        this.BR = versionCode;
        this.PL = (Bundle) C0238o.m283i(valueBundle);
        this.PL.setClassLoader(getClass().getClassLoader());
        List<String> arrayList = new ArrayList();
        for (String str : this.PL.keySet()) {
            if (C0282e.bj(str) == null) {
                arrayList.add(str);
                C0273v.m475p("MetadataBundle", "Ignored unknown metadata field in bundle: " + str);
            }
        }
        for (String str2 : arrayList) {
            this.PL.remove(str2);
        }
    }

    private MetadataBundle(Bundle valueBundle) {
        this(1, valueBundle);
    }

    public static <T> MetadataBundle m2586a(MetadataField<T> metadataField, T t) {
        MetadataBundle io = io();
        io.m2589b(metadataField, t);
        return io;
    }

    public static MetadataBundle m2587a(MetadataBundle metadataBundle) {
        return new MetadataBundle(new Bundle(metadataBundle.PL));
    }

    public static MetadataBundle io() {
        return new MetadataBundle(new Bundle());
    }

    public <T> T m2588a(MetadataField<T> metadataField) {
        return metadataField.m482f(this.PL);
    }

    public <T> void m2589b(MetadataField<T> metadataField, T t) {
        if (C0282e.bj(metadataField.getName()) == null) {
            throw new IllegalArgumentException("Unregistered field: " + metadataField.getName());
        }
        metadataField.m481a(t, this.PL);
    }

    public int describeContents() {
        return 0;
    }

    public boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (!(obj instanceof MetadataBundle)) {
            return false;
        }
        MetadataBundle metadataBundle = (MetadataBundle) obj;
        Set<String> keySet = this.PL.keySet();
        if (!keySet.equals(metadataBundle.PL.keySet())) {
            return false;
        }
        for (String str : keySet) {
            if (!C0237n.equal(this.PL.get(str), metadataBundle.PL.get(str))) {
                return false;
            }
        }
        return true;
    }

    public int hashCode() {
        int i = 1;
        for (String str : this.PL.keySet()) {
            i *= 31;
            i = this.PL.get(str).hashCode() + i;
        }
        return i;
    }

    public Set<MetadataField<?>> ip() {
        Set<MetadataField<?>> hashSet = new HashSet();
        for (String bj : this.PL.keySet()) {
            hashSet.add(C0282e.bj(bj));
        }
        return hashSet;
    }

    public void setContext(Context context) {
        C1693a c1693a = (C1693a) m2588a(kd.Ql);
        if (c1693a != null) {
            c1693a.m2436a(context.getCacheDir());
        }
    }

    public String toString() {
        return "MetadataBundle [values=" + this.PL + "]";
    }

    public void writeToParcel(Parcel dest, int flags) {
        C0283h.m487a(this, dest, flags);
    }
}
