package com.google.android.gms.drive.metadata.internal;

import android.os.Bundle;
import com.google.android.gms.common.data.DataHolder;
import com.google.android.gms.drive.metadata.C1729a;

/* renamed from: com.google.android.gms.drive.metadata.internal.l */
public class C2411l extends C1729a<String> {
    public C2411l(String str, int i) {
        super(str, i);
    }

    protected void m3888a(Bundle bundle, String str) {
        bundle.putString(getName(), str);
    }

    protected /* synthetic */ Object m3889c(DataHolder dataHolder, int i, int i2) {
        return m3891i(dataHolder, i, i2);
    }

    protected /* synthetic */ Object m3890g(Bundle bundle) {
        return m3892n(bundle);
    }

    protected String m3891i(DataHolder dataHolder, int i, int i2) {
        return dataHolder.m2428c(getName(), i, i2);
    }

    protected String m3892n(Bundle bundle) {
        return bundle.getString(getName());
    }
}
