package com.google.android.gms.drive.metadata.internal;

import android.os.Bundle;
import com.google.android.gms.common.data.DataHolder;
import com.google.android.gms.drive.metadata.C1729a;

/* renamed from: com.google.android.gms.drive.metadata.internal.b */
public class C2407b extends C1729a<Boolean> {
    public C2407b(String str, int i) {
        super(str, i);
    }

    protected void m3865a(Bundle bundle, Boolean bool) {
        bundle.putBoolean(getName(), bool.booleanValue());
    }

    protected /* synthetic */ Object m3867c(DataHolder dataHolder, int i, int i2) {
        return m3868e(dataHolder, i, i2);
    }

    protected Boolean m3868e(DataHolder dataHolder, int i, int i2) {
        return Boolean.valueOf(dataHolder.m2429d(getName(), i, i2));
    }

    protected /* synthetic */ Object m3869g(Bundle bundle) {
        return m3870h(bundle);
    }

    protected Boolean m3870h(Bundle bundle) {
        return Boolean.valueOf(bundle.getBoolean(getName()));
    }
}
