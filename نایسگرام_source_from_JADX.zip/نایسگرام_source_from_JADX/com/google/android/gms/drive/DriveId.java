package com.google.android.gms.drive;

import android.os.Parcel;
import android.os.Parcelable.Creator;
import android.util.Base64;
import com.google.android.gms.common.internal.C0238o;
import com.google.android.gms.common.internal.safeparcel.SafeParcelable;
import com.google.android.gms.drive.internal.C0273v;
import com.google.android.gms.drive.internal.ah;
import com.google.android.gms.internal.pm;
import com.google.android.gms.internal.pn;
import org.telegram.messenger.BuildConfig;

public class DriveId implements SafeParcelable {
    public static final Creator<DriveId> CREATOR;
    final int BR;
    final String Ni;
    final long Nj;
    final long Nk;
    private volatile String Nl;

    static {
        CREATOR = new C0248c();
    }

    DriveId(int versionCode, String resourceId, long sqlId, long databaseInstanceId) {
        boolean z = false;
        this.Nl = null;
        this.BR = versionCode;
        this.Ni = resourceId;
        C0238o.m276K(!BuildConfig.FLAVOR.equals(resourceId));
        if (!(resourceId == null && sqlId == -1)) {
            z = true;
        }
        C0238o.m276K(z);
        this.Nj = sqlId;
        this.Nk = databaseInstanceId;
    }

    public DriveId(String resourceId, long sqlId, long databaseInstanceId) {
        this(1, resourceId, sqlId, databaseInstanceId);
    }

    public static DriveId bg(String str) {
        C0238o.m283i(str);
        return new DriveId(str, -1, -1);
    }

    public static DriveId decodeFromString(String s) {
        C0238o.m281b(s.startsWith("DriveId:"), "Invalid DriveId: " + s);
        return m2517f(Base64.decode(s.substring("DriveId:".length()), 10));
    }

    static DriveId m2517f(byte[] bArr) {
        try {
            ah g = ah.m3833g(bArr);
            return new DriveId(g.versionCode, BuildConfig.FLAVOR.equals(g.Pl) ? null : g.Pl, g.Pm, g.Pn);
        } catch (pm e) {
            throw new IllegalArgumentException();
        }
    }

    public int describeContents() {
        return 0;
    }

    public final String encodeToString() {
        if (this.Nl == null) {
            this.Nl = "DriveId:" + Base64.encodeToString(hN(), 10);
        }
        return this.Nl;
    }

    public boolean equals(Object obj) {
        if (!(obj instanceof DriveId)) {
            return false;
        }
        DriveId driveId = (DriveId) obj;
        if (driveId.Nk != this.Nk) {
            C0273v.m475p("DriveId", "Attempt to compare invalid DriveId detected. Has local storage been cleared?");
            return false;
        } else if (driveId.Nj == -1 && this.Nj == -1) {
            return driveId.Ni.equals(this.Ni);
        } else {
            return driveId.Nj == this.Nj;
        }
    }

    public String getResourceId() {
        return this.Ni;
    }

    final byte[] hN() {
        pn ahVar = new ah();
        ahVar.versionCode = this.BR;
        ahVar.Pl = this.Ni == null ? BuildConfig.FLAVOR : this.Ni;
        ahVar.Pm = this.Nj;
        ahVar.Pn = this.Nk;
        return pn.m1838f(ahVar);
    }

    public int hashCode() {
        return this.Nj == -1 ? this.Ni.hashCode() : (String.valueOf(this.Nk) + String.valueOf(this.Nj)).hashCode();
    }

    public String toString() {
        return encodeToString();
    }

    public void writeToParcel(Parcel out, int flags) {
        C0248c.m366a(this, out, flags);
    }
}
