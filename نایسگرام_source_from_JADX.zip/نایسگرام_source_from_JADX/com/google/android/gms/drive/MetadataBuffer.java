package com.google.android.gms.drive;

import com.google.android.gms.common.data.DataBuffer;
import com.google.android.gms.common.data.DataHolder;
import com.google.android.gms.drive.internal.C2393l;
import com.google.android.gms.drive.metadata.C2405b;
import com.google.android.gms.drive.metadata.MetadataField;
import com.google.android.gms.drive.metadata.internal.C0282e;
import com.google.android.gms.drive.metadata.internal.MetadataBundle;
import com.google.android.gms.internal.kd;

public final class MetadataBuffer extends DataBuffer<Metadata> {
    private final String Nq;
    private C2390a Nr;

    /* renamed from: com.google.android.gms.drive.MetadataBuffer.a */
    private static class C2390a extends Metadata {
        private final DataHolder II;
        private final int JY;
        private final int Ns;

        public C2390a(DataHolder dataHolder, int i) {
            this.II = dataHolder;
            this.Ns = i;
            this.JY = dataHolder.ar(i);
        }

        protected <T> T m3827a(MetadataField<T> metadataField) {
            return metadataField.m479a(this.II, this.Ns, this.JY);
        }

        public /* synthetic */ Object freeze() {
            return hR();
        }

        public Metadata hR() {
            MetadataBundle io = MetadataBundle.io();
            for (MetadataField metadataField : C0282e.in()) {
                if (!((metadataField instanceof C2405b) || metadataField == kd.Ql)) {
                    metadataField.m480a(this.II, io, this.Ns, this.JY);
                }
            }
            return new C2393l(io);
        }

        public boolean isDataValid() {
            return !this.II.isClosed();
        }
    }

    public MetadataBuffer(DataHolder dataHolder, String nextPageToken) {
        super(dataHolder);
        this.Nq = nextPageToken;
        dataHolder.gy().setClassLoader(MetadataBuffer.class.getClassLoader());
    }

    public Metadata get(int row) {
        C2390a c2390a = this.Nr;
        if (c2390a != null && c2390a.Ns == row) {
            return c2390a;
        }
        Metadata c2390a2 = new C2390a(this.II, row);
        this.Nr = c2390a2;
        return c2390a2;
    }

    public String getNextPageToken() {
        return this.Nq;
    }
}
