package com.google.android.gms.drive;

import android.os.Parcel;
import android.os.Parcelable.Creator;
import com.google.android.gms.common.internal.safeparcel.C0242a;
import com.google.android.gms.common.internal.safeparcel.C0242a.C0241a;
import com.google.android.gms.common.internal.safeparcel.C0243b;
import com.google.android.gms.drive.events.CompletionEvent;
import com.google.android.gms.games.quest.Quest;
import com.google.android.gms.location.DetectedActivity;
import org.telegram.android.support.widget.helper.ItemTouchHelper;
import org.telegram.android.time.FastDatePrinter;

/* renamed from: com.google.android.gms.drive.g */
public class C0258g implements Creator<StorageStats> {
    static void m380a(StorageStats storageStats, Parcel parcel, int i) {
        int D = C0243b.m329D(parcel);
        C0243b.m356c(parcel, 1, storageStats.BR);
        C0243b.m336a(parcel, 2, storageStats.NB);
        C0243b.m336a(parcel, 3, storageStats.NC);
        C0243b.m336a(parcel, 4, storageStats.ND);
        C0243b.m336a(parcel, 5, storageStats.NE);
        C0243b.m356c(parcel, 6, storageStats.NF);
        C0243b.m332H(parcel, D);
    }

    public StorageStats m381R(Parcel parcel) {
        int i = 0;
        long j = 0;
        int C = C0242a.m293C(parcel);
        long j2 = 0;
        long j3 = 0;
        long j4 = 0;
        int i2 = 0;
        while (parcel.dataPosition() < C) {
            int B = C0242a.m291B(parcel);
            switch (C0242a.aD(B)) {
                case CompletionEvent.STATUS_FAILURE /*1*/:
                    i2 = C0242a.m309g(parcel, B);
                    break;
                case CompletionEvent.STATUS_CONFLICT /*2*/:
                    j4 = C0242a.m311i(parcel, B);
                    break;
                case FastDatePrinter.SHORT /*3*/:
                    j3 = C0242a.m311i(parcel, B);
                    break;
                case ItemTouchHelper.LEFT /*4*/:
                    j2 = C0242a.m311i(parcel, B);
                    break;
                case DetectedActivity.TILTING /*5*/:
                    j = C0242a.m311i(parcel, B);
                    break;
                case Quest.STATE_FAILED /*6*/:
                    i = C0242a.m309g(parcel, B);
                    break;
                default:
                    C0242a.m302b(parcel, B);
                    break;
            }
        }
        if (parcel.dataPosition() == C) {
            return new StorageStats(i2, j4, j3, j2, j, i);
        }
        throw new C0241a("Overread allowed size end=" + C, parcel);
    }

    public StorageStats[] aY(int i) {
        return new StorageStats[i];
    }

    public /* synthetic */ Object createFromParcel(Parcel x0) {
        return m381R(x0);
    }

    public /* synthetic */ Object[] newArray(int x0) {
        return aY(x0);
    }
}
