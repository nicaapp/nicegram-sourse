package com.google.android.gms.drive;

import com.google.android.gms.common.data.Freezable;
import com.google.android.gms.drive.metadata.MetadataField;
import com.google.android.gms.internal.kd;
import com.google.android.gms.internal.kf;
import com.google.android.gms.internal.kh;
import java.util.Date;

public abstract class Metadata implements Freezable<Metadata> {
    public static final int CONTENT_AVAILABLE_LOCALLY = 1;
    public static final int CONTENT_NOT_AVAILABLE_LOCALLY = 0;

    protected abstract <T> T m2518a(MetadataField<T> metadataField);

    public String getAlternateLink() {
        return (String) m2518a(kd.PN);
    }

    public int getContentAvailability() {
        Integer num = (Integer) m2518a(kh.Qz);
        return num == null ? 0 : num.intValue();
    }

    public Date getCreatedDate() {
        return (Date) m2518a(kf.Qt);
    }

    public String getDescription() {
        return (String) m2518a(kd.PP);
    }

    public DriveId getDriveId() {
        return (DriveId) m2518a(kd.PM);
    }

    public String getEmbedLink() {
        return (String) m2518a(kd.PQ);
    }

    public String getFileExtension() {
        return (String) m2518a(kd.PR);
    }

    public long getFileSize() {
        return ((Long) m2518a(kd.PS)).longValue();
    }

    public Date getLastViewedByMeDate() {
        return (Date) m2518a(kf.Qu);
    }

    public String getMimeType() {
        return (String) m2518a(kd.Qd);
    }

    public Date getModifiedByMeDate() {
        return (Date) m2518a(kf.Qw);
    }

    public Date getModifiedDate() {
        return (Date) m2518a(kf.Qv);
    }

    public String getOriginalFilename() {
        return (String) m2518a(kd.Qe);
    }

    public long getQuotaBytesUsed() {
        return ((Long) m2518a(kd.Qj)).longValue();
    }

    public Date getSharedWithMeDate() {
        return (Date) m2518a(kf.Qx);
    }

    public String getTitle() {
        return (String) m2518a(kd.Qm);
    }

    public String getWebContentLink() {
        return (String) m2518a(kd.Qo);
    }

    public String getWebViewLink() {
        return (String) m2518a(kd.Qp);
    }

    public boolean isEditable() {
        Boolean bool = (Boolean) m2518a(kd.PX);
        return bool == null ? false : bool.booleanValue();
    }

    public boolean isFolder() {
        return DriveFolder.MIME_TYPE.equals(getMimeType());
    }

    public boolean isInAppFolder() {
        Boolean bool = (Boolean) m2518a(kd.PV);
        return bool == null ? false : bool.booleanValue();
    }

    public boolean isPinnable() {
        Boolean bool = (Boolean) m2518a(kh.QA);
        return bool == null ? false : bool.booleanValue();
    }

    public boolean isPinned() {
        Boolean bool = (Boolean) m2518a(kd.PY);
        return bool == null ? false : bool.booleanValue();
    }

    public boolean isRestricted() {
        Boolean bool = (Boolean) m2518a(kd.PZ);
        return bool == null ? false : bool.booleanValue();
    }

    public boolean isShared() {
        Boolean bool = (Boolean) m2518a(kd.Qa);
        return bool == null ? false : bool.booleanValue();
    }

    public boolean isStarred() {
        Boolean bool = (Boolean) m2518a(kd.Qk);
        return bool == null ? false : bool.booleanValue();
    }

    public boolean isTrashed() {
        Boolean bool = (Boolean) m2518a(kd.Qn);
        return bool == null ? false : bool.booleanValue();
    }

    public boolean isViewed() {
        Boolean bool = (Boolean) m2518a(kd.Qc);
        return bool == null ? false : bool.booleanValue();
    }
}
