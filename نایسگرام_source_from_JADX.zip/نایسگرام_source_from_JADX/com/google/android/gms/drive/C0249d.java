package com.google.android.gms.drive;

import android.os.Parcel;
import android.os.Parcelable.Creator;
import com.google.android.gms.common.internal.safeparcel.C0242a;
import com.google.android.gms.common.internal.safeparcel.C0242a.C0241a;
import com.google.android.gms.common.internal.safeparcel.C0243b;
import com.google.android.gms.drive.events.CompletionEvent;

/* renamed from: com.google.android.gms.drive.d */
public class C0249d implements Creator<DrivePreferences> {
    static void m368a(DrivePreferences drivePreferences, Parcel parcel, int i) {
        int D = C0243b.m329D(parcel);
        C0243b.m356c(parcel, 1, drivePreferences.BR);
        C0243b.m347a(parcel, 2, drivePreferences.Nm);
        C0243b.m332H(parcel, D);
    }

    public DrivePreferences m369P(Parcel parcel) {
        boolean z = false;
        int C = C0242a.m293C(parcel);
        int i = 0;
        while (parcel.dataPosition() < C) {
            int B = C0242a.m291B(parcel);
            switch (C0242a.aD(B)) {
                case CompletionEvent.STATUS_FAILURE /*1*/:
                    i = C0242a.m309g(parcel, B);
                    break;
                case CompletionEvent.STATUS_CONFLICT /*2*/:
                    z = C0242a.m305c(parcel, B);
                    break;
                default:
                    C0242a.m302b(parcel, B);
                    break;
            }
        }
        if (parcel.dataPosition() == C) {
            return new DrivePreferences(i, z);
        }
        throw new C0241a("Overread allowed size end=" + C, parcel);
    }

    public DrivePreferences[] aU(int i) {
        return new DrivePreferences[i];
    }

    public /* synthetic */ Object createFromParcel(Parcel x0) {
        return m369P(x0);
    }

    public /* synthetic */ Object[] newArray(int x0) {
        return aU(x0);
    }
}
