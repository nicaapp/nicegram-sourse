package com.google.android.gms.drive.query.internal;

import android.os.Parcel;
import com.google.android.gms.drive.metadata.C2405b;
import com.google.android.gms.drive.metadata.SearchableCollectionMetadataField;
import com.google.android.gms.drive.metadata.internal.MetadataBundle;
import java.util.Collection;
import java.util.Collections;

public class InFilter<T> extends AbstractFilter {
    public static final C0294h CREATOR;
    final int BR;
    final MetadataBundle QL;
    private final C2405b<T> QW;

    static {
        CREATOR = new C0294h();
    }

    InFilter(int versionCode, MetadataBundle value) {
        this.BR = versionCode;
        this.QL = value;
        this.QW = (C2405b) C0291e.m494b(value);
    }

    public InFilter(SearchableCollectionMetadataField<T> field, T value) {
        this(1, MetadataBundle.m2586a(field, Collections.singleton(value)));
    }

    public <F> F m4655a(C0292f<F> c0292f) {
        return c0292f.m495b(this.QW, getValue());
    }

    public int describeContents() {
        return 0;
    }

    public T getValue() {
        return ((Collection) this.QL.m2588a(this.QW)).iterator().next();
    }

    public void writeToParcel(Parcel out, int flags) {
        C0294h.m502a(this, out, flags);
    }
}
