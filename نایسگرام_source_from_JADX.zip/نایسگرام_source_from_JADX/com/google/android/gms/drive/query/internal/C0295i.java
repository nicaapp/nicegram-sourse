package com.google.android.gms.drive.query.internal;

import android.os.Parcel;
import android.os.Parcelable.Creator;
import com.google.android.gms.common.internal.safeparcel.C0242a;
import com.google.android.gms.common.internal.safeparcel.C0242a.C0241a;
import com.google.android.gms.common.internal.safeparcel.C0243b;
import com.google.android.gms.drive.events.CompletionEvent;
import com.google.android.gms.location.GeofenceStatusCodes;
import java.util.ArrayList;
import java.util.List;

/* renamed from: com.google.android.gms.drive.query.internal.i */
public class C0295i implements Creator<LogicalFilter> {
    static void m503a(LogicalFilter logicalFilter, Parcel parcel, int i) {
        int D = C0243b.m329D(parcel);
        C0243b.m356c(parcel, GeofenceStatusCodes.GEOFENCE_NOT_AVAILABLE, logicalFilter.BR);
        C0243b.m340a(parcel, 1, logicalFilter.QK, i, false);
        C0243b.m357c(parcel, 2, logicalFilter.QX, false);
        C0243b.m332H(parcel, D);
    }

    public LogicalFilter aQ(Parcel parcel) {
        List list = null;
        int C = C0242a.m293C(parcel);
        int i = 0;
        Operator operator = null;
        while (parcel.dataPosition() < C) {
            int i2;
            Operator operator2;
            ArrayList c;
            int B = C0242a.m291B(parcel);
            List list2;
            switch (C0242a.aD(B)) {
                case CompletionEvent.STATUS_FAILURE /*1*/:
                    i2 = i;
                    Operator operator3 = (Operator) C0242a.m298a(parcel, B, Operator.CREATOR);
                    list2 = list;
                    operator2 = operator3;
                    break;
                case CompletionEvent.STATUS_CONFLICT /*2*/:
                    c = C0242a.m304c(parcel, B, FilterHolder.CREATOR);
                    operator2 = operator;
                    i2 = i;
                    break;
                case GeofenceStatusCodes.GEOFENCE_NOT_AVAILABLE /*1000*/:
                    List list3 = list;
                    operator2 = operator;
                    i2 = C0242a.m309g(parcel, B);
                    list2 = list3;
                    break;
                default:
                    C0242a.m302b(parcel, B);
                    c = list;
                    operator2 = operator;
                    i2 = i;
                    break;
            }
            i = i2;
            operator = operator2;
            Object obj = c;
        }
        if (parcel.dataPosition() == C) {
            return new LogicalFilter(i, operator, list);
        }
        throw new C0241a("Overread allowed size end=" + C, parcel);
    }

    public LogicalFilter[] cc(int i) {
        return new LogicalFilter[i];
    }

    public /* synthetic */ Object createFromParcel(Parcel x0) {
        return aQ(x0);
    }

    public /* synthetic */ Object[] newArray(int x0) {
        return cc(x0);
    }
}
