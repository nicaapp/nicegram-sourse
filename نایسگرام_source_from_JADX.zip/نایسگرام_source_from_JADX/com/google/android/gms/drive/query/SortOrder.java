package com.google.android.gms.drive.query;

import android.os.Parcel;
import android.os.Parcelable.Creator;
import android.text.TextUtils;
import com.google.android.gms.common.internal.safeparcel.SafeParcelable;
import com.google.android.gms.drive.metadata.SortableMetadataField;
import com.google.android.gms.drive.query.internal.FieldWithSortOrder;
import java.util.ArrayList;
import java.util.List;
import java.util.Locale;

public class SortOrder implements SafeParcelable {
    public static final Creator<SortOrder> CREATOR;
    final int BR;
    final List<FieldWithSortOrder> QI;
    final boolean QJ;

    public static class Builder {
        private final List<FieldWithSortOrder> QI;
        private boolean QJ;

        public Builder() {
            this.QI = new ArrayList();
            this.QJ = false;
        }

        public Builder addSortAscending(SortableMetadataField sortField) {
            this.QI.add(new FieldWithSortOrder(sortField.getName(), true));
            return this;
        }

        public Builder addSortDescending(SortableMetadataField sortField) {
            this.QI.add(new FieldWithSortOrder(sortField.getName(), false));
            return this;
        }

        public SortOrder build() {
            return new SortOrder(this.QJ, null);
        }
    }

    static {
        CREATOR = new C0286b();
    }

    SortOrder(int versionCode, List<FieldWithSortOrder> sortingFields, boolean sortFolderFirst) {
        this.BR = versionCode;
        this.QI = sortingFields;
        this.QJ = sortFolderFirst;
    }

    private SortOrder(List<FieldWithSortOrder> sortingFields, boolean sortFolderFirst) {
        this(1, (List) sortingFields, sortFolderFirst);
    }

    public int describeContents() {
        return 0;
    }

    public String toString() {
        return String.format(Locale.US, "SortOrder[%s, %s]", new Object[]{TextUtils.join(",", this.QI), Boolean.valueOf(this.QJ)});
    }

    public void writeToParcel(Parcel out, int flags) {
        C0286b.m489a(this, out, flags);
    }
}
