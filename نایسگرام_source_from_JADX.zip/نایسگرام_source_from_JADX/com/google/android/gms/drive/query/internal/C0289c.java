package com.google.android.gms.drive.query.internal;

import android.os.Parcel;
import android.os.Parcelable.Creator;
import com.google.android.gms.common.internal.safeparcel.C0242a;
import com.google.android.gms.common.internal.safeparcel.C0242a.C0241a;
import com.google.android.gms.common.internal.safeparcel.C0243b;
import com.google.android.gms.drive.events.CompletionEvent;
import com.google.android.gms.location.GeofenceStatusCodes;

/* renamed from: com.google.android.gms.drive.query.internal.c */
public class C0289c implements Creator<FieldWithSortOrder> {
    static void m492a(FieldWithSortOrder fieldWithSortOrder, Parcel parcel, int i) {
        int D = C0243b.m329D(parcel);
        C0243b.m356c(parcel, GeofenceStatusCodes.GEOFENCE_NOT_AVAILABLE, fieldWithSortOrder.BR);
        C0243b.m344a(parcel, 1, fieldWithSortOrder.PB, false);
        C0243b.m347a(parcel, 2, fieldWithSortOrder.QN);
        C0243b.m332H(parcel, D);
    }

    public FieldWithSortOrder aM(Parcel parcel) {
        boolean z = false;
        int C = C0242a.m293C(parcel);
        String str = null;
        int i = 0;
        while (parcel.dataPosition() < C) {
            int B = C0242a.m291B(parcel);
            switch (C0242a.aD(B)) {
                case CompletionEvent.STATUS_FAILURE /*1*/:
                    str = C0242a.m317o(parcel, B);
                    break;
                case CompletionEvent.STATUS_CONFLICT /*2*/:
                    z = C0242a.m305c(parcel, B);
                    break;
                case GeofenceStatusCodes.GEOFENCE_NOT_AVAILABLE /*1000*/:
                    i = C0242a.m309g(parcel, B);
                    break;
                default:
                    C0242a.m302b(parcel, B);
                    break;
            }
        }
        if (parcel.dataPosition() == C) {
            return new FieldWithSortOrder(i, str, z);
        }
        throw new C0241a("Overread allowed size end=" + C, parcel);
    }

    public FieldWithSortOrder[] bY(int i) {
        return new FieldWithSortOrder[i];
    }

    public /* synthetic */ Object createFromParcel(Parcel x0) {
        return aM(x0);
    }

    public /* synthetic */ Object[] newArray(int x0) {
        return bY(x0);
    }
}
