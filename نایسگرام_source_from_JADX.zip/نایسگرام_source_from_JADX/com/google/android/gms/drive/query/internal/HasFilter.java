package com.google.android.gms.drive.query.internal;

import android.os.Parcel;
import com.google.android.gms.drive.metadata.MetadataField;
import com.google.android.gms.drive.metadata.internal.MetadataBundle;

public class HasFilter<T> extends AbstractFilter {
    public static final C0293g CREATOR;
    final int BR;
    final MetadataBundle QL;
    final MetadataField<T> QM;

    static {
        CREATOR = new C0293g();
    }

    HasFilter(int versionCode, MetadataBundle value) {
        this.BR = versionCode;
        this.QL = value;
        this.QM = C0291e.m494b(value);
    }

    public <F> F m4654a(C0292f<F> c0292f) {
        return c0292f.m499d(this.QM, getValue());
    }

    public int describeContents() {
        return 0;
    }

    public T getValue() {
        return this.QL.m2588a(this.QM);
    }

    public void writeToParcel(Parcel out, int flags) {
        C0293g.m501a(this, out, flags);
    }
}
