package com.google.android.gms.drive.query.internal;

import android.os.Parcel;

public class MatchAllFilter extends AbstractFilter {
    public static final C0296j CREATOR;
    final int BR;

    static {
        CREATOR = new C0296j();
    }

    public MatchAllFilter() {
        this(1);
    }

    MatchAllFilter(int versionCode) {
        this.BR = versionCode;
    }

    public <F> F m4657a(C0292f<F> c0292f) {
        return c0292f.is();
    }

    public int describeContents() {
        return 0;
    }

    public void writeToParcel(Parcel out, int flags) {
        C0296j.m504a(this, out, flags);
    }
}
