package com.google.android.gms.drive.query;

import com.google.android.gms.common.internal.safeparcel.SafeParcelable;
import com.google.android.gms.drive.query.internal.C0292f;

public interface Filter extends SafeParcelable {
    <T> T m2590a(C0292f<T> c0292f);
}
