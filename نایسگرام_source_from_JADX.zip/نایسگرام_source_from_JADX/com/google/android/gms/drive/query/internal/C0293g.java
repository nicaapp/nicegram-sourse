package com.google.android.gms.drive.query.internal;

import android.os.Parcel;
import android.os.Parcelable.Creator;
import com.google.android.gms.common.internal.safeparcel.C0242a;
import com.google.android.gms.common.internal.safeparcel.C0242a.C0241a;
import com.google.android.gms.common.internal.safeparcel.C0243b;
import com.google.android.gms.drive.events.CompletionEvent;
import com.google.android.gms.drive.metadata.internal.MetadataBundle;
import com.google.android.gms.location.GeofenceStatusCodes;

/* renamed from: com.google.android.gms.drive.query.internal.g */
public class C0293g implements Creator<HasFilter> {
    static void m501a(HasFilter hasFilter, Parcel parcel, int i) {
        int D = C0243b.m329D(parcel);
        C0243b.m356c(parcel, GeofenceStatusCodes.GEOFENCE_NOT_AVAILABLE, hasFilter.BR);
        C0243b.m340a(parcel, 1, hasFilter.QL, i, false);
        C0243b.m332H(parcel, D);
    }

    public HasFilter aO(Parcel parcel) {
        int C = C0242a.m293C(parcel);
        int i = 0;
        MetadataBundle metadataBundle = null;
        while (parcel.dataPosition() < C) {
            int B = C0242a.m291B(parcel);
            switch (C0242a.aD(B)) {
                case CompletionEvent.STATUS_FAILURE /*1*/:
                    metadataBundle = (MetadataBundle) C0242a.m298a(parcel, B, MetadataBundle.CREATOR);
                    break;
                case GeofenceStatusCodes.GEOFENCE_NOT_AVAILABLE /*1000*/:
                    i = C0242a.m309g(parcel, B);
                    break;
                default:
                    C0242a.m302b(parcel, B);
                    break;
            }
        }
        if (parcel.dataPosition() == C) {
            return new HasFilter(i, metadataBundle);
        }
        throw new C0241a("Overread allowed size end=" + C, parcel);
    }

    public HasFilter[] ca(int i) {
        return new HasFilter[i];
    }

    public /* synthetic */ Object createFromParcel(Parcel x0) {
        return aO(x0);
    }

    public /* synthetic */ Object[] newArray(int x0) {
        return ca(x0);
    }
}
