package com.google.android.gms.drive.query.internal;

import android.os.Parcel;
import com.google.android.gms.drive.metadata.MetadataField;
import com.google.android.gms.drive.metadata.SearchableMetadataField;
import com.google.android.gms.drive.metadata.internal.MetadataBundle;

public class ComparisonFilter<T> extends AbstractFilter {
    public static final C0287a CREATOR;
    final int BR;
    final Operator QK;
    final MetadataBundle QL;
    final MetadataField<T> QM;

    static {
        CREATOR = new C0287a();
    }

    ComparisonFilter(int versionCode, Operator operator, MetadataBundle value) {
        this.BR = versionCode;
        this.QK = operator;
        this.QL = value;
        this.QM = C0291e.m494b(value);
    }

    public ComparisonFilter(Operator operator, SearchableMetadataField<T> field, T value) {
        this(1, operator, MetadataBundle.m2586a(field, value));
    }

    public <F> F m4652a(C0292f<F> c0292f) {
        return c0292f.m496b(this.QK, this.QM, getValue());
    }

    public int describeContents() {
        return 0;
    }

    public T getValue() {
        return this.QL.m2588a(this.QM);
    }

    public void writeToParcel(Parcel out, int flags) {
        C0287a.m490a(this, out, flags);
    }
}
