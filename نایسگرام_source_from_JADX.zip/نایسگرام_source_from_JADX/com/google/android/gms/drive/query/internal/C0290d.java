package com.google.android.gms.drive.query.internal;

import android.os.Parcel;
import android.os.Parcelable.Creator;
import com.google.android.gms.common.internal.safeparcel.C0242a;
import com.google.android.gms.common.internal.safeparcel.C0242a.C0241a;
import com.google.android.gms.common.internal.safeparcel.C0243b;
import com.google.android.gms.drive.events.CompletionEvent;
import com.google.android.gms.games.quest.Quest;
import com.google.android.gms.location.DetectedActivity;
import com.google.android.gms.location.GeofenceStatusCodes;
import org.telegram.android.support.widget.helper.ItemTouchHelper;
import org.telegram.android.time.FastDatePrinter;

/* renamed from: com.google.android.gms.drive.query.internal.d */
public class C0290d implements Creator<FilterHolder> {
    static void m493a(FilterHolder filterHolder, Parcel parcel, int i) {
        int D = C0243b.m329D(parcel);
        C0243b.m340a(parcel, 1, filterHolder.QO, i, false);
        C0243b.m356c(parcel, GeofenceStatusCodes.GEOFENCE_NOT_AVAILABLE, filterHolder.BR);
        C0243b.m340a(parcel, 2, filterHolder.QP, i, false);
        C0243b.m340a(parcel, 3, filterHolder.QQ, i, false);
        C0243b.m340a(parcel, 4, filterHolder.QR, i, false);
        C0243b.m340a(parcel, 5, filterHolder.QS, i, false);
        C0243b.m340a(parcel, 6, filterHolder.QT, i, false);
        C0243b.m340a(parcel, 7, filterHolder.QU, i, false);
        C0243b.m332H(parcel, D);
    }

    public FilterHolder aN(Parcel parcel) {
        HasFilter hasFilter = null;
        int C = C0242a.m293C(parcel);
        int i = 0;
        MatchAllFilter matchAllFilter = null;
        InFilter inFilter = null;
        NotFilter notFilter = null;
        LogicalFilter logicalFilter = null;
        FieldOnlyFilter fieldOnlyFilter = null;
        ComparisonFilter comparisonFilter = null;
        while (parcel.dataPosition() < C) {
            int B = C0242a.m291B(parcel);
            switch (C0242a.aD(B)) {
                case CompletionEvent.STATUS_FAILURE /*1*/:
                    comparisonFilter = (ComparisonFilter) C0242a.m298a(parcel, B, ComparisonFilter.CREATOR);
                    break;
                case CompletionEvent.STATUS_CONFLICT /*2*/:
                    fieldOnlyFilter = (FieldOnlyFilter) C0242a.m298a(parcel, B, FieldOnlyFilter.CREATOR);
                    break;
                case FastDatePrinter.SHORT /*3*/:
                    logicalFilter = (LogicalFilter) C0242a.m298a(parcel, B, LogicalFilter.CREATOR);
                    break;
                case ItemTouchHelper.LEFT /*4*/:
                    notFilter = (NotFilter) C0242a.m298a(parcel, B, NotFilter.CREATOR);
                    break;
                case DetectedActivity.TILTING /*5*/:
                    inFilter = (InFilter) C0242a.m298a(parcel, B, InFilter.CREATOR);
                    break;
                case Quest.STATE_FAILED /*6*/:
                    matchAllFilter = (MatchAllFilter) C0242a.m298a(parcel, B, MatchAllFilter.CREATOR);
                    break;
                case DetectedActivity.WALKING /*7*/:
                    hasFilter = (HasFilter) C0242a.m298a(parcel, B, HasFilter.CREATOR);
                    break;
                case GeofenceStatusCodes.GEOFENCE_NOT_AVAILABLE /*1000*/:
                    i = C0242a.m309g(parcel, B);
                    break;
                default:
                    C0242a.m302b(parcel, B);
                    break;
            }
        }
        if (parcel.dataPosition() == C) {
            return new FilterHolder(i, comparisonFilter, fieldOnlyFilter, logicalFilter, notFilter, inFilter, matchAllFilter, hasFilter);
        }
        throw new C0241a("Overread allowed size end=" + C, parcel);
    }

    public FilterHolder[] bZ(int i) {
        return new FilterHolder[i];
    }

    public /* synthetic */ Object createFromParcel(Parcel x0) {
        return aN(x0);
    }

    public /* synthetic */ Object[] newArray(int x0) {
        return bZ(x0);
    }
}
