package com.google.android.gms.drive.query;

import android.os.Parcel;
import android.os.Parcelable.Creator;
import com.google.android.gms.common.internal.safeparcel.C0242a;
import com.google.android.gms.common.internal.safeparcel.C0242a.C0241a;
import com.google.android.gms.common.internal.safeparcel.C0243b;
import com.google.android.gms.drive.events.CompletionEvent;
import com.google.android.gms.drive.query.internal.LogicalFilter;
import com.google.android.gms.location.DetectedActivity;
import com.google.android.gms.location.GeofenceStatusCodes;
import java.util.List;
import org.telegram.android.support.widget.helper.ItemTouchHelper;
import org.telegram.android.time.FastDatePrinter;

/* renamed from: com.google.android.gms.drive.query.a */
public class C0285a implements Creator<Query> {
    static void m488a(Query query, Parcel parcel, int i) {
        int D = C0243b.m329D(parcel);
        C0243b.m356c(parcel, GeofenceStatusCodes.GEOFENCE_NOT_AVAILABLE, query.BR);
        C0243b.m340a(parcel, 1, query.QB, i, false);
        C0243b.m344a(parcel, 3, query.QC, false);
        C0243b.m340a(parcel, 4, query.QD, i, false);
        C0243b.m355b(parcel, 5, query.QE, false);
        C0243b.m332H(parcel, D);
    }

    public Query aI(Parcel parcel) {
        List list = null;
        int C = C0242a.m293C(parcel);
        int i = 0;
        SortOrder sortOrder = null;
        String str = null;
        LogicalFilter logicalFilter = null;
        while (parcel.dataPosition() < C) {
            int B = C0242a.m291B(parcel);
            switch (C0242a.aD(B)) {
                case CompletionEvent.STATUS_FAILURE /*1*/:
                    logicalFilter = (LogicalFilter) C0242a.m298a(parcel, B, LogicalFilter.CREATOR);
                    break;
                case FastDatePrinter.SHORT /*3*/:
                    str = C0242a.m317o(parcel, B);
                    break;
                case ItemTouchHelper.LEFT /*4*/:
                    sortOrder = (SortOrder) C0242a.m298a(parcel, B, SortOrder.CREATOR);
                    break;
                case DetectedActivity.TILTING /*5*/:
                    list = C0242a.m294C(parcel, B);
                    break;
                case GeofenceStatusCodes.GEOFENCE_NOT_AVAILABLE /*1000*/:
                    i = C0242a.m309g(parcel, B);
                    break;
                default:
                    C0242a.m302b(parcel, B);
                    break;
            }
        }
        if (parcel.dataPosition() == C) {
            return new Query(i, logicalFilter, str, sortOrder, list);
        }
        throw new C0241a("Overread allowed size end=" + C, parcel);
    }

    public Query[] bU(int i) {
        return new Query[i];
    }

    public /* synthetic */ Object createFromParcel(Parcel x0) {
        return aI(x0);
    }

    public /* synthetic */ Object[] newArray(int x0) {
        return bU(x0);
    }
}
