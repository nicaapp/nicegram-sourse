package com.google.android.gms.drive.query.internal;

import com.google.android.gms.drive.metadata.C2405b;
import com.google.android.gms.drive.metadata.MetadataField;
import java.util.List;

/* renamed from: com.google.android.gms.drive.query.internal.f */
public interface C0292f<F> {
    <T> F m495b(C2405b<T> c2405b, T t);

    <T> F m496b(Operator operator, MetadataField<T> metadataField, T t);

    F m497b(Operator operator, List<F> list);

    F m498d(MetadataField<?> metadataField);

    <T> F m499d(MetadataField<T> metadataField, T t);

    F is();

    F m500j(F f);
}
