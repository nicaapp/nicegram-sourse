package com.google.android.gms.drive.query;

import android.os.Parcel;
import android.os.Parcelable.Creator;
import com.google.android.gms.common.internal.safeparcel.C0242a;
import com.google.android.gms.common.internal.safeparcel.C0242a.C0241a;
import com.google.android.gms.common.internal.safeparcel.C0243b;
import com.google.android.gms.drive.events.CompletionEvent;
import com.google.android.gms.drive.query.internal.FieldWithSortOrder;
import com.google.android.gms.location.GeofenceStatusCodes;
import java.util.List;

/* renamed from: com.google.android.gms.drive.query.b */
public class C0286b implements Creator<SortOrder> {
    static void m489a(SortOrder sortOrder, Parcel parcel, int i) {
        int D = C0243b.m329D(parcel);
        C0243b.m356c(parcel, GeofenceStatusCodes.GEOFENCE_NOT_AVAILABLE, sortOrder.BR);
        C0243b.m357c(parcel, 1, sortOrder.QI, false);
        C0243b.m347a(parcel, 2, sortOrder.QJ);
        C0243b.m332H(parcel, D);
    }

    public SortOrder aJ(Parcel parcel) {
        boolean z = false;
        int C = C0242a.m293C(parcel);
        List list = null;
        int i = 0;
        while (parcel.dataPosition() < C) {
            int B = C0242a.m291B(parcel);
            switch (C0242a.aD(B)) {
                case CompletionEvent.STATUS_FAILURE /*1*/:
                    list = C0242a.m304c(parcel, B, FieldWithSortOrder.CREATOR);
                    break;
                case CompletionEvent.STATUS_CONFLICT /*2*/:
                    z = C0242a.m305c(parcel, B);
                    break;
                case GeofenceStatusCodes.GEOFENCE_NOT_AVAILABLE /*1000*/:
                    i = C0242a.m309g(parcel, B);
                    break;
                default:
                    C0242a.m302b(parcel, B);
                    break;
            }
        }
        if (parcel.dataPosition() == C) {
            return new SortOrder(i, list, z);
        }
        throw new C0241a("Overread allowed size end=" + C, parcel);
    }

    public SortOrder[] bV(int i) {
        return new SortOrder[i];
    }

    public /* synthetic */ Object createFromParcel(Parcel x0) {
        return aJ(x0);
    }

    public /* synthetic */ Object[] newArray(int x0) {
        return bV(x0);
    }
}
