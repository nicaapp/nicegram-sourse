package com.google.android.gms.drive.query;

import com.google.android.gms.drive.metadata.C2405b;
import com.google.android.gms.drive.metadata.MetadataField;
import com.google.android.gms.drive.query.internal.C0292f;
import com.google.android.gms.drive.query.internal.Operator;
import java.util.List;
import org.telegram.messenger.BuildConfig;

/* renamed from: com.google.android.gms.drive.query.c */
public class C1730c implements C0292f<String> {
    public <T> String m2591a(C2405b<T> c2405b, T t) {
        return String.format("contains(%s,%s)", new Object[]{c2405b.getName(), t});
    }

    public <T> String m2592a(Operator operator, MetadataField<T> metadataField, T t) {
        return String.format("cmp(%s,%s,%s)", new Object[]{operator.getTag(), metadataField.getName(), t});
    }

    public String m2593a(Operator operator, List<String> list) {
        StringBuilder stringBuilder = new StringBuilder(operator.getTag() + "(");
        String str = BuildConfig.FLAVOR;
        String str2 = str;
        for (String str3 : list) {
            stringBuilder.append(str2);
            stringBuilder.append(str3);
            str2 = ",";
        }
        return stringBuilder.append(")").toString();
    }

    public /* synthetic */ Object m2594b(C2405b c2405b, Object obj) {
        return m2591a(c2405b, obj);
    }

    public /* synthetic */ Object m2595b(Operator operator, MetadataField metadataField, Object obj) {
        return m2592a(operator, metadataField, obj);
    }

    public /* synthetic */ Object m2596b(Operator operator, List list) {
        return m2593a(operator, list);
    }

    public String bn(String str) {
        return String.format("not(%s)", new Object[]{str});
    }

    public String m2597c(MetadataField<?> metadataField) {
        return String.format("fieldOnly(%s)", new Object[]{metadataField.getName()});
    }

    public <T> String m2598c(MetadataField<T> metadataField, T t) {
        return String.format("has(%s,%s)", new Object[]{metadataField.getName(), t});
    }

    public /* synthetic */ Object m2599d(MetadataField metadataField) {
        return m2597c(metadataField);
    }

    public /* synthetic */ Object m2600d(MetadataField metadataField, Object obj) {
        return m2598c(metadataField, obj);
    }

    public String ir() {
        return "all()";
    }

    public /* synthetic */ Object is() {
        return ir();
    }

    public /* synthetic */ Object m2601j(Object obj) {
        return bn((String) obj);
    }
}
