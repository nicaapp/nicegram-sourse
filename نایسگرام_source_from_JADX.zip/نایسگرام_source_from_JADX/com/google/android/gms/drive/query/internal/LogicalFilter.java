package com.google.android.gms.drive.query.internal;

import android.os.Parcel;
import android.os.Parcelable.Creator;
import com.google.android.gms.drive.query.Filter;
import java.util.ArrayList;
import java.util.List;

public class LogicalFilter extends AbstractFilter {
    public static final Creator<LogicalFilter> CREATOR;
    final int BR;
    private List<Filter> QF;
    final Operator QK;
    final List<FilterHolder> QX;

    static {
        CREATOR = new C0295i();
    }

    LogicalFilter(int versionCode, Operator operator, List<FilterHolder> filterHolders) {
        this.BR = versionCode;
        this.QK = operator;
        this.QX = filterHolders;
    }

    public LogicalFilter(Operator operator, Filter filter, Filter... additionalFilters) {
        this.BR = 1;
        this.QK = operator;
        this.QX = new ArrayList(additionalFilters.length + 1);
        this.QX.add(new FilterHolder(filter));
        this.QF = new ArrayList(additionalFilters.length + 1);
        this.QF.add(filter);
        for (Filter filter2 : additionalFilters) {
            this.QX.add(new FilterHolder(filter2));
            this.QF.add(filter2);
        }
    }

    public LogicalFilter(Operator operator, Iterable<Filter> filters) {
        this.BR = 1;
        this.QK = operator;
        this.QF = new ArrayList();
        this.QX = new ArrayList();
        for (Filter filter : filters) {
            this.QF.add(filter);
            this.QX.add(new FilterHolder(filter));
        }
    }

    public <T> T m4656a(C0292f<T> c0292f) {
        List arrayList = new ArrayList();
        for (FilterHolder filter : this.QX) {
            arrayList.add(filter.getFilter().m2590a(c0292f));
        }
        return c0292f.m497b(this.QK, arrayList);
    }

    public int describeContents() {
        return 0;
    }

    public void writeToParcel(Parcel out, int flags) {
        C0295i.m503a(this, out, flags);
    }
}
