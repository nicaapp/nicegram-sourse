package com.google.android.gms.drive.query.internal;

import android.os.Parcel;
import android.os.Parcelable.Creator;
import com.google.android.gms.common.internal.safeparcel.SafeParcelable;
import com.google.android.gms.drive.query.Filter;

public class FilterHolder implements SafeParcelable {
    public static final Creator<FilterHolder> CREATOR;
    final int BR;
    final ComparisonFilter<?> QO;
    final FieldOnlyFilter QP;
    final LogicalFilter QQ;
    final NotFilter QR;
    final InFilter<?> QS;
    final MatchAllFilter QT;
    final HasFilter QU;
    private final Filter QV;

    static {
        CREATOR = new C0290d();
    }

    FilterHolder(int versionCode, ComparisonFilter<?> comparisonField, FieldOnlyFilter fieldOnlyFilter, LogicalFilter logicalFilter, NotFilter notFilter, InFilter<?> containsFilter, MatchAllFilter matchAllFilter, HasFilter<?> hasFilter) {
        this.BR = versionCode;
        this.QO = comparisonField;
        this.QP = fieldOnlyFilter;
        this.QQ = logicalFilter;
        this.QR = notFilter;
        this.QS = containsFilter;
        this.QT = matchAllFilter;
        this.QU = hasFilter;
        if (this.QO != null) {
            this.QV = this.QO;
        } else if (this.QP != null) {
            this.QV = this.QP;
        } else if (this.QQ != null) {
            this.QV = this.QQ;
        } else if (this.QR != null) {
            this.QV = this.QR;
        } else if (this.QS != null) {
            this.QV = this.QS;
        } else if (this.QT != null) {
            this.QV = this.QT;
        } else if (this.QU != null) {
            this.QV = this.QU;
        } else {
            throw new IllegalArgumentException("At least one filter must be set.");
        }
    }

    public FilterHolder(Filter filter) {
        this.BR = 2;
        this.QO = filter instanceof ComparisonFilter ? (ComparisonFilter) filter : null;
        this.QP = filter instanceof FieldOnlyFilter ? (FieldOnlyFilter) filter : null;
        this.QQ = filter instanceof LogicalFilter ? (LogicalFilter) filter : null;
        this.QR = filter instanceof NotFilter ? (NotFilter) filter : null;
        this.QS = filter instanceof InFilter ? (InFilter) filter : null;
        this.QT = filter instanceof MatchAllFilter ? (MatchAllFilter) filter : null;
        this.QU = filter instanceof HasFilter ? (HasFilter) filter : null;
        if (this.QO == null && this.QP == null && this.QQ == null && this.QR == null && this.QS == null && this.QT == null && this.QU == null) {
            throw new IllegalArgumentException("Invalid filter type or null filter.");
        }
        this.QV = filter;
    }

    public int describeContents() {
        return 0;
    }

    public Filter getFilter() {
        return this.QV;
    }

    public String toString() {
        return String.format("FilterHolder[%s]", new Object[]{this.QV});
    }

    public void writeToParcel(Parcel out, int flags) {
        C0290d.m493a(this, out, flags);
    }
}
