package com.google.android.gms.drive.query;

import android.os.Parcel;
import android.os.Parcelable.Creator;
import com.google.android.gms.common.internal.safeparcel.SafeParcelable;
import com.google.android.gms.drive.query.internal.LogicalFilter;
import com.google.android.gms.drive.query.internal.MatchAllFilter;
import com.google.android.gms.drive.query.internal.Operator;
import java.util.ArrayList;
import java.util.List;
import java.util.Locale;

public class Query implements SafeParcelable {
    public static final Creator<Query> CREATOR;
    final int BR;
    final LogicalFilter QB;
    final String QC;
    final SortOrder QD;
    final List<String> QE;

    public static class Builder {
        private String QC;
        private SortOrder QD;
        private List<String> QE;
        private final List<Filter> QF;

        public Builder() {
            this.QF = new ArrayList();
        }

        public Builder(Query query) {
            this.QF = new ArrayList();
            this.QF.add(query.getFilter());
            this.QC = query.getPageToken();
            this.QD = query.getSortOrder();
            this.QE = query.iq();
        }

        public Builder addFilter(Filter filter) {
            if (!(filter instanceof MatchAllFilter)) {
                this.QF.add(filter);
            }
            return this;
        }

        public Query build() {
            return new Query(new LogicalFilter(Operator.Re, this.QF), this.QC, this.QD, this.QE);
        }

        public Builder setPageToken(String token) {
            this.QC = token;
            return this;
        }

        public Builder setSortOrder(SortOrder sortOrder) {
            this.QD = sortOrder;
            return this;
        }
    }

    static {
        CREATOR = new C0285a();
    }

    Query(int versionCode, LogicalFilter clause, String pageToken, SortOrder sortOrder, List<String> requestedMetadataFields) {
        this.BR = versionCode;
        this.QB = clause;
        this.QC = pageToken;
        this.QD = sortOrder;
        this.QE = requestedMetadataFields;
    }

    Query(LogicalFilter clause, String pageToken, SortOrder sortOrder, List<String> requestedMetadataFields) {
        this(1, clause, pageToken, sortOrder, requestedMetadataFields);
    }

    public int describeContents() {
        return 0;
    }

    public Filter getFilter() {
        return this.QB;
    }

    public String getPageToken() {
        return this.QC;
    }

    public SortOrder getSortOrder() {
        return this.QD;
    }

    public List<String> iq() {
        return this.QE;
    }

    public String toString() {
        return String.format(Locale.US, "Query[%s,%s,PageToken=%s]", new Object[]{this.QB, this.QD, this.QC});
    }

    public void writeToParcel(Parcel out, int flags) {
        C0285a.m488a(this, out, flags);
    }
}
