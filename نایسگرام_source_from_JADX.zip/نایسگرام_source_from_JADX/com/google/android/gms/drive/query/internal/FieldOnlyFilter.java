package com.google.android.gms.drive.query.internal;

import android.os.Parcel;
import android.os.Parcelable.Creator;
import com.google.android.gms.drive.metadata.MetadataField;
import com.google.android.gms.drive.metadata.SearchableMetadataField;
import com.google.android.gms.drive.metadata.internal.MetadataBundle;

public class FieldOnlyFilter extends AbstractFilter {
    public static final Creator<FieldOnlyFilter> CREATOR;
    final int BR;
    final MetadataBundle QL;
    private final MetadataField<?> QM;

    static {
        CREATOR = new C0288b();
    }

    FieldOnlyFilter(int versionCode, MetadataBundle value) {
        this.BR = versionCode;
        this.QL = value;
        this.QM = C0291e.m494b(value);
    }

    public FieldOnlyFilter(SearchableMetadataField<?> field) {
        this(1, MetadataBundle.m2586a(field, null));
    }

    public <T> T m4653a(C0292f<T> c0292f) {
        return c0292f.m498d(this.QM);
    }

    public int describeContents() {
        return 0;
    }

    public void writeToParcel(Parcel out, int flags) {
        C0288b.m491a(this, out, flags);
    }
}
