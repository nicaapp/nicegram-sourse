package com.google.android.gms.drive;

import android.content.IntentSender;
import com.google.android.gms.common.api.GoogleApiClient;
import com.google.android.gms.common.internal.C0238o;
import com.google.android.gms.drive.internal.C0267h;
import com.google.android.gms.drive.internal.C1723r;
import com.google.android.gms.internal.jy;

public class CreateFileActivityBuilder {
    public static final String EXTRA_RESPONSE_DRIVE_ID = "response_drive_id";
    private final C0267h Na;
    private DriveContents Nb;

    public CreateFileActivityBuilder() {
        this.Na = new C0267h(0);
    }

    public IntentSender build(GoogleApiClient apiClient) {
        C0238o.m279b(this.Nb, (Object) "Must provide initial contents to CreateFileActivityBuilder.");
        boolean z = apiClient.m151a(Drive.SCOPE_FILE) || apiClient.m151a(Drive.Nc);
        C0238o.m281b(z, (Object) "The apiClient must have suitable scope to create files");
        jy.m1597a(this.Nb.getParcelFileDescriptor());
        this.Nb.getContents().hJ();
        return this.Na.build(apiClient);
    }

    public CreateFileActivityBuilder setActivityStartFolder(DriveId folder) {
        this.Na.m465a(folder);
        return this;
    }

    public CreateFileActivityBuilder setActivityTitle(String title) {
        this.Na.bi(title);
        return this;
    }

    @Deprecated
    public CreateFileActivityBuilder setInitialContents(Contents contents) {
        return setInitialDriveContents(new C1723r(contents));
    }

    public CreateFileActivityBuilder setInitialDriveContents(DriveContents driveContents) {
        if (driveContents == null) {
            throw new IllegalArgumentException("DriveContents must be provided.");
        } else if (!(driveContents instanceof C1723r)) {
            throw new IllegalArgumentException("Only DriveContents obtained from the Drive API are accepted.");
        } else if (driveContents.getDriveId() != null) {
            throw new IllegalArgumentException("Only DriveContents obtained through DriveApi.newDriveContents are accepted for file creation.");
        } else if (driveContents.getContents().hK()) {
            throw new IllegalArgumentException("DriveContents are already closed.");
        } else {
            this.Na.bk(driveContents.getContents().getRequestId());
            this.Nb = driveContents;
            return this;
        }
    }

    public CreateFileActivityBuilder setInitialMetadata(MetadataChangeSet metadataChangeSet) {
        this.Na.m466a(metadataChangeSet);
        return this;
    }
}
