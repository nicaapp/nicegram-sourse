package com.google.android.gms.drive;

import android.os.Parcel;
import android.os.Parcelable.Creator;
import com.google.android.gms.common.internal.safeparcel.C0242a;
import com.google.android.gms.common.internal.safeparcel.C0242a.C0241a;
import com.google.android.gms.common.internal.safeparcel.C0243b;
import com.google.android.gms.drive.events.CompletionEvent;
import com.google.android.gms.games.quest.Quest;
import com.google.android.gms.location.DetectedActivity;
import org.telegram.android.support.widget.helper.ItemTouchHelper;
import org.telegram.android.time.FastDatePrinter;

/* renamed from: com.google.android.gms.drive.h */
public class C0259h implements Creator<UserMetadata> {
    static void m382a(UserMetadata userMetadata, Parcel parcel, int i) {
        int D = C0243b.m329D(parcel);
        C0243b.m356c(parcel, 1, userMetadata.BR);
        C0243b.m344a(parcel, 2, userMetadata.NG, false);
        C0243b.m344a(parcel, 3, userMetadata.NH, false);
        C0243b.m344a(parcel, 4, userMetadata.NI, false);
        C0243b.m347a(parcel, 5, userMetadata.NJ);
        C0243b.m344a(parcel, 6, userMetadata.NK, false);
        C0243b.m332H(parcel, D);
    }

    public UserMetadata m383S(Parcel parcel) {
        boolean z = false;
        String str = null;
        int C = C0242a.m293C(parcel);
        String str2 = null;
        String str3 = null;
        String str4 = null;
        int i = 0;
        while (parcel.dataPosition() < C) {
            int B = C0242a.m291B(parcel);
            switch (C0242a.aD(B)) {
                case CompletionEvent.STATUS_FAILURE /*1*/:
                    i = C0242a.m309g(parcel, B);
                    break;
                case CompletionEvent.STATUS_CONFLICT /*2*/:
                    str4 = C0242a.m317o(parcel, B);
                    break;
                case FastDatePrinter.SHORT /*3*/:
                    str3 = C0242a.m317o(parcel, B);
                    break;
                case ItemTouchHelper.LEFT /*4*/:
                    str2 = C0242a.m317o(parcel, B);
                    break;
                case DetectedActivity.TILTING /*5*/:
                    z = C0242a.m305c(parcel, B);
                    break;
                case Quest.STATE_FAILED /*6*/:
                    str = C0242a.m317o(parcel, B);
                    break;
                default:
                    C0242a.m302b(parcel, B);
                    break;
            }
        }
        if (parcel.dataPosition() == C) {
            return new UserMetadata(i, str4, str3, str2, z, str);
        }
        throw new C0241a("Overread allowed size end=" + C, parcel);
    }

    public UserMetadata[] aZ(int i) {
        return new UserMetadata[i];
    }

    public /* synthetic */ Object createFromParcel(Parcel x0) {
        return m383S(x0);
    }

    public /* synthetic */ Object[] newArray(int x0) {
        return aZ(x0);
    }
}
