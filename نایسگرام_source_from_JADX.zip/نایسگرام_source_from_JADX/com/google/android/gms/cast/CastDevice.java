package com.google.android.gms.cast;

import android.os.Bundle;
import android.os.Parcel;
import android.os.Parcelable.Creator;
import com.google.android.gms.common.images.WebImage;
import com.google.android.gms.common.internal.safeparcel.SafeParcelable;
import com.google.android.gms.internal.ik;
import java.net.Inet4Address;
import java.net.InetAddress;
import java.net.UnknownHostException;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

public class CastDevice implements SafeParcelable {
    public static final Creator<CastDevice> CREATOR;
    private final int BR;
    private String ER;
    String ES;
    private Inet4Address ET;
    private String EU;
    private String EV;
    private String EW;
    private int EX;
    private List<WebImage> EY;
    private int EZ;
    private int Fa;

    static {
        CREATOR = new C0185b();
    }

    private CastDevice() {
        this(3, null, null, null, null, null, -1, new ArrayList(), 0, -1);
    }

    CastDevice(int versionCode, String deviceId, String hostAddress, String friendlyName, String modelName, String deviceVersion, int servicePort, List<WebImage> icons, int capabilities, int status) {
        this.BR = versionCode;
        this.ER = deviceId;
        this.ES = hostAddress;
        if (this.ES != null) {
            try {
                InetAddress byName = InetAddress.getByName(this.ES);
                if (byName instanceof Inet4Address) {
                    this.ET = (Inet4Address) byName;
                }
            } catch (UnknownHostException e) {
                this.ET = null;
            }
        }
        this.EU = friendlyName;
        this.EV = modelName;
        this.EW = deviceVersion;
        this.EX = servicePort;
        this.EY = icons;
        this.EZ = capabilities;
        this.Fa = status;
    }

    public static CastDevice getFromBundle(Bundle extras) {
        if (extras == null) {
            return null;
        }
        extras.setClassLoader(CastDevice.class.getClassLoader());
        return (CastDevice) extras.getParcelable("com.google.android.gms.cast.EXTRA_CAST_DEVICE");
    }

    public int describeContents() {
        return 0;
    }

    public boolean equals(Object obj) {
        if (obj == this) {
            return true;
        }
        if (!(obj instanceof CastDevice)) {
            return false;
        }
        CastDevice castDevice = (CastDevice) obj;
        return getDeviceId() == null ? castDevice.getDeviceId() == null : ik.m1511a(this.ER, castDevice.ER) && ik.m1511a(this.ET, castDevice.ET) && ik.m1511a(this.EV, castDevice.EV) && ik.m1511a(this.EU, castDevice.EU) && ik.m1511a(this.EW, castDevice.EW) && this.EX == castDevice.EX && ik.m1511a(this.EY, castDevice.EY) && this.EZ == castDevice.EZ && this.Fa == castDevice.Fa;
    }

    public int getCapabilities() {
        return this.EZ;
    }

    public String getDeviceId() {
        return this.ER;
    }

    public String getDeviceVersion() {
        return this.EW;
    }

    public String getFriendlyName() {
        return this.EU;
    }

    public WebImage getIcon(int preferredWidth, int preferredHeight) {
        WebImage webImage = null;
        if (this.EY.isEmpty()) {
            return null;
        }
        if (preferredWidth <= 0 || preferredHeight <= 0) {
            return (WebImage) this.EY.get(0);
        }
        WebImage webImage2 = null;
        for (WebImage webImage3 : this.EY) {
            WebImage webImage32;
            int width = webImage32.getWidth();
            int height = webImage32.getHeight();
            if (width < preferredWidth || height < preferredHeight) {
                if (width < preferredWidth && height < preferredHeight && (webImage == null || (webImage.getWidth() < width && webImage.getHeight() < height))) {
                    webImage = webImage2;
                }
                webImage32 = webImage;
                webImage = webImage2;
            } else {
                if (webImage2 == null || (webImage2.getWidth() > width && webImage2.getHeight() > height)) {
                    WebImage webImage4 = webImage;
                    webImage = webImage32;
                    webImage32 = webImage4;
                }
                webImage32 = webImage;
                webImage = webImage2;
            }
            webImage2 = webImage;
            webImage = webImage32;
        }
        if (webImage2 == null) {
            webImage2 = webImage != null ? webImage : (WebImage) this.EY.get(0);
        }
        return webImage2;
    }

    public List<WebImage> getIcons() {
        return Collections.unmodifiableList(this.EY);
    }

    public Inet4Address getIpAddress() {
        return this.ET;
    }

    public String getModelName() {
        return this.EV;
    }

    public int getServicePort() {
        return this.EX;
    }

    public int getStatus() {
        return this.Fa;
    }

    int getVersionCode() {
        return this.BR;
    }

    public boolean hasIcons() {
        return !this.EY.isEmpty();
    }

    public int hashCode() {
        return this.ER == null ? 0 : this.ER.hashCode();
    }

    public boolean isSameDevice(CastDevice castDevice) {
        if (castDevice == null) {
            return false;
        }
        if (getDeviceId() == null) {
            return castDevice.getDeviceId() == null;
        } else {
            return ik.m1511a(getDeviceId(), castDevice.getDeviceId());
        }
    }

    public void putInBundle(Bundle bundle) {
        if (bundle != null) {
            bundle.putParcelable("com.google.android.gms.cast.EXTRA_CAST_DEVICE", this);
        }
    }

    public String toString() {
        return String.format("\"%s\" (%s)", new Object[]{this.EU, this.ER});
    }

    public void writeToParcel(Parcel out, int flags) {
        C0185b.m120a(this, out, flags);
    }
}
