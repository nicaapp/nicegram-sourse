package com.google.android.gms.cast;

import android.content.Context;
import android.graphics.Color;
import android.graphics.Typeface;
import android.view.accessibility.CaptioningManager;
import android.view.accessibility.CaptioningManager.CaptionStyle;
import com.google.android.gms.common.internal.C0237n;
import com.google.android.gms.internal.ik;
import com.google.android.gms.internal.jz;
import com.google.android.gms.internal.kc;
import org.json.JSONException;
import org.json.JSONObject;

public final class TextTrackStyle {
    public static final int COLOR_UNSPECIFIED = 0;
    public static final float DEFAULT_FONT_SCALE = 1.0f;
    public static final int EDGE_TYPE_DEPRESSED = 4;
    public static final int EDGE_TYPE_DROP_SHADOW = 2;
    public static final int EDGE_TYPE_NONE = 0;
    public static final int EDGE_TYPE_OUTLINE = 1;
    public static final int EDGE_TYPE_RAISED = 3;
    public static final int EDGE_TYPE_UNSPECIFIED = -1;
    public static final int FONT_FAMILY_CASUAL = 4;
    public static final int FONT_FAMILY_CURSIVE = 5;
    public static final int FONT_FAMILY_MONOSPACED_SANS_SERIF = 1;
    public static final int FONT_FAMILY_MONOSPACED_SERIF = 3;
    public static final int FONT_FAMILY_SANS_SERIF = 0;
    public static final int FONT_FAMILY_SERIF = 2;
    public static final int FONT_FAMILY_SMALL_CAPITALS = 6;
    public static final int FONT_FAMILY_UNSPECIFIED = -1;
    public static final int FONT_STYLE_BOLD = 1;
    public static final int FONT_STYLE_BOLD_ITALIC = 3;
    public static final int FONT_STYLE_ITALIC = 2;
    public static final int FONT_STYLE_NORMAL = 0;
    public static final int FONT_STYLE_UNSPECIFIED = -1;
    public static final int WINDOW_TYPE_NONE = 0;
    public static final int WINDOW_TYPE_NORMAL = 1;
    public static final int WINDOW_TYPE_ROUNDED = 2;
    public static final int WINDOW_TYPE_UNSPECIFIED = -1;
    private JSONObject Fl;
    private float Gd;
    private int Ge;
    private int Gf;
    private int Gg;
    private int Gh;
    private int Gi;
    private int Gj;
    private String Gk;
    private int Gl;
    private int Gm;
    private int xm;

    public TextTrackStyle() {
        clear();
    }

    private int aC(String str) {
        int i = WINDOW_TYPE_NONE;
        if (str != null && str.length() == 9 && str.charAt(i) == '#') {
            try {
                i = Color.argb(Integer.parseInt(str.substring(7, 9), 16), Integer.parseInt(str.substring(WINDOW_TYPE_NORMAL, FONT_STYLE_BOLD_ITALIC), 16), Integer.parseInt(str.substring(FONT_STYLE_BOLD_ITALIC, FONT_FAMILY_CURSIVE), 16), Integer.parseInt(str.substring(FONT_FAMILY_CURSIVE, 7), 16));
            } catch (NumberFormatException e) {
            }
        }
        return i;
    }

    private void clear() {
        this.Gd = DEFAULT_FONT_SCALE;
        this.Ge = WINDOW_TYPE_NONE;
        this.xm = WINDOW_TYPE_NONE;
        this.Gf = WINDOW_TYPE_UNSPECIFIED;
        this.Gg = WINDOW_TYPE_NONE;
        this.Gh = WINDOW_TYPE_UNSPECIFIED;
        this.Gi = WINDOW_TYPE_NONE;
        this.Gj = WINDOW_TYPE_NONE;
        this.Gk = null;
        this.Gl = WINDOW_TYPE_UNSPECIFIED;
        this.Gm = WINDOW_TYPE_UNSPECIFIED;
        this.Fl = null;
    }

    public static TextTrackStyle fromSystemSettings(Context context) {
        TextTrackStyle textTrackStyle = new TextTrackStyle();
        if (!kc.hH()) {
            return textTrackStyle;
        }
        CaptioningManager captioningManager = (CaptioningManager) context.getSystemService("captioning");
        textTrackStyle.setFontScale(captioningManager.getFontScale());
        CaptionStyle userStyle = captioningManager.getUserStyle();
        textTrackStyle.setBackgroundColor(userStyle.backgroundColor);
        textTrackStyle.setForegroundColor(userStyle.foregroundColor);
        switch (userStyle.edgeType) {
            case WINDOW_TYPE_NORMAL /*1*/:
                textTrackStyle.setEdgeType(WINDOW_TYPE_NORMAL);
                break;
            case WINDOW_TYPE_ROUNDED /*2*/:
                textTrackStyle.setEdgeType(WINDOW_TYPE_ROUNDED);
                break;
            default:
                textTrackStyle.setEdgeType(WINDOW_TYPE_NONE);
                break;
        }
        textTrackStyle.setEdgeColor(userStyle.edgeColor);
        Typeface typeface = userStyle.getTypeface();
        if (typeface != null) {
            if (Typeface.MONOSPACE.equals(typeface)) {
                textTrackStyle.setFontGenericFamily(WINDOW_TYPE_NORMAL);
            } else if (Typeface.SANS_SERIF.equals(typeface)) {
                textTrackStyle.setFontGenericFamily(WINDOW_TYPE_NONE);
            } else if (Typeface.SERIF.equals(typeface)) {
                textTrackStyle.setFontGenericFamily(WINDOW_TYPE_ROUNDED);
            } else {
                textTrackStyle.setFontGenericFamily(WINDOW_TYPE_NONE);
            }
            boolean isBold = typeface.isBold();
            boolean isItalic = typeface.isItalic();
            if (isBold && isItalic) {
                textTrackStyle.setFontStyle(FONT_STYLE_BOLD_ITALIC);
            } else if (isBold) {
                textTrackStyle.setFontStyle(WINDOW_TYPE_NORMAL);
            } else if (isItalic) {
                textTrackStyle.setFontStyle(WINDOW_TYPE_ROUNDED);
            } else {
                textTrackStyle.setFontStyle(WINDOW_TYPE_NONE);
            }
        }
        return textTrackStyle;
    }

    private String m115t(int i) {
        Object[] objArr = new Object[FONT_FAMILY_CASUAL];
        objArr[WINDOW_TYPE_NONE] = Integer.valueOf(Color.red(i));
        objArr[WINDOW_TYPE_NORMAL] = Integer.valueOf(Color.green(i));
        objArr[WINDOW_TYPE_ROUNDED] = Integer.valueOf(Color.blue(i));
        objArr[FONT_STYLE_BOLD_ITALIC] = Integer.valueOf(Color.alpha(i));
        return String.format("#%02X%02X%02X%02X", objArr);
    }

    public JSONObject bK() {
        JSONObject jSONObject = new JSONObject();
        try {
            jSONObject.put("fontScale", (double) this.Gd);
            if (this.Ge != 0) {
                jSONObject.put("foregroundColor", m115t(this.Ge));
            }
            if (this.xm != 0) {
                jSONObject.put("backgroundColor", m115t(this.xm));
            }
            switch (this.Gf) {
                case WINDOW_TYPE_NONE /*0*/:
                    jSONObject.put("edgeType", "NONE");
                    break;
                case WINDOW_TYPE_NORMAL /*1*/:
                    jSONObject.put("edgeType", "OUTLINE");
                    break;
                case WINDOW_TYPE_ROUNDED /*2*/:
                    jSONObject.put("edgeType", "DROP_SHADOW");
                    break;
                case FONT_STYLE_BOLD_ITALIC /*3*/:
                    jSONObject.put("edgeType", "RAISED");
                    break;
                case FONT_FAMILY_CASUAL /*4*/:
                    jSONObject.put("edgeType", "DEPRESSED");
                    break;
            }
            if (this.Gg != 0) {
                jSONObject.put("edgeColor", m115t(this.Gg));
            }
            switch (this.Gh) {
                case WINDOW_TYPE_NONE /*0*/:
                    jSONObject.put("windowType", "NONE");
                    break;
                case WINDOW_TYPE_NORMAL /*1*/:
                    jSONObject.put("windowType", "NORMAL");
                    break;
                case WINDOW_TYPE_ROUNDED /*2*/:
                    jSONObject.put("windowType", "ROUNDED_CORNERS");
                    break;
            }
            if (this.Gi != 0) {
                jSONObject.put("windowColor", m115t(this.Gi));
            }
            if (this.Gh == WINDOW_TYPE_ROUNDED) {
                jSONObject.put("windowRoundedCornerRadius", this.Gj);
            }
            if (this.Gk != null) {
                jSONObject.put("fontFamily", this.Gk);
            }
            switch (this.Gl) {
                case WINDOW_TYPE_NONE /*0*/:
                    jSONObject.put("fontGenericFamily", "SANS_SERIF");
                    break;
                case WINDOW_TYPE_NORMAL /*1*/:
                    jSONObject.put("fontGenericFamily", "MONOSPACED_SANS_SERIF");
                    break;
                case WINDOW_TYPE_ROUNDED /*2*/:
                    jSONObject.put("fontGenericFamily", "SERIF");
                    break;
                case FONT_STYLE_BOLD_ITALIC /*3*/:
                    jSONObject.put("fontGenericFamily", "MONOSPACED_SERIF");
                    break;
                case FONT_FAMILY_CASUAL /*4*/:
                    jSONObject.put("fontGenericFamily", "CASUAL");
                    break;
                case FONT_FAMILY_CURSIVE /*5*/:
                    jSONObject.put("fontGenericFamily", "CURSIVE");
                    break;
                case FONT_FAMILY_SMALL_CAPITALS /*6*/:
                    jSONObject.put("fontGenericFamily", "SMALL_CAPITALS");
                    break;
            }
            switch (this.Gm) {
                case WINDOW_TYPE_NONE /*0*/:
                    jSONObject.put("fontStyle", "NORMAL");
                    break;
                case WINDOW_TYPE_NORMAL /*1*/:
                    jSONObject.put("fontStyle", "BOLD");
                    break;
                case WINDOW_TYPE_ROUNDED /*2*/:
                    jSONObject.put("fontStyle", "ITALIC");
                    break;
                case FONT_STYLE_BOLD_ITALIC /*3*/:
                    jSONObject.put("fontStyle", "BOLD_ITALIC");
                    break;
            }
            if (this.Fl != null) {
                jSONObject.put("customData", this.Fl);
            }
        } catch (JSONException e) {
        }
        return jSONObject;
    }

    public void m116c(JSONObject jSONObject) throws JSONException {
        String string;
        clear();
        this.Gd = (float) jSONObject.optDouble("fontScale", 1.0d);
        this.Ge = aC(jSONObject.optString("foregroundColor"));
        this.xm = aC(jSONObject.optString("backgroundColor"));
        if (jSONObject.has("edgeType")) {
            string = jSONObject.getString("edgeType");
            if ("NONE".equals(string)) {
                this.Gf = WINDOW_TYPE_NONE;
            } else if ("OUTLINE".equals(string)) {
                this.Gf = WINDOW_TYPE_NORMAL;
            } else if ("DROP_SHADOW".equals(string)) {
                this.Gf = WINDOW_TYPE_ROUNDED;
            } else if ("RAISED".equals(string)) {
                this.Gf = FONT_STYLE_BOLD_ITALIC;
            } else if ("DEPRESSED".equals(string)) {
                this.Gf = FONT_FAMILY_CASUAL;
            }
        }
        this.Gg = aC(jSONObject.optString("edgeColor"));
        if (jSONObject.has("windowType")) {
            string = jSONObject.getString("windowType");
            if ("NONE".equals(string)) {
                this.Gh = WINDOW_TYPE_NONE;
            } else if ("NORMAL".equals(string)) {
                this.Gh = WINDOW_TYPE_NORMAL;
            } else if ("ROUNDED_CORNERS".equals(string)) {
                this.Gh = WINDOW_TYPE_ROUNDED;
            }
        }
        this.Gi = aC(jSONObject.optString("windowColor"));
        if (this.Gh == WINDOW_TYPE_ROUNDED) {
            this.Gj = jSONObject.optInt("windowRoundedCornerRadius", WINDOW_TYPE_NONE);
        }
        this.Gk = jSONObject.optString("fontFamily", null);
        if (jSONObject.has("fontGenericFamily")) {
            string = jSONObject.getString("fontGenericFamily");
            if ("SANS_SERIF".equals(string)) {
                this.Gl = WINDOW_TYPE_NONE;
            } else if ("MONOSPACED_SANS_SERIF".equals(string)) {
                this.Gl = WINDOW_TYPE_NORMAL;
            } else if ("SERIF".equals(string)) {
                this.Gl = WINDOW_TYPE_ROUNDED;
            } else if ("MONOSPACED_SERIF".equals(string)) {
                this.Gl = FONT_STYLE_BOLD_ITALIC;
            } else if ("CASUAL".equals(string)) {
                this.Gl = FONT_FAMILY_CASUAL;
            } else if ("CURSIVE".equals(string)) {
                this.Gl = FONT_FAMILY_CURSIVE;
            } else if ("SMALL_CAPITALS".equals(string)) {
                this.Gl = FONT_FAMILY_SMALL_CAPITALS;
            }
        }
        if (jSONObject.has("fontStyle")) {
            string = jSONObject.getString("fontStyle");
            if ("NORMAL".equals(string)) {
                this.Gm = WINDOW_TYPE_NONE;
            } else if ("BOLD".equals(string)) {
                this.Gm = WINDOW_TYPE_NORMAL;
            } else if ("ITALIC".equals(string)) {
                this.Gm = WINDOW_TYPE_ROUNDED;
            } else if ("BOLD_ITALIC".equals(string)) {
                this.Gm = FONT_STYLE_BOLD_ITALIC;
            }
        }
        this.Fl = jSONObject.optJSONObject("customData");
    }

    public boolean equals(Object other) {
        boolean z = true;
        if (this == other) {
            return true;
        }
        if (!(other instanceof TextTrackStyle)) {
            return false;
        }
        TextTrackStyle textTrackStyle = (TextTrackStyle) other;
        if ((this.Fl == null ? WINDOW_TYPE_NORMAL : false) != (textTrackStyle.Fl == null ? WINDOW_TYPE_NORMAL : false)) {
            return false;
        }
        if (this.Fl != null && textTrackStyle.Fl != null && !jz.m1601d(this.Fl, textTrackStyle.Fl)) {
            return false;
        }
        if (!(this.Gd == textTrackStyle.Gd && this.Ge == textTrackStyle.Ge && this.xm == textTrackStyle.xm && this.Gf == textTrackStyle.Gf && this.Gg == textTrackStyle.Gg && this.Gh == textTrackStyle.Gh && this.Gj == textTrackStyle.Gj && ik.m1511a(this.Gk, textTrackStyle.Gk) && this.Gl == textTrackStyle.Gl && this.Gm == textTrackStyle.Gm)) {
            z = false;
        }
        return z;
    }

    public int getBackgroundColor() {
        return this.xm;
    }

    public JSONObject getCustomData() {
        return this.Fl;
    }

    public int getEdgeColor() {
        return this.Gg;
    }

    public int getEdgeType() {
        return this.Gf;
    }

    public String getFontFamily() {
        return this.Gk;
    }

    public int getFontGenericFamily() {
        return this.Gl;
    }

    public float getFontScale() {
        return this.Gd;
    }

    public int getFontStyle() {
        return this.Gm;
    }

    public int getForegroundColor() {
        return this.Ge;
    }

    public int getWindowColor() {
        return this.Gi;
    }

    public int getWindowCornerRadius() {
        return this.Gj;
    }

    public int getWindowType() {
        return this.Gh;
    }

    public int hashCode() {
        return C0237n.hashCode(Float.valueOf(this.Gd), Integer.valueOf(this.Ge), Integer.valueOf(this.xm), Integer.valueOf(this.Gf), Integer.valueOf(this.Gg), Integer.valueOf(this.Gh), Integer.valueOf(this.Gi), Integer.valueOf(this.Gj), this.Gk, Integer.valueOf(this.Gl), Integer.valueOf(this.Gm), this.Fl);
    }

    public void setBackgroundColor(int backgroundColor) {
        this.xm = backgroundColor;
    }

    public void setCustomData(JSONObject customData) {
        this.Fl = customData;
    }

    public void setEdgeColor(int edgeColor) {
        this.Gg = edgeColor;
    }

    public void setEdgeType(int edgeType) {
        if (edgeType < 0 || edgeType > FONT_FAMILY_CASUAL) {
            throw new IllegalArgumentException("invalid edgeType");
        }
        this.Gf = edgeType;
    }

    public void setFontFamily(String fontFamily) {
        this.Gk = fontFamily;
    }

    public void setFontGenericFamily(int fontGenericFamily) {
        if (fontGenericFamily < 0 || fontGenericFamily > FONT_FAMILY_SMALL_CAPITALS) {
            throw new IllegalArgumentException("invalid fontGenericFamily");
        }
        this.Gl = fontGenericFamily;
    }

    public void setFontScale(float fontScale) {
        this.Gd = fontScale;
    }

    public void setFontStyle(int fontStyle) {
        if (fontStyle < 0 || fontStyle > FONT_STYLE_BOLD_ITALIC) {
            throw new IllegalArgumentException("invalid fontStyle");
        }
        this.Gm = fontStyle;
    }

    public void setForegroundColor(int foregroundColor) {
        this.Ge = foregroundColor;
    }

    public void setWindowColor(int windowColor) {
        this.Gi = windowColor;
    }

    public void setWindowCornerRadius(int windowCornerRadius) {
        if (windowCornerRadius < 0) {
            throw new IllegalArgumentException("invalid windowCornerRadius");
        }
        this.Gj = windowCornerRadius;
    }

    public void setWindowType(int windowType) {
        if (windowType < 0 || windowType > WINDOW_TYPE_ROUNDED) {
            throw new IllegalArgumentException("invalid windowType");
        }
        this.Gh = windowType;
    }
}
