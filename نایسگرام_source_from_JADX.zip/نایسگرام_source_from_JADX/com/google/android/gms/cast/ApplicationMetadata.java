package com.google.android.gms.cast;

import android.net.Uri;
import android.os.Parcel;
import android.os.Parcelable.Creator;
import com.google.android.gms.common.images.WebImage;
import com.google.android.gms.common.internal.C0237n;
import com.google.android.gms.common.internal.safeparcel.SafeParcelable;
import com.google.android.gms.internal.ik;
import java.util.ArrayList;
import java.util.List;

public final class ApplicationMetadata implements SafeParcelable {
    public static final Creator<ApplicationMetadata> CREATOR;
    private final int BR;
    List<WebImage> EA;
    List<String> EB;
    String EC;
    Uri ED;
    String Ez;
    String mName;

    static {
        CREATOR = new C0184a();
    }

    private ApplicationMetadata() {
        this.BR = 1;
        this.EA = new ArrayList();
        this.EB = new ArrayList();
    }

    ApplicationMetadata(int versionCode, String applicationId, String name, List<WebImage> images, List<String> namespaces, String senderAppIdentifier, Uri senderAppLaunchUrl) {
        this.BR = versionCode;
        this.Ez = applicationId;
        this.mName = name;
        this.EA = images;
        this.EB = namespaces;
        this.EC = senderAppIdentifier;
        this.ED = senderAppLaunchUrl;
    }

    public boolean areNamespacesSupported(List<String> namespaces) {
        return this.EB != null && this.EB.containsAll(namespaces);
    }

    public int describeContents() {
        return 0;
    }

    public boolean equals(Object obj) {
        if (obj == this) {
            return true;
        }
        if (!(obj instanceof ApplicationMetadata)) {
            return false;
        }
        ApplicationMetadata applicationMetadata = (ApplicationMetadata) obj;
        return ik.m1511a(this.Ez, applicationMetadata.Ez) && ik.m1511a(this.EA, applicationMetadata.EA) && ik.m1511a(this.mName, applicationMetadata.mName) && ik.m1511a(this.EB, applicationMetadata.EB) && ik.m1511a(this.EC, applicationMetadata.EC) && ik.m1511a(this.ED, applicationMetadata.ED);
    }

    public Uri fu() {
        return this.ED;
    }

    public String getApplicationId() {
        return this.Ez;
    }

    public List<WebImage> getImages() {
        return this.EA;
    }

    public String getName() {
        return this.mName;
    }

    public String getSenderAppIdentifier() {
        return this.EC;
    }

    int getVersionCode() {
        return this.BR;
    }

    public int hashCode() {
        return C0237n.hashCode(Integer.valueOf(this.BR), this.Ez, this.mName, this.EA, this.EB, this.EC, this.ED);
    }

    public boolean isNamespaceSupported(String namespace) {
        return this.EB != null && this.EB.contains(namespace);
    }

    public String toString() {
        return this.mName;
    }

    public void writeToParcel(Parcel out, int flags) {
        C0184a.m117a(this, out, flags);
    }
}
