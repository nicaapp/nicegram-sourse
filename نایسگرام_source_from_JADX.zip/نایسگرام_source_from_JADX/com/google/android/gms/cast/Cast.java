package com.google.android.gms.cast;

import android.content.Context;
import android.os.Looper;
import android.os.RemoteException;
import android.text.TextUtils;
import com.google.android.gms.cast.LaunchOptions.Builder;
import com.google.android.gms.common.api.Api;
import com.google.android.gms.common.api.Api.ApiOptions.HasOptions;
import com.google.android.gms.common.api.Api.C0189b;
import com.google.android.gms.common.api.Api.C0190c;
import com.google.android.gms.common.api.BaseImplementation.C0191b;
import com.google.android.gms.common.api.BaseImplementation.C2381a;
import com.google.android.gms.common.api.GoogleApiClient;
import com.google.android.gms.common.api.GoogleApiClient.ConnectionCallbacks;
import com.google.android.gms.common.api.GoogleApiClient.OnConnectionFailedListener;
import com.google.android.gms.common.api.PendingResult;
import com.google.android.gms.common.api.Result;
import com.google.android.gms.common.api.Scope;
import com.google.android.gms.common.api.Status;
import com.google.android.gms.common.internal.C0238o;
import com.google.android.gms.common.internal.ClientSettings;
import com.google.android.gms.games.GamesStatusCodes;
import com.google.android.gms.internal.ij;
import java.io.IOException;
import org.telegram.messenger.BuildConfig;
import org.telegram.messenger.ConnectionsManager;

public final class Cast {
    public static final Api<CastOptions> API;
    static final C0190c<ij> CU;
    private static final C0189b<ij, CastOptions> CV;
    public static final CastApi CastApi;
    public static final String EXTRA_APP_NO_LONGER_RUNNING = "com.google.android.gms.cast.EXTRA_APP_NO_LONGER_RUNNING";
    public static final int MAX_MESSAGE_LENGTH = 65536;
    public static final int MAX_NAMESPACE_LENGTH = 128;

    public interface CastApi {

        /* renamed from: com.google.android.gms.cast.Cast.CastApi.a */
        public static final class C1681a implements CastApi {

            /* renamed from: com.google.android.gms.cast.Cast.CastApi.a.1 */
            class C27221 extends C2653b {
                final /* synthetic */ String EE;
                final /* synthetic */ String EF;
                final /* synthetic */ C1681a EG;

                C27221(C1681a c1681a, String str, String str2) {
                    this.EG = c1681a;
                    this.EE = str;
                    this.EF = str2;
                    super();
                }

                protected void m5076a(ij ijVar) throws RemoteException {
                    try {
                        ijVar.m4323a(this.EE, this.EF, (C0191b) this);
                    } catch (IllegalArgumentException e) {
                        m4605V(GamesStatusCodes.STATUS_REQUEST_UPDATE_TOTAL_FAILURE);
                    } catch (IllegalStateException e2) {
                        m4605V(GamesStatusCodes.STATUS_REQUEST_UPDATE_TOTAL_FAILURE);
                    }
                }
            }

            /* renamed from: com.google.android.gms.cast.Cast.CastApi.a.2 */
            class C27232 extends C2654c {
                final /* synthetic */ C1681a EG;
                final /* synthetic */ String EH;

                C27232(C1681a c1681a, String str) {
                    this.EG = c1681a;
                    this.EH = str;
                    super();
                }

                protected void m5078a(ij ijVar) throws RemoteException {
                    try {
                        ijVar.m4324a(this.EH, false, (C0191b) this);
                    } catch (IllegalStateException e) {
                        m4605V(GamesStatusCodes.STATUS_REQUEST_UPDATE_TOTAL_FAILURE);
                    }
                }
            }

            /* renamed from: com.google.android.gms.cast.Cast.CastApi.a.3 */
            class C27243 extends C2654c {
                final /* synthetic */ C1681a EG;
                final /* synthetic */ String EH;
                final /* synthetic */ LaunchOptions EI;

                C27243(C1681a c1681a, String str, LaunchOptions launchOptions) {
                    this.EG = c1681a;
                    this.EH = str;
                    this.EI = launchOptions;
                    super();
                }

                protected void m5080a(ij ijVar) throws RemoteException {
                    try {
                        ijVar.m4321a(this.EH, this.EI, (C0191b) this);
                    } catch (IllegalStateException e) {
                        m4605V(GamesStatusCodes.STATUS_REQUEST_UPDATE_TOTAL_FAILURE);
                    }
                }
            }

            /* renamed from: com.google.android.gms.cast.Cast.CastApi.a.4 */
            class C27254 extends C2654c {
                final /* synthetic */ C1681a EG;
                final /* synthetic */ String EH;
                final /* synthetic */ String EJ;

                C27254(C1681a c1681a, String str, String str2) {
                    this.EG = c1681a;
                    this.EH = str;
                    this.EJ = str2;
                    super();
                }

                protected void m5082a(ij ijVar) throws RemoteException {
                    try {
                        ijVar.m4325b(this.EH, this.EJ, this);
                    } catch (IllegalStateException e) {
                        m4605V(GamesStatusCodes.STATUS_REQUEST_UPDATE_TOTAL_FAILURE);
                    }
                }
            }

            /* renamed from: com.google.android.gms.cast.Cast.CastApi.a.5 */
            class C27265 extends C2654c {
                final /* synthetic */ C1681a EG;
                final /* synthetic */ String EH;

                C27265(C1681a c1681a, String str) {
                    this.EG = c1681a;
                    this.EH = str;
                    super();
                }

                protected void m5084a(ij ijVar) throws RemoteException {
                    try {
                        ijVar.m4325b(this.EH, null, this);
                    } catch (IllegalStateException e) {
                        m4605V(GamesStatusCodes.STATUS_REQUEST_UPDATE_TOTAL_FAILURE);
                    }
                }
            }

            /* renamed from: com.google.android.gms.cast.Cast.CastApi.a.6 */
            class C27276 extends C2654c {
                final /* synthetic */ C1681a EG;

                C27276(C1681a c1681a) {
                    this.EG = c1681a;
                    super();
                }

                protected void m5086a(ij ijVar) throws RemoteException {
                    try {
                        ijVar.m4325b(null, null, this);
                    } catch (IllegalStateException e) {
                        m4605V(GamesStatusCodes.STATUS_REQUEST_UPDATE_TOTAL_FAILURE);
                    }
                }
            }

            /* renamed from: com.google.android.gms.cast.Cast.CastApi.a.7 */
            class C27287 extends C2653b {
                final /* synthetic */ C1681a EG;

                C27287(C1681a c1681a) {
                    this.EG = c1681a;
                    super();
                }

                protected void m5088a(ij ijVar) throws RemoteException {
                    try {
                        ijVar.m4326d((C0191b) this);
                    } catch (IllegalStateException e) {
                        m4605V(GamesStatusCodes.STATUS_REQUEST_UPDATE_TOTAL_FAILURE);
                    }
                }
            }

            /* renamed from: com.google.android.gms.cast.Cast.CastApi.a.8 */
            class C27298 extends C2653b {
                final /* synthetic */ C1681a EG;

                C27298(C1681a c1681a) {
                    this.EG = c1681a;
                    super();
                }

                protected void m5090a(ij ijVar) throws RemoteException {
                    try {
                        ijVar.m4322a(BuildConfig.FLAVOR, (C0191b) this);
                    } catch (IllegalStateException e) {
                        m4605V(GamesStatusCodes.STATUS_REQUEST_UPDATE_TOTAL_FAILURE);
                    }
                }
            }

            /* renamed from: com.google.android.gms.cast.Cast.CastApi.a.9 */
            class C27309 extends C2653b {
                final /* synthetic */ C1681a EG;
                final /* synthetic */ String EJ;

                C27309(C1681a c1681a, String str) {
                    this.EG = c1681a;
                    this.EJ = str;
                    super();
                }

                protected void m5092a(ij ijVar) throws RemoteException {
                    if (TextUtils.isEmpty(this.EJ)) {
                        m4606e(GamesStatusCodes.STATUS_REQUEST_UPDATE_TOTAL_FAILURE, "IllegalArgument: sessionId cannot be null or empty");
                        return;
                    }
                    try {
                        ijVar.m4322a(this.EJ, (C0191b) this);
                    } catch (IllegalStateException e) {
                        m4605V(GamesStatusCodes.STATUS_REQUEST_UPDATE_TOTAL_FAILURE);
                    }
                }
            }

            public ApplicationMetadata getApplicationMetadata(GoogleApiClient client) throws IllegalStateException {
                return ((ij) client.m149a(Cast.CU)).getApplicationMetadata();
            }

            public String getApplicationStatus(GoogleApiClient client) throws IllegalStateException {
                return ((ij) client.m149a(Cast.CU)).getApplicationStatus();
            }

            public double getVolume(GoogleApiClient client) throws IllegalStateException {
                return ((ij) client.m149a(Cast.CU)).fE();
            }

            public boolean isMute(GoogleApiClient client) throws IllegalStateException {
                return ((ij) client.m149a(Cast.CU)).isMute();
            }

            public PendingResult<ApplicationConnectionResult> joinApplication(GoogleApiClient client) {
                return client.m152b(new C27276(this));
            }

            public PendingResult<ApplicationConnectionResult> joinApplication(GoogleApiClient client, String applicationId) {
                return client.m152b(new C27265(this, applicationId));
            }

            public PendingResult<ApplicationConnectionResult> joinApplication(GoogleApiClient client, String applicationId, String sessionId) {
                return client.m152b(new C27254(this, applicationId, sessionId));
            }

            public PendingResult<ApplicationConnectionResult> launchApplication(GoogleApiClient client, String applicationId) {
                return client.m152b(new C27232(this, applicationId));
            }

            public PendingResult<ApplicationConnectionResult> launchApplication(GoogleApiClient client, String applicationId, LaunchOptions options) {
                return client.m152b(new C27243(this, applicationId, options));
            }

            @Deprecated
            public PendingResult<ApplicationConnectionResult> launchApplication(GoogleApiClient client, String applicationId, boolean relaunchIfRunning) {
                return launchApplication(client, applicationId, new Builder().setRelaunchIfRunning(relaunchIfRunning).build());
            }

            public PendingResult<Status> leaveApplication(GoogleApiClient client) {
                return client.m152b(new C27287(this));
            }

            public void removeMessageReceivedCallbacks(GoogleApiClient client, String namespace) throws IOException, IllegalArgumentException {
                try {
                    ((ij) client.m149a(Cast.CU)).aE(namespace);
                } catch (RemoteException e) {
                    throw new IOException("service error");
                }
            }

            public void requestStatus(GoogleApiClient client) throws IOException, IllegalStateException {
                try {
                    ((ij) client.m149a(Cast.CU)).fD();
                } catch (RemoteException e) {
                    throw new IOException("service error");
                }
            }

            public PendingResult<Status> sendMessage(GoogleApiClient client, String namespace, String message) {
                return client.m152b(new C27221(this, namespace, message));
            }

            public void setMessageReceivedCallbacks(GoogleApiClient client, String namespace, MessageReceivedCallback callbacks) throws IOException, IllegalStateException {
                try {
                    ((ij) client.m149a(Cast.CU)).m4320a(namespace, callbacks);
                } catch (RemoteException e) {
                    throw new IOException("service error");
                }
            }

            public void setMute(GoogleApiClient client, boolean mute) throws IOException, IllegalStateException {
                try {
                    ((ij) client.m149a(Cast.CU)).m4315G(mute);
                } catch (RemoteException e) {
                    throw new IOException("service error");
                }
            }

            public void setVolume(GoogleApiClient client, double volume) throws IOException, IllegalArgumentException, IllegalStateException {
                try {
                    ((ij) client.m149a(Cast.CU)).m4317a(volume);
                } catch (RemoteException e) {
                    throw new IOException("service error");
                }
            }

            public PendingResult<Status> stopApplication(GoogleApiClient client) {
                return client.m152b(new C27298(this));
            }

            public PendingResult<Status> stopApplication(GoogleApiClient client, String sessionId) {
                return client.m152b(new C27309(this, sessionId));
            }
        }

        ApplicationMetadata getApplicationMetadata(GoogleApiClient googleApiClient) throws IllegalStateException;

        String getApplicationStatus(GoogleApiClient googleApiClient) throws IllegalStateException;

        double getVolume(GoogleApiClient googleApiClient) throws IllegalStateException;

        boolean isMute(GoogleApiClient googleApiClient) throws IllegalStateException;

        PendingResult<ApplicationConnectionResult> joinApplication(GoogleApiClient googleApiClient);

        PendingResult<ApplicationConnectionResult> joinApplication(GoogleApiClient googleApiClient, String str);

        PendingResult<ApplicationConnectionResult> joinApplication(GoogleApiClient googleApiClient, String str, String str2);

        PendingResult<ApplicationConnectionResult> launchApplication(GoogleApiClient googleApiClient, String str);

        PendingResult<ApplicationConnectionResult> launchApplication(GoogleApiClient googleApiClient, String str, LaunchOptions launchOptions);

        @Deprecated
        PendingResult<ApplicationConnectionResult> launchApplication(GoogleApiClient googleApiClient, String str, boolean z);

        PendingResult<Status> leaveApplication(GoogleApiClient googleApiClient);

        void removeMessageReceivedCallbacks(GoogleApiClient googleApiClient, String str) throws IOException, IllegalArgumentException;

        void requestStatus(GoogleApiClient googleApiClient) throws IOException, IllegalStateException;

        PendingResult<Status> sendMessage(GoogleApiClient googleApiClient, String str, String str2);

        void setMessageReceivedCallbacks(GoogleApiClient googleApiClient, String str, MessageReceivedCallback messageReceivedCallback) throws IOException, IllegalStateException;

        void setMute(GoogleApiClient googleApiClient, boolean z) throws IOException, IllegalStateException;

        void setVolume(GoogleApiClient googleApiClient, double d) throws IOException, IllegalArgumentException, IllegalStateException;

        PendingResult<Status> stopApplication(GoogleApiClient googleApiClient);

        PendingResult<Status> stopApplication(GoogleApiClient googleApiClient, String str);
    }

    public static class Listener {
        public void m101W(int i) {
        }

        public void m102X(int i) {
        }

        public void onApplicationDisconnected(int statusCode) {
        }

        public void onApplicationStatusChanged() {
        }

        public void onVolumeChanged() {
        }
    }

    public interface MessageReceivedCallback {
        void onMessageReceived(CastDevice castDevice, String str, String str2);
    }

    /* renamed from: com.google.android.gms.cast.Cast.1 */
    static class C16801 implements C0189b<ij, CastOptions> {
        C16801() {
        }

        public ij m2373a(Context context, Looper looper, ClientSettings clientSettings, CastOptions castOptions, ConnectionCallbacks connectionCallbacks, OnConnectionFailedListener onConnectionFailedListener) {
            C0238o.m279b((Object) castOptions, (Object) "Setting the API options is required.");
            return new ij(context, looper, castOptions.EK, (long) castOptions.EM, castOptions.EL, connectionCallbacks, onConnectionFailedListener);
        }

        public int getPriority() {
            return ConnectionsManager.DEFAULT_DATACENTER_ID;
        }
    }

    public interface ApplicationConnectionResult extends Result {
        ApplicationMetadata getApplicationMetadata();

        String getApplicationStatus();

        String getSessionId();

        boolean getWasLaunched();
    }

    public static final class CastOptions implements HasOptions {
        final CastDevice EK;
        final Listener EL;
        private final int EM;

        public static final class Builder {
            CastDevice EN;
            Listener EO;
            private int EP;

            private Builder(CastDevice castDevice, Listener castListener) {
                C0238o.m279b((Object) castDevice, (Object) "CastDevice parameter cannot be null");
                C0238o.m279b((Object) castListener, (Object) "CastListener parameter cannot be null");
                this.EN = castDevice;
                this.EO = castListener;
                this.EP = 0;
            }

            public CastOptions build() {
                return new CastOptions();
            }

            public Builder setVerboseLoggingEnabled(boolean enabled) {
                if (enabled) {
                    this.EP |= 1;
                } else {
                    this.EP &= -2;
                }
                return this;
            }
        }

        private CastOptions(Builder builder) {
            this.EK = builder.EN;
            this.EL = builder.EO;
            this.EM = builder.EP;
        }

        public static Builder builder(CastDevice castDevice, Listener castListener) {
            return new Builder(castListener, null);
        }
    }

    /* renamed from: com.google.android.gms.cast.Cast.a */
    protected static abstract class C2594a<R extends Result> extends C2381a<R, ij> {
        public C2594a() {
            super(Cast.CU);
        }

        public void m4605V(int i) {
            m2389b(m2391c(new Status(i)));
        }

        public void m4606e(int i, String str) {
            m2389b(m2391c(new Status(i, str, null)));
        }
    }

    /* renamed from: com.google.android.gms.cast.Cast.b */
    private static abstract class C2653b extends C2594a<Status> {
        private C2653b() {
        }

        public /* synthetic */ Result m4836c(Status status) {
            return m4837d(status);
        }

        public Status m4837d(Status status) {
            return status;
        }
    }

    /* renamed from: com.google.android.gms.cast.Cast.c */
    private static abstract class C2654c extends C2594a<ApplicationConnectionResult> {

        /* renamed from: com.google.android.gms.cast.Cast.c.1 */
        class C23771 implements ApplicationConnectionResult {
            final /* synthetic */ Status CW;
            final /* synthetic */ C2654c EQ;

            C23771(C2654c c2654c, Status status) {
                this.EQ = c2654c;
                this.CW = status;
            }

            public ApplicationMetadata getApplicationMetadata() {
                return null;
            }

            public String getApplicationStatus() {
                return null;
            }

            public String getSessionId() {
                return null;
            }

            public Status getStatus() {
                return this.CW;
            }

            public boolean getWasLaunched() {
                return false;
            }
        }

        private C2654c() {
        }

        public /* synthetic */ Result m4838c(Status status) {
            return m4839j(status);
        }

        public ApplicationConnectionResult m4839j(Status status) {
            return new C23771(this, status);
        }
    }

    static {
        CU = new C0190c();
        CV = new C16801();
        API = new Api(CV, CU, new Scope[0]);
        CastApi = new C1681a();
    }

    private Cast() {
    }
}
