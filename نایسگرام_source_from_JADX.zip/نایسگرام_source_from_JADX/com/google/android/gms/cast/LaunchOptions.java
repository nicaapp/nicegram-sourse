package com.google.android.gms.cast;

import android.os.Parcel;
import android.os.Parcelable.Creator;
import com.google.android.gms.common.internal.C0237n;
import com.google.android.gms.common.internal.safeparcel.SafeParcelable;
import com.google.android.gms.internal.ik;
import java.util.Locale;

public class LaunchOptions implements SafeParcelable {
    public static final Creator<LaunchOptions> CREATOR;
    private final int BR;
    private boolean Fb;
    private String Fc;

    public static final class Builder {
        private LaunchOptions Fd;

        public Builder() {
            this.Fd = new LaunchOptions();
        }

        public LaunchOptions build() {
            return this.Fd;
        }

        public Builder setLocale(Locale locale) {
            this.Fd.setLanguage(ik.m1513b(locale));
            return this;
        }

        public Builder setRelaunchIfRunning(boolean relaunchIfRunning) {
            this.Fd.setRelaunchIfRunning(relaunchIfRunning);
            return this;
        }
    }

    static {
        CREATOR = new C0186c();
    }

    public LaunchOptions() {
        this(1, false, ik.m1513b(Locale.getDefault()));
    }

    LaunchOptions(int versionCode, boolean relaunchIfRunning, String language) {
        this.BR = versionCode;
        this.Fb = relaunchIfRunning;
        this.Fc = language;
    }

    public int describeContents() {
        return 0;
    }

    public boolean equals(Object obj) {
        if (obj == this) {
            return true;
        }
        if (!(obj instanceof LaunchOptions)) {
            return false;
        }
        LaunchOptions launchOptions = (LaunchOptions) obj;
        return this.Fb == launchOptions.Fb && ik.m1511a(this.Fc, launchOptions.Fc);
    }

    public String getLanguage() {
        return this.Fc;
    }

    public boolean getRelaunchIfRunning() {
        return this.Fb;
    }

    int getVersionCode() {
        return this.BR;
    }

    public int hashCode() {
        return C0237n.hashCode(Boolean.valueOf(this.Fb), this.Fc);
    }

    public void setLanguage(String language) {
        this.Fc = language;
    }

    public void setRelaunchIfRunning(boolean relaunchIfRunning) {
        this.Fb = relaunchIfRunning;
    }

    public String toString() {
        return String.format("LaunchOptions(relaunchIfRunning=%b, language=%s)", new Object[]{Boolean.valueOf(this.Fb), this.Fc});
    }

    public void writeToParcel(Parcel out, int flags) {
        C0186c.m123a(this, out, flags);
    }
}
