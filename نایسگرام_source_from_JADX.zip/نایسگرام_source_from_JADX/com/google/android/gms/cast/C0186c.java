package com.google.android.gms.cast;

import android.os.Parcel;
import android.os.Parcelable.Creator;
import com.google.android.gms.common.internal.safeparcel.C0242a;
import com.google.android.gms.common.internal.safeparcel.C0242a.C0241a;
import com.google.android.gms.common.internal.safeparcel.C0243b;
import com.google.android.gms.drive.events.CompletionEvent;
import org.telegram.android.time.FastDatePrinter;

/* renamed from: com.google.android.gms.cast.c */
public class C0186c implements Creator<LaunchOptions> {
    static void m123a(LaunchOptions launchOptions, Parcel parcel, int i) {
        int D = C0243b.m329D(parcel);
        C0243b.m356c(parcel, 1, launchOptions.getVersionCode());
        C0243b.m347a(parcel, 2, launchOptions.getRelaunchIfRunning());
        C0243b.m344a(parcel, 3, launchOptions.getLanguage(), false);
        C0243b.m332H(parcel, D);
    }

    public LaunchOptions[] m124Z(int i) {
        return new LaunchOptions[i];
    }

    public /* synthetic */ Object createFromParcel(Parcel x0) {
        return m125v(x0);
    }

    public /* synthetic */ Object[] newArray(int x0) {
        return m124Z(x0);
    }

    public LaunchOptions m125v(Parcel parcel) {
        boolean z = false;
        int C = C0242a.m293C(parcel);
        String str = null;
        int i = 0;
        while (parcel.dataPosition() < C) {
            int B = C0242a.m291B(parcel);
            switch (C0242a.aD(B)) {
                case CompletionEvent.STATUS_FAILURE /*1*/:
                    i = C0242a.m309g(parcel, B);
                    break;
                case CompletionEvent.STATUS_CONFLICT /*2*/:
                    z = C0242a.m305c(parcel, B);
                    break;
                case FastDatePrinter.SHORT /*3*/:
                    str = C0242a.m317o(parcel, B);
                    break;
                default:
                    C0242a.m302b(parcel, B);
                    break;
            }
        }
        if (parcel.dataPosition() == C) {
            return new LaunchOptions(i, z, str);
        }
        throw new C0241a("Overread allowed size end=" + C, parcel);
    }
}
