package com.google.android.gms.cast;

import com.google.android.gms.cast.Cast.C2594a;
import com.google.android.gms.cast.Cast.MessageReceivedCallback;
import com.google.android.gms.common.api.GoogleApiClient;
import com.google.android.gms.common.api.PendingResult;
import com.google.android.gms.common.api.Result;
import com.google.android.gms.common.api.ResultCallback;
import com.google.android.gms.common.api.Status;
import com.google.android.gms.internal.ij;
import com.google.android.gms.internal.iq;
import com.google.android.gms.internal.ir;
import com.google.android.gms.internal.is;
import java.io.IOException;
import org.json.JSONObject;

public class RemoteMediaPlayer implements MessageReceivedCallback {
    public static final int RESUME_STATE_PAUSE = 2;
    public static final int RESUME_STATE_PLAY = 1;
    public static final int RESUME_STATE_UNCHANGED = 0;
    public static final int STATUS_CANCELED = 2101;
    public static final int STATUS_FAILED = 2100;
    public static final int STATUS_REPLACED = 2103;
    public static final int STATUS_SUCCEEDED = 0;
    public static final int STATUS_TIMED_OUT = 2102;
    private final iq FG;
    private final C1683a FH;
    private OnMetadataUpdatedListener FI;
    private OnStatusUpdatedListener FJ;
    private final Object mw;

    public interface OnMetadataUpdatedListener {
        void onMetadataUpdated();
    }

    public interface OnStatusUpdatedListener {
        void onStatusUpdated();
    }

    public interface MediaChannelResult extends Result {
        JSONObject getCustomData();
    }

    /* renamed from: com.google.android.gms.cast.RemoteMediaPlayer.a */
    private class C1683a implements ir {
        final /* synthetic */ RemoteMediaPlayer FK;
        private GoogleApiClient FX;
        private long FY;

        /* renamed from: com.google.android.gms.cast.RemoteMediaPlayer.a.a */
        private final class C1682a implements ResultCallback<Status> {
            private final long FZ;
            final /* synthetic */ C1683a Ga;

            C1682a(C1683a c1683a, long j) {
                this.Ga = c1683a;
                this.FZ = j;
            }

            public void m2374k(Status status) {
                if (!status.isSuccess()) {
                    this.Ga.FK.FG.m3282b(this.FZ, status.getStatusCode());
                }
            }

            public /* synthetic */ void onResult(Result x0) {
                m2374k((Status) x0);
            }
        }

        public C1683a(RemoteMediaPlayer remoteMediaPlayer) {
            this.FK = remoteMediaPlayer;
            this.FY = 0;
        }

        public void m2375a(String str, String str2, long j, String str3) throws IOException {
            if (this.FX == null) {
                throw new IOException("No GoogleApiClient available");
            }
            Cast.CastApi.sendMessage(this.FX, str, str2).setResultCallback(new C1682a(this, j));
        }

        public void m2376b(GoogleApiClient googleApiClient) {
            this.FX = googleApiClient;
        }

        public long fx() {
            long j = this.FY + 1;
            this.FY = j;
            return j;
        }
    }

    /* renamed from: com.google.android.gms.cast.RemoteMediaPlayer.1 */
    class C23781 extends iq {
        final /* synthetic */ RemoteMediaPlayer FK;

        C23781(RemoteMediaPlayer remoteMediaPlayer) {
            this.FK = remoteMediaPlayer;
        }

        protected void onMetadataUpdated() {
            this.FK.onMetadataUpdated();
        }

        protected void onStatusUpdated() {
            this.FK.onStatusUpdated();
        }
    }

    /* renamed from: com.google.android.gms.cast.RemoteMediaPlayer.c */
    private static final class C2380c implements MediaChannelResult {
        private final Status CM;
        private final JSONObject Fl;

        C2380c(Status status, JSONObject jSONObject) {
            this.CM = status;
            this.Fl = jSONObject;
        }

        public JSONObject getCustomData() {
            return this.Fl;
        }

        public Status getStatus() {
            return this.CM;
        }
    }

    /* renamed from: com.google.android.gms.cast.RemoteMediaPlayer.b */
    private static abstract class C2655b extends C2594a<MediaChannelResult> {
        is Gb;

        /* renamed from: com.google.android.gms.cast.RemoteMediaPlayer.b.1 */
        class C16841 implements is {
            final /* synthetic */ C2655b Gc;

            C16841(C2655b c2655b) {
                this.Gc = c2655b;
            }

            public void m2377a(long j, int i, JSONObject jSONObject) {
                this.Gc.m2389b(new C2380c(new Status(i), jSONObject));
            }

            public void m2378n(long j) {
                this.Gc.m2389b(this.Gc.m4841l(new Status(RemoteMediaPlayer.STATUS_REPLACED)));
            }
        }

        /* renamed from: com.google.android.gms.cast.RemoteMediaPlayer.b.2 */
        class C23792 implements MediaChannelResult {
            final /* synthetic */ Status CW;
            final /* synthetic */ C2655b Gc;

            C23792(C2655b c2655b, Status status) {
                this.Gc = c2655b;
                this.CW = status;
            }

            public JSONObject getCustomData() {
                return null;
            }

            public Status getStatus() {
                return this.CW;
            }
        }

        C2655b() {
            this.Gb = new C16841(this);
        }

        public /* synthetic */ Result m4840c(Status status) {
            return m4841l(status);
        }

        public MediaChannelResult m4841l(Status status) {
            return new C23792(this, status);
        }
    }

    /* renamed from: com.google.android.gms.cast.RemoteMediaPlayer.10 */
    class AnonymousClass10 extends C2655b {
        final /* synthetic */ RemoteMediaPlayer FK;
        final /* synthetic */ GoogleApiClient FL;
        final /* synthetic */ JSONObject FS;
        final /* synthetic */ boolean FW;

        AnonymousClass10(RemoteMediaPlayer remoteMediaPlayer, GoogleApiClient googleApiClient, boolean z, JSONObject jSONObject) {
            this.FK = remoteMediaPlayer;
            this.FL = googleApiClient;
            this.FW = z;
            this.FS = jSONObject;
        }

        protected void m5094a(ij ijVar) {
            synchronized (this.FK.mw) {
                this.FK.FH.m2376b(this.FL);
                try {
                    this.FK.FG.m3279a(this.Gb, this.FW, this.FS);
                    this.FK.FH.m2376b(null);
                } catch (IllegalStateException e) {
                    m2389b(m4841l(new Status(RemoteMediaPlayer.STATUS_FAILED)));
                    this.FK.FH.m2376b(null);
                } catch (IOException e2) {
                    m2389b(m4841l(new Status(RemoteMediaPlayer.STATUS_FAILED)));
                    this.FK.FH.m2376b(null);
                } catch (Throwable th) {
                    this.FK.FH.m2376b(null);
                }
            }
        }
    }

    /* renamed from: com.google.android.gms.cast.RemoteMediaPlayer.11 */
    class AnonymousClass11 extends C2655b {
        final /* synthetic */ RemoteMediaPlayer FK;
        final /* synthetic */ GoogleApiClient FL;

        AnonymousClass11(RemoteMediaPlayer remoteMediaPlayer, GoogleApiClient googleApiClient) {
            this.FK = remoteMediaPlayer;
            this.FL = googleApiClient;
        }

        protected void m5096a(ij ijVar) {
            synchronized (this.FK.mw) {
                this.FK.FH.m2376b(this.FL);
                try {
                    this.FK.FG.m3273a(this.Gb);
                    this.FK.FH.m2376b(null);
                } catch (IOException e) {
                    m2389b(m4841l(new Status(RemoteMediaPlayer.STATUS_FAILED)));
                    this.FK.FH.m2376b(null);
                } catch (Throwable th) {
                    this.FK.FH.m2376b(null);
                }
            }
        }
    }

    /* renamed from: com.google.android.gms.cast.RemoteMediaPlayer.2 */
    class C27312 extends C2655b {
        final /* synthetic */ RemoteMediaPlayer FK;
        final /* synthetic */ GoogleApiClient FL;
        final /* synthetic */ long[] FM;

        C27312(RemoteMediaPlayer remoteMediaPlayer, GoogleApiClient googleApiClient, long[] jArr) {
            this.FK = remoteMediaPlayer;
            this.FL = googleApiClient;
            this.FM = jArr;
        }

        protected void m5098a(ij ijVar) {
            synchronized (this.FK.mw) {
                this.FK.FH.m2376b(this.FL);
                try {
                    this.FK.FG.m3280a(this.Gb, this.FM);
                    this.FK.FH.m2376b(null);
                } catch (IOException e) {
                    m2389b(m4841l(new Status(RemoteMediaPlayer.STATUS_FAILED)));
                    this.FK.FH.m2376b(null);
                } catch (Throwable th) {
                    this.FK.FH.m2376b(null);
                }
            }
        }
    }

    /* renamed from: com.google.android.gms.cast.RemoteMediaPlayer.3 */
    class C27323 extends C2655b {
        final /* synthetic */ RemoteMediaPlayer FK;
        final /* synthetic */ GoogleApiClient FL;
        final /* synthetic */ TextTrackStyle FN;

        C27323(RemoteMediaPlayer remoteMediaPlayer, GoogleApiClient googleApiClient, TextTrackStyle textTrackStyle) {
            this.FK = remoteMediaPlayer;
            this.FL = googleApiClient;
            this.FN = textTrackStyle;
        }

        protected void m5100a(ij ijVar) {
            synchronized (this.FK.mw) {
                this.FK.FH.m2376b(this.FL);
                try {
                    this.FK.FG.m3277a(this.Gb, this.FN);
                    this.FK.FH.m2376b(null);
                } catch (IOException e) {
                    m2389b(m4841l(new Status(RemoteMediaPlayer.STATUS_FAILED)));
                    this.FK.FH.m2376b(null);
                } catch (Throwable th) {
                    this.FK.FH.m2376b(null);
                }
            }
        }
    }

    /* renamed from: com.google.android.gms.cast.RemoteMediaPlayer.4 */
    class C27334 extends C2655b {
        final /* synthetic */ RemoteMediaPlayer FK;
        final /* synthetic */ GoogleApiClient FL;
        final /* synthetic */ MediaInfo FO;
        final /* synthetic */ boolean FP;
        final /* synthetic */ long FQ;
        final /* synthetic */ long[] FR;
        final /* synthetic */ JSONObject FS;

        C27334(RemoteMediaPlayer remoteMediaPlayer, GoogleApiClient googleApiClient, MediaInfo mediaInfo, boolean z, long j, long[] jArr, JSONObject jSONObject) {
            this.FK = remoteMediaPlayer;
            this.FL = googleApiClient;
            this.FO = mediaInfo;
            this.FP = z;
            this.FQ = j;
            this.FR = jArr;
            this.FS = jSONObject;
        }

        protected void m5102a(ij ijVar) {
            synchronized (this.FK.mw) {
                this.FK.FH.m2376b(this.FL);
                try {
                    this.FK.FG.m3276a(this.Gb, this.FO, this.FP, this.FQ, this.FR, this.FS);
                    this.FK.FH.m2376b(null);
                } catch (IOException e) {
                    m2389b(m4841l(new Status(RemoteMediaPlayer.STATUS_FAILED)));
                    this.FK.FH.m2376b(null);
                } catch (Throwable th) {
                    this.FK.FH.m2376b(null);
                }
            }
        }
    }

    /* renamed from: com.google.android.gms.cast.RemoteMediaPlayer.5 */
    class C27345 extends C2655b {
        final /* synthetic */ RemoteMediaPlayer FK;
        final /* synthetic */ GoogleApiClient FL;
        final /* synthetic */ JSONObject FS;

        C27345(RemoteMediaPlayer remoteMediaPlayer, GoogleApiClient googleApiClient, JSONObject jSONObject) {
            this.FK = remoteMediaPlayer;
            this.FL = googleApiClient;
            this.FS = jSONObject;
        }

        protected void m5104a(ij ijVar) {
            synchronized (this.FK.mw) {
                this.FK.FH.m2376b(this.FL);
                try {
                    this.FK.FG.m3278a(this.Gb, this.FS);
                    this.FK.FH.m2376b(null);
                } catch (IOException e) {
                    m2389b(m4841l(new Status(RemoteMediaPlayer.STATUS_FAILED)));
                    this.FK.FH.m2376b(null);
                } catch (Throwable th) {
                    this.FK.FH.m2376b(null);
                }
            }
        }
    }

    /* renamed from: com.google.android.gms.cast.RemoteMediaPlayer.6 */
    class C27356 extends C2655b {
        final /* synthetic */ RemoteMediaPlayer FK;
        final /* synthetic */ GoogleApiClient FL;
        final /* synthetic */ JSONObject FS;

        C27356(RemoteMediaPlayer remoteMediaPlayer, GoogleApiClient googleApiClient, JSONObject jSONObject) {
            this.FK = remoteMediaPlayer;
            this.FL = googleApiClient;
            this.FS = jSONObject;
        }

        protected void m5106a(ij ijVar) {
            synchronized (this.FK.mw) {
                this.FK.FH.m2376b(this.FL);
                try {
                    this.FK.FG.m3281b(this.Gb, this.FS);
                    this.FK.FH.m2376b(null);
                } catch (IOException e) {
                    m2389b(m4841l(new Status(RemoteMediaPlayer.STATUS_FAILED)));
                    this.FK.FH.m2376b(null);
                } catch (Throwable th) {
                    this.FK.FH.m2376b(null);
                }
            }
        }
    }

    /* renamed from: com.google.android.gms.cast.RemoteMediaPlayer.7 */
    class C27367 extends C2655b {
        final /* synthetic */ RemoteMediaPlayer FK;
        final /* synthetic */ GoogleApiClient FL;
        final /* synthetic */ JSONObject FS;

        C27367(RemoteMediaPlayer remoteMediaPlayer, GoogleApiClient googleApiClient, JSONObject jSONObject) {
            this.FK = remoteMediaPlayer;
            this.FL = googleApiClient;
            this.FS = jSONObject;
        }

        protected void m5108a(ij ijVar) {
            synchronized (this.FK.mw) {
                this.FK.FH.m2376b(this.FL);
                try {
                    this.FK.FG.m3283c(this.Gb, this.FS);
                    this.FK.FH.m2376b(null);
                } catch (IOException e) {
                    m2389b(m4841l(new Status(RemoteMediaPlayer.STATUS_FAILED)));
                    this.FK.FH.m2376b(null);
                } catch (Throwable th) {
                    this.FK.FH.m2376b(null);
                }
            }
        }
    }

    /* renamed from: com.google.android.gms.cast.RemoteMediaPlayer.8 */
    class C27378 extends C2655b {
        final /* synthetic */ RemoteMediaPlayer FK;
        final /* synthetic */ GoogleApiClient FL;
        final /* synthetic */ JSONObject FS;
        final /* synthetic */ long FT;
        final /* synthetic */ int FU;

        C27378(RemoteMediaPlayer remoteMediaPlayer, GoogleApiClient googleApiClient, long j, int i, JSONObject jSONObject) {
            this.FK = remoteMediaPlayer;
            this.FL = googleApiClient;
            this.FT = j;
            this.FU = i;
            this.FS = jSONObject;
        }

        protected void m5110a(ij ijVar) {
            synchronized (this.FK.mw) {
                this.FK.FH.m2376b(this.FL);
                try {
                    this.FK.FG.m3275a(this.Gb, this.FT, this.FU, this.FS);
                    this.FK.FH.m2376b(null);
                } catch (IOException e) {
                    m2389b(m4841l(new Status(RemoteMediaPlayer.STATUS_FAILED)));
                    this.FK.FH.m2376b(null);
                } catch (Throwable th) {
                    this.FK.FH.m2376b(null);
                }
            }
        }
    }

    /* renamed from: com.google.android.gms.cast.RemoteMediaPlayer.9 */
    class C27389 extends C2655b {
        final /* synthetic */ RemoteMediaPlayer FK;
        final /* synthetic */ GoogleApiClient FL;
        final /* synthetic */ JSONObject FS;
        final /* synthetic */ double FV;

        C27389(RemoteMediaPlayer remoteMediaPlayer, GoogleApiClient googleApiClient, double d, JSONObject jSONObject) {
            this.FK = remoteMediaPlayer;
            this.FL = googleApiClient;
            this.FV = d;
            this.FS = jSONObject;
        }

        protected void m5112a(ij ijVar) {
            synchronized (this.FK.mw) {
                this.FK.FH.m2376b(this.FL);
                try {
                    this.FK.FG.m3274a(this.Gb, this.FV, this.FS);
                    this.FK.FH.m2376b(null);
                } catch (IllegalStateException e) {
                    m2389b(m4841l(new Status(RemoteMediaPlayer.STATUS_FAILED)));
                    this.FK.FH.m2376b(null);
                } catch (IllegalArgumentException e2) {
                    m2389b(m4841l(new Status(RemoteMediaPlayer.STATUS_FAILED)));
                    this.FK.FH.m2376b(null);
                } catch (IOException e3) {
                    m2389b(m4841l(new Status(RemoteMediaPlayer.STATUS_FAILED)));
                    this.FK.FH.m2376b(null);
                } catch (Throwable th) {
                    this.FK.FH.m2376b(null);
                }
            }
        }
    }

    public RemoteMediaPlayer() {
        this.mw = new Object();
        this.FH = new C1683a(this);
        this.FG = new C23781(this);
        this.FG.m1508a(this.FH);
    }

    private void onMetadataUpdated() {
        if (this.FI != null) {
            this.FI.onMetadataUpdated();
        }
    }

    private void onStatusUpdated() {
        if (this.FJ != null) {
            this.FJ.onStatusUpdated();
        }
    }

    public long getApproximateStreamPosition() {
        long approximateStreamPosition;
        synchronized (this.mw) {
            approximateStreamPosition = this.FG.getApproximateStreamPosition();
        }
        return approximateStreamPosition;
    }

    public MediaInfo getMediaInfo() {
        MediaInfo mediaInfo;
        synchronized (this.mw) {
            mediaInfo = this.FG.getMediaInfo();
        }
        return mediaInfo;
    }

    public MediaStatus getMediaStatus() {
        MediaStatus mediaStatus;
        synchronized (this.mw) {
            mediaStatus = this.FG.getMediaStatus();
        }
        return mediaStatus;
    }

    public String getNamespace() {
        return this.FG.getNamespace();
    }

    public long getStreamDuration() {
        long streamDuration;
        synchronized (this.mw) {
            streamDuration = this.FG.getStreamDuration();
        }
        return streamDuration;
    }

    public PendingResult<MediaChannelResult> load(GoogleApiClient apiClient, MediaInfo mediaInfo) {
        return load(apiClient, mediaInfo, true, 0, null, null);
    }

    public PendingResult<MediaChannelResult> load(GoogleApiClient apiClient, MediaInfo mediaInfo, boolean autoplay) {
        return load(apiClient, mediaInfo, autoplay, 0, null, null);
    }

    public PendingResult<MediaChannelResult> load(GoogleApiClient apiClient, MediaInfo mediaInfo, boolean autoplay, long playPosition) {
        return load(apiClient, mediaInfo, autoplay, playPosition, null, null);
    }

    public PendingResult<MediaChannelResult> load(GoogleApiClient apiClient, MediaInfo mediaInfo, boolean autoplay, long playPosition, JSONObject customData) {
        return load(apiClient, mediaInfo, autoplay, playPosition, null, customData);
    }

    public PendingResult<MediaChannelResult> load(GoogleApiClient apiClient, MediaInfo mediaInfo, boolean autoplay, long playPosition, long[] activeTrackIds, JSONObject customData) {
        return apiClient.m152b(new C27334(this, apiClient, mediaInfo, autoplay, playPosition, activeTrackIds, customData));
    }

    public void onMessageReceived(CastDevice castDevice, String namespace, String message) {
        this.FG.aD(message);
    }

    public PendingResult<MediaChannelResult> pause(GoogleApiClient apiClient) {
        return pause(apiClient, null);
    }

    public PendingResult<MediaChannelResult> pause(GoogleApiClient apiClient, JSONObject customData) {
        return apiClient.m152b(new C27345(this, apiClient, customData));
    }

    public PendingResult<MediaChannelResult> play(GoogleApiClient apiClient) {
        return play(apiClient, null);
    }

    public PendingResult<MediaChannelResult> play(GoogleApiClient apiClient, JSONObject customData) {
        return apiClient.m152b(new C27367(this, apiClient, customData));
    }

    public PendingResult<MediaChannelResult> requestStatus(GoogleApiClient apiClient) {
        return apiClient.m152b(new AnonymousClass11(this, apiClient));
    }

    public PendingResult<MediaChannelResult> seek(GoogleApiClient apiClient, long position) {
        return seek(apiClient, position, STATUS_SUCCEEDED, null);
    }

    public PendingResult<MediaChannelResult> seek(GoogleApiClient apiClient, long position, int resumeState) {
        return seek(apiClient, position, resumeState, null);
    }

    public PendingResult<MediaChannelResult> seek(GoogleApiClient apiClient, long position, int resumeState, JSONObject customData) {
        return apiClient.m152b(new C27378(this, apiClient, position, resumeState, customData));
    }

    public PendingResult<MediaChannelResult> setActiveMediaTracks(GoogleApiClient apiClient, long[] trackIds) {
        return apiClient.m152b(new C27312(this, apiClient, trackIds));
    }

    public void setOnMetadataUpdatedListener(OnMetadataUpdatedListener listener) {
        this.FI = listener;
    }

    public void setOnStatusUpdatedListener(OnStatusUpdatedListener listener) {
        this.FJ = listener;
    }

    public PendingResult<MediaChannelResult> setStreamMute(GoogleApiClient apiClient, boolean muteState) {
        return setStreamMute(apiClient, muteState, null);
    }

    public PendingResult<MediaChannelResult> setStreamMute(GoogleApiClient apiClient, boolean muteState, JSONObject customData) {
        return apiClient.m152b(new AnonymousClass10(this, apiClient, muteState, customData));
    }

    public PendingResult<MediaChannelResult> setStreamVolume(GoogleApiClient apiClient, double volume) throws IllegalArgumentException {
        return setStreamVolume(apiClient, volume, null);
    }

    public PendingResult<MediaChannelResult> setStreamVolume(GoogleApiClient apiClient, double volume, JSONObject customData) throws IllegalArgumentException {
        if (!Double.isInfinite(volume) && !Double.isNaN(volume)) {
            return apiClient.m152b(new C27389(this, apiClient, volume, customData));
        }
        throw new IllegalArgumentException("Volume cannot be " + volume);
    }

    public PendingResult<MediaChannelResult> setTextTrackStyle(GoogleApiClient apiClient, TextTrackStyle trackStyle) {
        if (trackStyle != null) {
            return apiClient.m152b(new C27323(this, apiClient, trackStyle));
        }
        throw new IllegalArgumentException("trackStyle cannot be null");
    }

    public PendingResult<MediaChannelResult> stop(GoogleApiClient apiClient) {
        return stop(apiClient, null);
    }

    public PendingResult<MediaChannelResult> stop(GoogleApiClient apiClient, JSONObject customData) {
        return apiClient.m152b(new C27356(this, apiClient, customData));
    }
}
