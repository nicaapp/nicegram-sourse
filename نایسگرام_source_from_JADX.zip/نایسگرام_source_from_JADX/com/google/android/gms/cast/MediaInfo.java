package com.google.android.gms.cast;

import android.text.TextUtils;
import com.google.android.gms.common.internal.C0237n;
import com.google.android.gms.internal.ik;
import com.google.android.gms.internal.jz;
import java.util.ArrayList;
import java.util.List;
import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

public final class MediaInfo {
    public static final int STREAM_TYPE_BUFFERED = 1;
    public static final int STREAM_TYPE_INVALID = -1;
    public static final int STREAM_TYPE_LIVE = 2;
    public static final int STREAM_TYPE_NONE = 0;
    private final String Fe;
    private int Ff;
    private String Fg;
    private MediaMetadata Fh;
    private long Fi;
    private List<MediaTrack> Fj;
    private TextTrackStyle Fk;
    private JSONObject Fl;

    public static class Builder {
        private final MediaInfo Fm;

        public Builder(String contentId) throws IllegalArgumentException {
            if (TextUtils.isEmpty(contentId)) {
                throw new IllegalArgumentException("Content ID cannot be empty");
            }
            this.Fm = new MediaInfo(contentId);
        }

        public MediaInfo build() throws IllegalArgumentException {
            this.Fm.fv();
            return this.Fm;
        }

        public Builder setContentType(String contentType) throws IllegalArgumentException {
            this.Fm.setContentType(contentType);
            return this;
        }

        public Builder setCustomData(JSONObject customData) {
            this.Fm.setCustomData(customData);
            return this;
        }

        public Builder setMediaTracks(List<MediaTrack> mediaTracks) {
            this.Fm.m105c(mediaTracks);
            return this;
        }

        public Builder setMetadata(MediaMetadata metadata) {
            this.Fm.m104a(metadata);
            return this;
        }

        public Builder setStreamDuration(long duration) throws IllegalArgumentException {
            this.Fm.m106m(duration);
            return this;
        }

        public Builder setStreamType(int streamType) throws IllegalArgumentException {
            this.Fm.setStreamType(streamType);
            return this;
        }

        public Builder setTextTrackStyle(TextTrackStyle textTrackStyle) {
            this.Fm.setTextTrackStyle(textTrackStyle);
            return this;
        }
    }

    MediaInfo(String contentId) throws IllegalArgumentException {
        if (TextUtils.isEmpty(contentId)) {
            throw new IllegalArgumentException("content ID cannot be null or empty");
        }
        this.Fe = contentId;
        this.Ff = STREAM_TYPE_INVALID;
    }

    MediaInfo(JSONObject json) throws JSONException {
        int i = 0;
        this.Fe = json.getString("contentId");
        String string = json.getString("streamType");
        if ("NONE".equals(string)) {
            this.Ff = 0;
        } else if ("BUFFERED".equals(string)) {
            this.Ff = STREAM_TYPE_BUFFERED;
        } else if ("LIVE".equals(string)) {
            this.Ff = STREAM_TYPE_LIVE;
        } else {
            this.Ff = STREAM_TYPE_INVALID;
        }
        this.Fg = json.getString("contentType");
        if (json.has("metadata")) {
            JSONObject jSONObject = json.getJSONObject("metadata");
            this.Fh = new MediaMetadata(jSONObject.getInt("metadataType"));
            this.Fh.m112c(jSONObject);
        }
        this.Fi = ik.m1512b(json.optDouble("duration", 0.0d));
        if (json.has("tracks")) {
            this.Fj = new ArrayList();
            JSONArray jSONArray = json.getJSONArray("tracks");
            while (i < jSONArray.length()) {
                this.Fj.add(new MediaTrack(jSONArray.getJSONObject(i)));
                i += STREAM_TYPE_BUFFERED;
            }
        } else {
            this.Fj = null;
        }
        if (json.has("textTrackStyle")) {
            JSONObject jSONObject2 = json.getJSONObject("textTrackStyle");
            TextTrackStyle textTrackStyle = new TextTrackStyle();
            textTrackStyle.m116c(jSONObject2);
            this.Fk = textTrackStyle;
        } else {
            this.Fk = null;
        }
        this.Fl = json.optJSONObject("customData");
    }

    void m104a(MediaMetadata mediaMetadata) {
        this.Fh = mediaMetadata;
    }

    public JSONObject bK() {
        JSONObject jSONObject = new JSONObject();
        try {
            Object obj;
            jSONObject.put("contentId", this.Fe);
            switch (this.Ff) {
                case STREAM_TYPE_BUFFERED /*1*/:
                    obj = "BUFFERED";
                    break;
                case STREAM_TYPE_LIVE /*2*/:
                    obj = "LIVE";
                    break;
                default:
                    obj = "NONE";
                    break;
            }
            jSONObject.put("streamType", obj);
            if (this.Fg != null) {
                jSONObject.put("contentType", this.Fg);
            }
            if (this.Fh != null) {
                jSONObject.put("metadata", this.Fh.bK());
            }
            jSONObject.put("duration", ik.m1514o(this.Fi));
            if (this.Fj != null) {
                JSONArray jSONArray = new JSONArray();
                for (MediaTrack bK : this.Fj) {
                    jSONArray.put(bK.bK());
                }
                jSONObject.put("tracks", jSONArray);
            }
            if (this.Fk != null) {
                jSONObject.put("textTrackStyle", this.Fk.bK());
            }
            if (this.Fl != null) {
                jSONObject.put("customData", this.Fl);
            }
        } catch (JSONException e) {
        }
        return jSONObject;
    }

    void m105c(List<MediaTrack> list) {
        this.Fj = list;
    }

    public boolean equals(Object other) {
        boolean z = true;
        if (this == other) {
            return true;
        }
        if (!(other instanceof MediaInfo)) {
            return false;
        }
        MediaInfo mediaInfo = (MediaInfo) other;
        if ((this.Fl == null ? STREAM_TYPE_BUFFERED : false) != (mediaInfo.Fl == null ? STREAM_TYPE_BUFFERED : false)) {
            return false;
        }
        if (this.Fl != null && mediaInfo.Fl != null && !jz.m1601d(this.Fl, mediaInfo.Fl)) {
            return false;
        }
        if (!(ik.m1511a(this.Fe, mediaInfo.Fe) && this.Ff == mediaInfo.Ff && ik.m1511a(this.Fg, mediaInfo.Fg) && ik.m1511a(this.Fh, mediaInfo.Fh) && this.Fi == mediaInfo.Fi)) {
            z = false;
        }
        return z;
    }

    void fv() throws IllegalArgumentException {
        if (TextUtils.isEmpty(this.Fe)) {
            throw new IllegalArgumentException("content ID cannot be null or empty");
        } else if (TextUtils.isEmpty(this.Fg)) {
            throw new IllegalArgumentException("content type cannot be null or empty");
        } else if (this.Ff == STREAM_TYPE_INVALID) {
            throw new IllegalArgumentException("a valid stream type must be specified");
        }
    }

    public String getContentId() {
        return this.Fe;
    }

    public String getContentType() {
        return this.Fg;
    }

    public JSONObject getCustomData() {
        return this.Fl;
    }

    public List<MediaTrack> getMediaTracks() {
        return this.Fj;
    }

    public MediaMetadata getMetadata() {
        return this.Fh;
    }

    public long getStreamDuration() {
        return this.Fi;
    }

    public int getStreamType() {
        return this.Ff;
    }

    public TextTrackStyle getTextTrackStyle() {
        return this.Fk;
    }

    public int hashCode() {
        return C0237n.hashCode(this.Fe, Integer.valueOf(this.Ff), this.Fg, this.Fh, Long.valueOf(this.Fi), String.valueOf(this.Fl));
    }

    void m106m(long j) throws IllegalArgumentException {
        if (j < 0) {
            throw new IllegalArgumentException("Stream duration cannot be negative");
        }
        this.Fi = j;
    }

    void setContentType(String contentType) throws IllegalArgumentException {
        if (TextUtils.isEmpty(contentType)) {
            throw new IllegalArgumentException("content type cannot be null or empty");
        }
        this.Fg = contentType;
    }

    void setCustomData(JSONObject customData) {
        this.Fl = customData;
    }

    void setStreamType(int streamType) throws IllegalArgumentException {
        if (streamType < STREAM_TYPE_INVALID || streamType > STREAM_TYPE_LIVE) {
            throw new IllegalArgumentException("invalid stream type");
        }
        this.Ff = streamType;
    }

    public void setTextTrackStyle(TextTrackStyle textTrackStyle) {
        this.Fk = textTrackStyle;
    }
}
