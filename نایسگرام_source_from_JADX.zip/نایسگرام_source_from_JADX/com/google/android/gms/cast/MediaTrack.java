package com.google.android.gms.cast;

import android.text.TextUtils;
import com.google.android.gms.common.internal.C0237n;
import com.google.android.gms.internal.ik;
import com.google.android.gms.internal.jz;
import java.util.Locale;
import org.json.JSONException;
import org.json.JSONObject;

public final class MediaTrack {
    public static final int SUBTYPE_CAPTIONS = 2;
    public static final int SUBTYPE_CHAPTERS = 4;
    public static final int SUBTYPE_DESCRIPTIONS = 3;
    public static final int SUBTYPE_METADATA = 5;
    public static final int SUBTYPE_NONE = 0;
    public static final int SUBTYPE_SUBTITLES = 1;
    public static final int SUBTYPE_UNKNOWN = -1;
    public static final int TYPE_AUDIO = 2;
    public static final int TYPE_TEXT = 1;
    public static final int TYPE_UNKNOWN = 0;
    public static final int TYPE_VIDEO = 3;
    private long Dj;
    private int FD;
    private int FE;
    private String Fc;
    private String Fe;
    private String Fg;
    private JSONObject Fl;
    private String mName;

    public static class Builder {
        private final MediaTrack FF;

        public Builder(long trackId, int trackType) throws IllegalArgumentException {
            this.FF = new MediaTrack(trackId, trackType);
        }

        public MediaTrack build() {
            return this.FF;
        }

        public Builder setContentId(String contentId) {
            this.FF.setContentId(contentId);
            return this;
        }

        public Builder setContentType(String contentType) {
            this.FF.setContentType(contentType);
            return this;
        }

        public Builder setCustomData(JSONObject customData) {
            this.FF.setCustomData(customData);
            return this;
        }

        public Builder setLanguage(String language) {
            this.FF.setLanguage(language);
            return this;
        }

        public Builder setLanguage(Locale locale) {
            this.FF.setLanguage(ik.m1513b(locale));
            return this;
        }

        public Builder setName(String trackName) {
            this.FF.setName(trackName);
            return this;
        }

        public Builder setSubtype(int subtype) throws IllegalArgumentException {
            this.FF.aa(subtype);
            return this;
        }
    }

    MediaTrack(long id, int type) throws IllegalArgumentException {
        clear();
        this.Dj = id;
        if (type <= 0 || type > TYPE_VIDEO) {
            throw new IllegalArgumentException("invalid type " + type);
        }
        this.FD = type;
    }

    MediaTrack(JSONObject json) throws JSONException {
        m114c(json);
    }

    private void m114c(JSONObject jSONObject) throws JSONException {
        clear();
        this.Dj = jSONObject.getLong("trackId");
        String string = jSONObject.getString("type");
        if ("TEXT".equals(string)) {
            this.FD = TYPE_TEXT;
        } else if ("AUDIO".equals(string)) {
            this.FD = TYPE_AUDIO;
        } else if ("VIDEO".equals(string)) {
            this.FD = TYPE_VIDEO;
        } else {
            throw new JSONException("invalid type: " + string);
        }
        this.Fe = jSONObject.optString("trackContentId", null);
        this.Fg = jSONObject.optString("trackContentType", null);
        this.mName = jSONObject.optString("name", null);
        this.Fc = jSONObject.optString("language", null);
        if (jSONObject.has("subtype")) {
            string = jSONObject.getString("subtype");
            if ("SUBTITLES".equals(string)) {
                this.FE = TYPE_TEXT;
            } else if ("CAPTIONS".equals(string)) {
                this.FE = TYPE_AUDIO;
            } else if ("DESCRIPTIONS".equals(string)) {
                this.FE = TYPE_VIDEO;
            } else if ("CHAPTERS".equals(string)) {
                this.FE = SUBTYPE_CHAPTERS;
            } else if ("METADATA".equals(string)) {
                this.FE = SUBTYPE_METADATA;
            } else {
                throw new JSONException("invalid subtype: " + string);
            }
        }
        this.FE = TYPE_UNKNOWN;
        this.Fl = jSONObject.optJSONObject("customData");
    }

    private void clear() {
        this.Dj = 0;
        this.FD = TYPE_UNKNOWN;
        this.Fe = null;
        this.mName = null;
        this.Fc = null;
        this.FE = SUBTYPE_UNKNOWN;
        this.Fl = null;
    }

    void aa(int i) throws IllegalArgumentException {
        if (i <= SUBTYPE_UNKNOWN || i > SUBTYPE_METADATA) {
            throw new IllegalArgumentException("invalid subtype " + i);
        } else if (i == 0 || this.FD == TYPE_TEXT) {
            this.FE = i;
        } else {
            throw new IllegalArgumentException("subtypes are only valid for text tracks");
        }
    }

    public JSONObject bK() {
        JSONObject jSONObject = new JSONObject();
        try {
            jSONObject.put("trackId", this.Dj);
            switch (this.FD) {
                case TYPE_TEXT /*1*/:
                    jSONObject.put("type", "TEXT");
                    break;
                case TYPE_AUDIO /*2*/:
                    jSONObject.put("type", "AUDIO");
                    break;
                case TYPE_VIDEO /*3*/:
                    jSONObject.put("type", "VIDEO");
                    break;
            }
            if (this.Fe != null) {
                jSONObject.put("trackContentId", this.Fe);
            }
            if (this.Fg != null) {
                jSONObject.put("trackContentType", this.Fg);
            }
            if (this.mName != null) {
                jSONObject.put("name", this.mName);
            }
            if (!TextUtils.isEmpty(this.Fc)) {
                jSONObject.put("language", this.Fc);
            }
            switch (this.FE) {
                case TYPE_TEXT /*1*/:
                    jSONObject.put("subtype", "SUBTITLES");
                    break;
                case TYPE_AUDIO /*2*/:
                    jSONObject.put("subtype", "CAPTIONS");
                    break;
                case TYPE_VIDEO /*3*/:
                    jSONObject.put("subtype", "DESCRIPTIONS");
                    break;
                case SUBTYPE_CHAPTERS /*4*/:
                    jSONObject.put("subtype", "CHAPTERS");
                    break;
                case SUBTYPE_METADATA /*5*/:
                    jSONObject.put("subtype", "METADATA");
                    break;
            }
            if (this.Fl != null) {
                jSONObject.put("customData", this.Fl);
            }
        } catch (JSONException e) {
        }
        return jSONObject;
    }

    public boolean equals(Object other) {
        boolean z = true;
        if (this == other) {
            return true;
        }
        if (!(other instanceof MediaTrack)) {
            return false;
        }
        MediaTrack mediaTrack = (MediaTrack) other;
        if ((this.Fl == null ? TYPE_TEXT : false) != (mediaTrack.Fl == null ? TYPE_TEXT : false)) {
            return false;
        }
        if (this.Fl != null && mediaTrack.Fl != null && !jz.m1601d(this.Fl, mediaTrack.Fl)) {
            return false;
        }
        if (!(this.Dj == mediaTrack.Dj && this.FD == mediaTrack.FD && ik.m1511a(this.Fe, mediaTrack.Fe) && ik.m1511a(this.Fg, mediaTrack.Fg) && ik.m1511a(this.mName, mediaTrack.mName) && ik.m1511a(this.Fc, mediaTrack.Fc) && this.FE == mediaTrack.FE)) {
            z = false;
        }
        return z;
    }

    public String getContentId() {
        return this.Fe;
    }

    public String getContentType() {
        return this.Fg;
    }

    public JSONObject getCustomData() {
        return this.Fl;
    }

    public long getId() {
        return this.Dj;
    }

    public String getLanguage() {
        return this.Fc;
    }

    public String getName() {
        return this.mName;
    }

    public int getSubtype() {
        return this.FE;
    }

    public int getType() {
        return this.FD;
    }

    public int hashCode() {
        return C0237n.hashCode(Long.valueOf(this.Dj), Integer.valueOf(this.FD), this.Fe, this.Fg, this.mName, this.Fc, Integer.valueOf(this.FE), this.Fl);
    }

    public void setContentId(String contentId) {
        this.Fe = contentId;
    }

    public void setContentType(String contentType) {
        this.Fg = contentType;
    }

    void setCustomData(JSONObject customData) {
        this.Fl = customData;
    }

    void setLanguage(String language) {
        this.Fc = language;
    }

    void setName(String name) {
        this.mName = name;
    }
}
