package com.google.android.gms.cast;

import android.os.Parcel;
import android.os.Parcelable.Creator;
import com.google.android.gms.common.images.WebImage;
import com.google.android.gms.common.internal.safeparcel.C0242a;
import com.google.android.gms.common.internal.safeparcel.C0242a.C0241a;
import com.google.android.gms.common.internal.safeparcel.C0243b;
import com.google.android.gms.drive.events.CompletionEvent;
import com.google.android.gms.games.quest.Quest;
import com.google.android.gms.location.DetectedActivity;
import com.googlecode.mp4parser.boxes.microsoft.XtraBox;
import java.util.List;
import org.telegram.C0811R;
import org.telegram.android.support.widget.helper.ItemTouchHelper;
import org.telegram.android.time.FastDatePrinter;

/* renamed from: com.google.android.gms.cast.b */
public class C0185b implements Creator<CastDevice> {
    static void m120a(CastDevice castDevice, Parcel parcel, int i) {
        int D = C0243b.m329D(parcel);
        C0243b.m356c(parcel, 1, castDevice.getVersionCode());
        C0243b.m344a(parcel, 2, castDevice.getDeviceId(), false);
        C0243b.m344a(parcel, 3, castDevice.ES, false);
        C0243b.m344a(parcel, 4, castDevice.getFriendlyName(), false);
        C0243b.m344a(parcel, 5, castDevice.getModelName(), false);
        C0243b.m344a(parcel, 6, castDevice.getDeviceVersion(), false);
        C0243b.m356c(parcel, 7, castDevice.getServicePort());
        C0243b.m357c(parcel, 8, castDevice.getIcons(), false);
        C0243b.m356c(parcel, 9, castDevice.getCapabilities());
        C0243b.m356c(parcel, 10, castDevice.getStatus());
        C0243b.m332H(parcel, D);
    }

    public CastDevice[] m121Y(int i) {
        return new CastDevice[i];
    }

    public /* synthetic */ Object createFromParcel(Parcel x0) {
        return m122u(x0);
    }

    public /* synthetic */ Object[] newArray(int x0) {
        return m121Y(x0);
    }

    public CastDevice m122u(Parcel parcel) {
        int i = 0;
        List list = null;
        int C = C0242a.m293C(parcel);
        int i2 = 0;
        int i3 = 0;
        String str = null;
        String str2 = null;
        String str3 = null;
        String str4 = null;
        String str5 = null;
        int i4 = 0;
        while (parcel.dataPosition() < C) {
            int B = C0242a.m291B(parcel);
            switch (C0242a.aD(B)) {
                case CompletionEvent.STATUS_FAILURE /*1*/:
                    i4 = C0242a.m309g(parcel, B);
                    break;
                case CompletionEvent.STATUS_CONFLICT /*2*/:
                    str5 = C0242a.m317o(parcel, B);
                    break;
                case FastDatePrinter.SHORT /*3*/:
                    str4 = C0242a.m317o(parcel, B);
                    break;
                case ItemTouchHelper.LEFT /*4*/:
                    str3 = C0242a.m317o(parcel, B);
                    break;
                case DetectedActivity.TILTING /*5*/:
                    str2 = C0242a.m317o(parcel, B);
                    break;
                case Quest.STATE_FAILED /*6*/:
                    str = C0242a.m317o(parcel, B);
                    break;
                case DetectedActivity.WALKING /*7*/:
                    i3 = C0242a.m309g(parcel, B);
                    break;
                case XtraBox.MP4_XTRA_BT_UNICODE /*8*/:
                    list = C0242a.m304c(parcel, B, WebImage.CREATOR);
                    break;
                case C0811R.styleable.WalletFragmentStyle_maskedWalletDetailsLogoTextColor /*9*/:
                    i2 = C0242a.m309g(parcel, B);
                    break;
                case C0811R.styleable.WalletFragmentStyle_maskedWalletDetailsLogoImageType /*10*/:
                    i = C0242a.m309g(parcel, B);
                    break;
                default:
                    C0242a.m302b(parcel, B);
                    break;
            }
        }
        if (parcel.dataPosition() == C) {
            return new CastDevice(i4, str5, str4, str3, str2, str, i3, list, i2, i);
        }
        throw new C0241a("Overread allowed size end=" + C, parcel);
    }
}
