package com.google.android.gms.panorama;

import android.content.Context;
import android.os.Looper;
import com.google.android.gms.common.api.Api;
import com.google.android.gms.common.api.Api.ApiOptions.NoOptions;
import com.google.android.gms.common.api.Api.C0188a;
import com.google.android.gms.common.api.Api.C0189b;
import com.google.android.gms.common.api.Api.C0190c;
import com.google.android.gms.common.api.GoogleApiClient.ConnectionCallbacks;
import com.google.android.gms.common.api.GoogleApiClient.OnConnectionFailedListener;
import com.google.android.gms.common.api.Scope;
import com.google.android.gms.common.internal.ClientSettings;
import com.google.android.gms.internal.nc;
import com.google.android.gms.internal.nd;
import org.telegram.messenger.ConnectionsManager;

public final class Panorama {
    public static final Api<NoOptions> API;
    public static final C0190c<nd> CU;
    static final C0189b<nd, NoOptions> CV;
    public static final PanoramaApi PanoramaApi;

    /* renamed from: com.google.android.gms.panorama.Panorama.1 */
    static class C20501 implements C0189b<nd, NoOptions> {
        C20501() {
        }

        public /* synthetic */ C0188a m3509a(Context context, Looper looper, ClientSettings clientSettings, Object obj, ConnectionCallbacks connectionCallbacks, OnConnectionFailedListener onConnectionFailedListener) {
            return m3510e(context, looper, clientSettings, (NoOptions) obj, connectionCallbacks, onConnectionFailedListener);
        }

        public nd m3510e(Context context, Looper looper, ClientSettings clientSettings, NoOptions noOptions, ConnectionCallbacks connectionCallbacks, OnConnectionFailedListener onConnectionFailedListener) {
            return new nd(context, looper, connectionCallbacks, onConnectionFailedListener);
        }

        public int getPriority() {
            return ConnectionsManager.DEFAULT_DATACENTER_ID;
        }
    }

    static {
        CU = new C0190c();
        CV = new C20501();
        API = new Api(CV, CU, new Scope[0]);
        PanoramaApi = new nc();
    }

    private Panorama() {
    }
}
