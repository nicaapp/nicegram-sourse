package com.google.android.gms.internal;

import com.google.ads.AdSize;
import com.google.android.gms.drive.events.CompletionEvent;
import com.google.android.gms.games.quest.Quest;
import com.google.android.gms.location.DetectedActivity;
import com.googlecode.mp4parser.authoring.tracks.h265.NalUnitTypes;
import com.googlecode.mp4parser.boxes.microsoft.XtraBox;
import java.io.IOException;
import org.telegram.C0811R;
import org.telegram.android.MessagesController;
import org.telegram.android.support.widget.helper.ItemTouchHelper;
import org.telegram.android.time.FastDatePrinter;
import org.telegram.messenger.BuildConfig;
import org.telegram.messenger.TLRPC;

/* renamed from: com.google.android.gms.internal.d */
public interface C0444d {

    /* renamed from: com.google.android.gms.internal.d.a */
    public static final class C2468a extends ph<C2468a> {
        private static volatile C2468a[] gu;
        public String gA;
        public long gB;
        public boolean gC;
        public C2468a[] gD;
        public int[] gE;
        public boolean gF;
        public String gv;
        public C2468a[] gw;
        public C2468a[] gx;
        public C2468a[] gy;
        public String gz;
        public int type;

        public C2468a() {
            m4220s();
        }

        public static C2468a[] m4215r() {
            if (gu == null) {
                synchronized (pl.awT) {
                    if (gu == null) {
                        gu = new C2468a[0];
                    }
                }
            }
            return gu;
        }

        public void m4216a(pg pgVar) throws IOException {
            int i = 0;
            pgVar.m1812s(1, this.type);
            if (!this.gv.equals(BuildConfig.FLAVOR)) {
                pgVar.m1803b(2, this.gv);
            }
            if (this.gw != null && this.gw.length > 0) {
                for (pn pnVar : this.gw) {
                    if (pnVar != null) {
                        pgVar.m1798a(3, pnVar);
                    }
                }
            }
            if (this.gx != null && this.gx.length > 0) {
                for (pn pnVar2 : this.gx) {
                    if (pnVar2 != null) {
                        pgVar.m1798a(4, pnVar2);
                    }
                }
            }
            if (this.gy != null && this.gy.length > 0) {
                for (pn pnVar22 : this.gy) {
                    if (pnVar22 != null) {
                        pgVar.m1798a(5, pnVar22);
                    }
                }
            }
            if (!this.gz.equals(BuildConfig.FLAVOR)) {
                pgVar.m1803b(6, this.gz);
            }
            if (!this.gA.equals(BuildConfig.FLAVOR)) {
                pgVar.m1803b(7, this.gA);
            }
            if (this.gB != 0) {
                pgVar.m1802b(8, this.gB);
            }
            if (this.gF) {
                pgVar.m1804b(9, this.gF);
            }
            if (this.gE != null && this.gE.length > 0) {
                for (int s : this.gE) {
                    pgVar.m1812s(10, s);
                }
            }
            if (this.gD != null && this.gD.length > 0) {
                while (i < this.gD.length) {
                    pn pnVar3 = this.gD[i];
                    if (pnVar3 != null) {
                        pgVar.m1798a(11, pnVar3);
                    }
                    i++;
                }
            }
            if (this.gC) {
                pgVar.m1804b(12, this.gC);
            }
            super.m3435a(pgVar);
        }

        public /* synthetic */ pn m4217b(pf pfVar) throws IOException {
            return m4219l(pfVar);
        }

        protected int m4218c() {
            int i;
            int i2 = 0;
            int c = super.m3438c() + pg.m1790u(1, this.type);
            if (!this.gv.equals(BuildConfig.FLAVOR)) {
                c += pg.m1787j(2, this.gv);
            }
            if (this.gw != null && this.gw.length > 0) {
                i = c;
                for (pn pnVar : this.gw) {
                    if (pnVar != null) {
                        i += pg.m1779c(3, pnVar);
                    }
                }
                c = i;
            }
            if (this.gx != null && this.gx.length > 0) {
                i = c;
                for (pn pnVar2 : this.gx) {
                    if (pnVar2 != null) {
                        i += pg.m1779c(4, pnVar2);
                    }
                }
                c = i;
            }
            if (this.gy != null && this.gy.length > 0) {
                i = c;
                for (pn pnVar22 : this.gy) {
                    if (pnVar22 != null) {
                        i += pg.m1779c(5, pnVar22);
                    }
                }
                c = i;
            }
            if (!this.gz.equals(BuildConfig.FLAVOR)) {
                c += pg.m1787j(6, this.gz);
            }
            if (!this.gA.equals(BuildConfig.FLAVOR)) {
                c += pg.m1787j(7, this.gA);
            }
            if (this.gB != 0) {
                c += pg.m1781d(8, this.gB);
            }
            if (this.gF) {
                c += pg.m1780c(9, this.gF);
            }
            if (this.gE != null && this.gE.length > 0) {
                int i3 = 0;
                for (int gw : this.gE) {
                    i3 += pg.gw(gw);
                }
                c = (c + i3) + (this.gE.length * 1);
            }
            if (this.gD != null && this.gD.length > 0) {
                while (i2 < this.gD.length) {
                    pn pnVar3 = this.gD[i2];
                    if (pnVar3 != null) {
                        c += pg.m1779c(11, pnVar3);
                    }
                    i2++;
                }
            }
            return this.gC ? c + pg.m1780c(12, this.gC) : c;
        }

        public boolean equals(Object o) {
            if (o == this) {
                return true;
            }
            if (!(o instanceof C2468a)) {
                return false;
            }
            C2468a c2468a = (C2468a) o;
            if (this.type != c2468a.type) {
                return false;
            }
            if (this.gv == null) {
                if (c2468a.gv != null) {
                    return false;
                }
            } else if (!this.gv.equals(c2468a.gv)) {
                return false;
            }
            if (!pl.equals(this.gw, c2468a.gw) || !pl.equals(this.gx, c2468a.gx) || !pl.equals(this.gy, c2468a.gy)) {
                return false;
            }
            if (this.gz == null) {
                if (c2468a.gz != null) {
                    return false;
                }
            } else if (!this.gz.equals(c2468a.gz)) {
                return false;
            }
            if (this.gA == null) {
                if (c2468a.gA != null) {
                    return false;
                }
            } else if (!this.gA.equals(c2468a.gA)) {
                return false;
            }
            return (this.gB == c2468a.gB && this.gC == c2468a.gC && pl.equals(this.gD, c2468a.gD) && pl.equals(this.gE, c2468a.gE) && this.gF == c2468a.gF) ? m3437a((ph) c2468a) : false;
        }

        public int hashCode() {
            int i = 1231;
            int i2 = 0;
            int hashCode = ((this.gz == null ? 0 : this.gz.hashCode()) + (((((((((this.gv == null ? 0 : this.gv.hashCode()) + ((this.type + 527) * 31)) * 31) + pl.hashCode(this.gw)) * 31) + pl.hashCode(this.gx)) * 31) + pl.hashCode(this.gy)) * 31)) * 31;
            if (this.gA != null) {
                i2 = this.gA.hashCode();
            }
            hashCode = ((((((this.gC ? 1231 : 1237) + ((((hashCode + i2) * 31) + ((int) (this.gB ^ (this.gB >>> 32)))) * 31)) * 31) + pl.hashCode(this.gD)) * 31) + pl.hashCode(this.gE)) * 31;
            if (!this.gF) {
                i = 1237;
            }
            return ((hashCode + i) * 31) + qz();
        }

        public C2468a m4219l(pf pfVar) throws IOException {
            while (true) {
                int qi = pfVar.qi();
                int b;
                Object obj;
                int i;
                switch (qi) {
                    case FastDatePrinter.FULL /*0*/:
                        break;
                    case XtraBox.MP4_XTRA_BT_UNICODE /*8*/:
                        qi = pfVar.ql();
                        switch (qi) {
                            case CompletionEvent.STATUS_FAILURE /*1*/:
                            case CompletionEvent.STATUS_CONFLICT /*2*/:
                            case FastDatePrinter.SHORT /*3*/:
                            case ItemTouchHelper.LEFT /*4*/:
                            case DetectedActivity.TILTING /*5*/:
                            case Quest.STATE_FAILED /*6*/:
                            case DetectedActivity.WALKING /*7*/:
                            case XtraBox.MP4_XTRA_BT_UNICODE /*8*/:
                                this.type = qi;
                                break;
                            default:
                                continue;
                        }
                    case NalUnitTypes.NAL_TYPE_BLA_N_LP /*18*/:
                        this.gv = pfVar.readString();
                        continue;
                    case NalUnitTypes.NAL_TYPE_RSV_VCL26 /*26*/:
                        b = pq.m1847b(pfVar, 26);
                        qi = this.gw == null ? 0 : this.gw.length;
                        obj = new C2468a[(b + qi)];
                        if (qi != 0) {
                            System.arraycopy(this.gw, 0, obj, 0, qi);
                        }
                        while (qi < obj.length - 1) {
                            obj[qi] = new C2468a();
                            pfVar.m1766a(obj[qi]);
                            pfVar.qi();
                            qi++;
                        }
                        obj[qi] = new C2468a();
                        pfVar.m1766a(obj[qi]);
                        this.gw = obj;
                        continue;
                    case TLRPC.LAYER /*34*/:
                        b = pq.m1847b(pfVar, 34);
                        qi = this.gx == null ? 0 : this.gx.length;
                        obj = new C2468a[(b + qi)];
                        if (qi != 0) {
                            System.arraycopy(this.gx, 0, obj, 0, qi);
                        }
                        while (qi < obj.length - 1) {
                            obj[qi] = new C2468a();
                            pfVar.m1766a(obj[qi]);
                            pfVar.qi();
                            qi++;
                        }
                        obj[qi] = new C2468a();
                        pfVar.m1766a(obj[qi]);
                        this.gx = obj;
                        continue;
                    case NalUnitTypes.NAL_TYPE_RSV_NVCL42 /*42*/:
                        b = pq.m1847b(pfVar, 42);
                        qi = this.gy == null ? 0 : this.gy.length;
                        obj = new C2468a[(b + qi)];
                        if (qi != 0) {
                            System.arraycopy(this.gy, 0, obj, 0, qi);
                        }
                        while (qi < obj.length - 1) {
                            obj[qi] = new C2468a();
                            pfVar.m1766a(obj[qi]);
                            pfVar.qi();
                            qi++;
                        }
                        obj[qi] = new C2468a();
                        pfVar.m1766a(obj[qi]);
                        this.gy = obj;
                        continue;
                    case NalUnitTypes.NAL_TYPE_UNSPEC50 /*50*/:
                        this.gz = pfVar.readString();
                        continue;
                    case 58:
                        this.gA = pfVar.readString();
                        continue;
                    case MessagesController.UPDATE_MASK_USER_PRINT /*64*/:
                        this.gB = pfVar.qk();
                        continue;
                    case XtraBox.MP4_XTRA_BT_GUID /*72*/:
                        this.gF = pfVar.qm();
                        continue;
                    case 80:
                        int b2 = pq.m1847b(pfVar, 80);
                        Object obj2 = new int[b2];
                        i = 0;
                        b = 0;
                        while (i < b2) {
                            if (i != 0) {
                                pfVar.qi();
                            }
                            int ql = pfVar.ql();
                            switch (ql) {
                                case CompletionEvent.STATUS_FAILURE /*1*/:
                                case CompletionEvent.STATUS_CONFLICT /*2*/:
                                case FastDatePrinter.SHORT /*3*/:
                                case ItemTouchHelper.LEFT /*4*/:
                                case DetectedActivity.TILTING /*5*/:
                                case Quest.STATE_FAILED /*6*/:
                                case DetectedActivity.WALKING /*7*/:
                                case XtraBox.MP4_XTRA_BT_UNICODE /*8*/:
                                case C0811R.styleable.WalletFragmentStyle_maskedWalletDetailsLogoTextColor /*9*/:
                                case C0811R.styleable.WalletFragmentStyle_maskedWalletDetailsLogoImageType /*10*/:
                                case C0811R.styleable.MapAttrs_uiZoomGestures /*11*/:
                                case C0811R.styleable.MapAttrs_useViewLifecycle /*12*/:
                                case C0811R.styleable.MapAttrs_zOrderOnTop /*13*/:
                                case NalUnitTypes.NAL_TYPE_RSV_VCL_N14 /*14*/:
                                case NalUnitTypes.NAL_TYPE_RSV_VCL_R15 /*15*/:
                                case ItemTouchHelper.START /*16*/:
                                case NalUnitTypes.NAL_TYPE_BLA_W_RADL /*17*/:
                                    qi = b + 1;
                                    obj2[b] = ql;
                                    break;
                                default:
                                    qi = b;
                                    break;
                            }
                            i++;
                            b = qi;
                        }
                        if (b != 0) {
                            qi = this.gE == null ? 0 : this.gE.length;
                            if (qi != 0 || b != obj2.length) {
                                Object obj3 = new int[(qi + b)];
                                if (qi != 0) {
                                    System.arraycopy(this.gE, 0, obj3, 0, qi);
                                }
                                System.arraycopy(obj2, 0, obj3, qi, b);
                                this.gE = obj3;
                                break;
                            }
                            this.gE = obj2;
                            break;
                        }
                        continue;
                    case 82:
                        i = pfVar.gp(pfVar.qp());
                        b = pfVar.getPosition();
                        qi = 0;
                        while (pfVar.qu() > 0) {
                            switch (pfVar.ql()) {
                                case CompletionEvent.STATUS_FAILURE /*1*/:
                                case CompletionEvent.STATUS_CONFLICT /*2*/:
                                case FastDatePrinter.SHORT /*3*/:
                                case ItemTouchHelper.LEFT /*4*/:
                                case DetectedActivity.TILTING /*5*/:
                                case Quest.STATE_FAILED /*6*/:
                                case DetectedActivity.WALKING /*7*/:
                                case XtraBox.MP4_XTRA_BT_UNICODE /*8*/:
                                case C0811R.styleable.WalletFragmentStyle_maskedWalletDetailsLogoTextColor /*9*/:
                                case C0811R.styleable.WalletFragmentStyle_maskedWalletDetailsLogoImageType /*10*/:
                                case C0811R.styleable.MapAttrs_uiZoomGestures /*11*/:
                                case C0811R.styleable.MapAttrs_useViewLifecycle /*12*/:
                                case C0811R.styleable.MapAttrs_zOrderOnTop /*13*/:
                                case NalUnitTypes.NAL_TYPE_RSV_VCL_N14 /*14*/:
                                case NalUnitTypes.NAL_TYPE_RSV_VCL_R15 /*15*/:
                                case ItemTouchHelper.START /*16*/:
                                case NalUnitTypes.NAL_TYPE_BLA_W_RADL /*17*/:
                                    qi++;
                                    break;
                                default:
                                    break;
                            }
                        }
                        if (qi != 0) {
                            pfVar.gr(b);
                            b = this.gE == null ? 0 : this.gE.length;
                            Object obj4 = new int[(qi + b)];
                            if (b != 0) {
                                System.arraycopy(this.gE, 0, obj4, 0, b);
                            }
                            while (pfVar.qu() > 0) {
                                int ql2 = pfVar.ql();
                                switch (ql2) {
                                    case CompletionEvent.STATUS_FAILURE /*1*/:
                                    case CompletionEvent.STATUS_CONFLICT /*2*/:
                                    case FastDatePrinter.SHORT /*3*/:
                                    case ItemTouchHelper.LEFT /*4*/:
                                    case DetectedActivity.TILTING /*5*/:
                                    case Quest.STATE_FAILED /*6*/:
                                    case DetectedActivity.WALKING /*7*/:
                                    case XtraBox.MP4_XTRA_BT_UNICODE /*8*/:
                                    case C0811R.styleable.WalletFragmentStyle_maskedWalletDetailsLogoTextColor /*9*/:
                                    case C0811R.styleable.WalletFragmentStyle_maskedWalletDetailsLogoImageType /*10*/:
                                    case C0811R.styleable.MapAttrs_uiZoomGestures /*11*/:
                                    case C0811R.styleable.MapAttrs_useViewLifecycle /*12*/:
                                    case C0811R.styleable.MapAttrs_zOrderOnTop /*13*/:
                                    case NalUnitTypes.NAL_TYPE_RSV_VCL_N14 /*14*/:
                                    case NalUnitTypes.NAL_TYPE_RSV_VCL_R15 /*15*/:
                                    case ItemTouchHelper.START /*16*/:
                                    case NalUnitTypes.NAL_TYPE_BLA_W_RADL /*17*/:
                                        qi = b + 1;
                                        obj4[b] = ql2;
                                        b = qi;
                                        break;
                                    default:
                                        break;
                                }
                            }
                            this.gE = obj4;
                        }
                        pfVar.gq(i);
                        continue;
                    case AdSize.LARGE_AD_HEIGHT /*90*/:
                        b = pq.m1847b(pfVar, 90);
                        qi = this.gD == null ? 0 : this.gD.length;
                        obj = new C2468a[(b + qi)];
                        if (qi != 0) {
                            System.arraycopy(this.gD, 0, obj, 0, qi);
                        }
                        while (qi < obj.length - 1) {
                            obj[qi] = new C2468a();
                            pfVar.m1766a(obj[qi]);
                            pfVar.qi();
                            qi++;
                        }
                        obj[qi] = new C2468a();
                        pfVar.m1766a(obj[qi]);
                        this.gD = obj;
                        continue;
                    case 96:
                        this.gC = pfVar.qm();
                        continue;
                    default:
                        if (!m3436a(pfVar, qi)) {
                            break;
                        }
                        continue;
                }
                return this;
            }
        }

        public C2468a m4220s() {
            this.type = 1;
            this.gv = BuildConfig.FLAVOR;
            this.gw = C2468a.m4215r();
            this.gx = C2468a.m4215r();
            this.gy = C2468a.m4215r();
            this.gz = BuildConfig.FLAVOR;
            this.gA = BuildConfig.FLAVOR;
            this.gB = 0;
            this.gC = false;
            this.gD = C2468a.m4215r();
            this.gE = pq.awW;
            this.gF = false;
            this.awJ = null;
            this.awU = -1;
            return this;
        }
    }
}
