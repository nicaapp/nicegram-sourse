package com.google.android.gms.internal;

import android.os.Parcel;
import android.os.Parcelable.Creator;
import com.google.android.gms.common.internal.safeparcel.C0242a;
import com.google.android.gms.common.internal.safeparcel.C0242a.C0241a;
import com.google.android.gms.common.internal.safeparcel.C0243b;
import com.google.android.gms.drive.events.CompletionEvent;
import org.telegram.android.time.FastDatePrinter;

/* renamed from: com.google.android.gms.internal.y */
public class C0561y implements Creator<C1953x> {
    static void m1879a(C1953x c1953x, Parcel parcel, int i) {
        int D = C0243b.m329D(parcel);
        C0243b.m356c(parcel, 1, c1953x.versionCode);
        C0243b.m347a(parcel, 2, c1953x.lX);
        C0243b.m347a(parcel, 3, c1953x.mh);
        C0243b.m332H(parcel, D);
    }

    public C1953x m1880a(Parcel parcel) {
        boolean z = false;
        int C = C0242a.m293C(parcel);
        boolean z2 = false;
        int i = 0;
        while (parcel.dataPosition() < C) {
            int B = C0242a.m291B(parcel);
            switch (C0242a.aD(B)) {
                case CompletionEvent.STATUS_FAILURE /*1*/:
                    i = C0242a.m309g(parcel, B);
                    break;
                case CompletionEvent.STATUS_CONFLICT /*2*/:
                    z2 = C0242a.m305c(parcel, B);
                    break;
                case FastDatePrinter.SHORT /*3*/:
                    z = C0242a.m305c(parcel, B);
                    break;
                default:
                    C0242a.m302b(parcel, B);
                    break;
            }
        }
        if (parcel.dataPosition() == C) {
            return new C1953x(i, z2, z);
        }
        throw new C0241a("Overread allowed size end=" + C, parcel);
    }

    public C1953x[] m1881b(int i) {
        return new C1953x[i];
    }

    public /* synthetic */ Object createFromParcel(Parcel x0) {
        return m1880a(x0);
    }

    public /* synthetic */ Object[] newArray(int x0) {
        return m1881b(x0);
    }
}
