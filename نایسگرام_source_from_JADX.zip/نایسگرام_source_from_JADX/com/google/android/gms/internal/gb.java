package com.google.android.gms.internal;

import android.app.Activity;
import android.app.Application;
import android.content.Context;
import android.content.res.Resources;
import android.os.Bundle;
import com.google.android.c2dm.C2DMessaging;
import com.google.android.gms.common.GooglePlayServicesUtil;
import com.google.android.gms.internal.cf.C0440b;
import java.math.BigInteger;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Iterator;
import java.util.LinkedList;

@ez
public class gb implements C0440b {
    private static final gb vJ;
    public static final String vK;
    private Context mContext;
    private final Object mw;
    private am nu;
    private al nv;
    private ey nw;
    private gt qs;
    private boolean uH;
    private boolean uI;
    public final String vL;
    private final gc vM;
    private BigInteger vN;
    private final HashSet<ga> vO;
    private final HashMap<String, ge> vP;
    private boolean vQ;
    private boolean vR;
    private an vS;
    private LinkedList<Thread> vT;
    private boolean vU;
    private Bundle vV;
    private String vW;

    static {
        vJ = new gb();
        vK = vJ.vL;
    }

    private gb() {
        this.mw = new Object();
        this.vN = BigInteger.ONE;
        this.vO = new HashSet();
        this.vP = new HashMap();
        this.vQ = false;
        this.uH = true;
        this.vR = false;
        this.uI = true;
        this.nu = null;
        this.vS = null;
        this.nv = null;
        this.vT = new LinkedList();
        this.vU = false;
        this.vV = bn.bs();
        this.nw = null;
        this.vL = gj.m1378do();
        this.vM = new gc(this.vL);
    }

    public static Bundle m3189a(Context context, gd gdVar, String str) {
        return vJ.m3199b(context, gdVar, str);
    }

    public static void m3190a(Context context, gt gtVar) {
        vJ.m3200b(context, gtVar);
    }

    public static void m3191a(Context context, boolean z) {
        vJ.m3201b(context, z);
    }

    public static void m3192b(HashSet<ga> hashSet) {
        vJ.m3202c(hashSet);
    }

    public static Bundle bD() {
        return vJ.dg();
    }

    public static String m3193c(int i, String str) {
        return vJ.m3203d(i, str);
    }

    public static gb cU() {
        return vJ;
    }

    public static String cW() {
        return vJ.cX();
    }

    public static gc cY() {
        return vJ.cZ();
    }

    public static boolean da() {
        return vJ.db();
    }

    public static boolean dc() {
        return vJ.dd();
    }

    public static String de() {
        return vJ.df();
    }

    public static void m3194e(Throwable th) {
        vJ.m3204f(th);
    }

    public void m3195a(Bundle bundle) {
        synchronized (this.mw) {
            this.vU = true;
            this.vV = bundle;
            while (!this.vT.isEmpty()) {
                ey.m1250a(this.mContext, (Thread) this.vT.remove(0), this.qs);
            }
        }
    }

    public void m3196a(ga gaVar) {
        synchronized (this.mw) {
            this.vO.add(gaVar);
        }
    }

    public void m3197a(String str, ge geVar) {
        synchronized (this.mw) {
            this.vP.put(str, geVar);
        }
    }

    public void m3198a(Thread thread) {
        synchronized (this.mw) {
            if (this.vU) {
                ey.m1250a(this.mContext, thread, this.qs);
            } else {
                this.vT.add(thread);
            }
        }
    }

    public Bundle m3199b(Context context, gd gdVar, String str) {
        Bundle bundle;
        synchronized (this.mw) {
            bundle = new Bundle();
            bundle.putBundle(C2DMessaging.EXTRA_APPLICATION_PENDING_INTENT, this.vM.m1343b(context, str));
            Bundle bundle2 = new Bundle();
            for (String str2 : this.vP.keySet()) {
                bundle2.putBundle(str2, ((ge) this.vP.get(str2)).toBundle());
            }
            bundle.putBundle("slots", bundle2);
            ArrayList arrayList = new ArrayList();
            Iterator it = this.vO.iterator();
            while (it.hasNext()) {
                arrayList.add(((ga) it.next()).toBundle());
            }
            bundle.putParcelableArrayList("ads", arrayList);
            gdVar.m1345a(this.vO);
            this.vO.clear();
        }
        return bundle;
    }

    public void m3200b(Context context, gt gtVar) {
        synchronized (this.mw) {
            if (!this.vR) {
                this.mContext = context.getApplicationContext();
                this.qs = gtVar;
                this.uH = gh.m1352o(context);
                iv.m1549H(context);
                cf.m1166a(context, this);
                m3198a(Thread.currentThread());
                this.vW = gj.m1374c(context, gtVar.wD);
                this.vR = true;
            }
        }
    }

    public void m3201b(Context context, boolean z) {
        synchronized (this.mw) {
            if (z != this.uH) {
                this.uH = z;
                gh.m1350a(context, z);
            }
        }
    }

    public void m3202c(HashSet<ga> hashSet) {
        synchronized (this.mw) {
            this.vO.addAll(hashSet);
        }
    }

    public boolean cV() {
        boolean z;
        synchronized (this.mw) {
            z = this.uI;
        }
        return z;
    }

    public String cX() {
        String bigInteger;
        synchronized (this.mw) {
            bigInteger = this.vN.toString();
            this.vN = this.vN.add(BigInteger.ONE);
        }
        return bigInteger;
    }

    public gc cZ() {
        gc gcVar;
        synchronized (this.mw) {
            gcVar = this.vM;
        }
        return gcVar;
    }

    public String m3203d(int i, String str) {
        Resources resources = this.qs.wG ? this.mContext.getResources() : GooglePlayServicesUtil.getRemoteResource(this.mContext);
        return resources == null ? str : resources.getString(i);
    }

    public boolean db() {
        boolean z;
        synchronized (this.mw) {
            z = this.vQ;
            this.vQ = true;
        }
        return z;
    }

    public boolean dd() {
        boolean z;
        synchronized (this.mw) {
            z = this.uH;
        }
        return z;
    }

    public String df() {
        String str;
        synchronized (this.mw) {
            str = this.vW;
        }
        return str;
    }

    public Bundle dg() {
        Bundle bundle;
        synchronized (this.mw) {
            bundle = this.vV;
        }
        return bundle;
    }

    public void m3204f(Throwable th) {
        if (this.vR) {
            new ey(this.mContext, this.qs, null, null).m1256b(th);
        }
    }

    public an m3205l(Context context) {
        an anVar = null;
        if (bD().getBoolean(bn.pd.getKey(), false) && kc.hE() && !cV()) {
            synchronized (this.mw) {
                if (this.nu == null) {
                    if (context instanceof Activity) {
                        this.nu = new am((Application) context.getApplicationContext(), (Activity) context);
                    }
                }
                if (this.nv == null) {
                    this.nv = new al();
                }
                if (this.vS == null) {
                    this.vS = new an(this.nu, this.nv, this.vV, new ey(this.mContext, this.qs, null, null));
                }
                this.vS.aV();
                anVar = this.vS;
            }
        }
        return anVar;
    }

    public void m3206v(boolean z) {
        synchronized (this.mw) {
            this.uI = z;
        }
    }
}
