package com.google.android.gms.internal;

import android.content.Context;
import com.google.android.gms.common.GooglePlayServicesUtil;
import com.google.android.gms.internal.fg.C2469a;
import com.google.android.gms.internal.fg.C2470b;

@ez
public final class ff {

    /* renamed from: com.google.android.gms.internal.ff.a */
    public interface C0485a {
        void m1275a(fk fkVar);
    }

    public static gg m1276a(Context context, fi fiVar, C0485a c0485a) {
        return fiVar.lD.wG ? m1277b(context, fiVar, c0485a) : m1278c(context, fiVar, c0485a);
    }

    private static gg m1277b(Context context, fi fiVar, C0485a c0485a) {
        gs.m1408S("Fetching ad response from local ad request service.");
        gg c2469a = new C2469a(context, fiVar, c0485a);
        c2469a.start();
        return c2469a;
    }

    private static gg m1278c(Context context, fi fiVar, C0485a c0485a) {
        gs.m1408S("Fetching ad response from remote ad request service.");
        if (GooglePlayServicesUtil.isGooglePlayServicesAvailable(context) == 0) {
            return new C2470b(context, fiVar, c0485a);
        }
        gs.m1412W("Failed to connect to remote ad request service.");
        return null;
    }
}
