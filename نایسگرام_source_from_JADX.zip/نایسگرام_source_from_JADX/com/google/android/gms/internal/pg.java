package com.google.android.gms.internal;

import android.support.v4.media.TransportMediator;
import android.support.v4.view.MotionEventCompat;
import java.io.IOException;
import java.io.UnsupportedEncodingException;
import org.telegram.android.MessagesController;

public final class pg {
    private final int awI;
    private final byte[] buffer;
    private int position;

    /* renamed from: com.google.android.gms.internal.pg.a */
    public static class C0549a extends IOException {
        C0549a(int i, int i2) {
            super("CodedOutputStream was writing to a flat byte array and ran out of space (pos " + i + " limit " + i2 + ").");
        }
    }

    private pg(byte[] bArr, int i, int i2) {
        this.buffer = bArr;
        this.position = i;
        this.awI = i + i2;
    }

    public static int m1769D(long j) {
        return m1771G(j);
    }

    public static int m1770E(long j) {
        return m1771G(m1772I(j));
    }

    public static int m1771G(long j) {
        return (-128 & j) == 0 ? 1 : (-16384 & j) == 0 ? 2 : (-2097152 & j) == 0 ? 3 : (-268435456 & j) == 0 ? 4 : (-34359738368L & j) == 0 ? 5 : (-4398046511104L & j) == 0 ? 6 : (-562949953421312L & j) == 0 ? 7 : (-72057594037927936L & j) == 0 ? 8 : (Long.MIN_VALUE & j) == 0 ? 9 : 10;
    }

    public static long m1772I(long j) {
        return (j << 1) ^ (j >> 63);
    }

    public static int m1773V(boolean z) {
        return 1;
    }

    public static int m1774b(int i, double d) {
        return gz(i) + m1786f(d);
    }

    public static int m1775b(int i, pn pnVar) {
        return (gz(i) * 2) + m1782d(pnVar);
    }

    public static int m1776b(int i, byte[] bArr) {
        return gz(i) + m1789s(bArr);
    }

    public static pg m1777b(byte[] bArr, int i, int i2) {
        return new pg(bArr, i, i2);
    }

    public static int m1778c(int i, float f) {
        return gz(i) + m1783e(f);
    }

    public static int m1779c(int i, pn pnVar) {
        return gz(i) + m1785e(pnVar);
    }

    public static int m1780c(int i, boolean z) {
        return gz(i) + m1773V(z);
    }

    public static int m1781d(int i, long j) {
        return gz(i) + m1769D(j);
    }

    public static int m1782d(pn pnVar) {
        return pnVar.qI();
    }

    public static int di(String str) {
        try {
            byte[] bytes = str.getBytes("UTF-8");
            return bytes.length + gB(bytes.length);
        } catch (UnsupportedEncodingException e) {
            throw new RuntimeException("UTF-8 not supported.");
        }
    }

    public static int m1783e(float f) {
        return 4;
    }

    public static int m1784e(int i, long j) {
        return gz(i) + m1770E(j);
    }

    public static int m1785e(pn pnVar) {
        int qI = pnVar.qI();
        return qI + gB(qI);
    }

    public static int m1786f(double d) {
        return 8;
    }

    public static int gB(int i) {
        return (i & -128) == 0 ? 1 : (i & -16384) == 0 ? 2 : (-2097152 & i) == 0 ? 3 : (-268435456 & i) == 0 ? 4 : 5;
    }

    public static int gD(int i) {
        return (i << 1) ^ (i >> 31);
    }

    public static int gw(int i) {
        return i >= 0 ? gB(i) : 10;
    }

    public static int gx(int i) {
        return gB(gD(i));
    }

    public static int gz(int i) {
        return gB(pq.m1848x(i, 0));
    }

    public static int m1787j(int i, String str) {
        return gz(i) + di(str);
    }

    public static pg m1788q(byte[] bArr) {
        return m1777b(bArr, 0, bArr.length);
    }

    public static int m1789s(byte[] bArr) {
        return gB(bArr.length) + bArr.length;
    }

    public static int m1790u(int i, int i2) {
        return gz(i) + gw(i2);
    }

    public static int m1791v(int i, int i2) {
        return gz(i) + gx(i2);
    }

    public void m1792B(long j) throws IOException {
        m1794F(j);
    }

    public void m1793C(long j) throws IOException {
        m1794F(m1772I(j));
    }

    public void m1794F(long j) throws IOException {
        while ((-128 & j) != 0) {
            gy((((int) j) & TransportMediator.KEYCODE_MEDIA_PAUSE) | MessagesController.UPDATE_MASK_USER_PHONE);
            j >>>= 7;
        }
        gy((int) j);
    }

    public void m1795H(long j) throws IOException {
        gy(((int) j) & MotionEventCompat.ACTION_MASK);
        gy(((int) (j >> 8)) & MotionEventCompat.ACTION_MASK);
        gy(((int) (j >> 16)) & MotionEventCompat.ACTION_MASK);
        gy(((int) (j >> 24)) & MotionEventCompat.ACTION_MASK);
        gy(((int) (j >> 32)) & MotionEventCompat.ACTION_MASK);
        gy(((int) (j >> 40)) & MotionEventCompat.ACTION_MASK);
        gy(((int) (j >> 48)) & MotionEventCompat.ACTION_MASK);
        gy(((int) (j >> 56)) & MotionEventCompat.ACTION_MASK);
    }

    public void m1796U(boolean z) throws IOException {
        gy(z ? 1 : 0);
    }

    public void m1797a(int i, double d) throws IOException {
        m1815w(i, 1);
        m1810e(d);
    }

    public void m1798a(int i, pn pnVar) throws IOException {
        m1815w(i, 2);
        m1807c(pnVar);
    }

    public void m1799a(int i, byte[] bArr) throws IOException {
        m1815w(i, 2);
        m1811r(bArr);
    }

    public void m1800b(byte b) throws IOException {
        if (this.position == this.awI) {
            throw new C0549a(this.position, this.awI);
        }
        byte[] bArr = this.buffer;
        int i = this.position;
        this.position = i + 1;
        bArr[i] = b;
    }

    public void m1801b(int i, float f) throws IOException {
        m1815w(i, 5);
        m1809d(f);
    }

    public void m1802b(int i, long j) throws IOException {
        m1815w(i, 0);
        m1792B(j);
    }

    public void m1803b(int i, String str) throws IOException {
        m1815w(i, 2);
        dh(str);
    }

    public void m1804b(int i, boolean z) throws IOException {
        m1815w(i, 0);
        m1796U(z);
    }

    public void m1805b(pn pnVar) throws IOException {
        pnVar.m1839a(this);
    }

    public void m1806c(int i, long j) throws IOException {
        m1815w(i, 0);
        m1793C(j);
    }

    public void m1807c(pn pnVar) throws IOException {
        gA(pnVar.qH());
        pnVar.m1839a(this);
    }

    public void m1808c(byte[] bArr, int i, int i2) throws IOException {
        if (this.awI - this.position >= i2) {
            System.arraycopy(bArr, i, this.buffer, this.position, i2);
            this.position += i2;
            return;
        }
        throw new C0549a(this.position, this.awI);
    }

    public void m1809d(float f) throws IOException {
        gC(Float.floatToIntBits(f));
    }

    public void dh(String str) throws IOException {
        byte[] bytes = str.getBytes("UTF-8");
        gA(bytes.length);
        m1814t(bytes);
    }

    public void m1810e(double d) throws IOException {
        m1795H(Double.doubleToLongBits(d));
    }

    public void gA(int i) throws IOException {
        while ((i & -128) != 0) {
            gy((i & TransportMediator.KEYCODE_MEDIA_PAUSE) | MessagesController.UPDATE_MASK_USER_PHONE);
            i >>>= 7;
        }
        gy(i);
    }

    public void gC(int i) throws IOException {
        gy(i & MotionEventCompat.ACTION_MASK);
        gy((i >> 8) & MotionEventCompat.ACTION_MASK);
        gy((i >> 16) & MotionEventCompat.ACTION_MASK);
        gy((i >> 24) & MotionEventCompat.ACTION_MASK);
    }

    public void gu(int i) throws IOException {
        if (i >= 0) {
            gA(i);
        } else {
            m1794F((long) i);
        }
    }

    public void gv(int i) throws IOException {
        gA(gD(i));
    }

    public void gy(int i) throws IOException {
        m1800b((byte) i);
    }

    public int qx() {
        return this.awI - this.position;
    }

    public void qy() {
        if (qx() != 0) {
            throw new IllegalStateException("Did not write as much data as expected.");
        }
    }

    public void m1811r(byte[] bArr) throws IOException {
        gA(bArr.length);
        m1814t(bArr);
    }

    public void m1812s(int i, int i2) throws IOException {
        m1815w(i, 0);
        gu(i2);
    }

    public void m1813t(int i, int i2) throws IOException {
        m1815w(i, 0);
        gv(i2);
    }

    public void m1814t(byte[] bArr) throws IOException {
        m1808c(bArr, 0, bArr.length);
    }

    public void m1815w(int i, int i2) throws IOException {
        gA(pq.m1848x(i, i2));
    }
}
