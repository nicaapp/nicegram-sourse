package com.google.android.gms.internal;

import java.util.Map;

@ez
public final class bv implements by {
    private final bw pz;

    public bv(bw bwVar) {
        this.pz = bwVar;
    }

    public void m3061a(gv gvVar, Map<String, String> map) {
        String str = (String) map.get("name");
        if (str == null) {
            gs.m1412W("App event with no name parameter.");
        } else {
            this.pz.onAppEvent(str, (String) map.get("info"));
        }
    }
}
