package com.google.android.gms.internal;

import android.graphics.drawable.Drawable;
import com.google.android.gms.common.internal.C0237n;

public final class iz extends ja<C0531a, Drawable> {

    /* renamed from: com.google.android.gms.internal.iz.a */
    public static final class C0531a {
        public final int Lp;
        public final int Lq;

        public C0531a(int i, int i2) {
            this.Lp = i;
            this.Lq = i2;
        }

        public boolean equals(Object obj) {
            if (!(obj instanceof C0531a)) {
                return false;
            }
            if (this == obj) {
                return true;
            }
            C0531a c0531a = (C0531a) obj;
            return c0531a.Lp == this.Lp && c0531a.Lq == this.Lq;
        }

        public int hashCode() {
            return C0237n.hashCode(Integer.valueOf(this.Lp), Integer.valueOf(this.Lq));
        }
    }

    public iz() {
        super(10);
    }
}
