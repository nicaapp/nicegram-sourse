package com.google.android.gms.internal;

import android.content.Context;

public class lp {
    private final String Dd;
    private final me<lx> Dh;
    private final String IM;
    private lq aeA;
    private final Context mContext;

    private lp(Context context, String str, String str2, me<lx> meVar) {
        this.mContext = context;
        this.Dd = str;
        this.Dh = meVar;
        this.aeA = null;
        this.IM = str2;
    }

    public static lp m1657a(Context context, String str, String str2, me<lx> meVar) {
        return new lp(context, str, str2, meVar);
    }
}
