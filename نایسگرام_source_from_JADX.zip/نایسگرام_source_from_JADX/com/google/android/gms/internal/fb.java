package com.google.android.gms.internal;

import android.content.Context;
import android.os.SystemClock;
import android.text.TextUtils;
import com.google.android.gms.internal.fa.C0474a;
import com.google.android.gms.internal.ff.C0485a;
import com.google.android.gms.internal.fi.C0486a;
import com.google.android.gms.internal.fz.C0490a;
import org.json.JSONException;
import org.json.JSONObject;

@ez
public class fb extends gg implements C0485a {
    private final Context mContext;
    private final Object mw;
    private cm pR;
    private final C0474a sU;
    private final Object sV;
    private final C0486a sW;
    private final C0534k sX;
    private gg sY;
    private fk sZ;

    /* renamed from: com.google.android.gms.internal.fb.1 */
    class C04751 implements Runnable {
        final /* synthetic */ fb ta;

        C04751(fb fbVar) {
            this.ta = fbVar;
        }

        public void run() {
            this.ta.onStop();
        }
    }

    /* renamed from: com.google.android.gms.internal.fb.2 */
    class C04762 implements Runnable {
        final /* synthetic */ fb ta;
        final /* synthetic */ C0490a tb;

        C04762(fb fbVar, C0490a c0490a) {
            this.ta = fbVar;
            this.tb = c0490a;
        }

        public void run() {
            synchronized (this.ta.mw) {
                this.ta.sU.m1260a(this.tb);
            }
        }
    }

    @ez
    /* renamed from: com.google.android.gms.internal.fb.a */
    private static final class C0477a extends Exception {
        private final int tc;

        public C0477a(String str, int i) {
            super(str);
            this.tc = i;
        }

        public int getErrorCode() {
            return this.tc;
        }
    }

    public fb(Context context, C0486a c0486a, C0534k c0534k, C0474a c0474a) {
        this.sV = new Object();
        this.mw = new Object();
        this.sU = c0474a;
        this.mContext = context;
        this.sW = c0486a;
        this.sX = c0534k;
    }

    private ay m3156a(fi fiVar) throws C0477a {
        if (this.sZ.tL == null) {
            throw new C0477a("The ad response must specify one of the supported ad sizes.", 0);
        }
        String[] split = this.sZ.tL.split("x");
        if (split.length != 2) {
            throw new C0477a("Could not parse the ad size from the ad response: " + this.sZ.tL, 0);
        }
        try {
            int parseInt = Integer.parseInt(split[0]);
            int parseInt2 = Integer.parseInt(split[1]);
            for (ay ayVar : fiVar.lH.oh) {
                float f = this.mContext.getResources().getDisplayMetrics().density;
                int i = ayVar.width == -1 ? (int) (((float) ayVar.widthPixels) / f) : ayVar.width;
                int i2 = ayVar.height == -2 ? (int) (((float) ayVar.heightPixels) / f) : ayVar.height;
                if (parseInt == i && parseInt2 == i2) {
                    return new ay(ayVar, fiVar.lH.oh);
                }
            }
            throw new C0477a("The ad size from the ad response was not one of the requested sizes: " + this.sZ.tL, 0);
        } catch (NumberFormatException e) {
            throw new C0477a("Could not parse the ad size from the ad response: " + this.sZ.tL, 0);
        }
    }

    private boolean m3159c(long j) throws C0477a {
        long elapsedRealtime = 60000 - (SystemClock.elapsedRealtime() - j);
        if (elapsedRealtime <= 0) {
            return false;
        }
        try {
            this.mw.wait(elapsedRealtime);
            return true;
        } catch (InterruptedException e) {
            throw new C0477a("Ad request cancelled.", -1);
        }
    }

    private void cx() throws C0477a {
        if (this.sZ.errorCode != -3) {
            if (TextUtils.isEmpty(this.sZ.tG)) {
                throw new C0477a("No fill from ad server.", 3);
            }
            gb.m3191a(this.mContext, this.sZ.tF);
            if (this.sZ.tI) {
                try {
                    this.pR = new cm(this.sZ.tG);
                } catch (JSONException e) {
                    throw new C0477a("Could not parse mediation config: " + this.sZ.tG, 0);
                }
            }
        }
    }

    private void m3160e(long j) throws C0477a {
        while (m3159c(j)) {
            if (this.sZ != null) {
                synchronized (this.sV) {
                    this.sY = null;
                }
                if (this.sZ.errorCode != -2 && this.sZ.errorCode != -3) {
                    throw new C0477a("There was a problem getting an ad response. ErrorCode: " + this.sZ.errorCode, this.sZ.errorCode);
                }
                return;
            }
        }
        throw new C0477a("Timed out waiting for ad response.", 2);
    }

    private void m3161r(boolean z) {
        gb.cU().m3206v(z);
        an l = gb.cU().m3205l(this.mContext);
        if (l != null && !l.isAlive()) {
            gs.m1408S("start fetching content...");
            l.aV();
        }
    }

    public void m3162a(fk fkVar) {
        synchronized (this.mw) {
            gs.m1408S("Received ad response.");
            this.sZ = fkVar;
            this.mw.notify();
        }
    }

    public void co() {
        long elapsedRealtime;
        ay a;
        C0477a e;
        JSONObject jSONObject;
        synchronized (this.mw) {
            gs.m1408S("AdLoaderBackgroundTask started.");
            fi fiVar = new fi(this.sW, this.sX.m1609z().m1333a(this.mContext));
            int i = -2;
            long j = -1;
            try {
                elapsedRealtime = SystemClock.elapsedRealtime();
                gg a2 = ff.m1276a(this.mContext, fiVar, this);
                synchronized (this.sV) {
                    this.sY = a2;
                    if (this.sY == null) {
                        throw new C0477a("Could not start the ad request service.", 0);
                    }
                }
                m3160e(elapsedRealtime);
                j = SystemClock.elapsedRealtime();
                cx();
                a = fiVar.lH.oh != null ? m3156a(fiVar) : null;
                try {
                    m3161r(this.sZ.tT);
                    elapsedRealtime = j;
                } catch (C0477a e2) {
                    e = e2;
                    i = e.getErrorCode();
                    if (i == 3 || i == -1) {
                        gs.m1410U(e.getMessage());
                    } else {
                        gs.m1412W(e.getMessage());
                    }
                    if (this.sZ == null) {
                        this.sZ = new fk(i);
                    } else {
                        this.sZ = new fk(i, this.sZ.qj);
                    }
                    gr.wC.post(new C04751(this));
                    elapsedRealtime = j;
                    if (!TextUtils.isEmpty(this.sZ.tQ)) {
                        try {
                            jSONObject = new JSONObject(this.sZ.tQ);
                        } catch (Throwable e3) {
                            gs.m1414b("Error parsing the JSON for Active View.", e3);
                        }
                        gr.wC.post(new C04762(this, new C0490a(fiVar, this.sZ, this.pR, a, i, elapsedRealtime, this.sZ.tM, jSONObject)));
                    }
                    jSONObject = null;
                    gr.wC.post(new C04762(this, new C0490a(fiVar, this.sZ, this.pR, a, i, elapsedRealtime, this.sZ.tM, jSONObject)));
                }
            } catch (C0477a e4) {
                e = e4;
                a = null;
            }
            if (TextUtils.isEmpty(this.sZ.tQ)) {
                jSONObject = new JSONObject(this.sZ.tQ);
                gr.wC.post(new C04762(this, new C0490a(fiVar, this.sZ, this.pR, a, i, elapsedRealtime, this.sZ.tM, jSONObject)));
            }
            jSONObject = null;
            gr.wC.post(new C04762(this, new C0490a(fiVar, this.sZ, this.pR, a, i, elapsedRealtime, this.sZ.tM, jSONObject)));
        }
    }

    public void onStop() {
        synchronized (this.sV) {
            if (this.sY != null) {
                this.sY.cancel();
            }
        }
    }
}
