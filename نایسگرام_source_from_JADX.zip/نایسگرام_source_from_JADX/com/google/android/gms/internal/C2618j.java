package com.google.android.gms.internal;

import android.content.Context;
import com.google.android.gms.ads.identifier.AdvertisingIdClient;
import com.google.android.gms.ads.identifier.AdvertisingIdClient.Info;
import com.google.android.gms.common.GooglePlayServicesNotAvailableException;
import com.google.android.gms.internal.C2472i.C0516a;
import java.io.IOException;

/* renamed from: com.google.android.gms.internal.j */
public class C2618j extends C2472i {

    /* renamed from: com.google.android.gms.internal.j.a */
    class C0532a {
        private String kO;
        private boolean kP;
        final /* synthetic */ C2618j kQ;

        public C0532a(C2618j c2618j, String str, boolean z) {
            this.kQ = c2618j;
            this.kO = str;
            this.kP = z;
        }

        public String getId() {
            return this.kO;
        }

        public boolean isLimitAdTrackingEnabled() {
            return this.kP;
        }
    }

    protected C2618j(Context context, C0539m c0539m, C0540n c0540n) {
        super(context, c0539m, c0540n);
    }

    public static C2618j m4784a(String str, Context context) {
        C0539m c1826e = new C1826e();
        C2472i.m4259a(str, context, c1826e);
        return new C2618j(context, c1826e, new C1946p(239));
    }

    protected void m4785b(Context context) {
        super.m4270b(context);
        try {
            C0532a h = m4786h(context);
            m3217a(28, h.isLimitAdTrackingEnabled() ? 1 : 0);
            String id = h.getId();
            if (id != null) {
                m3217a(26, 5);
                m3218a(24, id);
            }
        } catch (GooglePlayServicesNotAvailableException e) {
            try {
                m3218a(24, C2472i.m4262d(context));
            } catch (IOException e2) {
            } catch (C0516a e3) {
            }
        }
    }

    C0532a m4786h(Context context) throws IOException, GooglePlayServicesNotAvailableException {
        int i = 0;
        try {
            String str;
            Info advertisingIdInfo = AdvertisingIdClient.getAdvertisingIdInfo(context);
            String id = advertisingIdInfo.getId();
            if (id == null || !id.matches("^[a-fA-F0-9]{8}-[a-fA-F0-9]{4}-[a-fA-F0-9]{4}-[a-fA-F0-9]{4}-[a-fA-F0-9]{12}$")) {
                str = id;
            } else {
                byte[] bArr = new byte[16];
                int i2 = 0;
                while (i < id.length()) {
                    if (i == 8 || i == 13 || i == 18 || i == 23) {
                        i++;
                    }
                    bArr[i2] = (byte) ((Character.digit(id.charAt(i), 16) << 4) + Character.digit(id.charAt(i + 1), 16));
                    i2++;
                    i += 2;
                }
                str = this.ky.m1689a(bArr, true);
            }
            return new C0532a(this, str, advertisingIdInfo.isLimitAdTrackingEnabled());
        } catch (Throwable e) {
            throw new IOException(e);
        } catch (Throwable e2) {
            throw new IOException(e2);
        }
    }
}
