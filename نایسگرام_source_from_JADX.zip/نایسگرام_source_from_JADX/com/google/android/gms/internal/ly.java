package com.google.android.gms.internal;

import android.app.PendingIntent;
import android.content.ContentProviderClient;
import android.content.Context;
import android.location.Location;
import android.os.Handler;
import android.os.Looper;
import android.os.Message;
import android.os.RemoteException;
import android.util.Log;
import com.google.android.gms.common.internal.C0238o;
import com.google.android.gms.drive.events.CompletionEvent;
import com.google.android.gms.location.C0563a;
import com.google.android.gms.location.C0563a.C1958a;
import com.google.android.gms.location.LocationListener;
import com.google.android.gms.location.LocationRequest;
import java.util.HashMap;

public class ly {
    private final me<lx> Dh;
    private ContentProviderClient aeR;
    private boolean aeS;
    private HashMap<LocationListener, C2491b> aeT;
    private final Context mContext;

    /* renamed from: com.google.android.gms.internal.ly.a */
    private static class C0537a extends Handler {
        private final LocationListener aeU;

        public C0537a(LocationListener locationListener) {
            this.aeU = locationListener;
        }

        public C0537a(LocationListener locationListener, Looper looper) {
            super(looper);
            this.aeU = locationListener;
        }

        public void handleMessage(Message msg) {
            switch (msg.what) {
                case CompletionEvent.STATUS_FAILURE /*1*/:
                    this.aeU.onLocationChanged(new Location((Location) msg.obj));
                default:
                    Log.e("LocationClientHelper", "unknown message in LocationHandler.handleMessage");
            }
        }
    }

    /* renamed from: com.google.android.gms.internal.ly.b */
    private static class C2491b extends C1958a {
        private Handler aeV;

        C2491b(LocationListener locationListener, Looper looper) {
            this.aeV = looper == null ? new C0537a(locationListener) : new C0537a(locationListener, looper);
        }

        public void onLocationChanged(Location location) {
            if (this.aeV == null) {
                Log.e("LocationClientHelper", "Received a location in client after calling removeLocationUpdates.");
                return;
            }
            Message obtain = Message.obtain();
            obtain.what = 1;
            obtain.obj = location;
            this.aeV.sendMessage(obtain);
        }

        public void release() {
            this.aeV = null;
        }
    }

    public ly(Context context, me<lx> meVar) {
        this.aeR = null;
        this.aeS = false;
        this.aeT = new HashMap();
        this.mContext = context;
        this.Dh = meVar;
    }

    private C2491b m1686a(LocationListener locationListener, Looper looper) {
        C2491b c2491b;
        if (looper == null) {
            C0238o.m279b(Looper.myLooper(), (Object) "Can't create handler inside thread that has not called Looper.prepare()");
        }
        synchronized (this.aeT) {
            c2491b = (C2491b) this.aeT.get(locationListener);
            if (c2491b == null) {
                c2491b = new C2491b(locationListener, looper);
            }
            this.aeT.put(locationListener, c2491b);
        }
        return c2491b;
    }

    public void m1687a(ma maVar, LocationListener locationListener, Looper looper) throws RemoteException {
        this.Dh.dJ();
        ((lx) this.Dh.gS()).m1665a(maVar, m1686a(locationListener, looper));
    }

    public void m1688b(ma maVar, PendingIntent pendingIntent) throws RemoteException {
        this.Dh.dJ();
        ((lx) this.Dh.gS()).m1664a(maVar, pendingIntent);
    }

    public Location getLastLocation() {
        this.Dh.dJ();
        try {
            return ((lx) this.Dh.gS()).bW(this.mContext.getPackageName());
        } catch (Throwable e) {
            throw new IllegalStateException(e);
        }
    }

    public void lY() {
        if (this.aeS) {
            try {
                setMockMode(false);
            } catch (Throwable e) {
                throw new IllegalStateException(e);
            }
        }
    }

    public void removeAllListeners() {
        try {
            synchronized (this.aeT) {
                for (C0563a c0563a : this.aeT.values()) {
                    if (c0563a != null) {
                        ((lx) this.Dh.gS()).m1676a(c0563a);
                    }
                }
                this.aeT.clear();
            }
        } catch (Throwable e) {
            throw new IllegalStateException(e);
        }
    }

    public void removeLocationUpdates(PendingIntent callbackIntent) throws RemoteException {
        this.Dh.dJ();
        ((lx) this.Dh.gS()).m1660a(callbackIntent);
    }

    public void removeLocationUpdates(LocationListener listener) throws RemoteException {
        this.Dh.dJ();
        C0238o.m279b((Object) listener, (Object) "Invalid null listener");
        synchronized (this.aeT) {
            C0563a c0563a = (C2491b) this.aeT.remove(listener);
            if (this.aeR != null && this.aeT.isEmpty()) {
                this.aeR.release();
                this.aeR = null;
            }
            if (c0563a != null) {
                c0563a.release();
                ((lx) this.Dh.gS()).m1676a(c0563a);
            }
        }
    }

    public void requestLocationUpdates(LocationRequest request, PendingIntent callbackIntent) throws RemoteException {
        this.Dh.dJ();
        ((lx) this.Dh.gS()).m1673a(request, callbackIntent);
    }

    public void requestLocationUpdates(LocationRequest request, LocationListener listener, Looper looper) throws RemoteException {
        this.Dh.dJ();
        ((lx) this.Dh.gS()).m1674a(request, m1686a(listener, looper));
    }

    public void setMockLocation(Location mockLocation) throws RemoteException {
        this.Dh.dJ();
        ((lx) this.Dh.gS()).setMockLocation(mockLocation);
    }

    public void setMockMode(boolean isMockMode) throws RemoteException {
        this.Dh.dJ();
        ((lx) this.Dh.gS()).setMockMode(isMockMode);
        this.aeS = isMockMode;
    }
}
