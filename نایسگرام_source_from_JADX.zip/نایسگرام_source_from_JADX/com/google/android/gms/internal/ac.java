package com.google.android.gms.internal;

public interface ac {
    void m1045a(af afVar, boolean z);
}
