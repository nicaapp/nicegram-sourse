package com.google.android.gms.internal;

import org.json.JSONObject;

public interface ah {

    /* renamed from: com.google.android.gms.internal.ah.a */
    public interface C0425a {
        void aM();
    }

    void m1062a(C0425a c0425a);

    void m1063a(C0553t c0553t, dn dnVar, bw bwVar, dq dqVar, boolean z, bz bzVar);

    void m1064a(String str, by byVar);

    void m1065a(String str, JSONObject jSONObject);

    void destroy();

    void m1066f(String str);

    void m1067g(String str);

    void pause();

    void resume();
}
