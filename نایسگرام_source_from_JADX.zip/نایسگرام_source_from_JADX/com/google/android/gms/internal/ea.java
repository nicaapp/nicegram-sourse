package com.google.android.gms.internal;

@ez
public final class ea {
    public long sA;
    public final String sB;
    public final String sC;

    public ea(long j, String str, String str2) {
        this.sA = j;
        this.sC = str;
        this.sB = str2;
    }

    public ea(String str, String str2) {
        this.sC = str;
        this.sB = str2;
    }
}
