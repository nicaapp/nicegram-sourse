package com.google.android.gms.internal;

import com.google.android.gms.internal.pd.C2511a;
import com.google.android.gms.internal.pd.C2511a.C2510a;
import com.google.android.gms.internal.pd.C2511a.C2510a.C2509a;
import com.google.android.gms.wearable.Asset;
import com.google.android.gms.wearable.DataMap;
import java.util.ArrayList;
import java.util.List;
import java.util.Set;

public final class pc {

    /* renamed from: com.google.android.gms.internal.pc.a */
    public static class C0548a {
        public final pd awb;
        public final List<Asset> awc;

        public C0548a(pd pdVar, List<Asset> list) {
            this.awb = pdVar;
            this.awc = list;
        }
    }

    private static int m1754a(String str, C2510a[] c2510aArr) {
        int i = 14;
        for (C2510a c2510a : c2510aArr) {
            if (i == 14) {
                if (c2510a.type == 9 || c2510a.type == 2 || c2510a.type == 6) {
                    i = c2510a.type;
                } else if (c2510a.type != 14) {
                    throw new IllegalArgumentException("Unexpected TypedValue type: " + c2510a.type + " for key " + str);
                }
            } else if (c2510a.type != i) {
                throw new IllegalArgumentException("The ArrayList elements should all be the same type, but ArrayList with key " + str + " contains items of type " + i + " and " + c2510a.type);
            }
        }
        return i;
    }

    static int m1755a(List<Asset> list, Asset asset) {
        list.add(asset);
        return list.size() - 1;
    }

    public static C0548a m1756a(DataMap dataMap) {
        pd pdVar = new pd();
        List arrayList = new ArrayList();
        pdVar.awd = m1761a(dataMap, arrayList);
        return new C0548a(pdVar, arrayList);
    }

    private static C2510a m1757a(List<Asset> list, Object obj) {
        C2510a c2510a = new C2510a();
        if (obj == null) {
            c2510a.type = 14;
            return c2510a;
        }
        c2510a.awh = new C2509a();
        if (obj instanceof String) {
            c2510a.type = 2;
            c2510a.awh.awj = (String) obj;
        } else if (obj instanceof Integer) {
            c2510a.type = 6;
            c2510a.awh.awn = ((Integer) obj).intValue();
        } else if (obj instanceof Long) {
            c2510a.type = 5;
            c2510a.awh.awm = ((Long) obj).longValue();
        } else if (obj instanceof Double) {
            c2510a.type = 3;
            c2510a.awh.awk = ((Double) obj).doubleValue();
        } else if (obj instanceof Float) {
            c2510a.type = 4;
            c2510a.awh.awl = ((Float) obj).floatValue();
        } else if (obj instanceof Boolean) {
            c2510a.type = 8;
            c2510a.awh.awp = ((Boolean) obj).booleanValue();
        } else if (obj instanceof Byte) {
            c2510a.type = 7;
            c2510a.awh.awo = ((Byte) obj).byteValue();
        } else if (obj instanceof byte[]) {
            c2510a.type = 1;
            c2510a.awh.awi = (byte[]) obj;
        } else if (obj instanceof String[]) {
            c2510a.type = 11;
            c2510a.awh.aws = (String[]) obj;
        } else if (obj instanceof long[]) {
            c2510a.type = 12;
            c2510a.awh.awt = (long[]) obj;
        } else if (obj instanceof float[]) {
            c2510a.type = 15;
            c2510a.awh.awu = (float[]) obj;
        } else if (obj instanceof Asset) {
            c2510a.type = 13;
            c2510a.awh.awv = (long) m1755a((List) list, (Asset) obj);
        } else if (obj instanceof DataMap) {
            c2510a.type = 9;
            DataMap dataMap = (DataMap) obj;
            Set<String> keySet = dataMap.keySet();
            C2511a[] c2511aArr = new C2511a[keySet.size()];
            r1 = 0;
            for (String str : keySet) {
                c2511aArr[r1] = new C2511a();
                c2511aArr[r1].name = str;
                c2511aArr[r1].awf = m1757a((List) list, dataMap.get(str));
                r1++;
            }
            c2510a.awh.awq = c2511aArr;
        } else if (obj instanceof ArrayList) {
            c2510a.type = 10;
            ArrayList arrayList = (ArrayList) obj;
            C2510a[] c2510aArr = new C2510a[arrayList.size()];
            Object obj2 = null;
            int size = arrayList.size();
            int i = 0;
            int i2 = 14;
            while (i < size) {
                Object obj3 = arrayList.get(i);
                C2510a a = m1757a((List) list, obj3);
                if (a.type == 14 || a.type == 2 || a.type == 6 || a.type == 9) {
                    if (i2 == 14 && a.type != 14) {
                        r1 = a.type;
                    } else if (a.type != i2) {
                        throw new IllegalArgumentException("ArrayList elements must all be of the sameclass, but this one contains a " + obj2.getClass() + " and a " + obj3.getClass());
                    } else {
                        obj3 = obj2;
                        r1 = i2;
                    }
                    c2510aArr[i] = a;
                    i++;
                    i2 = r1;
                    obj2 = obj3;
                } else {
                    throw new IllegalArgumentException("The only ArrayList element types supported by DataBundleUtil are String, Integer, Bundle, and null, but this ArrayList contains a " + obj3.getClass());
                }
            }
            c2510a.awh.awr = c2510aArr;
        } else {
            throw new RuntimeException("newFieldValueFromValue: unexpected value " + obj.getClass().getSimpleName());
        }
        return c2510a;
    }

    public static DataMap m1758a(C0548a c0548a) {
        DataMap dataMap = new DataMap();
        for (C2511a c2511a : c0548a.awb.awd) {
            m1760a(c0548a.awc, dataMap, c2511a.name, c2511a.awf);
        }
        return dataMap;
    }

    private static ArrayList m1759a(List<Asset> list, C2509a c2509a, int i) {
        ArrayList arrayList = new ArrayList(c2509a.awr.length);
        for (C2510a c2510a : c2509a.awr) {
            if (c2510a.type == 14) {
                arrayList.add(null);
            } else if (i == 9) {
                DataMap dataMap = new DataMap();
                for (C2511a c2511a : c2510a.awh.awq) {
                    m1760a(list, dataMap, c2511a.name, c2511a.awf);
                }
                arrayList.add(dataMap);
            } else if (i == 2) {
                arrayList.add(c2510a.awh.awj);
            } else if (i == 6) {
                arrayList.add(Integer.valueOf(c2510a.awh.awn));
            } else {
                throw new IllegalArgumentException("Unexpected typeOfArrayList: " + i);
            }
        }
        return arrayList;
    }

    private static void m1760a(List<Asset> list, DataMap dataMap, String str, C2510a c2510a) {
        int i = c2510a.type;
        if (i == 14) {
            dataMap.putString(str, null);
            return;
        }
        C2509a c2509a = c2510a.awh;
        if (i == 1) {
            dataMap.putByteArray(str, c2509a.awi);
        } else if (i == 11) {
            dataMap.putStringArray(str, c2509a.aws);
        } else if (i == 12) {
            dataMap.putLongArray(str, c2509a.awt);
        } else if (i == 15) {
            dataMap.putFloatArray(str, c2509a.awu);
        } else if (i == 2) {
            dataMap.putString(str, c2509a.awj);
        } else if (i == 3) {
            dataMap.putDouble(str, c2509a.awk);
        } else if (i == 4) {
            dataMap.putFloat(str, c2509a.awl);
        } else if (i == 5) {
            dataMap.putLong(str, c2509a.awm);
        } else if (i == 6) {
            dataMap.putInt(str, c2509a.awn);
        } else if (i == 7) {
            dataMap.putByte(str, (byte) c2509a.awo);
        } else if (i == 8) {
            dataMap.putBoolean(str, c2509a.awp);
        } else if (i == 13) {
            if (list == null) {
                throw new RuntimeException("populateBundle: unexpected type for: " + str);
            }
            dataMap.putAsset(str, (Asset) list.get((int) c2509a.awv));
        } else if (i == 9) {
            DataMap dataMap2 = new DataMap();
            for (C2511a c2511a : c2509a.awq) {
                m1760a(list, dataMap2, c2511a.name, c2511a.awf);
            }
            dataMap.putDataMap(str, dataMap2);
        } else if (i == 10) {
            i = m1754a(str, c2509a.awr);
            ArrayList a = m1759a(list, c2509a, i);
            if (i == 14) {
                dataMap.putStringArrayList(str, a);
            } else if (i == 9) {
                dataMap.putDataMapArrayList(str, a);
            } else if (i == 2) {
                dataMap.putStringArrayList(str, a);
            } else if (i == 6) {
                dataMap.putIntegerArrayList(str, a);
            } else {
                throw new IllegalStateException("Unexpected typeOfArrayList: " + i);
            }
        } else {
            throw new RuntimeException("populateBundle: unexpected type " + i);
        }
    }

    private static C2511a[] m1761a(DataMap dataMap, List<Asset> list) {
        Set<String> keySet = dataMap.keySet();
        C2511a[] c2511aArr = new C2511a[keySet.size()];
        int i = 0;
        for (String str : keySet) {
            Object obj = dataMap.get(str);
            c2511aArr[i] = new C2511a();
            c2511aArr[i].name = str;
            c2511aArr[i].awf = m1757a((List) list, obj);
            i++;
        }
        return c2511aArr;
    }
}
