package com.google.android.gms.internal;

import android.os.Parcel;
import com.google.android.gms.drive.events.CompletionEvent;
import com.google.android.gms.games.quest.Quest;
import com.google.android.gms.internal.ji.C1889a;
import com.google.android.gms.location.DetectedActivity;
import com.google.android.gms.plus.model.moments.ItemScope;
import com.google.android.gms.plus.model.moments.Moment;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Set;
import org.telegram.android.support.widget.helper.ItemTouchHelper;

public final class nw extends jj implements Moment {
    public static final nx CREATOR;
    private static final HashMap<String, C1889a<?, ?>> amb;
    String BL;
    final int BR;
    String amP;
    nu amX;
    nu amY;
    final Set<Integer> amc;
    String uO;

    static {
        CREATOR = new nx();
        amb = new HashMap();
        amb.put("id", C1889a.m3295l("id", 2));
        amb.put("result", C1889a.m3289a("result", 4, nu.class));
        amb.put("startDate", C1889a.m3295l("startDate", 5));
        amb.put("target", C1889a.m3289a("target", 6, nu.class));
        amb.put("type", C1889a.m3295l("type", 7));
    }

    public nw() {
        this.BR = 1;
        this.amc = new HashSet();
    }

    nw(Set<Integer> set, int i, String str, nu nuVar, String str2, nu nuVar2, String str3) {
        this.amc = set;
        this.BR = i;
        this.BL = str;
        this.amX = nuVar;
        this.amP = str2;
        this.amY = nuVar2;
        this.uO = str3;
    }

    public nw(Set<Integer> set, String str, nu nuVar, String str2, nu nuVar2, String str3) {
        this.amc = set;
        this.BR = 1;
        this.BL = str;
        this.amX = nuVar;
        this.amP = str2;
        this.amY = nuVar2;
        this.uO = str3;
    }

    protected boolean m4371a(C1889a c1889a) {
        return this.amc.contains(Integer.valueOf(c1889a.hm()));
    }

    protected Object m4372b(C1889a c1889a) {
        switch (c1889a.hm()) {
            case CompletionEvent.STATUS_CONFLICT /*2*/:
                return this.BL;
            case ItemTouchHelper.LEFT /*4*/:
                return this.amX;
            case DetectedActivity.TILTING /*5*/:
                return this.amP;
            case Quest.STATE_FAILED /*6*/:
                return this.amY;
            case DetectedActivity.WALKING /*7*/:
                return this.uO;
            default:
                throw new IllegalStateException("Unknown safe parcelable id=" + c1889a.hm());
        }
    }

    public int describeContents() {
        nx nxVar = CREATOR;
        return 0;
    }

    public boolean equals(Object obj) {
        if (!(obj instanceof nw)) {
            return false;
        }
        if (this == obj) {
            return true;
        }
        nw nwVar = (nw) obj;
        for (C1889a c1889a : amb.values()) {
            if (m4371a(c1889a)) {
                if (!nwVar.m4371a(c1889a)) {
                    return false;
                }
                if (!m4372b(c1889a).equals(nwVar.m4372b(c1889a))) {
                    return false;
                }
            } else if (nwVar.m4371a(c1889a)) {
                return false;
            }
        }
        return true;
    }

    public /* synthetic */ Object freeze() {
        return ns();
    }

    public String getId() {
        return this.BL;
    }

    public ItemScope getResult() {
        return this.amX;
    }

    public String getStartDate() {
        return this.amP;
    }

    public ItemScope getTarget() {
        return this.amY;
    }

    public String getType() {
        return this.uO;
    }

    public boolean hasId() {
        return this.amc.contains(Integer.valueOf(2));
    }

    public boolean hasResult() {
        return this.amc.contains(Integer.valueOf(4));
    }

    public boolean hasStartDate() {
        return this.amc.contains(Integer.valueOf(5));
    }

    public boolean hasTarget() {
        return this.amc.contains(Integer.valueOf(6));
    }

    public boolean hasType() {
        return this.amc.contains(Integer.valueOf(7));
    }

    public int hashCode() {
        int i = 0;
        for (C1889a c1889a : amb.values()) {
            int hashCode;
            if (m4371a(c1889a)) {
                hashCode = m4372b(c1889a).hashCode() + (i + c1889a.hm());
            } else {
                hashCode = i;
            }
            i = hashCode;
        }
        return i;
    }

    public HashMap<String, C1889a<?, ?>> hf() {
        return amb;
    }

    public boolean isDataValid() {
        return true;
    }

    public nw ns() {
        return this;
    }

    public void writeToParcel(Parcel out, int flags) {
        nx nxVar = CREATOR;
        nx.m1720a(this, out, flags);
    }
}
