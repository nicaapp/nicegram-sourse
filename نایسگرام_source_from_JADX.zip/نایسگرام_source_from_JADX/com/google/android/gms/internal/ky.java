package com.google.android.gms.internal;

import android.os.RemoteException;
import com.google.android.gms.common.api.BaseImplementation.C0191b;
import com.google.android.gms.common.api.GoogleApiClient;
import com.google.android.gms.common.api.PendingResult;
import com.google.android.gms.common.api.Result;
import com.google.android.gms.common.api.Status;
import com.google.android.gms.fitness.ConfigApi;
import com.google.android.gms.fitness.request.C1774j;
import com.google.android.gms.fitness.request.DataTypeCreateRequest;
import com.google.android.gms.fitness.result.DataTypeResult;
import com.google.android.gms.internal.kk.C2479b;
import com.google.android.gms.internal.kk.C2626a;
import com.google.android.gms.internal.kk.C2677c;
import com.google.android.gms.internal.ko.C1897a;

public class ky implements ConfigApi {

    /* renamed from: com.google.android.gms.internal.ky.a */
    private static class C2481a extends C1897a {
        private final C0191b<DataTypeResult> De;

        private C2481a(C0191b<DataTypeResult> c0191b) {
            this.De = c0191b;
        }

        public void m4332a(DataTypeResult dataTypeResult) {
            this.De.m147b(dataTypeResult);
        }
    }

    /* renamed from: com.google.android.gms.internal.ky.1 */
    class C26791 extends C2626a<DataTypeResult> {
        final /* synthetic */ DataTypeCreateRequest TE;
        final /* synthetic */ ky TF;

        C26791(ky kyVar, DataTypeCreateRequest dataTypeCreateRequest) {
            this.TF = kyVar;
            this.TE = dataTypeCreateRequest;
        }

        protected void m4951a(kk kkVar) throws RemoteException {
            kkVar.jb().m1622a(this.TE, new C2481a(null), kkVar.getContext().getPackageName());
        }

        protected /* synthetic */ Result m4952c(Status status) {
            return m4953x(status);
        }

        protected DataTypeResult m4953x(Status status) {
            return DataTypeResult.m2726F(status);
        }
    }

    /* renamed from: com.google.android.gms.internal.ky.2 */
    class C26802 extends C2626a<DataTypeResult> {
        final /* synthetic */ ky TF;
        final /* synthetic */ C1774j TG;

        C26802(ky kyVar, C1774j c1774j) {
            this.TF = kyVar;
            this.TG = c1774j;
        }

        protected void m4955a(kk kkVar) throws RemoteException {
            kkVar.jb().m1633a(this.TG, new C2481a(null), kkVar.getContext().getPackageName());
        }

        protected /* synthetic */ Result m4956c(Status status) {
            return m4957x(status);
        }

        protected DataTypeResult m4957x(Status status) {
            return DataTypeResult.m2726F(status);
        }
    }

    /* renamed from: com.google.android.gms.internal.ky.3 */
    class C28463 extends C2677c {
        final /* synthetic */ ky TF;

        C28463(ky kyVar) {
            this.TF = kyVar;
        }

        protected void m5403a(kk kkVar) throws RemoteException {
            kkVar.jb().m1640a(new C2479b(this), kkVar.getContext().getPackageName());
        }
    }

    public PendingResult<DataTypeResult> createCustomDataType(GoogleApiClient client, DataTypeCreateRequest request) {
        return client.m152b(new C26791(this, request));
    }

    public PendingResult<Status> disableFit(GoogleApiClient client) {
        return client.m152b(new C28463(this));
    }

    public PendingResult<DataTypeResult> readDataType(GoogleApiClient client, String dataTypeName) {
        return client.m150a(new C26802(this, new C1774j(dataTypeName)));
    }
}
