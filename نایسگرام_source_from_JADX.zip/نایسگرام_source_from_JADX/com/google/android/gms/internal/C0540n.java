package com.google.android.gms.internal;

import java.io.IOException;

/* renamed from: com.google.android.gms.internal.n */
interface C0540n {
    byte[] m1705A() throws IOException;

    void m1706b(int i, long j) throws IOException;

    void m1707b(int i, String str) throws IOException;

    void reset();
}
