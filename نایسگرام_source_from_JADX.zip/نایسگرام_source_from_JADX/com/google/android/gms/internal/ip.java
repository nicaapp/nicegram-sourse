package com.google.android.gms.internal;

import android.text.TextUtils;
import android.util.Log;

public class ip {
    private static boolean GX;
    private boolean GY;
    private boolean GZ;
    private String Ha;
    private final String mTag;

    static {
        GX = false;
    }

    public ip(String str) {
        this(str, fS());
    }

    public ip(String str, boolean z) {
        this.mTag = str;
        this.GY = z;
        this.GZ = false;
    }

    private String m1532e(String str, Object... objArr) {
        if (objArr.length != 0) {
            str = String.format(str, objArr);
        }
        return !TextUtils.isEmpty(this.Ha) ? this.Ha + str : str;
    }

    public static boolean fS() {
        return GX;
    }

    public void m1533a(String str, Object... objArr) {
        if (fR()) {
            Log.v(this.mTag, m1532e(str, objArr));
        }
    }

    public void m1534a(Throwable th, String str, Object... objArr) {
        if (fQ() || GX) {
            Log.d(this.mTag, m1532e(str, objArr), th);
        }
    }

    public void aK(String str) {
        String str2;
        if (TextUtils.isEmpty(str)) {
            str2 = null;
        } else {
            str2 = String.format("[%s] ", new Object[]{str});
        }
        this.Ha = str2;
    }

    public void m1535b(String str, Object... objArr) {
        if (fQ() || GX) {
            Log.d(this.mTag, m1532e(str, objArr));
        }
    }

    public void m1536c(String str, Object... objArr) {
        Log.i(this.mTag, m1532e(str, objArr));
    }

    public void m1537d(String str, Object... objArr) {
        Log.w(this.mTag, m1532e(str, objArr));
    }

    public boolean fQ() {
        return this.GY;
    }

    public boolean fR() {
        return this.GZ;
    }
}
