package com.google.android.gms.internal;

import com.google.android.gms.common.data.DataHolder;
import com.google.android.gms.internal.ic.C1878a;

public abstract class ia extends C1878a {
    public void m4272S(int i) {
    }

    public void m4273a(int i, DataHolder dataHolder) {
    }

    public void m4274a(DataHolder dataHolder) {
    }

    public void m4275e(int i, int i2) {
    }

    public void fp() {
    }
}
