package com.google.android.gms.internal;

import android.app.Activity;
import android.content.Intent;
import android.net.Uri;
import android.net.Uri.Builder;
import android.os.ParcelFileDescriptor;
import android.os.RemoteException;
import com.google.android.gms.appindexing.AppIndexApi;
import com.google.android.gms.appindexing.AppIndexApi.AppIndexingLink;
import com.google.android.gms.common.api.BaseImplementation.C0191b;
import com.google.android.gms.common.api.BaseImplementation.C2381a;
import com.google.android.gms.common.api.GoogleApiClient;
import com.google.android.gms.common.api.PendingResult;
import com.google.android.gms.common.api.Result;
import com.google.android.gms.common.api.Status;
import com.google.android.gms.internal.hu.C1871a;
import java.util.List;

public final class hz implements AppIndexApi, hu {

    /* renamed from: com.google.android.gms.internal.hz.a */
    private static abstract class C1876a<T> implements Result {
        private final Status CM;
        protected final T CN;

        public C1876a(Status status, T t) {
            this.CM = status;
            this.CN = t;
        }

        public Status getStatus() {
            return this.CM;
        }
    }

    /* renamed from: com.google.android.gms.internal.hz.b */
    static class C2471b extends C1876a<ParcelFileDescriptor> implements C1871a {
        public C2471b(Status status, ParcelFileDescriptor parcelFileDescriptor) {
            super(status, parcelFileDescriptor);
        }
    }

    /* renamed from: com.google.android.gms.internal.hz.c */
    private static abstract class C2612c<T extends Result> extends C2381a<T, hy> {
        public C2612c() {
            super(hd.BN);
        }

        protected abstract void m4778a(hv hvVar) throws RemoteException;

        protected final void m4779a(hy hyVar) throws RemoteException {
            m4778a(hyVar.fn());
        }
    }

    /* renamed from: com.google.android.gms.internal.hz.e */
    private static final class C2613e extends hx<Status> {
        public C2613e(C0191b<Status> c0191b) {
            super(c0191b);
        }

        public void m4780a(Status status) {
            this.CH.m147b(status);
        }
    }

    /* renamed from: com.google.android.gms.internal.hz.1 */
    class C26681 extends C2612c<C1871a> {

        /* renamed from: com.google.android.gms.internal.hz.1.1 */
        class C26111 extends hx<C1871a> {
            final /* synthetic */ C26681 CI;

            C26111(C26681 c26681, C0191b c0191b) {
                this.CI = c26681;
                super(c0191b);
            }

            public void m4776a(Status status, ParcelFileDescriptor parcelFileDescriptor) {
                this.CH.m147b(new C2471b(status, parcelFileDescriptor));
            }
        }

        protected void m4939a(hv hvVar) throws RemoteException {
            hvVar.m1486a(new C26111(this, this));
        }

        public C1871a m4940b(Status status) {
            return new C2471b(status, null);
        }

        public /* synthetic */ Result m4941c(Status status) {
            return m4940b(status);
        }
    }

    /* renamed from: com.google.android.gms.internal.hz.d */
    private static abstract class C2669d<T extends Result> extends C2612c<Status> {
        private C2669d() {
        }

        protected /* synthetic */ Result m4942c(Status status) {
            return m4943d(status);
        }

        protected Status m4943d(Status status) {
            return status;
        }
    }

    /* renamed from: com.google.android.gms.internal.hz.2 */
    class C28402 extends C2669d<Status> {
        final /* synthetic */ String CJ;
        final /* synthetic */ hs[] CK;
        final /* synthetic */ hz CL;

        C28402(hz hzVar, String str, hs[] hsVarArr) {
            this.CL = hzVar;
            this.CJ = str;
            this.CK = hsVarArr;
            super();
        }

        protected void m5391a(hv hvVar) throws RemoteException {
            hvVar.m1487a(new C2613e(this), this.CJ, this.CK);
        }
    }

    public static Uri m3245a(String str, Uri uri) {
        if (!"android-app".equals(uri.getScheme())) {
            throw new IllegalArgumentException("Uri scheme must be android-app: " + uri);
        } else if (str.equals(uri.getHost())) {
            List pathSegments = uri.getPathSegments();
            if (pathSegments.isEmpty() || ((String) pathSegments.get(0)).isEmpty()) {
                throw new IllegalArgumentException("Uri path must exist: " + uri);
            }
            String str2 = (String) pathSegments.get(0);
            Builder builder = new Builder();
            builder.scheme(str2);
            if (pathSegments.size() > 1) {
                builder.authority((String) pathSegments.get(1));
                for (int i = 2; i < pathSegments.size(); i++) {
                    builder.appendPath((String) pathSegments.get(i));
                }
            }
            builder.encodedQuery(uri.getEncodedQuery());
            builder.encodedFragment(uri.getEncodedFragment());
            return builder.build();
        } else {
            throw new IllegalArgumentException("Uri host must match package name: " + uri);
        }
    }

    public PendingResult<Status> m3246a(GoogleApiClient googleApiClient, hs... hsVarArr) {
        return googleApiClient.m150a(new C28402(this, ((hy) googleApiClient.m149a(hd.BN)).getContext().getPackageName(), hsVarArr));
    }

    public PendingResult<Status> view(GoogleApiClient apiClient, Activity activity, Intent viewIntent, String title, Uri webUrl, List<AppIndexingLink> outLinks) {
        return m3246a(apiClient, new hs(((hy) apiClient.m149a(hd.BN)).getContext().getPackageName(), viewIntent, title, webUrl, null, (List) outLinks));
    }

    public PendingResult<Status> view(GoogleApiClient apiClient, Activity activity, Uri appIndexingUrl, String title, Uri webUrl, List<AppIndexingLink> outLinks) {
        return view(apiClient, activity, new Intent("android.intent.action.VIEW", m3245a(((hy) apiClient.m149a(hd.BN)).getContext().getPackageName(), appIndexingUrl)), title, webUrl, (List) outLinks);
    }

    public PendingResult<Status> viewEnd(GoogleApiClient apiClient, Activity activity, Intent viewIntent) {
        hs hsVar = new hs(hs.m3228a(((hy) apiClient.m149a(hd.BN)).getContext().getPackageName(), viewIntent), System.currentTimeMillis(), 3);
        return m3246a(apiClient, hsVar);
    }

    public PendingResult<Status> viewEnd(GoogleApiClient apiClient, Activity activity, Uri appIndexingUrl) {
        return viewEnd(apiClient, activity, new Intent("android.intent.action.VIEW", m3245a(((hy) apiClient.m149a(hd.BN)).getContext().getPackageName(), appIndexingUrl)));
    }
}
