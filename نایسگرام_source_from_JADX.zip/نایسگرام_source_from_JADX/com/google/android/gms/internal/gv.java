package com.google.android.gms.internal;

import android.app.Activity;
import android.content.ActivityNotFoundException;
import android.content.Context;
import android.content.Intent;
import android.content.MutableContextWrapper;
import android.net.Uri;
import android.os.Build.VERSION;
import android.util.DisplayMetrics;
import android.view.Display;
import android.view.MotionEvent;
import android.view.View.MeasureSpec;
import android.view.WindowManager;
import android.webkit.DownloadListener;
import android.webkit.ValueCallback;
import android.webkit.WebSettings;
import android.webkit.WebView;
import com.google.android.gms.drive.DriveFile;
import java.util.HashMap;
import java.util.Map;
import org.json.JSONException;
import org.json.JSONObject;
import org.telegram.android.support.widget.LinearLayoutManager;
import org.telegram.messenger.ConnectionsManager;

@ez
public class gv extends WebView implements DownloadListener {
    private final WindowManager mG;
    private final Object mw;
    private ay qr;
    private final gt qs;
    private final C0534k sX;
    private final gw wH;
    private final C0503a wI;
    private dk wJ;
    private boolean wK;
    private boolean wL;
    private boolean wM;
    private boolean wN;

    @ez
    /* renamed from: com.google.android.gms.internal.gv.a */
    protected static class C0503a extends MutableContextWrapper {
        private Context mD;
        private Activity wO;

        public C0503a(Context context) {
            super(context);
            setBaseContext(context);
        }

        public Context dz() {
            return this.wO;
        }

        public void setBaseContext(Context base) {
            this.mD = base.getApplicationContext();
            this.wO = base instanceof Activity ? (Activity) base : null;
            super.setBaseContext(this.mD);
        }

        public void startActivity(Intent intent) {
            if (this.wO != null) {
                this.wO.startActivity(intent);
                return;
            }
            intent.setFlags(DriveFile.MODE_READ_ONLY);
            this.mD.startActivity(intent);
        }
    }

    protected gv(C0503a c0503a, ay ayVar, boolean z, boolean z2, C0534k c0534k, gt gtVar) {
        super(c0503a);
        this.mw = new Object();
        this.wI = c0503a;
        this.qr = ayVar;
        this.wK = z;
        this.sX = c0534k;
        this.qs = gtVar;
        this.mG = (WindowManager) getContext().getSystemService("window");
        setBackgroundColor(0);
        WebSettings settings = getSettings();
        settings.setJavaScriptEnabled(true);
        settings.setSavePassword(false);
        settings.setSupportMultipleWindows(true);
        settings.setJavaScriptCanOpenWindowsAutomatically(true);
        gj.m1362a((Context) c0503a, gtVar.wD, settings);
        if (VERSION.SDK_INT >= 17) {
            gp.m1400a(getContext(), settings);
        } else if (VERSION.SDK_INT >= 11) {
            gn.m1392a(getContext(), settings);
        }
        setDownloadListener(this);
        if (VERSION.SDK_INT >= 11) {
            this.wH = new gy(this, z2);
        } else {
            this.wH = new gw(this, z2);
        }
        setWebViewClient(this.wH);
        if (VERSION.SDK_INT >= 14) {
            setWebChromeClient(new gz(this));
        } else if (VERSION.SDK_INT >= 11) {
            setWebChromeClient(new gx(this));
        }
        dA();
    }

    public static gv m1421a(Context context, ay ayVar, boolean z, boolean z2, C0534k c0534k, gt gtVar) {
        return new gv(new C0503a(context), ayVar, z, z2, c0534k, gtVar);
    }

    private void dA() {
        synchronized (this.mw) {
            if (this.wK || this.qr.og) {
                if (VERSION.SDK_INT < 14) {
                    gs.m1408S("Disabling hardware acceleration on an overlay.");
                    dB();
                } else {
                    gs.m1408S("Enabling hardware acceleration on an overlay.");
                    dC();
                }
            } else if (VERSION.SDK_INT < 18) {
                gs.m1408S("Disabling hardware acceleration on an AdView.");
                dB();
            } else {
                gs.m1408S("Enabling hardware acceleration on an AdView.");
                dC();
            }
        }
    }

    private void dB() {
        synchronized (this.mw) {
            if (!this.wL && VERSION.SDK_INT >= 11) {
                gn.m1396i(this);
            }
            this.wL = true;
        }
    }

    private void dC() {
        synchronized (this.mw) {
            if (this.wL && VERSION.SDK_INT >= 11) {
                gn.m1397j(this);
            }
            this.wL = false;
        }
    }

    protected void m1422X(String str) {
        synchronized (this.mw) {
            if (isDestroyed()) {
                gs.m1412W("The webview is destroyed. Ignoring action.");
            } else {
                loadUrl(str);
            }
        }
    }

    public ay m1423Y() {
        ay ayVar;
        synchronized (this.mw) {
            ayVar = this.qr;
        }
        return ayVar;
    }

    public void m1424a(Context context, ay ayVar) {
        synchronized (this.mw) {
            this.wI.setBaseContext(context);
            this.wJ = null;
            this.qr = ayVar;
            this.wK = false;
            this.wN = false;
            gj.m1373b(this);
            loadUrl("about:blank");
            this.wH.reset();
            setOnTouchListener(null);
            setOnClickListener(null);
        }
    }

    public void m1425a(ay ayVar) {
        synchronized (this.mw) {
            this.qr = ayVar;
            requestLayout();
        }
    }

    public void m1426a(dk dkVar) {
        synchronized (this.mw) {
            this.wJ = dkVar;
        }
    }

    public void m1427a(String str, Map<String, ?> map) {
        try {
            m1429b(str, gj.m1383t((Map) map));
        } catch (JSONException e) {
            gs.m1412W("Could not convert parameters to JSON.");
        }
    }

    public void m1428a(String str, JSONObject jSONObject) {
        if (jSONObject == null) {
            jSONObject = new JSONObject();
        }
        String jSONObject2 = jSONObject.toString();
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append("javascript:" + str + "(");
        stringBuilder.append(jSONObject2);
        stringBuilder.append(");");
        m1422X(stringBuilder.toString());
    }

    public void m1429b(String str, JSONObject jSONObject) {
        if (jSONObject == null) {
            jSONObject = new JSONObject();
        }
        String jSONObject2 = jSONObject.toString();
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append("javascript:AFMA_ReceiveMessage('");
        stringBuilder.append(str);
        stringBuilder.append("'");
        stringBuilder.append(",");
        stringBuilder.append(jSONObject2);
        stringBuilder.append(");");
        gs.m1411V("Dispatching AFMA event: " + stringBuilder);
        m1422X(stringBuilder.toString());
    }

    public void bS() {
        if (du().dE()) {
            DisplayMetrics displayMetrics = new DisplayMetrics();
            Display defaultDisplay = this.mG.getDefaultDisplay();
            defaultDisplay.getMetrics(displayMetrics);
            int s = gj.m1382s(getContext());
            float f = 160.0f / ((float) displayMetrics.densityDpi);
            int round = Math.round(((float) displayMetrics.widthPixels) * f);
            try {
                m1429b("onScreenInfoChanged", new JSONObject().put("width", round).put("height", Math.round(((float) (displayMetrics.heightPixels - s)) * f)).put("density", (double) displayMetrics.density).put("rotation", defaultDisplay.getRotation()));
            } catch (Throwable e) {
                gs.m1414b("Error occured while obtaining screen information.", e);
            }
        }
    }

    public void bZ() {
        Map hashMap = new HashMap(1);
        hashMap.put("version", this.qs.wD);
        m1427a("onshow", hashMap);
    }

    public void ca() {
        Map hashMap = new HashMap(1);
        hashMap.put("version", this.qs.wD);
        m1427a("onhide", hashMap);
    }

    public void destroy() {
        synchronized (this.mw) {
            super.destroy();
            this.wM = true;
        }
    }

    public dk dt() {
        dk dkVar;
        synchronized (this.mw) {
            dkVar = this.wJ;
        }
        return dkVar;
    }

    public gw du() {
        return this.wH;
    }

    public boolean dv() {
        return this.wN;
    }

    public C0534k dw() {
        return this.sX;
    }

    public gt dx() {
        return this.qs;
    }

    public boolean dy() {
        boolean z;
        synchronized (this.mw) {
            z = this.wK;
        }
        return z;
    }

    public Context dz() {
        return this.wI.dz();
    }

    public void evaluateJavascript(String script, ValueCallback<String> resultCallback) {
        synchronized (this.mw) {
            if (isDestroyed()) {
                gs.m1412W("The webview is destroyed. Ignoring action.");
                if (resultCallback != null) {
                    resultCallback.onReceiveValue(null);
                }
                return;
            }
            super.evaluateJavascript(script, resultCallback);
        }
    }

    public boolean isDestroyed() {
        boolean z;
        synchronized (this.mw) {
            z = this.wM;
        }
        return z;
    }

    public void m1430o(boolean z) {
        synchronized (this.mw) {
            if (this.wJ != null) {
                this.wJ.m4228o(z);
            } else {
                this.wN = z;
            }
        }
    }

    public void onDownloadStart(String url, String userAgent, String contentDisposition, String mimeType, long size) {
        try {
            Intent intent = new Intent("android.intent.action.VIEW");
            intent.setDataAndType(Uri.parse(url), mimeType);
            getContext().startActivity(intent);
        } catch (ActivityNotFoundException e) {
            gs.m1408S("Couldn't find an Activity to view url/mimetype: " + url + " / " + mimeType);
        }
    }

    protected void onMeasure(int widthMeasureSpec, int heightMeasureSpec) {
        int i = ConnectionsManager.DEFAULT_DATACENTER_ID;
        synchronized (this.mw) {
            if (isInEditMode() || this.wK) {
                super.onMeasure(widthMeasureSpec, heightMeasureSpec);
                return;
            }
            int mode = MeasureSpec.getMode(widthMeasureSpec);
            int size = MeasureSpec.getSize(widthMeasureSpec);
            int mode2 = MeasureSpec.getMode(heightMeasureSpec);
            int size2 = MeasureSpec.getSize(heightMeasureSpec);
            mode = (mode == LinearLayoutManager.INVALID_OFFSET || mode == 1073741824) ? size : Integer.MAX_VALUE;
            if (mode2 == LinearLayoutManager.INVALID_OFFSET || mode2 == 1073741824) {
                i = size2;
            }
            if (this.qr.widthPixels > mode || this.qr.heightPixels > r0) {
                float f = this.wI.getResources().getDisplayMetrics().density;
                gs.m1412W("Not enough space to show ad. Needs " + ((int) (((float) this.qr.widthPixels) / f)) + "x" + ((int) (((float) this.qr.heightPixels) / f)) + " dp, but only has " + ((int) (((float) size) / f)) + "x" + ((int) (((float) size2) / f)) + " dp.");
                if (getVisibility() != 8) {
                    setVisibility(4);
                }
                setMeasuredDimension(0, 0);
            } else {
                if (getVisibility() != 8) {
                    setVisibility(0);
                }
                setMeasuredDimension(this.qr.widthPixels, this.qr.heightPixels);
            }
        }
    }

    public boolean onTouchEvent(MotionEvent event) {
        if (this.sX != null) {
            this.sX.m1606a(event);
        }
        return super.onTouchEvent(event);
    }

    public void setContext(Context context) {
        this.wI.setBaseContext(context);
    }

    public void m1431x(boolean z) {
        synchronized (this.mw) {
            this.wK = z;
            dA();
        }
    }
}
