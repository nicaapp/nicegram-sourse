package com.google.android.gms.internal;

import android.os.Parcel;
import android.os.Parcelable.Creator;
import com.google.android.gms.common.internal.safeparcel.C0242a;
import com.google.android.gms.common.internal.safeparcel.C0242a.C0241a;
import com.google.android.gms.common.internal.safeparcel.C0243b;
import com.google.android.gms.drive.events.CompletionEvent;
import com.google.android.gms.internal.nz.C2501b.C2499a;
import java.util.HashSet;
import java.util.Set;
import org.telegram.android.time.FastDatePrinter;

public class od implements Creator<C2499a> {
    static void m1727a(C2499a c2499a, Parcel parcel, int i) {
        int D = C0243b.m329D(parcel);
        Set set = c2499a.amc;
        if (set.contains(Integer.valueOf(1))) {
            C0243b.m356c(parcel, 1, c2499a.BR);
        }
        if (set.contains(Integer.valueOf(2))) {
            C0243b.m356c(parcel, 2, c2499a.any);
        }
        if (set.contains(Integer.valueOf(3))) {
            C0243b.m356c(parcel, 3, c2499a.anz);
        }
        C0243b.m332H(parcel, D);
    }

    public /* synthetic */ Object createFromParcel(Parcel x0) {
        return dg(x0);
    }

    public C2499a dg(Parcel parcel) {
        int i = 0;
        int C = C0242a.m293C(parcel);
        Set hashSet = new HashSet();
        int i2 = 0;
        int i3 = 0;
        while (parcel.dataPosition() < C) {
            int B = C0242a.m291B(parcel);
            switch (C0242a.aD(B)) {
                case CompletionEvent.STATUS_FAILURE /*1*/:
                    i3 = C0242a.m309g(parcel, B);
                    hashSet.add(Integer.valueOf(1));
                    break;
                case CompletionEvent.STATUS_CONFLICT /*2*/:
                    i2 = C0242a.m309g(parcel, B);
                    hashSet.add(Integer.valueOf(2));
                    break;
                case FastDatePrinter.SHORT /*3*/:
                    i = C0242a.m309g(parcel, B);
                    hashSet.add(Integer.valueOf(3));
                    break;
                default:
                    C0242a.m302b(parcel, B);
                    break;
            }
        }
        if (parcel.dataPosition() == C) {
            return new C2499a(hashSet, i3, i2, i);
        }
        throw new C0241a("Overread allowed size end=" + C, parcel);
    }

    public C2499a[] eY(int i) {
        return new C2499a[i];
    }

    public /* synthetic */ Object[] newArray(int x0) {
        return eY(x0);
    }
}
