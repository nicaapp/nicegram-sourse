package com.google.android.gms.internal;

import android.os.IInterface;
import android.os.RemoteException;

public interface bt extends IInterface {
    void m1160a(br brVar) throws RemoteException;
}
