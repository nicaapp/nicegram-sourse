package com.google.android.gms.internal;

import android.content.Context;
import android.graphics.Color;
import android.location.Location;
import android.os.Bundle;
import android.support.v4.view.ViewCompat;
import android.text.TextUtils;
import com.google.android.gms.drive.events.CompletionEvent;
import com.google.android.gms.plus.PlusShare;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.LinkedList;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;
import org.telegram.android.time.FastDatePrinter;

@ez
public final class fs {
    private static final SimpleDateFormat up;

    static {
        up = new SimpleDateFormat("yyyyMMdd");
    }

    public static fk m1295a(Context context, fi fiVar, String str) {
        try {
            fk fkVar;
            int i;
            List list;
            List list2;
            List list3;
            JSONObject jSONObject = new JSONObject(str);
            String optString = jSONObject.optString("ad_base_url", null);
            String optString2 = jSONObject.optString("ad_url", null);
            String optString3 = jSONObject.optString("ad_size", null);
            String optString4 = jSONObject.optString("ad_html", null);
            long j = -1;
            String optString5 = jSONObject.optString("debug_dialog", null);
            long j2 = jSONObject.has("interstitial_timeout") ? (long) (jSONObject.getDouble("interstitial_timeout") * 1000.0d) : -1;
            String optString6 = jSONObject.optString("orientation", null);
            int i2 = -1;
            if ("portrait".equals(optString6)) {
                i2 = gj.dm();
            } else if ("landscape".equals(optString6)) {
                i2 = gj.dl();
            }
            if (TextUtils.isEmpty(optString4)) {
                if (TextUtils.isEmpty(optString2)) {
                    gs.m1412W("Could not parse the mediation config: Missing required ad_html or ad_url field.");
                    return new fk(0);
                }
                fk a = fr.m4246a(context, fiVar.lD.wD, optString2, null, null);
                optString = a.rP;
                optString4 = a.tG;
                j = a.tM;
                fkVar = a;
            } else if (TextUtils.isEmpty(optString)) {
                gs.m1412W("Could not parse the mediation config: Missing required ad_base_url field");
                return new fk(0);
            } else {
                fkVar = null;
            }
            JSONArray optJSONArray = jSONObject.optJSONArray("click_urls");
            List list4 = fkVar == null ? null : fkVar.qf;
            if (optJSONArray != null) {
                if (list4 == null) {
                    list4 = new LinkedList();
                }
                for (i = 0; i < optJSONArray.length(); i++) {
                    list4.add(optJSONArray.getString(i));
                }
                list = list4;
            } else {
                list = list4;
            }
            JSONArray optJSONArray2 = jSONObject.optJSONArray("impression_urls");
            list4 = fkVar == null ? null : fkVar.qg;
            if (optJSONArray2 != null) {
                if (list4 == null) {
                    list4 = new LinkedList();
                }
                for (i = 0; i < optJSONArray2.length(); i++) {
                    list4.add(optJSONArray2.getString(i));
                }
                list2 = list4;
            } else {
                list2 = list4;
            }
            JSONArray optJSONArray3 = jSONObject.optJSONArray("manual_impression_urls");
            list4 = fkVar == null ? null : fkVar.tK;
            if (optJSONArray3 != null) {
                if (list4 == null) {
                    list4 = new LinkedList();
                }
                for (i = 0; i < optJSONArray3.length(); i++) {
                    list4.add(optJSONArray3.getString(i));
                }
                list3 = list4;
            } else {
                list3 = list4;
            }
            if (fkVar != null) {
                if (fkVar.orientation != -1) {
                    i2 = fkVar.orientation;
                }
                if (fkVar.tH > 0) {
                    j2 = fkVar.tH;
                }
            }
            String optString7 = jSONObject.optString("active_view");
            String str2 = null;
            boolean optBoolean = jSONObject.optBoolean("ad_is_javascript", false);
            if (optBoolean) {
                str2 = jSONObject.optString("ad_passback_url", null);
            }
            return new fk(optString, optString4, list, list2, j2, false, -1, list3, -1, i2, optString3, j, optString5, optBoolean, str2, optString7, false, false, fiVar.tF, false);
        } catch (JSONException e) {
            gs.m1412W("Could not parse the mediation config: " + e.getMessage());
            return new fk(0);
        }
    }

    public static String m1296a(fi fiVar, fw fwVar, Location location, String str, String str2) {
        try {
            Map hashMap = new HashMap();
            Iterable arrayList = new ArrayList();
            if (!TextUtils.isEmpty(str)) {
                arrayList.add(str);
            }
            if (!TextUtils.isEmpty(str2)) {
                arrayList.add(str2);
            }
            if (arrayList.size() > 0) {
                hashMap.put("eid", TextUtils.join(",", arrayList));
            }
            if (fiVar.tw != null) {
                hashMap.put("ad_pos", fiVar.tw);
            }
            m1298a((HashMap) hashMap, fiVar.tx);
            hashMap.put("format", fiVar.lH.of);
            if (fiVar.lH.width == -1) {
                hashMap.put("smart_w", "full");
            }
            if (fiVar.lH.height == -2) {
                hashMap.put("smart_h", "auto");
            }
            if (fiVar.lH.oh != null) {
                StringBuilder stringBuilder = new StringBuilder();
                for (ay ayVar : fiVar.lH.oh) {
                    if (stringBuilder.length() != 0) {
                        stringBuilder.append("|");
                    }
                    stringBuilder.append(ayVar.width == -1 ? (int) (((float) ayVar.widthPixels) / fwVar.vi) : ayVar.width);
                    stringBuilder.append("x");
                    stringBuilder.append(ayVar.height == -2 ? (int) (((float) ayVar.heightPixels) / fwVar.vi) : ayVar.height);
                }
                hashMap.put("sz", stringBuilder);
            }
            if (fiVar.tD != 0) {
                hashMap.put("native_version", Integer.valueOf(fiVar.tD));
                hashMap.put("native_templates", fiVar.lS);
            }
            hashMap.put("slotname", fiVar.lA);
            hashMap.put("pn", fiVar.applicationInfo.packageName);
            if (fiVar.ty != null) {
                hashMap.put("vc", Integer.valueOf(fiVar.ty.versionCode));
            }
            hashMap.put("ms", fiVar.tz);
            hashMap.put("seq_num", fiVar.tA);
            hashMap.put("session_id", fiVar.tB);
            hashMap.put("js", fiVar.lD.wD);
            m1300a((HashMap) hashMap, fwVar);
            if (fiVar.tx.versionCode >= 2 && fiVar.tx.ob != null) {
                m1297a((HashMap) hashMap, fiVar.tx.ob);
            }
            if (fiVar.versionCode >= 2) {
                hashMap.put("quality_signals", fiVar.tC);
            }
            if (fiVar.versionCode >= 4 && fiVar.tF) {
                hashMap.put("forceHttps", Boolean.valueOf(fiVar.tF));
            }
            if (fiVar.versionCode >= 3 && fiVar.tE != null) {
                hashMap.put("content_info", fiVar.tE);
            }
            if (gs.m1417u(2)) {
                gs.m1411V("Ad Request JSON: " + gj.m1383t(hashMap).toString(2));
            }
            return gj.m1383t(hashMap).toString();
        } catch (JSONException e) {
            gs.m1412W("Problem serializing ad request to JSON: " + e.getMessage());
            return null;
        }
    }

    private static void m1297a(HashMap<String, Object> hashMap, Location location) {
        HashMap hashMap2 = new HashMap();
        Float valueOf = Float.valueOf(location.getAccuracy() * 1000.0f);
        Long valueOf2 = Long.valueOf(location.getTime() * 1000);
        Long valueOf3 = Long.valueOf((long) (location.getLatitude() * 1.0E7d));
        Long valueOf4 = Long.valueOf((long) (location.getLongitude() * 1.0E7d));
        hashMap2.put("radius", valueOf);
        hashMap2.put("lat", valueOf3);
        hashMap2.put("long", valueOf4);
        hashMap2.put("time", valueOf2);
        hashMap.put("uule", hashMap2);
    }

    private static void m1298a(HashMap<String, Object> hashMap, av avVar) {
        String di = gf.di();
        if (di != null) {
            hashMap.put("abf", di);
        }
        if (avVar.nT != -1) {
            hashMap.put("cust_age", up.format(new Date(avVar.nT)));
        }
        if (avVar.extras != null) {
            hashMap.put("extras", avVar.extras);
        }
        if (avVar.nU != -1) {
            hashMap.put("cust_gender", Integer.valueOf(avVar.nU));
        }
        if (avVar.nV != null) {
            hashMap.put("kw", avVar.nV);
        }
        if (avVar.nX != -1) {
            hashMap.put("tag_for_child_directed_treatment", Integer.valueOf(avVar.nX));
        }
        if (avVar.nW) {
            hashMap.put("adtest", "on");
        }
        if (avVar.versionCode >= 2) {
            if (avVar.nY) {
                hashMap.put("d_imp_hdr", Integer.valueOf(1));
            }
            if (!TextUtils.isEmpty(avVar.nZ)) {
                hashMap.put("ppid", avVar.nZ);
            }
            if (avVar.oa != null) {
                m1299a((HashMap) hashMap, avVar.oa);
            }
        }
        if (avVar.versionCode >= 3 && avVar.oc != null) {
            hashMap.put(PlusShare.KEY_CALL_TO_ACTION_URL, avVar.oc);
        }
    }

    private static void m1299a(HashMap<String, Object> hashMap, bj bjVar) {
        Object obj;
        Object obj2 = null;
        if (Color.alpha(bjVar.oH) != 0) {
            hashMap.put("acolor", m1302t(bjVar.oH));
        }
        if (Color.alpha(bjVar.backgroundColor) != 0) {
            hashMap.put("bgcolor", m1302t(bjVar.backgroundColor));
        }
        if (!(Color.alpha(bjVar.oI) == 0 || Color.alpha(bjVar.oJ) == 0)) {
            hashMap.put("gradientto", m1302t(bjVar.oI));
            hashMap.put("gradientfrom", m1302t(bjVar.oJ));
        }
        if (Color.alpha(bjVar.oK) != 0) {
            hashMap.put("bcolor", m1302t(bjVar.oK));
        }
        hashMap.put("bthick", Integer.toString(bjVar.oL));
        switch (bjVar.oM) {
            case FastDatePrinter.FULL /*0*/:
                obj = "none";
                break;
            case CompletionEvent.STATUS_FAILURE /*1*/:
                obj = "dashed";
                break;
            case CompletionEvent.STATUS_CONFLICT /*2*/:
                obj = "dotted";
                break;
            case FastDatePrinter.SHORT /*3*/:
                obj = "solid";
                break;
            default:
                obj = null;
                break;
        }
        if (obj != null) {
            hashMap.put("btype", obj);
        }
        switch (bjVar.oN) {
            case FastDatePrinter.FULL /*0*/:
                obj2 = "light";
                break;
            case CompletionEvent.STATUS_FAILURE /*1*/:
                obj2 = "medium";
                break;
            case CompletionEvent.STATUS_CONFLICT /*2*/:
                obj2 = "dark";
                break;
        }
        if (obj2 != null) {
            hashMap.put("callbuttoncolor", obj2);
        }
        if (bjVar.oO != null) {
            hashMap.put("channel", bjVar.oO);
        }
        if (Color.alpha(bjVar.oP) != 0) {
            hashMap.put("dcolor", m1302t(bjVar.oP));
        }
        if (bjVar.oQ != null) {
            hashMap.put("font", bjVar.oQ);
        }
        if (Color.alpha(bjVar.oR) != 0) {
            hashMap.put("hcolor", m1302t(bjVar.oR));
        }
        hashMap.put("headersize", Integer.toString(bjVar.oS));
        if (bjVar.oT != null) {
            hashMap.put("q", bjVar.oT);
        }
    }

    private static void m1300a(HashMap<String, Object> hashMap, fw fwVar) {
        hashMap.put("am", Integer.valueOf(fwVar.uS));
        hashMap.put("cog", m1301s(fwVar.uT));
        hashMap.put("coh", m1301s(fwVar.uU));
        if (!TextUtils.isEmpty(fwVar.uV)) {
            hashMap.put("carrier", fwVar.uV);
        }
        hashMap.put("gl", fwVar.uW);
        if (fwVar.uX) {
            hashMap.put("simulator", Integer.valueOf(1));
        }
        hashMap.put("ma", m1301s(fwVar.uY));
        hashMap.put("sp", m1301s(fwVar.uZ));
        hashMap.put("hl", fwVar.va);
        if (!TextUtils.isEmpty(fwVar.vb)) {
            hashMap.put("mv", fwVar.vb);
        }
        hashMap.put("muv", Integer.valueOf(fwVar.vc));
        if (fwVar.vd != -2) {
            hashMap.put("cnt", Integer.valueOf(fwVar.vd));
        }
        hashMap.put("gnt", Integer.valueOf(fwVar.ve));
        hashMap.put("pt", Integer.valueOf(fwVar.vf));
        hashMap.put("rm", Integer.valueOf(fwVar.vg));
        hashMap.put("riv", Integer.valueOf(fwVar.vh));
        hashMap.put("u_sd", Float.valueOf(fwVar.vi));
        hashMap.put("sh", Integer.valueOf(fwVar.vk));
        hashMap.put("sw", Integer.valueOf(fwVar.vj));
        Bundle bundle = new Bundle();
        bundle.putInt("active_network_state", fwVar.vo);
        bundle.putBoolean("active_network_metered", fwVar.vn);
        hashMap.put("connectivity", bundle);
        bundle = new Bundle();
        bundle.putBoolean("is_charging", fwVar.vm);
        bundle.putDouble("battery_level", fwVar.vl);
        hashMap.put("battery", bundle);
    }

    private static Integer m1301s(boolean z) {
        return Integer.valueOf(z ? 1 : 0);
    }

    private static String m1302t(int i) {
        return String.format(Locale.US, "#%06x", new Object[]{Integer.valueOf(ViewCompat.MEASURED_SIZE_MASK & i)});
    }
}
