package com.google.android.gms.internal;

import android.content.Context;
import android.os.Bundle;
import android.os.RemoteException;
import com.google.ads.mediation.admob.AdMobAdapter;
import com.google.android.gms.ads.C0140a;
import com.google.android.gms.ads.mediation.MediationAdapter;
import com.google.android.gms.ads.mediation.MediationBannerAdapter;
import com.google.android.gms.ads.mediation.MediationInterstitialAdapter;
import com.google.android.gms.dynamic.C0330d;
import com.google.android.gms.dynamic.C2413e;
import com.google.android.gms.internal.cu.C1818a;
import java.util.Date;
import java.util.HashSet;
import java.util.Iterator;
import org.json.JSONObject;

@ez
public final class cx extends C1818a {
    private final MediationAdapter qE;

    public cx(MediationAdapter mediationAdapter) {
        this.qE = mediationAdapter;
    }

    private Bundle m4205a(String str, int i, String str2) throws RemoteException {
        gs.m1412W("Server parameters: " + str);
        try {
            Bundle bundle = new Bundle();
            if (str != null) {
                JSONObject jSONObject = new JSONObject(str);
                Bundle bundle2 = new Bundle();
                Iterator keys = jSONObject.keys();
                while (keys.hasNext()) {
                    String str3 = (String) keys.next();
                    bundle2.putString(str3, jSONObject.getString(str3));
                }
                bundle = bundle2;
            }
            if (this.qE instanceof AdMobAdapter) {
                bundle.putString("adJson", str2);
                bundle.putInt("tagForChildDirectedTreatment", i);
            }
            return bundle;
        } catch (Throwable th) {
            gs.m1416d("Could not get Server Parameters Bundle.", th);
            RemoteException remoteException = new RemoteException();
        }
    }

    public void m4206a(C0330d c0330d, av avVar, String str, cv cvVar) throws RemoteException {
        m4207a(c0330d, avVar, str, null, cvVar);
    }

    public void m4207a(C0330d c0330d, av avVar, String str, String str2, cv cvVar) throws RemoteException {
        if (this.qE instanceof MediationInterstitialAdapter) {
            gs.m1408S("Requesting interstitial ad from adapter.");
            try {
                MediationInterstitialAdapter mediationInterstitialAdapter = (MediationInterstitialAdapter) this.qE;
                mediationInterstitialAdapter.requestInterstitialAd((Context) C2413e.m3896f(c0330d), new cy(cvVar), m4205a(str, avVar.nX, str2), new cw(new Date(avVar.nT), avVar.nU, avVar.nV != null ? new HashSet(avVar.nV) : null, avVar.ob, avVar.nW, avVar.nX), avVar.od != null ? avVar.od.getBundle(mediationInterstitialAdapter.getClass().getName()) : null);
            } catch (Throwable th) {
                gs.m1416d("Could not request interstitial ad from adapter.", th);
                RemoteException remoteException = new RemoteException();
            }
        } else {
            gs.m1412W("MediationAdapter is not a MediationInterstitialAdapter: " + this.qE.getClass().getCanonicalName());
            throw new RemoteException();
        }
    }

    public void m4208a(C0330d c0330d, ay ayVar, av avVar, String str, cv cvVar) throws RemoteException {
        m4209a(c0330d, ayVar, avVar, str, null, cvVar);
    }

    public void m4209a(C0330d c0330d, ay ayVar, av avVar, String str, String str2, cv cvVar) throws RemoteException {
        Bundle bundle = null;
        if (this.qE instanceof MediationBannerAdapter) {
            gs.m1408S("Requesting banner ad from adapter.");
            try {
                MediationBannerAdapter mediationBannerAdapter = (MediationBannerAdapter) this.qE;
                cw cwVar = new cw(new Date(avVar.nT), avVar.nU, avVar.nV != null ? new HashSet(avVar.nV) : null, avVar.ob, avVar.nW, avVar.nX);
                if (avVar.od != null) {
                    bundle = avVar.od.getBundle(mediationBannerAdapter.getClass().getName());
                }
                mediationBannerAdapter.requestBannerAd((Context) C2413e.m3896f(c0330d), new cy(cvVar), m4205a(str, avVar.nX, str2), C0140a.m13a(ayVar.width, ayVar.height, ayVar.of), cwVar, bundle);
            } catch (Throwable th) {
                gs.m1416d("Could not request banner ad from adapter.", th);
                RemoteException remoteException = new RemoteException();
            }
        } else {
            gs.m1412W("MediationAdapter is not a MediationBannerAdapter: " + this.qE.getClass().getCanonicalName());
            throw new RemoteException();
        }
    }

    public void destroy() throws RemoteException {
        try {
            this.qE.onDestroy();
        } catch (Throwable th) {
            gs.m1416d("Could not destroy adapter.", th);
            RemoteException remoteException = new RemoteException();
        }
    }

    public C0330d getView() throws RemoteException {
        if (this.qE instanceof MediationBannerAdapter) {
            try {
                return C2413e.m3897k(((MediationBannerAdapter) this.qE).getBannerView());
            } catch (Throwable th) {
                gs.m1416d("Could not get banner view from adapter.", th);
                RemoteException remoteException = new RemoteException();
            }
        } else {
            gs.m1412W("MediationAdapter is not a MediationBannerAdapter: " + this.qE.getClass().getCanonicalName());
            throw new RemoteException();
        }
    }

    public void pause() throws RemoteException {
        try {
            this.qE.onPause();
        } catch (Throwable th) {
            gs.m1416d("Could not pause adapter.", th);
            RemoteException remoteException = new RemoteException();
        }
    }

    public void resume() throws RemoteException {
        try {
            this.qE.onResume();
        } catch (Throwable th) {
            gs.m1416d("Could not resume adapter.", th);
            RemoteException remoteException = new RemoteException();
        }
    }

    public void showInterstitial() throws RemoteException {
        if (this.qE instanceof MediationInterstitialAdapter) {
            gs.m1408S("Showing interstitial from adapter.");
            try {
                ((MediationInterstitialAdapter) this.qE).showInterstitial();
            } catch (Throwable th) {
                gs.m1416d("Could not show interstitial from adapter.", th);
                RemoteException remoteException = new RemoteException();
            }
        } else {
            gs.m1412W("MediationAdapter is not a MediationInterstitialAdapter: " + this.qE.getClass().getCanonicalName());
            throw new RemoteException();
        }
    }
}
