package com.google.android.gms.internal;

import android.content.Context;
import android.location.Location;
import android.os.SystemClock;
import android.text.TextUtils;
import com.google.android.gms.internal.fm.C1858a;
import com.google.android.gms.internal.gw.C0505a;
import com.google.android.gms.location.GeofenceStatusCodes;
import java.io.BufferedOutputStream;
import java.io.IOException;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;
import java.util.List;
import java.util.Map;
import java.util.concurrent.TimeUnit;
import org.telegram.android.support.widget.helper.ItemTouchHelper.Callback;

@ez
public final class fr extends C1858a {
    private static final Object uf;
    private static fr ug;
    private final Context mContext;
    private final fx uh;
    private final ci ui;
    private final bm uj;

    /* renamed from: com.google.android.gms.internal.fr.1 */
    static class C04891 implements Runnable {
        final /* synthetic */ Context mV;
        final /* synthetic */ fi uk;
        final /* synthetic */ ft ul;
        final /* synthetic */ C0505a um;
        final /* synthetic */ String un;

        C04891(Context context, fi fiVar, ft ftVar, C0505a c0505a, String str) {
            this.mV = context;
            this.uk = fiVar;
            this.ul = ftVar;
            this.um = c0505a;
            this.un = str;
        }

        public void run() {
            gv a = gv.m1421a(this.mV, new ay(), false, false, null, this.uk.lD);
            a.setWillNotDraw(true);
            this.ul.m1306b(a);
            gw du = a.du();
            du.m1440a("/invalidRequest", this.ul.us);
            du.m1440a("/loadAdURL", this.ul.ut);
            du.m1440a("/log", bx.pG);
            du.m1437a(this.um);
            gs.m1408S("Loading the JS library.");
            a.loadUrl(this.un);
        }
    }

    /* renamed from: com.google.android.gms.internal.fr.2 */
    static class C18612 implements C0505a {
        final /* synthetic */ String uo;

        C18612(String str) {
            this.uo = str;
        }

        public void m3185a(gv gvVar) {
            String format = String.format("javascript:%s(%s);", new Object[]{"AFMA_buildAdURL", this.uo});
            gs.m1411V("About to execute: " + format);
            gvVar.loadUrl(format);
        }
    }

    static {
        uf = new Object();
    }

    fr(Context context, bm bmVar, ci ciVar, fx fxVar) {
        this.mContext = context;
        this.uh = fxVar;
        this.ui = ciVar;
        this.uj = bmVar;
    }

    private static C0505a m4244I(String str) {
        return new C18612(str);
    }

    private static fk m4245a(Context context, bm bmVar, ci ciVar, fx fxVar, fi fiVar) {
        gs.m1408S("Starting ad request from service.");
        ciVar.init();
        fw fwVar = new fw(context);
        if (fwVar.vd == -1) {
            gs.m1408S("Device is offline.");
            return new fk(2);
        }
        String string;
        ft ftVar = new ft(fiVar.applicationInfo.packageName);
        if (fiVar.tx.extras != null) {
            string = fiVar.tx.extras.getString("_ad");
            if (string != null) {
                return fs.m1295a(context, fiVar, string);
            }
        }
        Location a = ciVar.m1167a(250);
        String bp = bmVar.bp();
        String a2 = fs.m1296a(fiVar, fwVar, a, bmVar.bq(), bmVar.br());
        if (a2 == null) {
            return new fk(0);
        }
        gr.wC.post(new C04891(context, fiVar, ftVar, m4244I(a2), bp));
        try {
            fv fvVar = (fv) ftVar.cK().get(10, TimeUnit.SECONDS);
            if (fvVar == null) {
                return new fk(0);
            }
            if (fvVar.getErrorCode() != -2) {
                return new fk(fvVar.getErrorCode());
            }
            string = null;
            if (fvVar.cN()) {
                string = fxVar.m1332K(fiVar.ty.packageName);
            }
            return m4246a(context, fiVar.lD.wD, fvVar.getUrl(), string, fvVar);
        } catch (Exception e) {
            return new fk(0);
        }
    }

    public static fk m4246a(Context context, String str, String str2, String str3, fv fvVar) {
        HttpURLConnection httpURLConnection;
        try {
            int responseCode;
            fk fkVar;
            fu fuVar = new fu();
            gs.m1408S("AdRequestServiceImpl: Sending request: " + str2);
            URL url = new URL(str2);
            long elapsedRealtime = SystemClock.elapsedRealtime();
            URL url2 = url;
            int i = 0;
            while (true) {
                httpURLConnection = (HttpURLConnection) url2.openConnection();
                gj.m1365a(context, str, false, httpURLConnection);
                if (!TextUtils.isEmpty(str3)) {
                    httpURLConnection.addRequestProperty("x-afma-drt-cookie", str3);
                }
                if (!(fvVar == null || TextUtils.isEmpty(fvVar.cM()))) {
                    httpURLConnection.setDoOutput(true);
                    byte[] bytes = fvVar.cM().getBytes();
                    httpURLConnection.setFixedLengthStreamingMode(bytes.length);
                    BufferedOutputStream bufferedOutputStream = new BufferedOutputStream(httpURLConnection.getOutputStream());
                    bufferedOutputStream.write(bytes);
                    bufferedOutputStream.close();
                }
                responseCode = httpURLConnection.getResponseCode();
                Map headerFields = httpURLConnection.getHeaderFields();
                if (responseCode < Callback.DEFAULT_DRAG_ANIMATION_DURATION || responseCode >= 300) {
                    m4248a(url2.toString(), headerFields, null, responseCode);
                    if (responseCode < 300 || responseCode >= 400) {
                        break;
                    }
                    Object headerField = httpURLConnection.getHeaderField("Location");
                    if (TextUtils.isEmpty(headerField)) {
                        gs.m1412W("No location header to follow redirect.");
                        fkVar = new fk(0);
                        httpURLConnection.disconnect();
                        return fkVar;
                    }
                    url2 = new URL(headerField);
                    i++;
                    if (i > 5) {
                        gs.m1412W("Too many redirects.");
                        fkVar = new fk(0);
                        httpURLConnection.disconnect();
                        return fkVar;
                    }
                    fuVar.m1326e(headerFields);
                    httpURLConnection.disconnect();
                } else {
                    String url3 = url2.toString();
                    String a = gj.m1359a(new InputStreamReader(httpURLConnection.getInputStream()));
                    m4248a(url3, headerFields, a, responseCode);
                    fuVar.m1325a(url3, headerFields, a);
                    fkVar = fuVar.m1327i(elapsedRealtime);
                    httpURLConnection.disconnect();
                    return fkVar;
                }
            }
            gs.m1412W("Received error HTTP response code: " + responseCode);
            fkVar = new fk(0);
            httpURLConnection.disconnect();
            return fkVar;
        } catch (IOException e) {
            gs.m1412W("Error while connecting to ad server: " + e.getMessage());
            return new fk(2);
        } catch (Throwable th) {
            httpURLConnection.disconnect();
        }
    }

    public static fr m4247a(Context context, bm bmVar, ci ciVar, fx fxVar) {
        fr frVar;
        synchronized (uf) {
            if (ug == null) {
                ug = new fr(context.getApplicationContext(), bmVar, ciVar, fxVar);
            }
            frVar = ug;
        }
        return frVar;
    }

    private static void m4248a(String str, Map<String, List<String>> map, String str2, int i) {
        if (gs.m1417u(2)) {
            gs.m1411V("Http Response: {\n  URL:\n    " + str + "\n  Headers:");
            if (map != null) {
                for (String str3 : map.keySet()) {
                    gs.m1411V("    " + str3 + ":");
                    for (String str32 : (List) map.get(str32)) {
                        gs.m1411V("      " + str32);
                    }
                }
            }
            gs.m1411V("  Body:");
            if (str2 != null) {
                for (int i2 = 0; i2 < Math.min(str2.length(), 100000); i2 += GeofenceStatusCodes.GEOFENCE_NOT_AVAILABLE) {
                    gs.m1411V(str2.substring(i2, Math.min(str2.length(), i2 + GeofenceStatusCodes.GEOFENCE_NOT_AVAILABLE)));
                }
            } else {
                gs.m1411V("    null");
            }
            gs.m1411V("  Response Code:\n    " + i + "\n}");
        }
    }

    public fk m4249b(fi fiVar) {
        return m4245a(this.mContext, this.uj, this.ui, this.uh, fiVar);
    }
}
