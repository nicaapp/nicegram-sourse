package com.google.android.gms.internal;

import android.view.View;
import android.webkit.WebChromeClient.CustomViewCallback;

@ez
public final class gz extends gx {
    public gz(gv gvVar) {
        super(gvVar);
    }

    public void onShowCustomView(View view, int requestedOrientation, CustomViewCallback customViewCallback) {
        m1448a(view, requestedOrientation, customViewCallback);
    }
}
