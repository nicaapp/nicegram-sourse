package com.google.android.gms.internal;

import java.io.IOException;
import java.io.InputStream;
import java.net.HttpURLConnection;
import java.net.MalformedURLException;
import java.net.URL;
import java.util.concurrent.Callable;
import java.util.concurrent.Future;
import org.telegram.android.support.widget.helper.ItemTouchHelper.Callback;

@ez
public class go {
    public static final C0502a<Void> wy;

    /* renamed from: com.google.android.gms.internal.go.2 */
    class C05012 implements Callable<T> {
        final /* synthetic */ C0502a wA;
        final /* synthetic */ go wB;
        final /* synthetic */ String wz;

        C05012(go goVar, String str, C0502a c0502a) {
            this.wB = goVar;
            this.wz = str;
            this.wA = c0502a;
        }

        public T call() {
            Throwable th;
            Throwable th2;
            HttpURLConnection httpURLConnection = null;
            try {
                HttpURLConnection httpURLConnection2 = (HttpURLConnection) new URL(this.wz).openConnection();
                try {
                    httpURLConnection2.connect();
                    int responseCode = httpURLConnection2.getResponseCode();
                    if (responseCode < Callback.DEFAULT_DRAG_ANIMATION_DURATION || responseCode > 299) {
                        if (httpURLConnection2 != null) {
                            httpURLConnection2.disconnect();
                        }
                        return this.wA.cJ();
                    }
                    T b = this.wA.m1398b(httpURLConnection2.getInputStream());
                    if (httpURLConnection2 != null) {
                        httpURLConnection2.disconnect();
                    }
                    return b;
                } catch (Throwable e) {
                    th = e;
                    httpURLConnection = httpURLConnection2;
                    th2 = th;
                    try {
                        gs.m1416d("Error making HTTP request.", th2);
                        if (httpURLConnection != null) {
                            httpURLConnection.disconnect();
                        }
                        return this.wA.cJ();
                    } catch (Throwable th3) {
                        th2 = th3;
                        if (httpURLConnection != null) {
                            httpURLConnection.disconnect();
                        }
                        throw th2;
                    }
                } catch (Throwable e2) {
                    th = e2;
                    httpURLConnection = httpURLConnection2;
                    th2 = th;
                    gs.m1416d("Error making HTTP request.", th2);
                    if (httpURLConnection != null) {
                        httpURLConnection.disconnect();
                    }
                    return this.wA.cJ();
                } catch (Throwable e22) {
                    th = e22;
                    httpURLConnection = httpURLConnection2;
                    th2 = th;
                    if (httpURLConnection != null) {
                        httpURLConnection.disconnect();
                    }
                    throw th2;
                }
            } catch (MalformedURLException e3) {
                th2 = e3;
                gs.m1416d("Error making HTTP request.", th2);
                if (httpURLConnection != null) {
                    httpURLConnection.disconnect();
                }
                return this.wA.cJ();
            } catch (IOException e4) {
                th2 = e4;
                gs.m1416d("Error making HTTP request.", th2);
                if (httpURLConnection != null) {
                    httpURLConnection.disconnect();
                }
                return this.wA.cJ();
            }
        }
    }

    /* renamed from: com.google.android.gms.internal.go.a */
    public interface C0502a<T> {
        T m1398b(InputStream inputStream);

        T cJ();
    }

    /* renamed from: com.google.android.gms.internal.go.1 */
    static class C18641 implements C0502a {
        C18641() {
        }

        public /* synthetic */ Object m3207b(InputStream inputStream) {
            return m3208c(inputStream);
        }

        public Void m3208c(InputStream inputStream) {
            return null;
        }

        public /* synthetic */ Object cJ() {
            return dq();
        }

        public Void dq() {
            return null;
        }
    }

    static {
        wy = new C18641();
    }

    public <T> Future<T> m1399a(String str, C0502a<T> c0502a) {
        return gi.submit(new C05012(this, str, c0502a));
    }
}
