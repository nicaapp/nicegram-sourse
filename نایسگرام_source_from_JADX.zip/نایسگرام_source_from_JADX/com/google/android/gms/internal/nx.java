package com.google.android.gms.internal;

import android.os.Parcel;
import android.os.Parcelable.Creator;
import com.google.android.gms.common.internal.safeparcel.C0242a;
import com.google.android.gms.common.internal.safeparcel.C0242a.C0241a;
import com.google.android.gms.common.internal.safeparcel.C0243b;
import com.google.android.gms.drive.events.CompletionEvent;
import com.google.android.gms.games.quest.Quest;
import com.google.android.gms.location.DetectedActivity;
import java.util.HashSet;
import java.util.Set;
import org.telegram.android.support.widget.helper.ItemTouchHelper;

public class nx implements Creator<nw> {
    static void m1720a(nw nwVar, Parcel parcel, int i) {
        int D = C0243b.m329D(parcel);
        Set set = nwVar.amc;
        if (set.contains(Integer.valueOf(1))) {
            C0243b.m356c(parcel, 1, nwVar.BR);
        }
        if (set.contains(Integer.valueOf(2))) {
            C0243b.m344a(parcel, 2, nwVar.BL, true);
        }
        if (set.contains(Integer.valueOf(4))) {
            C0243b.m340a(parcel, 4, nwVar.amX, i, true);
        }
        if (set.contains(Integer.valueOf(5))) {
            C0243b.m344a(parcel, 5, nwVar.amP, true);
        }
        if (set.contains(Integer.valueOf(6))) {
            C0243b.m340a(parcel, 6, nwVar.amY, i, true);
        }
        if (set.contains(Integer.valueOf(7))) {
            C0243b.m344a(parcel, 7, nwVar.uO, true);
        }
        C0243b.m332H(parcel, D);
    }

    public /* synthetic */ Object createFromParcel(Parcel x0) {
        return dc(x0);
    }

    public nw dc(Parcel parcel) {
        String str = null;
        int C = C0242a.m293C(parcel);
        Set hashSet = new HashSet();
        int i = 0;
        nu nuVar = null;
        String str2 = null;
        nu nuVar2 = null;
        String str3 = null;
        while (parcel.dataPosition() < C) {
            int B = C0242a.m291B(parcel);
            nu nuVar3;
            switch (C0242a.aD(B)) {
                case CompletionEvent.STATUS_FAILURE /*1*/:
                    i = C0242a.m309g(parcel, B);
                    hashSet.add(Integer.valueOf(1));
                    break;
                case CompletionEvent.STATUS_CONFLICT /*2*/:
                    str3 = C0242a.m317o(parcel, B);
                    hashSet.add(Integer.valueOf(2));
                    break;
                case ItemTouchHelper.LEFT /*4*/:
                    nuVar3 = (nu) C0242a.m298a(parcel, B, nu.CREATOR);
                    hashSet.add(Integer.valueOf(4));
                    nuVar2 = nuVar3;
                    break;
                case DetectedActivity.TILTING /*5*/:
                    str2 = C0242a.m317o(parcel, B);
                    hashSet.add(Integer.valueOf(5));
                    break;
                case Quest.STATE_FAILED /*6*/:
                    nuVar3 = (nu) C0242a.m298a(parcel, B, nu.CREATOR);
                    hashSet.add(Integer.valueOf(6));
                    nuVar = nuVar3;
                    break;
                case DetectedActivity.WALKING /*7*/:
                    str = C0242a.m317o(parcel, B);
                    hashSet.add(Integer.valueOf(7));
                    break;
                default:
                    C0242a.m302b(parcel, B);
                    break;
            }
        }
        if (parcel.dataPosition() == C) {
            return new nw(hashSet, i, str3, nuVar2, str2, nuVar, str);
        }
        throw new C0241a("Overread allowed size end=" + C, parcel);
    }

    public nw[] eU(int i) {
        return new nw[i];
    }

    public /* synthetic */ Object[] newArray(int x0) {
        return eU(x0);
    }
}
