package com.google.android.gms.internal;

import com.google.android.gms.common.data.C1693a;
import com.google.android.gms.common.data.DataHolder;
import com.google.android.gms.drive.DriveId;
import com.google.android.gms.drive.metadata.C2405b;
import com.google.android.gms.drive.metadata.MetadataField;
import com.google.android.gms.drive.metadata.SearchableCollectionMetadataField;
import com.google.android.gms.drive.metadata.SearchableMetadataField;
import com.google.android.gms.drive.metadata.SortableMetadataField;
import com.google.android.gms.drive.metadata.internal.AppVisibleCustomProperties;
import com.google.android.gms.drive.metadata.internal.C2407b;
import com.google.android.gms.drive.metadata.internal.C2409g;
import com.google.android.gms.drive.metadata.internal.C2410j;
import com.google.android.gms.drive.metadata.internal.C2411l;
import com.google.android.gms.drive.metadata.internal.C2607i;
import com.google.android.gms.drive.metadata.internal.C2608k;
import com.google.android.gms.drive.metadata.internal.C2609m;
import com.google.android.gms.plus.PlusShare;
import java.util.Collection;
import java.util.Collections;

public class kd {
    public static final MetadataField<DriveId> PM;
    public static final MetadataField<String> PN;
    public static final C2670a PO;
    public static final MetadataField<String> PP;
    public static final MetadataField<String> PQ;
    public static final MetadataField<String> PR;
    public static final MetadataField<Long> PS;
    public static final MetadataField<Boolean> PT;
    public static final MetadataField<String> PU;
    public static final MetadataField<Boolean> PV;
    public static final MetadataField<Boolean> PW;
    public static final MetadataField<Boolean> PX;
    public static final C2620b PY;
    public static final MetadataField<Boolean> PZ;
    public static final MetadataField<Boolean> Qa;
    public static final MetadataField<Boolean> Qb;
    public static final MetadataField<Boolean> Qc;
    public static final C2621c Qd;
    public static final MetadataField<String> Qe;
    public static final C2405b<String> Qf;
    public static final C2609m Qg;
    public static final C2609m Qh;
    public static final C2671d Qi;
    public static final C2622e Qj;
    public static final C2623f Qk;
    public static final MetadataField<C1693a> Ql;
    public static final C2624g Qm;
    public static final C2625h Qn;
    public static final MetadataField<String> Qo;
    public static final MetadataField<String> Qp;
    public static final MetadataField<String> Qq;
    public static final C2407b Qr;
    public static final MetadataField<String> Qs;

    /* renamed from: com.google.android.gms.internal.kd.1 */
    static class C26191 extends C2410j<C1693a> {
        C26191(String str, Collection collection, Collection collection2, int i) {
            super(str, collection, collection2, i);
        }

        protected /* synthetic */ Object m4787c(DataHolder dataHolder, int i, int i2) {
            return m4788k(dataHolder, i, i2);
        }

        protected C1693a m4788k(DataHolder dataHolder, int i, int i2) {
            throw new IllegalStateException("Thumbnail field is write only");
        }
    }

    /* renamed from: com.google.android.gms.internal.kd.b */
    public static class C2620b extends C2407b implements SearchableMetadataField<Boolean> {
        public C2620b(String str, int i) {
            super(str, i);
        }
    }

    /* renamed from: com.google.android.gms.internal.kd.c */
    public static class C2621c extends C2411l implements SearchableMetadataField<String> {
        public C2621c(String str, int i) {
            super(str, i);
        }
    }

    /* renamed from: com.google.android.gms.internal.kd.e */
    public static class C2622e extends C2409g implements SortableMetadataField<Long> {
        public C2622e(String str, int i) {
            super(str, i);
        }
    }

    /* renamed from: com.google.android.gms.internal.kd.f */
    public static class C2623f extends C2407b implements SearchableMetadataField<Boolean> {
        public C2623f(String str, int i) {
            super(str, i);
        }
    }

    /* renamed from: com.google.android.gms.internal.kd.g */
    public static class C2624g extends C2411l implements SearchableMetadataField<String>, SortableMetadataField<String> {
        public C2624g(String str, int i) {
            super(str, i);
        }
    }

    /* renamed from: com.google.android.gms.internal.kd.h */
    public static class C2625h extends C2407b implements SearchableMetadataField<Boolean> {
        public C2625h(String str, int i) {
            super(str, i);
        }

        protected /* synthetic */ Object m4789c(DataHolder dataHolder, int i, int i2) {
            return m4790e(dataHolder, i, i2);
        }

        protected Boolean m4790e(DataHolder dataHolder, int i, int i2) {
            return Boolean.valueOf(dataHolder.m2427b(getName(), i, i2) != 0);
        }
    }

    /* renamed from: com.google.android.gms.internal.kd.a */
    public static class C2670a extends ke implements SearchableMetadataField<AppVisibleCustomProperties> {
        public C2670a(int i) {
            super(i);
        }
    }

    /* renamed from: com.google.android.gms.internal.kd.d */
    public static class C2671d extends C2607i<DriveId> implements SearchableCollectionMetadataField<DriveId> {
        public C2671d(String str, int i) {
            super(str, i);
        }
    }

    static {
        PM = kg.Qy;
        PN = new C2411l("alternateLink", 4300000);
        PO = new C2670a(5000000);
        PP = new C2411l(PlusShare.KEY_CONTENT_DEEP_LINK_METADATA_DESCRIPTION, 4300000);
        PQ = new C2411l("embedLink", 4300000);
        PR = new C2411l("fileExtension", 4300000);
        PS = new C2409g("fileSize", 4300000);
        PT = new C2407b("hasThumbnail", 4300000);
        PU = new C2411l("indexableText", 4300000);
        PV = new C2407b("isAppData", 4300000);
        PW = new C2407b("isCopyable", 4300000);
        PX = new C2407b("isEditable", 4100000);
        PY = new C2620b("isPinned", 4100000);
        PZ = new C2407b("isRestricted", 4300000);
        Qa = new C2407b("isShared", 4300000);
        Qb = new C2407b("isTrashable", 4400000);
        Qc = new C2407b("isViewed", 4300000);
        Qd = new C2621c("mimeType", 4100000);
        Qe = new C2411l("originalFilename", 4300000);
        Qf = new C2608k("ownerNames", 4300000);
        Qg = new C2609m("lastModifyingUser", 6000000);
        Qh = new C2609m("sharingUser", 6000000);
        Qi = new C2671d("parents", 4100000);
        Qj = new C2622e("quotaBytesUsed", 4300000);
        Qk = new C2623f("starred", 4100000);
        Ql = new C26191("thumbnail", Collections.emptySet(), Collections.emptySet(), 4400000);
        Qm = new C2624g(PlusShare.KEY_CONTENT_DEEP_LINK_METADATA_TITLE, 4100000);
        Qn = new C2625h("trashed", 4100000);
        Qo = new C2411l("webContentLink", 4300000);
        Qp = new C2411l("webViewLink", 4300000);
        Qq = new C2411l("uniqueIdentifier", 5000000);
        Qr = new C2407b("writersCanShare", 6000000);
        Qs = new C2411l("role", 6000000);
    }
}
