package com.google.android.gms.internal;

import android.os.Parcel;
import android.os.Parcelable.Creator;
import com.google.android.gms.common.internal.safeparcel.C0242a;
import com.google.android.gms.common.internal.safeparcel.C0242a.C0241a;
import com.google.android.gms.common.internal.safeparcel.C0243b;
import com.google.android.gms.drive.events.CompletionEvent;
import org.telegram.android.time.FastDatePrinter;

public class mm implements Creator<ml> {
    static void m1696a(ml mlVar, Parcel parcel, int i) {
        int D = C0243b.m329D(parcel);
        C0243b.m356c(parcel, 1, mlVar.BR);
        C0243b.m344a(parcel, 2, mlVar.mk(), false);
        C0243b.m344a(parcel, 3, mlVar.getTag(), false);
        C0243b.m332H(parcel, D);
    }

    public ml cA(Parcel parcel) {
        String str = null;
        int C = C0242a.m293C(parcel);
        int i = 0;
        String str2 = null;
        while (parcel.dataPosition() < C) {
            int B = C0242a.m291B(parcel);
            switch (C0242a.aD(B)) {
                case CompletionEvent.STATUS_FAILURE /*1*/:
                    i = C0242a.m309g(parcel, B);
                    break;
                case CompletionEvent.STATUS_CONFLICT /*2*/:
                    str2 = C0242a.m317o(parcel, B);
                    break;
                case FastDatePrinter.SHORT /*3*/:
                    str = C0242a.m317o(parcel, B);
                    break;
                default:
                    C0242a.m302b(parcel, B);
                    break;
            }
        }
        if (parcel.dataPosition() == C) {
            return new ml(i, str2, str);
        }
        throw new C0241a("Overread allowed size end=" + C, parcel);
    }

    public /* synthetic */ Object createFromParcel(Parcel x0) {
        return cA(x0);
    }

    public ml[] eq(int i) {
        return new ml[i];
    }

    public /* synthetic */ Object[] newArray(int x0) {
        return eq(x0);
    }
}
