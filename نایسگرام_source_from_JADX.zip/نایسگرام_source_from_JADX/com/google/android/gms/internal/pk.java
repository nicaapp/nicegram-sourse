package com.google.android.gms.internal;

import java.io.IOException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

class pk {
    private pi<?, ?> awQ;
    private Object awR;
    private List<pp> awS;

    pk() {
        this.awS = new ArrayList();
    }

    private byte[] toByteArray() throws IOException {
        byte[] bArr = new byte[m1834c()];
        m1831a(pg.m1788q(bArr));
        return bArr;
    }

    void m1831a(pg pgVar) throws IOException {
        if (this.awR != null) {
            this.awQ.m1823a(this.awR, pgVar);
            return;
        }
        for (pp a : this.awS) {
            a.m1845a(pgVar);
        }
    }

    void m1832a(pp ppVar) {
        this.awS.add(ppVar);
    }

    <T> T m1833b(pi<?, T> piVar) {
        if (this.awR == null) {
            this.awQ = piVar;
            this.awR = piVar.m1826l(this.awS);
            this.awS = null;
        } else if (this.awQ != piVar) {
            throw new IllegalStateException("Tried to getExtension with a differernt Extension.");
        }
        return this.awR;
    }

    int m1834c() {
        if (this.awR != null) {
            return this.awQ.m1819A(this.awR);
        }
        int i = 0;
        for (pp c : this.awS) {
            i = c.m1846c() + i;
        }
        return i;
    }

    public boolean equals(Object o) {
        if (o == this) {
            return true;
        }
        if (!(o instanceof pk)) {
            return false;
        }
        pk pkVar = (pk) o;
        if (this.awR == null || pkVar.awR == null) {
            if (this.awS != null && pkVar.awS != null) {
                return this.awS.equals(pkVar.awS);
            }
            try {
                return Arrays.equals(toByteArray(), pkVar.toByteArray());
            } catch (Throwable e) {
                throw new IllegalStateException(e);
            }
        } else if (this.awQ != pkVar.awQ) {
            return false;
        } else {
            if (!this.awQ.awK.isArray()) {
                return this.awR.equals(pkVar.awR);
            }
            if (this.awR instanceof byte[]) {
                return Arrays.equals((byte[]) this.awR, (byte[]) pkVar.awR);
            }
            if (this.awR instanceof int[]) {
                return Arrays.equals((int[]) this.awR, (int[]) pkVar.awR);
            }
            if (this.awR instanceof long[]) {
                return Arrays.equals((long[]) this.awR, (long[]) pkVar.awR);
            }
            if (this.awR instanceof float[]) {
                return Arrays.equals((float[]) this.awR, (float[]) pkVar.awR);
            }
            if (this.awR instanceof double[]) {
                return Arrays.equals((double[]) this.awR, (double[]) pkVar.awR);
            }
            return this.awR instanceof boolean[] ? Arrays.equals((boolean[]) this.awR, (boolean[]) pkVar.awR) : Arrays.deepEquals((Object[]) this.awR, (Object[]) pkVar.awR);
        }
    }

    public int hashCode() {
        try {
            return Arrays.hashCode(toByteArray()) + 527;
        } catch (Throwable e) {
            throw new IllegalStateException(e);
        }
    }
}
