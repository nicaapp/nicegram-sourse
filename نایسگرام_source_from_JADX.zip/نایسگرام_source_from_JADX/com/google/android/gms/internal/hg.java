package com.google.android.gms.internal;

import android.os.Parcel;
import com.google.android.gms.common.internal.safeparcel.SafeParcelable;

public class hg implements SafeParcelable {
    public static final hh CREATOR;
    final int BR;
    final String BZ;
    final String Ca;
    final String Cb;

    static {
        CREATOR = new hh();
    }

    hg(int i, String str, String str2, String str3) {
        this.BR = i;
        this.BZ = str;
        this.Ca = str2;
        this.Cb = str3;
    }

    public hg(String str, String str2, String str3) {
        this(1, str, str2, str3);
    }

    public int describeContents() {
        hh hhVar = CREATOR;
        return 0;
    }

    public String toString() {
        return String.format("DocumentId[packageName=%s, corpusName=%s, uri=%s]", new Object[]{this.BZ, this.Ca, this.Cb});
    }

    public void writeToParcel(Parcel dest, int flags) {
        hh hhVar = CREATOR;
        hh.m1460a(this, dest, flags);
    }
}
