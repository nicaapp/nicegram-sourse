package com.google.android.gms.internal;

import android.content.Context;
import android.os.Bundle;
import android.os.IBinder;
import android.os.IInterface;
import android.os.RemoteException;
import android.util.Log;
import com.google.android.gms.common.GooglePlayServicesUtil;
import com.google.android.gms.common.internal.C0217a;
import com.google.android.gms.common.internal.C0233l;
import com.google.android.gms.common.internal.C0238o;
import com.google.android.gms.common.internal.C1702e;
import com.google.android.gms.common.internal.C1702e.C2386e;
import com.google.android.gms.internal.nh.C1933a;
import com.google.android.gms.internal.nj.C0543a;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

public class no extends C1702e<nh> {
    private final String BZ;
    private final nl akW;
    private final nj akX;
    private boolean akY;
    private final Object mw;

    public no(Context context, nl nlVar) {
        super(context, nlVar, nlVar, new String[0]);
        this.BZ = context.getPackageName();
        this.akW = (nl) C0238o.m283i(nlVar);
        this.akW.m3409a(this);
        this.akX = new nj();
        this.mw = new Object();
        this.akY = true;
    }

    private void m4363c(nm nmVar, ni niVar) {
        this.akX.m1716a(nmVar, niVar);
    }

    private void m4364d(nm nmVar, ni niVar) {
        try {
            mY();
            ((nh) gS()).m1713a(this.BZ, nmVar, niVar);
        } catch (RemoteException e) {
            Log.e("PlayLoggerImpl", "Couldn't send log event.  Will try caching.");
            m4363c(nmVar, niVar);
        } catch (IllegalStateException e2) {
            Log.e("PlayLoggerImpl", "Service was disconnected.  Will try caching.");
            m4363c(nmVar, niVar);
        }
    }

    private void mY() {
        C0217a.m202I(!this.akY);
        if (!this.akX.isEmpty()) {
            nm nmVar = null;
            try {
                List arrayList = new ArrayList();
                Iterator it = this.akX.mW().iterator();
                while (it.hasNext()) {
                    C0543a c0543a = (C0543a) it.next();
                    if (c0543a.akO != null) {
                        ((nh) gS()).m1715a(this.BZ, c0543a.akM, pn.m1838f(c0543a.akO));
                    } else {
                        nm nmVar2;
                        if (c0543a.akM.equals(nmVar)) {
                            arrayList.add(c0543a.akN);
                            nmVar2 = nmVar;
                        } else {
                            if (!arrayList.isEmpty()) {
                                ((nh) gS()).m1714a(this.BZ, nmVar, arrayList);
                                arrayList.clear();
                            }
                            nm nmVar3 = c0543a.akM;
                            arrayList.add(c0543a.akN);
                            nmVar2 = nmVar3;
                        }
                        nmVar = nmVar2;
                    }
                }
                if (!arrayList.isEmpty()) {
                    ((nh) gS()).m1714a(this.BZ, nmVar, arrayList);
                }
                this.akX.clear();
            } catch (RemoteException e) {
                Log.e("PlayLoggerImpl", "Couldn't send cached log events to AndroidLog service.  Retaining in memory cache.");
            }
        }
    }

    void m4365S(boolean z) {
        synchronized (this.mw) {
            boolean z2 = this.akY;
            this.akY = z;
            if (z2 && !this.akY) {
                mY();
            }
        }
    }

    protected void m4366a(C0233l c0233l, C2386e c2386e) throws RemoteException {
        c0233l.m252f(c2386e, GooglePlayServicesUtil.GOOGLE_PLAY_SERVICES_VERSION_CODE, getContext().getPackageName(), new Bundle());
    }

    public void m4367b(nm nmVar, ni niVar) {
        synchronized (this.mw) {
            if (this.akY) {
                m4363c(nmVar, niVar);
            } else {
                m4364d(nmVar, niVar);
            }
        }
    }

    protected nh bD(IBinder iBinder) {
        return C1933a.bC(iBinder);
    }

    protected String getServiceDescriptor() {
        return "com.google.android.gms.playlog.internal.IPlayLogService";
    }

    protected String getStartServiceAction() {
        return "com.google.android.gms.playlog.service.START";
    }

    protected /* synthetic */ IInterface m4368j(IBinder iBinder) {
        return bD(iBinder);
    }

    public void start() {
        synchronized (this.mw) {
            if (isConnecting() || isConnected()) {
                return;
            }
            this.akW.m3408R(true);
            connect();
        }
    }

    public void stop() {
        synchronized (this.mw) {
            this.akW.m3408R(false);
            disconnect();
        }
    }
}
