package com.google.android.gms.internal;

import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.os.IBinder;
import android.os.Parcel;
import com.google.android.gms.common.internal.safeparcel.SafeParcelable;
import com.google.android.gms.dynamic.C0330d.C1766a;
import com.google.android.gms.dynamic.C2413e;

@ez
public final class dv implements SafeParcelable {
    public static final du CREATOR;
    public final el lM;
    public final ee lT;
    public final eg si;
    public final Context sj;
    public final int versionCode;

    static {
        CREATOR = new du();
    }

    dv(int i, IBinder iBinder, IBinder iBinder2, IBinder iBinder3, IBinder iBinder4) {
        this.versionCode = i;
        this.lM = (el) C2413e.m3896f(C1766a.am(iBinder));
        this.lT = (ee) C2413e.m3896f(C1766a.am(iBinder2));
        this.si = (eg) C2413e.m3896f(C1766a.am(iBinder3));
        this.sj = (Context) C2413e.m3896f(C1766a.am(iBinder4));
    }

    public dv(eg egVar, el elVar, ee eeVar, Context context) {
        this.versionCode = 1;
        this.si = egVar;
        this.lM = elVar;
        this.lT = eeVar;
        this.sj = context;
    }

    public static void m3112a(Intent intent, dv dvVar) {
        Bundle bundle = new Bundle(1);
        bundle.putParcelable("com.google.android.gms.ads.internal.purchase.InAppPurchaseManagerInfo", dvVar);
        intent.putExtra("com.google.android.gms.ads.internal.purchase.InAppPurchaseManagerInfo", bundle);
    }

    public static dv m3113c(Intent intent) {
        try {
            Bundle bundleExtra = intent.getBundleExtra("com.google.android.gms.ads.internal.purchase.InAppPurchaseManagerInfo");
            bundleExtra.setClassLoader(dv.class.getClassLoader());
            return (dv) bundleExtra.getParcelable("com.google.android.gms.ads.internal.purchase.InAppPurchaseManagerInfo");
        } catch (Exception e) {
            return null;
        }
    }

    IBinder ck() {
        return C2413e.m3897k(this.lM).asBinder();
    }

    IBinder cl() {
        return C2413e.m3897k(this.lT).asBinder();
    }

    IBinder cm() {
        return C2413e.m3897k(this.si).asBinder();
    }

    IBinder cn() {
        return C2413e.m3897k(this.sj).asBinder();
    }

    public int describeContents() {
        return 0;
    }

    public void writeToParcel(Parcel out, int flags) {
        du.m1220a(this, out, flags);
    }
}
