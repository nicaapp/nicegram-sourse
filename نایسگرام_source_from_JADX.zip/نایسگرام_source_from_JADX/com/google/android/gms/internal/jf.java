package com.google.android.gms.internal;

import android.os.Parcel;
import com.google.android.gms.common.internal.safeparcel.SafeParcelable;
import com.google.android.gms.internal.ji.C0533b;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;

public final class jf implements SafeParcelable, C0533b<String, Integer> {
    public static final jg CREATOR;
    private final int BR;
    private final HashMap<String, Integer> Mt;
    private final HashMap<Integer, String> Mu;
    private final ArrayList<C1888a> Mv;

    /* renamed from: com.google.android.gms.internal.jf.a */
    public static final class C1888a implements SafeParcelable {
        public static final jh CREATOR;
        final String Mw;
        final int Mx;
        final int versionCode;

        static {
            CREATOR = new jh();
        }

        C1888a(int i, String str, int i2) {
            this.versionCode = i;
            this.Mw = str;
            this.Mx = i2;
        }

        C1888a(String str, int i) {
            this.versionCode = 1;
            this.Mw = str;
            this.Mx = i;
        }

        public int describeContents() {
            jh jhVar = CREATOR;
            return 0;
        }

        public void writeToParcel(Parcel out, int flags) {
            jh jhVar = CREATOR;
            jh.m1565a(this, out, flags);
        }
    }

    static {
        CREATOR = new jg();
    }

    public jf() {
        this.BR = 1;
        this.Mt = new HashMap();
        this.Mu = new HashMap();
        this.Mv = null;
    }

    jf(int i, ArrayList<C1888a> arrayList) {
        this.BR = i;
        this.Mt = new HashMap();
        this.Mu = new HashMap();
        this.Mv = null;
        m3285b(arrayList);
    }

    private void m3285b(ArrayList<C1888a> arrayList) {
        Iterator it = arrayList.iterator();
        while (it.hasNext()) {
            C1888a c1888a = (C1888a) it.next();
            m3287h(c1888a.Mw, c1888a.Mx);
        }
    }

    public String m3286a(Integer num) {
        String str = (String) this.Mu.get(num);
        return (str == null && this.Mt.containsKey("gms_unknown")) ? "gms_unknown" : str;
    }

    public /* synthetic */ Object convertBack(Object x0) {
        return m3286a((Integer) x0);
    }

    public int describeContents() {
        jg jgVar = CREATOR;
        return 0;
    }

    int getVersionCode() {
        return this.BR;
    }

    public jf m3287h(String str, int i) {
        this.Mt.put(str, Integer.valueOf(i));
        this.Mu.put(Integer.valueOf(i), str);
        return this;
    }

    ArrayList<C1888a> hc() {
        ArrayList<C1888a> arrayList = new ArrayList();
        for (String str : this.Mt.keySet()) {
            arrayList.add(new C1888a(str, ((Integer) this.Mt.get(str)).intValue()));
        }
        return arrayList;
    }

    public int hd() {
        return 7;
    }

    public int he() {
        return 0;
    }

    public void writeToParcel(Parcel out, int flags) {
        jg jgVar = CREATOR;
        jg.m1563a(this, out, flags);
    }
}
