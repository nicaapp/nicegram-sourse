package com.google.android.gms.internal;

import android.os.Parcel;
import android.os.Parcelable.Creator;
import com.google.android.gms.common.internal.safeparcel.C0242a;
import com.google.android.gms.common.internal.safeparcel.C0242a.C0241a;
import com.google.android.gms.common.internal.safeparcel.C0243b;
import com.google.android.gms.drive.events.CompletionEvent;
import com.google.android.gms.internal.nz.C2501b.C2500b;
import java.util.HashSet;
import java.util.Set;
import org.telegram.android.support.widget.helper.ItemTouchHelper;
import org.telegram.android.time.FastDatePrinter;

public class oe implements Creator<C2500b> {
    static void m1728a(C2500b c2500b, Parcel parcel, int i) {
        int D = C0243b.m329D(parcel);
        Set set = c2500b.amc;
        if (set.contains(Integer.valueOf(1))) {
            C0243b.m356c(parcel, 1, c2500b.BR);
        }
        if (set.contains(Integer.valueOf(2))) {
            C0243b.m356c(parcel, 2, c2500b.lg);
        }
        if (set.contains(Integer.valueOf(3))) {
            C0243b.m344a(parcel, 3, c2500b.uR, true);
        }
        if (set.contains(Integer.valueOf(4))) {
            C0243b.m356c(parcel, 4, c2500b.lf);
        }
        C0243b.m332H(parcel, D);
    }

    public /* synthetic */ Object createFromParcel(Parcel x0) {
        return dh(x0);
    }

    public C2500b dh(Parcel parcel) {
        int i = 0;
        int C = C0242a.m293C(parcel);
        Set hashSet = new HashSet();
        String str = null;
        int i2 = 0;
        int i3 = 0;
        while (parcel.dataPosition() < C) {
            int B = C0242a.m291B(parcel);
            switch (C0242a.aD(B)) {
                case CompletionEvent.STATUS_FAILURE /*1*/:
                    i3 = C0242a.m309g(parcel, B);
                    hashSet.add(Integer.valueOf(1));
                    break;
                case CompletionEvent.STATUS_CONFLICT /*2*/:
                    i2 = C0242a.m309g(parcel, B);
                    hashSet.add(Integer.valueOf(2));
                    break;
                case FastDatePrinter.SHORT /*3*/:
                    str = C0242a.m317o(parcel, B);
                    hashSet.add(Integer.valueOf(3));
                    break;
                case ItemTouchHelper.LEFT /*4*/:
                    i = C0242a.m309g(parcel, B);
                    hashSet.add(Integer.valueOf(4));
                    break;
                default:
                    C0242a.m302b(parcel, B);
                    break;
            }
        }
        if (parcel.dataPosition() == C) {
            return new C2500b(hashSet, i3, i2, str, i);
        }
        throw new C0241a("Overread allowed size end=" + C, parcel);
    }

    public C2500b[] eZ(int i) {
        return new C2500b[i];
    }

    public /* synthetic */ Object[] newArray(int x0) {
        return eZ(x0);
    }
}
