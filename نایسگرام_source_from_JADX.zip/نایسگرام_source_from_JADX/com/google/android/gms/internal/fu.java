package com.google.android.gms.internal;

import java.util.Arrays;
import java.util.List;
import java.util.Map;

@ez
public final class fu {
    private int mOrientation;
    private String pn;
    private List<String> uA;
    private long uB;
    private boolean uC;
    private final long uD;
    private long uE;
    private boolean uF;
    private boolean uG;
    private boolean uH;
    private boolean uI;
    private List<String> ua;
    private String uv;
    private String uw;
    private List<String> ux;
    private String uy;
    private String uz;

    public fu() {
        this.uB = -1;
        this.uC = false;
        this.uD = -1;
        this.uE = -1;
        this.mOrientation = -1;
        this.uF = false;
        this.uG = false;
        this.uH = false;
        this.uI = false;
    }

    static String m1307a(Map<String, List<String>> map, String str) {
        List list = (List) map.get(str);
        return (list == null || list.isEmpty()) ? null : (String) list.get(0);
    }

    static long m1308b(Map<String, List<String>> map, String str) {
        List list = (List) map.get(str);
        if (!(list == null || list.isEmpty())) {
            String str2 = (String) list.get(0);
            try {
                return (long) (Float.parseFloat(str2) * 1000.0f);
            } catch (NumberFormatException e) {
                gs.m1412W("Could not parse float from " + str + " header: " + str2);
            }
        }
        return -1;
    }

    static List<String> m1309c(Map<String, List<String>> map, String str) {
        List list = (List) map.get(str);
        if (!(list == null || list.isEmpty())) {
            String str2 = (String) list.get(0);
            if (str2 != null) {
                return Arrays.asList(str2.trim().split("\\s+"));
            }
        }
        return null;
    }

    private boolean m1310d(Map<String, List<String>> map, String str) {
        List list = (List) map.get(str);
        return (list == null || list.isEmpty() || !Boolean.valueOf((String) list.get(0)).booleanValue()) ? false : true;
    }

    private void m1311f(Map<String, List<String>> map) {
        this.uv = m1307a(map, "X-Afma-Ad-Size");
    }

    private void m1312g(Map<String, List<String>> map) {
        List c = m1309c(map, "X-Afma-Click-Tracking-Urls");
        if (c != null) {
            this.ux = c;
        }
    }

    private void m1313h(Map<String, List<String>> map) {
        List list = (List) map.get("X-Afma-Debug-Dialog");
        if (list != null && !list.isEmpty()) {
            this.uy = (String) list.get(0);
        }
    }

    private void m1314i(Map<String, List<String>> map) {
        List c = m1309c(map, "X-Afma-Tracking-Urls");
        if (c != null) {
            this.uA = c;
        }
    }

    private void m1315j(Map<String, List<String>> map) {
        long b = m1308b(map, "X-Afma-Interstitial-Timeout");
        if (b != -1) {
            this.uB = b;
        }
    }

    private void m1316k(Map<String, List<String>> map) {
        this.uz = m1307a(map, "X-Afma-ActiveView");
    }

    private void m1317l(Map<String, List<String>> map) {
        this.uG |= m1310d(map, "X-Afma-Native");
    }

    private void m1318m(Map<String, List<String>> map) {
        this.uF |= m1310d(map, "X-Afma-Custom-Rendering-Allowed");
    }

    private void m1319n(Map<String, List<String>> map) {
        this.uC |= m1310d(map, "X-Afma-Mediation");
    }

    private void m1320o(Map<String, List<String>> map) {
        List c = m1309c(map, "X-Afma-Manual-Tracking-Urls");
        if (c != null) {
            this.ua = c;
        }
    }

    private void m1321p(Map<String, List<String>> map) {
        long b = m1308b(map, "X-Afma-Refresh-Rate");
        if (b != -1) {
            this.uE = b;
        }
    }

    private void m1322q(Map<String, List<String>> map) {
        List list = (List) map.get("X-Afma-Orientation");
        if (list != null && !list.isEmpty()) {
            String str = (String) list.get(0);
            if ("portrait".equalsIgnoreCase(str)) {
                this.mOrientation = gj.dm();
            } else if ("landscape".equalsIgnoreCase(str)) {
                this.mOrientation = gj.dl();
            }
        }
    }

    private void m1323r(Map<String, List<String>> map) {
        List list = (List) map.get("X-Afma-Use-HTTPS");
        if (list != null && !list.isEmpty()) {
            this.uH = Boolean.valueOf((String) list.get(0)).booleanValue();
        }
    }

    private void m1324s(Map<String, List<String>> map) {
        List list = (List) map.get("X-Afma-Content-Url-Opted-Out");
        if (list != null && !list.isEmpty()) {
            this.uI = Boolean.valueOf((String) list.get(0)).booleanValue();
        }
    }

    public void m1325a(String str, Map<String, List<String>> map, String str2) {
        this.uw = str;
        this.pn = str2;
        m1326e(map);
    }

    public void m1326e(Map<String, List<String>> map) {
        m1311f(map);
        m1312g(map);
        m1313h(map);
        m1314i((Map) map);
        m1315j(map);
        m1319n(map);
        m1320o(map);
        m1321p(map);
        m1322q(map);
        m1316k(map);
        m1323r(map);
        m1318m(map);
        m1317l(map);
        m1324s(map);
    }

    public fk m1327i(long j) {
        return new fk(this.uw, this.pn, this.ux, this.uA, this.uB, this.uC, -1, this.ua, this.uE, this.mOrientation, this.uv, j, this.uy, this.uz, this.uF, this.uG, this.uH, this.uI);
    }
}
