package com.google.android.gms.internal;

import android.app.PendingIntent;
import android.os.RemoteException;
import android.util.Log;
import com.google.android.gms.common.api.GoogleApiClient;
import com.google.android.gms.common.api.PendingResult;
import com.google.android.gms.common.api.Result;
import com.google.android.gms.common.api.Status;
import com.google.android.gms.common.internal.C0238o;
import com.google.android.gms.location.Geofence;
import com.google.android.gms.location.GeofencingApi;
import com.google.android.gms.location.LocationClient.OnAddGeofencesResultListener;
import com.google.android.gms.location.LocationClient.OnRemoveGeofencesResultListener;
import com.google.android.gms.location.LocationServices.C2631a;
import com.google.android.gms.location.LocationStatusCodes;
import java.util.ArrayList;
import java.util.List;

public class lv implements GeofencingApi {

    /* renamed from: com.google.android.gms.internal.lv.a */
    private static abstract class C2690a extends C2631a<Status> {
        private C2690a() {
        }

        public /* synthetic */ Result m4990c(Status status) {
            return m4991d(status);
        }

        public Status m4991d(Status status) {
            return status;
        }
    }

    /* renamed from: com.google.android.gms.internal.lv.1 */
    class C28641 extends C2690a {
        final /* synthetic */ List aeK;
        final /* synthetic */ PendingIntent aeL;
        final /* synthetic */ lv aeM;

        /* renamed from: com.google.android.gms.internal.lv.1.1 */
        class C19161 implements OnAddGeofencesResultListener {
            final /* synthetic */ C28641 aeN;

            C19161(C28641 c28641) {
                this.aeN = c28641;
            }

            public void onAddGeofencesResult(int statusCode, String[] geofenceRequestIds) {
                this.aeN.m2389b(LocationStatusCodes.eg(statusCode));
            }
        }

        C28641(lv lvVar, List list, PendingIntent pendingIntent) {
            this.aeM = lvVar;
            this.aeK = list;
            this.aeL = pendingIntent;
            super();
        }

        protected void m5439a(lz lzVar) throws RemoteException {
            lzVar.addGeofences(this.aeK, this.aeL, new C19161(this));
        }
    }

    /* renamed from: com.google.android.gms.internal.lv.2 */
    class C28652 extends C2690a {
        final /* synthetic */ PendingIntent aeL;
        final /* synthetic */ lv aeM;

        /* renamed from: com.google.android.gms.internal.lv.2.1 */
        class C19171 implements OnRemoveGeofencesResultListener {
            final /* synthetic */ C28652 aeO;

            C19171(C28652 c28652) {
                this.aeO = c28652;
            }

            public void onRemoveGeofencesByPendingIntentResult(int statusCode, PendingIntent pendingIntent) {
                this.aeO.m2389b(LocationStatusCodes.eg(statusCode));
            }

            public void onRemoveGeofencesByRequestIdsResult(int statusCode, String[] geofenceRequestIds) {
                Log.wtf("GeofencingImpl", "Request ID callback shouldn't have been called");
            }
        }

        C28652(lv lvVar, PendingIntent pendingIntent) {
            this.aeM = lvVar;
            this.aeL = pendingIntent;
            super();
        }

        protected void m5441a(lz lzVar) throws RemoteException {
            lzVar.removeGeofences(this.aeL, new C19171(this));
        }
    }

    /* renamed from: com.google.android.gms.internal.lv.3 */
    class C28663 extends C2690a {
        final /* synthetic */ lv aeM;
        final /* synthetic */ List aeP;

        /* renamed from: com.google.android.gms.internal.lv.3.1 */
        class C19181 implements OnRemoveGeofencesResultListener {
            final /* synthetic */ C28663 aeQ;

            C19181(C28663 c28663) {
                this.aeQ = c28663;
            }

            public void onRemoveGeofencesByPendingIntentResult(int statusCode, PendingIntent pendingIntent) {
                Log.wtf("GeofencingImpl", "PendingIntent callback shouldn't have been called");
            }

            public void onRemoveGeofencesByRequestIdsResult(int statusCode, String[] geofenceRequestIds) {
                this.aeQ.m2389b(LocationStatusCodes.eg(statusCode));
            }
        }

        C28663(lv lvVar, List list) {
            this.aeM = lvVar;
            this.aeP = list;
            super();
        }

        protected void m5443a(lz lzVar) throws RemoteException {
            lzVar.removeGeofences(this.aeP, new C19181(this));
        }
    }

    public PendingResult<Status> addGeofences(GoogleApiClient client, List<Geofence> geofences, PendingIntent pendingIntent) {
        List list;
        if (geofences != null) {
            List arrayList = new ArrayList(geofences.size());
            for (Geofence geofence : geofences) {
                C0238o.m281b(geofence instanceof mc, (Object) "Geofence must be created using Geofence.Builder.");
                arrayList.add((mc) geofence);
            }
            list = arrayList;
        } else {
            list = null;
        }
        return client.m152b(new C28641(this, list, pendingIntent));
    }

    public PendingResult<Status> removeGeofences(GoogleApiClient client, PendingIntent pendingIntent) {
        return client.m152b(new C28652(this, pendingIntent));
    }

    public PendingResult<Status> removeGeofences(GoogleApiClient client, List<String> geofenceRequestIds) {
        return client.m152b(new C28663(this, geofenceRequestIds));
    }
}
