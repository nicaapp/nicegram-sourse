package com.google.android.gms.internal;

import android.content.Intent;
import com.google.android.gms.ads.purchase.InAppPurchaseResult;

@ez
public class eo implements InAppPurchaseResult {
    private final ek sL;

    public eo(ek ekVar) {
        this.sL = ekVar;
    }

    public void finishPurchase() {
        try {
            this.sL.finishPurchase();
        } catch (Throwable e) {
            gs.m1416d("Could not forward finishPurchase to InAppPurchaseResult", e);
        }
    }

    public String getProductId() {
        try {
            return this.sL.getProductId();
        } catch (Throwable e) {
            gs.m1416d("Could not forward getProductId to InAppPurchaseResult", e);
            return null;
        }
    }

    public Intent getPurchaseData() {
        try {
            return this.sL.getPurchaseData();
        } catch (Throwable e) {
            gs.m1416d("Could not forward getPurchaseData to InAppPurchaseResult", e);
            return null;
        }
    }

    public int getResultCode() {
        try {
            return this.sL.getResultCode();
        } catch (Throwable e) {
            gs.m1416d("Could not forward getPurchaseData to InAppPurchaseResult", e);
            return 0;
        }
    }

    public boolean isVerified() {
        try {
            return this.sL.isVerified();
        } catch (Throwable e) {
            gs.m1416d("Could not forward isVerified to InAppPurchaseResult", e);
            return false;
        }
    }
}
