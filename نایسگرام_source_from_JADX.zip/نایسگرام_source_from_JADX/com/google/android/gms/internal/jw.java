package com.google.android.gms.internal;

import android.os.SystemClock;

public final class jw implements ju {
    private static jw MS;

    public static synchronized ju hA() {
        ju juVar;
        synchronized (jw.class) {
            if (MS == null) {
                MS = new jw();
            }
            juVar = MS;
        }
        return juVar;
    }

    public long currentTimeMillis() {
        return System.currentTimeMillis();
    }

    public long elapsedRealtime() {
        return SystemClock.elapsedRealtime();
    }
}
