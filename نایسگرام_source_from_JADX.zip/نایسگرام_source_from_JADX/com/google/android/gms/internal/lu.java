package com.google.android.gms.internal;

import android.app.PendingIntent;
import android.location.Location;
import android.os.Looper;
import android.os.RemoteException;
import com.google.android.gms.common.api.GoogleApiClient;
import com.google.android.gms.common.api.PendingResult;
import com.google.android.gms.common.api.Result;
import com.google.android.gms.common.api.Status;
import com.google.android.gms.location.FusedLocationProviderApi;
import com.google.android.gms.location.LocationListener;
import com.google.android.gms.location.LocationRequest;
import com.google.android.gms.location.LocationServices;
import com.google.android.gms.location.LocationServices.C2631a;

public class lu implements FusedLocationProviderApi {

    /* renamed from: com.google.android.gms.internal.lu.a */
    private static abstract class C2689a extends C2631a<Status> {
        private C2689a() {
        }

        public /* synthetic */ Result m4988c(Status status) {
            return m4989d(status);
        }

        public Status m4989d(Status status) {
            return status;
        }
    }

    /* renamed from: com.google.android.gms.internal.lu.1 */
    class C28571 extends C2689a {
        final /* synthetic */ LocationRequest aeE;
        final /* synthetic */ LocationListener aeF;
        final /* synthetic */ lu aeG;

        C28571(lu luVar, LocationRequest locationRequest, LocationListener locationListener) {
            this.aeG = luVar;
            this.aeE = locationRequest;
            this.aeF = locationListener;
            super();
        }

        protected void m5425a(lz lzVar) throws RemoteException {
            lzVar.requestLocationUpdates(this.aeE, this.aeF, null);
            m2389b(Status.Jv);
        }
    }

    /* renamed from: com.google.android.gms.internal.lu.2 */
    class C28582 extends C2689a {
        final /* synthetic */ lu aeG;
        final /* synthetic */ Location aeH;

        C28582(lu luVar, Location location) {
            this.aeG = luVar;
            this.aeH = location;
            super();
        }

        protected void m5427a(lz lzVar) throws RemoteException {
            lzVar.setMockLocation(this.aeH);
            m2389b(Status.Jv);
        }
    }

    /* renamed from: com.google.android.gms.internal.lu.3 */
    class C28593 extends C2689a {
        final /* synthetic */ LocationRequest aeE;
        final /* synthetic */ LocationListener aeF;
        final /* synthetic */ lu aeG;
        final /* synthetic */ Looper aeI;

        C28593(lu luVar, LocationRequest locationRequest, LocationListener locationListener, Looper looper) {
            this.aeG = luVar;
            this.aeE = locationRequest;
            this.aeF = locationListener;
            this.aeI = looper;
            super();
        }

        protected void m5429a(lz lzVar) throws RemoteException {
            lzVar.requestLocationUpdates(this.aeE, this.aeF, this.aeI);
            m2389b(Status.Jv);
        }
    }

    /* renamed from: com.google.android.gms.internal.lu.4 */
    class C28604 extends C2689a {
        final /* synthetic */ PendingIntent aeC;
        final /* synthetic */ LocationRequest aeE;
        final /* synthetic */ lu aeG;

        C28604(lu luVar, LocationRequest locationRequest, PendingIntent pendingIntent) {
            this.aeG = luVar;
            this.aeE = locationRequest;
            this.aeC = pendingIntent;
            super();
        }

        protected void m5431a(lz lzVar) throws RemoteException {
            lzVar.requestLocationUpdates(this.aeE, this.aeC);
            m2389b(Status.Jv);
        }
    }

    /* renamed from: com.google.android.gms.internal.lu.5 */
    class C28615 extends C2689a {
        final /* synthetic */ LocationListener aeF;
        final /* synthetic */ lu aeG;

        C28615(lu luVar, LocationListener locationListener) {
            this.aeG = luVar;
            this.aeF = locationListener;
            super();
        }

        protected void m5433a(lz lzVar) throws RemoteException {
            lzVar.removeLocationUpdates(this.aeF);
            m2389b(Status.Jv);
        }
    }

    /* renamed from: com.google.android.gms.internal.lu.6 */
    class C28626 extends C2689a {
        final /* synthetic */ PendingIntent aeC;
        final /* synthetic */ lu aeG;

        C28626(lu luVar, PendingIntent pendingIntent) {
            this.aeG = luVar;
            this.aeC = pendingIntent;
            super();
        }

        protected void m5435a(lz lzVar) throws RemoteException {
            lzVar.removeLocationUpdates(this.aeC);
            m2389b(Status.Jv);
        }
    }

    /* renamed from: com.google.android.gms.internal.lu.7 */
    class C28637 extends C2689a {
        final /* synthetic */ lu aeG;
        final /* synthetic */ boolean aeJ;

        C28637(lu luVar, boolean z) {
            this.aeG = luVar;
            this.aeJ = z;
            super();
        }

        protected void m5437a(lz lzVar) throws RemoteException {
            lzVar.setMockMode(this.aeJ);
            m2389b(Status.Jv);
        }
    }

    public Location getLastLocation(GoogleApiClient client) {
        try {
            return LocationServices.m1885e(client).getLastLocation();
        } catch (Exception e) {
            return null;
        }
    }

    public PendingResult<Status> removeLocationUpdates(GoogleApiClient client, PendingIntent callbackIntent) {
        return client.m152b(new C28626(this, callbackIntent));
    }

    public PendingResult<Status> removeLocationUpdates(GoogleApiClient client, LocationListener listener) {
        return client.m152b(new C28615(this, listener));
    }

    public PendingResult<Status> requestLocationUpdates(GoogleApiClient client, LocationRequest request, PendingIntent callbackIntent) {
        return client.m152b(new C28604(this, request, callbackIntent));
    }

    public PendingResult<Status> requestLocationUpdates(GoogleApiClient client, LocationRequest request, LocationListener listener) {
        return client.m152b(new C28571(this, request, listener));
    }

    public PendingResult<Status> requestLocationUpdates(GoogleApiClient client, LocationRequest request, LocationListener listener, Looper looper) {
        return client.m152b(new C28593(this, request, listener, looper));
    }

    public PendingResult<Status> setMockLocation(GoogleApiClient client, Location mockLocation) {
        return client.m152b(new C28582(this, mockLocation));
    }

    public PendingResult<Status> setMockMode(GoogleApiClient client, boolean isMockMode) {
        return client.m152b(new C28637(this, isMockMode));
    }
}
