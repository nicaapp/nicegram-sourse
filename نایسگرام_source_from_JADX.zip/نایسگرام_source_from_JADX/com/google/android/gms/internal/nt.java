package com.google.android.gms.internal;

import com.google.android.gms.common.api.BaseImplementation.C0191b;
import com.google.android.gms.common.api.GoogleApiClient;
import com.google.android.gms.common.api.PendingResult;
import com.google.android.gms.common.api.Result;
import com.google.android.gms.common.api.Status;
import com.google.android.gms.plus.People;
import com.google.android.gms.plus.People.LoadPeopleResult;
import com.google.android.gms.plus.Plus;
import com.google.android.gms.plus.Plus.C2632a;
import com.google.android.gms.plus.internal.C2535e;
import com.google.android.gms.plus.model.people.Person;
import com.google.android.gms.plus.model.people.PersonBuffer;
import java.util.Collection;

public final class nt implements People {

    /* renamed from: com.google.android.gms.internal.nt.a */
    private static abstract class C2697a extends C2632a<LoadPeopleResult> {

        /* renamed from: com.google.android.gms.internal.nt.a.1 */
        class C24971 implements LoadPeopleResult {
            final /* synthetic */ Status CW;
            final /* synthetic */ C2697a ama;

            C24971(C2697a c2697a, Status status) {
                this.ama = c2697a;
                this.CW = status;
            }

            public String getNextPageToken() {
                return null;
            }

            public PersonBuffer getPersonBuffer() {
                return null;
            }

            public Status getStatus() {
                return this.CW;
            }

            public void release() {
            }
        }

        private C2697a() {
        }

        public LoadPeopleResult aD(Status status) {
            return new C24971(this, status);
        }

        public /* synthetic */ Result m5002c(Status status) {
            return aD(status);
        }
    }

    /* renamed from: com.google.android.gms.internal.nt.1 */
    class C28741 extends C2697a {
        final /* synthetic */ String alP;
        final /* synthetic */ int alW;
        final /* synthetic */ nt alX;

        C28741(nt ntVar, int i, String str) {
            this.alX = ntVar;
            this.alW = i;
            this.alP = str;
            super();
        }

        protected void m5457a(C2535e c2535e) {
            m2388a(c2535e.m4494a((C0191b) this, this.alW, this.alP));
        }
    }

    /* renamed from: com.google.android.gms.internal.nt.2 */
    class C28752 extends C2697a {
        final /* synthetic */ String alP;
        final /* synthetic */ nt alX;

        C28752(nt ntVar, String str) {
            this.alX = ntVar;
            this.alP = str;
            super();
        }

        protected void m5459a(C2535e c2535e) {
            m2388a(c2535e.m4505r(this, this.alP));
        }
    }

    /* renamed from: com.google.android.gms.internal.nt.3 */
    class C28763 extends C2697a {
        final /* synthetic */ nt alX;

        C28763(nt ntVar) {
            this.alX = ntVar;
            super();
        }

        protected void m5461a(C2535e c2535e) {
            c2535e.m4503l(this);
        }
    }

    /* renamed from: com.google.android.gms.internal.nt.4 */
    class C28774 extends C2697a {
        final /* synthetic */ nt alX;
        final /* synthetic */ Collection alY;

        C28774(nt ntVar, Collection collection) {
            this.alX = ntVar;
            this.alY = collection;
            super();
        }

        protected void m5463a(C2535e c2535e) {
            c2535e.m4498a((C0191b) this, this.alY);
        }
    }

    /* renamed from: com.google.android.gms.internal.nt.5 */
    class C28785 extends C2697a {
        final /* synthetic */ nt alX;
        final /* synthetic */ String[] alZ;

        C28785(nt ntVar, String[] strArr) {
            this.alX = ntVar;
            this.alZ = strArr;
            super();
        }

        protected void m5465a(C2535e c2535e) {
            c2535e.m4500d(this, this.alZ);
        }
    }

    public Person getCurrentPerson(GoogleApiClient googleApiClient) {
        return Plus.m1958a(googleApiClient, Plus.CU).getCurrentPerson();
    }

    public PendingResult<LoadPeopleResult> load(GoogleApiClient googleApiClient, Collection<String> personIds) {
        return googleApiClient.m150a(new C28774(this, personIds));
    }

    public PendingResult<LoadPeopleResult> load(GoogleApiClient googleApiClient, String... personIds) {
        return googleApiClient.m150a(new C28785(this, personIds));
    }

    public PendingResult<LoadPeopleResult> loadConnected(GoogleApiClient googleApiClient) {
        return googleApiClient.m150a(new C28763(this));
    }

    public PendingResult<LoadPeopleResult> loadVisible(GoogleApiClient googleApiClient, int orderBy, String pageToken) {
        return googleApiClient.m150a(new C28741(this, orderBy, pageToken));
    }

    public PendingResult<LoadPeopleResult> loadVisible(GoogleApiClient googleApiClient, String pageToken) {
        return googleApiClient.m150a(new C28752(this, pageToken));
    }
}
