package com.google.android.gms.internal;

class pj {
    private static final pk awM;
    private boolean awN;
    private int[] awO;
    private pk[] awP;
    private int mSize;

    static {
        awM = new pk();
    }

    public pj() {
        this(10);
    }

    public pj(int i) {
        this.awN = false;
        int idealIntArraySize = idealIntArraySize(i);
        this.awO = new int[idealIntArraySize];
        this.awP = new pk[idealIntArraySize];
        this.mSize = 0;
    }

    private boolean m1828a(int[] iArr, int[] iArr2, int i) {
        for (int i2 = 0; i2 < i; i2++) {
            if (iArr[i2] != iArr2[i2]) {
                return false;
            }
        }
        return true;
    }

    private boolean m1829a(pk[] pkVarArr, pk[] pkVarArr2, int i) {
        for (int i2 = 0; i2 < i; i2++) {
            if (!pkVarArr[i2].equals(pkVarArr2[i2])) {
                return false;
            }
        }
        return true;
    }

    private int gG(int i) {
        int i2 = 0;
        int i3 = this.mSize - 1;
        while (i2 <= i3) {
            int i4 = (i2 + i3) >>> 1;
            int i5 = this.awO[i4];
            if (i5 < i) {
                i2 = i4 + 1;
            } else if (i5 <= i) {
                return i4;
            } else {
                i3 = i4 - 1;
            }
        }
        return i2 ^ -1;
    }

    private void gc() {
        int i = this.mSize;
        int[] iArr = this.awO;
        pk[] pkVarArr = this.awP;
        int i2 = 0;
        for (int i3 = 0; i3 < i; i3++) {
            pk pkVar = pkVarArr[i3];
            if (pkVar != awM) {
                if (i3 != i2) {
                    iArr[i2] = iArr[i3];
                    pkVarArr[i2] = pkVar;
                    pkVarArr[i3] = null;
                }
                i2++;
            }
        }
        this.awN = false;
        this.mSize = i2;
    }

    private int idealByteArraySize(int need) {
        for (int i = 4; i < 32; i++) {
            if (need <= (1 << i) - 12) {
                return (1 << i) - 12;
            }
        }
        return need;
    }

    private int idealIntArraySize(int need) {
        return idealByteArraySize(need * 4) / 4;
    }

    public void m1830a(int i, pk pkVar) {
        int gG = gG(i);
        if (gG >= 0) {
            this.awP[gG] = pkVar;
            return;
        }
        gG ^= -1;
        if (gG >= this.mSize || this.awP[gG] != awM) {
            if (this.awN && this.mSize >= this.awO.length) {
                gc();
                gG = gG(i) ^ -1;
            }
            if (this.mSize >= this.awO.length) {
                int idealIntArraySize = idealIntArraySize(this.mSize + 1);
                Object obj = new int[idealIntArraySize];
                Object obj2 = new pk[idealIntArraySize];
                System.arraycopy(this.awO, 0, obj, 0, this.awO.length);
                System.arraycopy(this.awP, 0, obj2, 0, this.awP.length);
                this.awO = obj;
                this.awP = obj2;
            }
            if (this.mSize - gG != 0) {
                System.arraycopy(this.awO, gG, this.awO, gG + 1, this.mSize - gG);
                System.arraycopy(this.awP, gG, this.awP, gG + 1, this.mSize - gG);
            }
            this.awO[gG] = i;
            this.awP[gG] = pkVar;
            this.mSize++;
            return;
        }
        this.awO[gG] = i;
        this.awP[gG] = pkVar;
    }

    public boolean equals(Object o) {
        if (o == this) {
            return true;
        }
        if (!(o instanceof pj)) {
            return false;
        }
        pj pjVar = (pj) o;
        if (size() != pjVar.size()) {
            return false;
        }
        return m1828a(this.awO, pjVar.awO, this.mSize) && m1829a(this.awP, pjVar.awP, this.mSize);
    }

    public pk gE(int i) {
        int gG = gG(i);
        return (gG < 0 || this.awP[gG] == awM) ? null : this.awP[gG];
    }

    public pk gF(int i) {
        if (this.awN) {
            gc();
        }
        return this.awP[i];
    }

    public int hashCode() {
        if (this.awN) {
            gc();
        }
        int i = 17;
        for (int i2 = 0; i2 < this.mSize; i2++) {
            i = (((i * 31) + this.awO[i2]) * 31) + this.awP[i2].hashCode();
        }
        return i;
    }

    public boolean isEmpty() {
        return size() == 0;
    }

    public int size() {
        if (this.awN) {
            gc();
        }
        return this.mSize;
    }
}
