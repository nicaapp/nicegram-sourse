package com.google.android.gms.internal;

import android.os.Parcel;
import android.os.Parcelable.Creator;
import com.google.android.gms.common.internal.safeparcel.C0242a;
import com.google.android.gms.common.internal.safeparcel.C0242a.C0241a;
import com.google.android.gms.common.internal.safeparcel.C0243b;
import com.google.android.gms.drive.events.CompletionEvent;
import com.google.android.gms.games.quest.Quest;
import com.google.android.gms.location.DetectedActivity;
import com.googlecode.mp4parser.authoring.tracks.h265.NalUnitTypes;
import com.googlecode.mp4parser.boxes.microsoft.XtraBox;
import org.telegram.C0811R;
import org.telegram.android.support.widget.helper.ItemTouchHelper;
import org.telegram.android.time.FastDatePrinter;

public class bk implements Creator<bj> {
    static void m1149a(bj bjVar, Parcel parcel, int i) {
        int D = C0243b.m329D(parcel);
        C0243b.m356c(parcel, 1, bjVar.versionCode);
        C0243b.m356c(parcel, 2, bjVar.oH);
        C0243b.m356c(parcel, 3, bjVar.backgroundColor);
        C0243b.m356c(parcel, 4, bjVar.oI);
        C0243b.m356c(parcel, 5, bjVar.oJ);
        C0243b.m356c(parcel, 6, bjVar.oK);
        C0243b.m356c(parcel, 7, bjVar.oL);
        C0243b.m356c(parcel, 8, bjVar.oM);
        C0243b.m356c(parcel, 9, bjVar.oN);
        C0243b.m344a(parcel, 10, bjVar.oO, false);
        C0243b.m356c(parcel, 11, bjVar.oP);
        C0243b.m344a(parcel, 12, bjVar.oQ, false);
        C0243b.m356c(parcel, 13, bjVar.oR);
        C0243b.m356c(parcel, 14, bjVar.oS);
        C0243b.m344a(parcel, 15, bjVar.oT, false);
        C0243b.m332H(parcel, D);
    }

    public /* synthetic */ Object createFromParcel(Parcel x0) {
        return m1150d(x0);
    }

    public bj m1150d(Parcel parcel) {
        int C = C0242a.m293C(parcel);
        int i = 0;
        int i2 = 0;
        int i3 = 0;
        int i4 = 0;
        int i5 = 0;
        int i6 = 0;
        int i7 = 0;
        int i8 = 0;
        int i9 = 0;
        String str = null;
        int i10 = 0;
        String str2 = null;
        int i11 = 0;
        int i12 = 0;
        String str3 = null;
        while (parcel.dataPosition() < C) {
            int B = C0242a.m291B(parcel);
            switch (C0242a.aD(B)) {
                case CompletionEvent.STATUS_FAILURE /*1*/:
                    i = C0242a.m309g(parcel, B);
                    break;
                case CompletionEvent.STATUS_CONFLICT /*2*/:
                    i2 = C0242a.m309g(parcel, B);
                    break;
                case FastDatePrinter.SHORT /*3*/:
                    i3 = C0242a.m309g(parcel, B);
                    break;
                case ItemTouchHelper.LEFT /*4*/:
                    i4 = C0242a.m309g(parcel, B);
                    break;
                case DetectedActivity.TILTING /*5*/:
                    i5 = C0242a.m309g(parcel, B);
                    break;
                case Quest.STATE_FAILED /*6*/:
                    i6 = C0242a.m309g(parcel, B);
                    break;
                case DetectedActivity.WALKING /*7*/:
                    i7 = C0242a.m309g(parcel, B);
                    break;
                case XtraBox.MP4_XTRA_BT_UNICODE /*8*/:
                    i8 = C0242a.m309g(parcel, B);
                    break;
                case C0811R.styleable.WalletFragmentStyle_maskedWalletDetailsLogoTextColor /*9*/:
                    i9 = C0242a.m309g(parcel, B);
                    break;
                case C0811R.styleable.WalletFragmentStyle_maskedWalletDetailsLogoImageType /*10*/:
                    str = C0242a.m317o(parcel, B);
                    break;
                case C0811R.styleable.MapAttrs_uiZoomGestures /*11*/:
                    i10 = C0242a.m309g(parcel, B);
                    break;
                case C0811R.styleable.MapAttrs_useViewLifecycle /*12*/:
                    str2 = C0242a.m317o(parcel, B);
                    break;
                case C0811R.styleable.MapAttrs_zOrderOnTop /*13*/:
                    i11 = C0242a.m309g(parcel, B);
                    break;
                case NalUnitTypes.NAL_TYPE_RSV_VCL_N14 /*14*/:
                    i12 = C0242a.m309g(parcel, B);
                    break;
                case NalUnitTypes.NAL_TYPE_RSV_VCL_R15 /*15*/:
                    str3 = C0242a.m317o(parcel, B);
                    break;
                default:
                    C0242a.m302b(parcel, B);
                    break;
            }
        }
        if (parcel.dataPosition() == C) {
            return new bj(i, i2, i3, i4, i5, i6, i7, i8, i9, str, i10, str2, i11, i12, str3);
        }
        throw new C0241a("Overread allowed size end=" + C, parcel);
    }

    public bj[] m1151h(int i) {
        return new bj[i];
    }

    public /* synthetic */ Object[] newArray(int x0) {
        return m1151h(x0);
    }
}
