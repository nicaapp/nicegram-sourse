package com.google.android.gms.internal;

import android.content.Context;
import android.os.Looper;
import com.google.android.gms.common.api.Api;
import com.google.android.gms.common.api.Api.ApiOptions.NoOptions;
import com.google.android.gms.common.api.Api.C0189b;
import com.google.android.gms.common.api.Api.C0190c;
import com.google.android.gms.common.api.GoogleApiClient.ConnectionCallbacks;
import com.google.android.gms.common.api.GoogleApiClient.OnConnectionFailedListener;
import com.google.android.gms.common.api.Scope;
import com.google.android.gms.common.internal.ClientSettings;
import org.telegram.messenger.ConnectionsManager;

public final class hd {
    public static final C0190c<hy> BN;
    private static final C0189b<hy, NoOptions> BO;
    public static final Api<NoOptions> BP;
    public static final hu BQ;

    /* renamed from: com.google.android.gms.internal.hd.1 */
    static class C18681 implements C0189b<hy, NoOptions> {
        C18681() {
        }

        public hy m3226a(Context context, Looper looper, ClientSettings clientSettings, NoOptions noOptions, ConnectionCallbacks connectionCallbacks, OnConnectionFailedListener onConnectionFailedListener) {
            return new hy(context, looper, connectionCallbacks, onConnectionFailedListener);
        }

        public int getPriority() {
            return ConnectionsManager.DEFAULT_DATACENTER_ID;
        }
    }

    static {
        BN = new C0190c();
        BO = new C18681();
        BP = new Api(BO, BN, new Scope[0]);
        BQ = new hz();
    }
}
