package com.google.android.gms.internal;

import android.support.v4.media.TransportMediator;
import android.support.v4.view.MotionEventCompat;
import com.google.android.gms.drive.events.CompletionEvent;
import com.google.android.gms.internal.C0444d.C2468a;
import com.googlecode.mp4parser.authoring.tracks.h265.NalUnitTypes;
import com.googlecode.mp4parser.boxes.microsoft.XtraBox;
import java.io.IOException;
import org.telegram.C0811R;
import org.telegram.android.MessagesController;
import org.telegram.android.support.widget.helper.ItemTouchHelper;
import org.telegram.android.time.FastDatePrinter;
import org.telegram.messenger.BuildConfig;
import org.telegram.messenger.TLRPC;

/* renamed from: com.google.android.gms.internal.c */
public interface C0439c {

    /* renamed from: com.google.android.gms.internal.c.a */
    public static final class C2458a extends ph<C2458a> {
        public int fn;
        public int fo;
        public int level;

        public C2458a() {
            m4141b();
        }

        public C2458a m4139a(pf pfVar) throws IOException {
            while (true) {
                int qi = pfVar.qi();
                switch (qi) {
                    case FastDatePrinter.FULL /*0*/:
                        break;
                    case XtraBox.MP4_XTRA_BT_UNICODE /*8*/:
                        qi = pfVar.ql();
                        switch (qi) {
                            case CompletionEvent.STATUS_FAILURE /*1*/:
                            case CompletionEvent.STATUS_CONFLICT /*2*/:
                            case FastDatePrinter.SHORT /*3*/:
                                this.level = qi;
                                break;
                            default:
                                continue;
                        }
                    case ItemTouchHelper.START /*16*/:
                        this.fn = pfVar.ql();
                        continue;
                    case NalUnitTypes.NAL_TYPE_RSV_VCL24 /*24*/:
                        this.fo = pfVar.ql();
                        continue;
                    default:
                        if (!m3436a(pfVar, qi)) {
                            break;
                        }
                        continue;
                }
                return this;
            }
        }

        public void m4140a(pg pgVar) throws IOException {
            if (this.level != 1) {
                pgVar.m1812s(1, this.level);
            }
            if (this.fn != 0) {
                pgVar.m1812s(2, this.fn);
            }
            if (this.fo != 0) {
                pgVar.m1812s(3, this.fo);
            }
            super.m3435a(pgVar);
        }

        public C2458a m4141b() {
            this.level = 1;
            this.fn = 0;
            this.fo = 0;
            this.awJ = null;
            this.awU = -1;
            return this;
        }

        public /* synthetic */ pn m4142b(pf pfVar) throws IOException {
            return m4139a(pfVar);
        }

        protected int m4143c() {
            int c = super.m3438c();
            if (this.level != 1) {
                c += pg.m1790u(1, this.level);
            }
            if (this.fn != 0) {
                c += pg.m1790u(2, this.fn);
            }
            return this.fo != 0 ? c + pg.m1790u(3, this.fo) : c;
        }

        public boolean equals(Object o) {
            if (o == this) {
                return true;
            }
            if (!(o instanceof C2458a)) {
                return false;
            }
            C2458a c2458a = (C2458a) o;
            return (this.level == c2458a.level && this.fn == c2458a.fn && this.fo == c2458a.fo) ? m3437a((ph) c2458a) : false;
        }

        public int hashCode() {
            return ((((((this.level + 527) * 31) + this.fn) * 31) + this.fo) * 31) + qz();
        }
    }

    /* renamed from: com.google.android.gms.internal.c.b */
    public static final class C2459b extends ph<C2459b> {
        private static volatile C2459b[] fp;
        public int[] fq;
        public int fr;
        public boolean fs;
        public boolean ft;
        public int name;

        public C2459b() {
            m4149e();
        }

        public static C2459b[] m4144d() {
            if (fp == null) {
                synchronized (pl.awT) {
                    if (fp == null) {
                        fp = new C2459b[0];
                    }
                }
            }
            return fp;
        }

        public void m4145a(pg pgVar) throws IOException {
            if (this.ft) {
                pgVar.m1804b(1, this.ft);
            }
            pgVar.m1812s(2, this.fr);
            if (this.fq != null && this.fq.length > 0) {
                for (int s : this.fq) {
                    pgVar.m1812s(3, s);
                }
            }
            if (this.name != 0) {
                pgVar.m1812s(4, this.name);
            }
            if (this.fs) {
                pgVar.m1804b(6, this.fs);
            }
            super.m3435a(pgVar);
        }

        public /* synthetic */ pn m4146b(pf pfVar) throws IOException {
            return m4148c(pfVar);
        }

        protected int m4147c() {
            int i = 0;
            int c = super.m3438c();
            if (this.ft) {
                c += pg.m1780c(1, this.ft);
            }
            int u = pg.m1790u(2, this.fr) + c;
            if (this.fq == null || this.fq.length <= 0) {
                c = u;
            } else {
                for (int gw : this.fq) {
                    i += pg.gw(gw);
                }
                c = (u + i) + (this.fq.length * 1);
            }
            if (this.name != 0) {
                c += pg.m1790u(4, this.name);
            }
            return this.fs ? c + pg.m1780c(6, this.fs) : c;
        }

        public C2459b m4148c(pf pfVar) throws IOException {
            while (true) {
                int qi = pfVar.qi();
                int b;
                switch (qi) {
                    case FastDatePrinter.FULL /*0*/:
                        break;
                    case XtraBox.MP4_XTRA_BT_UNICODE /*8*/:
                        this.ft = pfVar.qm();
                        continue;
                    case ItemTouchHelper.START /*16*/:
                        this.fr = pfVar.ql();
                        continue;
                    case NalUnitTypes.NAL_TYPE_RSV_VCL24 /*24*/:
                        b = pq.m1847b(pfVar, 24);
                        qi = this.fq == null ? 0 : this.fq.length;
                        Object obj = new int[(b + qi)];
                        if (qi != 0) {
                            System.arraycopy(this.fq, 0, obj, 0, qi);
                        }
                        while (qi < obj.length - 1) {
                            obj[qi] = pfVar.ql();
                            pfVar.qi();
                            qi++;
                        }
                        obj[qi] = pfVar.ql();
                        this.fq = obj;
                        continue;
                    case NalUnitTypes.NAL_TYPE_RSV_VCL26 /*26*/:
                        int gp = pfVar.gp(pfVar.qp());
                        b = pfVar.getPosition();
                        qi = 0;
                        while (pfVar.qu() > 0) {
                            pfVar.ql();
                            qi++;
                        }
                        pfVar.gr(b);
                        b = this.fq == null ? 0 : this.fq.length;
                        Object obj2 = new int[(qi + b)];
                        if (b != 0) {
                            System.arraycopy(this.fq, 0, obj2, 0, b);
                        }
                        while (b < obj2.length) {
                            obj2[b] = pfVar.ql();
                            b++;
                        }
                        this.fq = obj2;
                        pfVar.gq(gp);
                        continue;
                    case ItemTouchHelper.END /*32*/:
                        this.name = pfVar.ql();
                        continue;
                    case NalUnitTypes.NAL_TYPE_UNSPEC48 /*48*/:
                        this.fs = pfVar.qm();
                        continue;
                    default:
                        if (!m3436a(pfVar, qi)) {
                            break;
                        }
                        continue;
                }
                return this;
            }
        }

        public C2459b m4149e() {
            this.fq = pq.awW;
            this.fr = 0;
            this.name = 0;
            this.fs = false;
            this.ft = false;
            this.awJ = null;
            this.awU = -1;
            return this;
        }

        public boolean equals(Object o) {
            if (o == this) {
                return true;
            }
            if (!(o instanceof C2459b)) {
                return false;
            }
            C2459b c2459b = (C2459b) o;
            return (pl.equals(this.fq, c2459b.fq) && this.fr == c2459b.fr && this.name == c2459b.name && this.fs == c2459b.fs && this.ft == c2459b.ft) ? m3437a((ph) c2459b) : false;
        }

        public int hashCode() {
            int i = 1231;
            int hashCode = ((this.fs ? 1231 : 1237) + ((((((pl.hashCode(this.fq) + 527) * 31) + this.fr) * 31) + this.name) * 31)) * 31;
            if (!this.ft) {
                i = 1237;
            }
            return ((hashCode + i) * 31) + qz();
        }
    }

    /* renamed from: com.google.android.gms.internal.c.c */
    public static final class C2460c extends ph<C2460c> {
        private static volatile C2460c[] fu;
        public String fv;
        public long fw;
        public long fx;
        public boolean fy;
        public long fz;

        public C2460c() {
            m4155g();
        }

        public static C2460c[] m4150f() {
            if (fu == null) {
                synchronized (pl.awT) {
                    if (fu == null) {
                        fu = new C2460c[0];
                    }
                }
            }
            return fu;
        }

        public void m4151a(pg pgVar) throws IOException {
            if (!this.fv.equals(BuildConfig.FLAVOR)) {
                pgVar.m1803b(1, this.fv);
            }
            if (this.fw != 0) {
                pgVar.m1802b(2, this.fw);
            }
            if (this.fx != 2147483647L) {
                pgVar.m1802b(3, this.fx);
            }
            if (this.fy) {
                pgVar.m1804b(4, this.fy);
            }
            if (this.fz != 0) {
                pgVar.m1802b(5, this.fz);
            }
            super.m3435a(pgVar);
        }

        public /* synthetic */ pn m4152b(pf pfVar) throws IOException {
            return m4154d(pfVar);
        }

        protected int m4153c() {
            int c = super.m3438c();
            if (!this.fv.equals(BuildConfig.FLAVOR)) {
                c += pg.m1787j(1, this.fv);
            }
            if (this.fw != 0) {
                c += pg.m1781d(2, this.fw);
            }
            if (this.fx != 2147483647L) {
                c += pg.m1781d(3, this.fx);
            }
            if (this.fy) {
                c += pg.m1780c(4, this.fy);
            }
            return this.fz != 0 ? c + pg.m1781d(5, this.fz) : c;
        }

        public C2460c m4154d(pf pfVar) throws IOException {
            while (true) {
                int qi = pfVar.qi();
                switch (qi) {
                    case FastDatePrinter.FULL /*0*/:
                        break;
                    case C0811R.styleable.WalletFragmentStyle_maskedWalletDetailsLogoImageType /*10*/:
                        this.fv = pfVar.readString();
                        continue;
                    case ItemTouchHelper.START /*16*/:
                        this.fw = pfVar.qk();
                        continue;
                    case NalUnitTypes.NAL_TYPE_RSV_VCL24 /*24*/:
                        this.fx = pfVar.qk();
                        continue;
                    case ItemTouchHelper.END /*32*/:
                        this.fy = pfVar.qm();
                        continue;
                    case MotionEventCompat.AXIS_GENERIC_9 /*40*/:
                        this.fz = pfVar.qk();
                        continue;
                    default:
                        if (!m3436a(pfVar, qi)) {
                            break;
                        }
                        continue;
                }
                return this;
            }
        }

        public boolean equals(Object o) {
            if (o == this) {
                return true;
            }
            if (!(o instanceof C2460c)) {
                return false;
            }
            C2460c c2460c = (C2460c) o;
            if (this.fv == null) {
                if (c2460c.fv != null) {
                    return false;
                }
            } else if (!this.fv.equals(c2460c.fv)) {
                return false;
            }
            return (this.fw == c2460c.fw && this.fx == c2460c.fx && this.fy == c2460c.fy && this.fz == c2460c.fz) ? m3437a((ph) c2460c) : false;
        }

        public C2460c m4155g() {
            this.fv = BuildConfig.FLAVOR;
            this.fw = 0;
            this.fx = 2147483647L;
            this.fy = false;
            this.fz = 0;
            this.awJ = null;
            this.awU = -1;
            return this;
        }

        public int hashCode() {
            return (((((this.fy ? 1231 : 1237) + (((((((this.fv == null ? 0 : this.fv.hashCode()) + 527) * 31) + ((int) (this.fw ^ (this.fw >>> 32)))) * 31) + ((int) (this.fx ^ (this.fx >>> 32)))) * 31)) * 31) + ((int) (this.fz ^ (this.fz >>> 32)))) * 31) + qz();
        }
    }

    /* renamed from: com.google.android.gms.internal.c.d */
    public static final class C2461d extends ph<C2461d> {
        public C2468a[] fA;
        public C2468a[] fB;
        public C2460c[] fC;

        public C2461d() {
            m4160h();
        }

        public void m4156a(pg pgVar) throws IOException {
            int i = 0;
            if (this.fA != null && this.fA.length > 0) {
                for (pn pnVar : this.fA) {
                    if (pnVar != null) {
                        pgVar.m1798a(1, pnVar);
                    }
                }
            }
            if (this.fB != null && this.fB.length > 0) {
                for (pn pnVar2 : this.fB) {
                    if (pnVar2 != null) {
                        pgVar.m1798a(2, pnVar2);
                    }
                }
            }
            if (this.fC != null && this.fC.length > 0) {
                while (i < this.fC.length) {
                    pn pnVar3 = this.fC[i];
                    if (pnVar3 != null) {
                        pgVar.m1798a(3, pnVar3);
                    }
                    i++;
                }
            }
            super.m3435a(pgVar);
        }

        public /* synthetic */ pn m4157b(pf pfVar) throws IOException {
            return m4159e(pfVar);
        }

        protected int m4158c() {
            int i;
            int i2 = 0;
            int c = super.m3438c();
            if (this.fA != null && this.fA.length > 0) {
                i = c;
                for (pn pnVar : this.fA) {
                    if (pnVar != null) {
                        i += pg.m1779c(1, pnVar);
                    }
                }
                c = i;
            }
            if (this.fB != null && this.fB.length > 0) {
                i = c;
                for (pn pnVar2 : this.fB) {
                    if (pnVar2 != null) {
                        i += pg.m1779c(2, pnVar2);
                    }
                }
                c = i;
            }
            if (this.fC != null && this.fC.length > 0) {
                while (i2 < this.fC.length) {
                    pn pnVar3 = this.fC[i2];
                    if (pnVar3 != null) {
                        c += pg.m1779c(3, pnVar3);
                    }
                    i2++;
                }
            }
            return c;
        }

        public C2461d m4159e(pf pfVar) throws IOException {
            while (true) {
                int qi = pfVar.qi();
                int b;
                Object obj;
                switch (qi) {
                    case FastDatePrinter.FULL /*0*/:
                        break;
                    case C0811R.styleable.WalletFragmentStyle_maskedWalletDetailsLogoImageType /*10*/:
                        b = pq.m1847b(pfVar, 10);
                        qi = this.fA == null ? 0 : this.fA.length;
                        obj = new C2468a[(b + qi)];
                        if (qi != 0) {
                            System.arraycopy(this.fA, 0, obj, 0, qi);
                        }
                        while (qi < obj.length - 1) {
                            obj[qi] = new C2468a();
                            pfVar.m1766a(obj[qi]);
                            pfVar.qi();
                            qi++;
                        }
                        obj[qi] = new C2468a();
                        pfVar.m1766a(obj[qi]);
                        this.fA = obj;
                        continue;
                    case NalUnitTypes.NAL_TYPE_BLA_N_LP /*18*/:
                        b = pq.m1847b(pfVar, 18);
                        qi = this.fB == null ? 0 : this.fB.length;
                        obj = new C2468a[(b + qi)];
                        if (qi != 0) {
                            System.arraycopy(this.fB, 0, obj, 0, qi);
                        }
                        while (qi < obj.length - 1) {
                            obj[qi] = new C2468a();
                            pfVar.m1766a(obj[qi]);
                            pfVar.qi();
                            qi++;
                        }
                        obj[qi] = new C2468a();
                        pfVar.m1766a(obj[qi]);
                        this.fB = obj;
                        continue;
                    case NalUnitTypes.NAL_TYPE_RSV_VCL26 /*26*/:
                        b = pq.m1847b(pfVar, 26);
                        qi = this.fC == null ? 0 : this.fC.length;
                        obj = new C2460c[(b + qi)];
                        if (qi != 0) {
                            System.arraycopy(this.fC, 0, obj, 0, qi);
                        }
                        while (qi < obj.length - 1) {
                            obj[qi] = new C2460c();
                            pfVar.m1766a(obj[qi]);
                            pfVar.qi();
                            qi++;
                        }
                        obj[qi] = new C2460c();
                        pfVar.m1766a(obj[qi]);
                        this.fC = obj;
                        continue;
                    default:
                        if (!m3436a(pfVar, qi)) {
                            break;
                        }
                        continue;
                }
                return this;
            }
        }

        public boolean equals(Object o) {
            if (o == this) {
                return true;
            }
            if (!(o instanceof C2461d)) {
                return false;
            }
            C2461d c2461d = (C2461d) o;
            return (pl.equals(this.fA, c2461d.fA) && pl.equals(this.fB, c2461d.fB) && pl.equals(this.fC, c2461d.fC)) ? m3437a((ph) c2461d) : false;
        }

        public C2461d m4160h() {
            this.fA = C2468a.m4215r();
            this.fB = C2468a.m4215r();
            this.fC = C2460c.m4150f();
            this.awJ = null;
            this.awU = -1;
            return this;
        }

        public int hashCode() {
            return ((((((pl.hashCode(this.fA) + 527) * 31) + pl.hashCode(this.fB)) * 31) + pl.hashCode(this.fC)) * 31) + qz();
        }
    }

    /* renamed from: com.google.android.gms.internal.c.e */
    public static final class C2462e extends ph<C2462e> {
        private static volatile C2462e[] fD;
        public int key;
        public int value;

        public C2462e() {
            m4166j();
        }

        public static C2462e[] m4161i() {
            if (fD == null) {
                synchronized (pl.awT) {
                    if (fD == null) {
                        fD = new C2462e[0];
                    }
                }
            }
            return fD;
        }

        public void m4162a(pg pgVar) throws IOException {
            pgVar.m1812s(1, this.key);
            pgVar.m1812s(2, this.value);
            super.m3435a(pgVar);
        }

        public /* synthetic */ pn m4163b(pf pfVar) throws IOException {
            return m4165f(pfVar);
        }

        protected int m4164c() {
            return (super.m3438c() + pg.m1790u(1, this.key)) + pg.m1790u(2, this.value);
        }

        public boolean equals(Object o) {
            if (o == this) {
                return true;
            }
            if (!(o instanceof C2462e)) {
                return false;
            }
            C2462e c2462e = (C2462e) o;
            return (this.key == c2462e.key && this.value == c2462e.value) ? m3437a((ph) c2462e) : false;
        }

        public C2462e m4165f(pf pfVar) throws IOException {
            while (true) {
                int qi = pfVar.qi();
                switch (qi) {
                    case FastDatePrinter.FULL /*0*/:
                        break;
                    case XtraBox.MP4_XTRA_BT_UNICODE /*8*/:
                        this.key = pfVar.ql();
                        continue;
                    case ItemTouchHelper.START /*16*/:
                        this.value = pfVar.ql();
                        continue;
                    default:
                        if (!m3436a(pfVar, qi)) {
                            break;
                        }
                        continue;
                }
                return this;
            }
        }

        public int hashCode() {
            return ((((this.key + 527) * 31) + this.value) * 31) + qz();
        }

        public C2462e m4166j() {
            this.key = 0;
            this.value = 0;
            this.awJ = null;
            this.awU = -1;
            return this;
        }
    }

    /* renamed from: com.google.android.gms.internal.c.f */
    public static final class C2463f extends ph<C2463f> {
        public String[] fE;
        public String[] fF;
        public C2468a[] fG;
        public C2462e[] fH;
        public C2459b[] fI;
        public C2459b[] fJ;
        public C2459b[] fK;
        public C2464g[] fL;
        public String fM;
        public String fN;
        public String fO;
        public C2458a fP;
        public float fQ;
        public boolean fR;
        public String[] fS;
        public int fT;
        public String version;

        public C2463f() {
            m4172k();
        }

        public static C2463f m4167a(byte[] bArr) throws pm {
            return (C2463f) pn.m1835a(new C2463f(), bArr);
        }

        public void m4168a(pg pgVar) throws IOException {
            int i = 0;
            if (this.fF != null && this.fF.length > 0) {
                for (String str : this.fF) {
                    if (str != null) {
                        pgVar.m1803b(1, str);
                    }
                }
            }
            if (this.fG != null && this.fG.length > 0) {
                for (pn pnVar : this.fG) {
                    if (pnVar != null) {
                        pgVar.m1798a(2, pnVar);
                    }
                }
            }
            if (this.fH != null && this.fH.length > 0) {
                for (pn pnVar2 : this.fH) {
                    if (pnVar2 != null) {
                        pgVar.m1798a(3, pnVar2);
                    }
                }
            }
            if (this.fI != null && this.fI.length > 0) {
                for (pn pnVar22 : this.fI) {
                    if (pnVar22 != null) {
                        pgVar.m1798a(4, pnVar22);
                    }
                }
            }
            if (this.fJ != null && this.fJ.length > 0) {
                for (pn pnVar222 : this.fJ) {
                    if (pnVar222 != null) {
                        pgVar.m1798a(5, pnVar222);
                    }
                }
            }
            if (this.fK != null && this.fK.length > 0) {
                for (pn pnVar2222 : this.fK) {
                    if (pnVar2222 != null) {
                        pgVar.m1798a(6, pnVar2222);
                    }
                }
            }
            if (this.fL != null && this.fL.length > 0) {
                for (pn pnVar22222 : this.fL) {
                    if (pnVar22222 != null) {
                        pgVar.m1798a(7, pnVar22222);
                    }
                }
            }
            if (!this.fM.equals(BuildConfig.FLAVOR)) {
                pgVar.m1803b(9, this.fM);
            }
            if (!this.fN.equals(BuildConfig.FLAVOR)) {
                pgVar.m1803b(10, this.fN);
            }
            if (!this.fO.equals("0")) {
                pgVar.m1803b(12, this.fO);
            }
            if (!this.version.equals(BuildConfig.FLAVOR)) {
                pgVar.m1803b(13, this.version);
            }
            if (this.fP != null) {
                pgVar.m1798a(14, this.fP);
            }
            if (Float.floatToIntBits(this.fQ) != Float.floatToIntBits(0.0f)) {
                pgVar.m1801b(15, this.fQ);
            }
            if (this.fS != null && this.fS.length > 0) {
                for (String str2 : this.fS) {
                    if (str2 != null) {
                        pgVar.m1803b(16, str2);
                    }
                }
            }
            if (this.fT != 0) {
                pgVar.m1812s(17, this.fT);
            }
            if (this.fR) {
                pgVar.m1804b(18, this.fR);
            }
            if (this.fE != null && this.fE.length > 0) {
                while (i < this.fE.length) {
                    String str3 = this.fE[i];
                    if (str3 != null) {
                        pgVar.m1803b(19, str3);
                    }
                    i++;
                }
            }
            super.m3435a(pgVar);
        }

        public /* synthetic */ pn m4169b(pf pfVar) throws IOException {
            return m4171g(pfVar);
        }

        protected int m4170c() {
            int i;
            int i2;
            int i3;
            int i4 = 0;
            int c = super.m3438c();
            if (this.fF == null || this.fF.length <= 0) {
                i = c;
            } else {
                i2 = 0;
                i3 = 0;
                for (String str : this.fF) {
                    if (str != null) {
                        i3++;
                        i2 += pg.di(str);
                    }
                }
                i = (c + i2) + (i3 * 1);
            }
            if (this.fG != null && this.fG.length > 0) {
                i2 = i;
                for (pn pnVar : this.fG) {
                    if (pnVar != null) {
                        i2 += pg.m1779c(2, pnVar);
                    }
                }
                i = i2;
            }
            if (this.fH != null && this.fH.length > 0) {
                i2 = i;
                for (pn pnVar2 : this.fH) {
                    if (pnVar2 != null) {
                        i2 += pg.m1779c(3, pnVar2);
                    }
                }
                i = i2;
            }
            if (this.fI != null && this.fI.length > 0) {
                i2 = i;
                for (pn pnVar22 : this.fI) {
                    if (pnVar22 != null) {
                        i2 += pg.m1779c(4, pnVar22);
                    }
                }
                i = i2;
            }
            if (this.fJ != null && this.fJ.length > 0) {
                i2 = i;
                for (pn pnVar222 : this.fJ) {
                    if (pnVar222 != null) {
                        i2 += pg.m1779c(5, pnVar222);
                    }
                }
                i = i2;
            }
            if (this.fK != null && this.fK.length > 0) {
                i2 = i;
                for (pn pnVar2222 : this.fK) {
                    if (pnVar2222 != null) {
                        i2 += pg.m1779c(6, pnVar2222);
                    }
                }
                i = i2;
            }
            if (this.fL != null && this.fL.length > 0) {
                i2 = i;
                for (pn pnVar22222 : this.fL) {
                    if (pnVar22222 != null) {
                        i2 += pg.m1779c(7, pnVar22222);
                    }
                }
                i = i2;
            }
            if (!this.fM.equals(BuildConfig.FLAVOR)) {
                i += pg.m1787j(9, this.fM);
            }
            if (!this.fN.equals(BuildConfig.FLAVOR)) {
                i += pg.m1787j(10, this.fN);
            }
            if (!this.fO.equals("0")) {
                i += pg.m1787j(12, this.fO);
            }
            if (!this.version.equals(BuildConfig.FLAVOR)) {
                i += pg.m1787j(13, this.version);
            }
            if (this.fP != null) {
                i += pg.m1779c(14, this.fP);
            }
            if (Float.floatToIntBits(this.fQ) != Float.floatToIntBits(0.0f)) {
                i += pg.m1778c(15, this.fQ);
            }
            if (this.fS != null && this.fS.length > 0) {
                i3 = 0;
                c = 0;
                for (String str2 : this.fS) {
                    if (str2 != null) {
                        c++;
                        i3 += pg.di(str2);
                    }
                }
                i = (i + i3) + (c * 2);
            }
            if (this.fT != 0) {
                i += pg.m1790u(17, this.fT);
            }
            if (this.fR) {
                i += pg.m1780c(18, this.fR);
            }
            if (this.fE == null || this.fE.length <= 0) {
                return i;
            }
            i2 = 0;
            i3 = 0;
            while (i4 < this.fE.length) {
                String str3 = this.fE[i4];
                if (str3 != null) {
                    i3++;
                    i2 += pg.di(str3);
                }
                i4++;
            }
            return (i + i2) + (i3 * 2);
        }

        public boolean equals(Object o) {
            if (o == this) {
                return true;
            }
            if (!(o instanceof C2463f)) {
                return false;
            }
            C2463f c2463f = (C2463f) o;
            if (!pl.equals(this.fE, c2463f.fE) || !pl.equals(this.fF, c2463f.fF) || !pl.equals(this.fG, c2463f.fG) || !pl.equals(this.fH, c2463f.fH) || !pl.equals(this.fI, c2463f.fI) || !pl.equals(this.fJ, c2463f.fJ) || !pl.equals(this.fK, c2463f.fK) || !pl.equals(this.fL, c2463f.fL)) {
                return false;
            }
            if (this.fM == null) {
                if (c2463f.fM != null) {
                    return false;
                }
            } else if (!this.fM.equals(c2463f.fM)) {
                return false;
            }
            if (this.fN == null) {
                if (c2463f.fN != null) {
                    return false;
                }
            } else if (!this.fN.equals(c2463f.fN)) {
                return false;
            }
            if (this.fO == null) {
                if (c2463f.fO != null) {
                    return false;
                }
            } else if (!this.fO.equals(c2463f.fO)) {
                return false;
            }
            if (this.version == null) {
                if (c2463f.version != null) {
                    return false;
                }
            } else if (!this.version.equals(c2463f.version)) {
                return false;
            }
            if (this.fP == null) {
                if (c2463f.fP != null) {
                    return false;
                }
            } else if (!this.fP.equals(c2463f.fP)) {
                return false;
            }
            return (Float.floatToIntBits(this.fQ) == Float.floatToIntBits(c2463f.fQ) && this.fR == c2463f.fR && pl.equals(this.fS, c2463f.fS) && this.fT == c2463f.fT) ? m3437a((ph) c2463f) : false;
        }

        public C2463f m4171g(pf pfVar) throws IOException {
            while (true) {
                int qi = pfVar.qi();
                int b;
                Object obj;
                switch (qi) {
                    case FastDatePrinter.FULL /*0*/:
                        break;
                    case C0811R.styleable.WalletFragmentStyle_maskedWalletDetailsLogoImageType /*10*/:
                        b = pq.m1847b(pfVar, 10);
                        qi = this.fF == null ? 0 : this.fF.length;
                        obj = new String[(b + qi)];
                        if (qi != 0) {
                            System.arraycopy(this.fF, 0, obj, 0, qi);
                        }
                        while (qi < obj.length - 1) {
                            obj[qi] = pfVar.readString();
                            pfVar.qi();
                            qi++;
                        }
                        obj[qi] = pfVar.readString();
                        this.fF = obj;
                        continue;
                    case NalUnitTypes.NAL_TYPE_BLA_N_LP /*18*/:
                        b = pq.m1847b(pfVar, 18);
                        qi = this.fG == null ? 0 : this.fG.length;
                        obj = new C2468a[(b + qi)];
                        if (qi != 0) {
                            System.arraycopy(this.fG, 0, obj, 0, qi);
                        }
                        while (qi < obj.length - 1) {
                            obj[qi] = new C2468a();
                            pfVar.m1766a(obj[qi]);
                            pfVar.qi();
                            qi++;
                        }
                        obj[qi] = new C2468a();
                        pfVar.m1766a(obj[qi]);
                        this.fG = obj;
                        continue;
                    case NalUnitTypes.NAL_TYPE_RSV_VCL26 /*26*/:
                        b = pq.m1847b(pfVar, 26);
                        qi = this.fH == null ? 0 : this.fH.length;
                        obj = new C2462e[(b + qi)];
                        if (qi != 0) {
                            System.arraycopy(this.fH, 0, obj, 0, qi);
                        }
                        while (qi < obj.length - 1) {
                            obj[qi] = new C2462e();
                            pfVar.m1766a(obj[qi]);
                            pfVar.qi();
                            qi++;
                        }
                        obj[qi] = new C2462e();
                        pfVar.m1766a(obj[qi]);
                        this.fH = obj;
                        continue;
                    case TLRPC.LAYER /*34*/:
                        b = pq.m1847b(pfVar, 34);
                        qi = this.fI == null ? 0 : this.fI.length;
                        obj = new C2459b[(b + qi)];
                        if (qi != 0) {
                            System.arraycopy(this.fI, 0, obj, 0, qi);
                        }
                        while (qi < obj.length - 1) {
                            obj[qi] = new C2459b();
                            pfVar.m1766a(obj[qi]);
                            pfVar.qi();
                            qi++;
                        }
                        obj[qi] = new C2459b();
                        pfVar.m1766a(obj[qi]);
                        this.fI = obj;
                        continue;
                    case NalUnitTypes.NAL_TYPE_RSV_NVCL42 /*42*/:
                        b = pq.m1847b(pfVar, 42);
                        qi = this.fJ == null ? 0 : this.fJ.length;
                        obj = new C2459b[(b + qi)];
                        if (qi != 0) {
                            System.arraycopy(this.fJ, 0, obj, 0, qi);
                        }
                        while (qi < obj.length - 1) {
                            obj[qi] = new C2459b();
                            pfVar.m1766a(obj[qi]);
                            pfVar.qi();
                            qi++;
                        }
                        obj[qi] = new C2459b();
                        pfVar.m1766a(obj[qi]);
                        this.fJ = obj;
                        continue;
                    case NalUnitTypes.NAL_TYPE_UNSPEC50 /*50*/:
                        b = pq.m1847b(pfVar, 50);
                        qi = this.fK == null ? 0 : this.fK.length;
                        obj = new C2459b[(b + qi)];
                        if (qi != 0) {
                            System.arraycopy(this.fK, 0, obj, 0, qi);
                        }
                        while (qi < obj.length - 1) {
                            obj[qi] = new C2459b();
                            pfVar.m1766a(obj[qi]);
                            pfVar.qi();
                            qi++;
                        }
                        obj[qi] = new C2459b();
                        pfVar.m1766a(obj[qi]);
                        this.fK = obj;
                        continue;
                    case 58:
                        b = pq.m1847b(pfVar, 58);
                        qi = this.fL == null ? 0 : this.fL.length;
                        obj = new C2464g[(b + qi)];
                        if (qi != 0) {
                            System.arraycopy(this.fL, 0, obj, 0, qi);
                        }
                        while (qi < obj.length - 1) {
                            obj[qi] = new C2464g();
                            pfVar.m1766a(obj[qi]);
                            pfVar.qi();
                            qi++;
                        }
                        obj[qi] = new C2464g();
                        pfVar.m1766a(obj[qi]);
                        this.fL = obj;
                        continue;
                    case 74:
                        this.fM = pfVar.readString();
                        continue;
                    case 82:
                        this.fN = pfVar.readString();
                        continue;
                    case 98:
                        this.fO = pfVar.readString();
                        continue;
                    case 106:
                        this.version = pfVar.readString();
                        continue;
                    case 114:
                        if (this.fP == null) {
                            this.fP = new C2458a();
                        }
                        pfVar.m1766a(this.fP);
                        continue;
                    case 125:
                        this.fQ = pfVar.readFloat();
                        continue;
                    case TransportMediator.KEYCODE_MEDIA_RECORD /*130*/:
                        b = pq.m1847b(pfVar, TransportMediator.KEYCODE_MEDIA_RECORD);
                        qi = this.fS == null ? 0 : this.fS.length;
                        obj = new String[(b + qi)];
                        if (qi != 0) {
                            System.arraycopy(this.fS, 0, obj, 0, qi);
                        }
                        while (qi < obj.length - 1) {
                            obj[qi] = pfVar.readString();
                            pfVar.qi();
                            qi++;
                        }
                        obj[qi] = pfVar.readString();
                        this.fS = obj;
                        continue;
                    case 136:
                        this.fT = pfVar.ql();
                        continue;
                    case 144:
                        this.fR = pfVar.qm();
                        continue;
                    case 154:
                        b = pq.m1847b(pfVar, 154);
                        qi = this.fE == null ? 0 : this.fE.length;
                        obj = new String[(b + qi)];
                        if (qi != 0) {
                            System.arraycopy(this.fE, 0, obj, 0, qi);
                        }
                        while (qi < obj.length - 1) {
                            obj[qi] = pfVar.readString();
                            pfVar.qi();
                            qi++;
                        }
                        obj[qi] = pfVar.readString();
                        this.fE = obj;
                        continue;
                    default:
                        if (!m3436a(pfVar, qi)) {
                            break;
                        }
                        continue;
                }
                return this;
            }
        }

        public int hashCode() {
            int i = 0;
            int hashCode = ((this.version == null ? 0 : this.version.hashCode()) + (((this.fO == null ? 0 : this.fO.hashCode()) + (((this.fN == null ? 0 : this.fN.hashCode()) + (((this.fM == null ? 0 : this.fM.hashCode()) + ((((((((((((((((pl.hashCode(this.fE) + 527) * 31) + pl.hashCode(this.fF)) * 31) + pl.hashCode(this.fG)) * 31) + pl.hashCode(this.fH)) * 31) + pl.hashCode(this.fI)) * 31) + pl.hashCode(this.fJ)) * 31) + pl.hashCode(this.fK)) * 31) + pl.hashCode(this.fL)) * 31)) * 31)) * 31)) * 31)) * 31;
            if (this.fP != null) {
                i = this.fP.hashCode();
            }
            return (((((((this.fR ? 1231 : 1237) + ((((hashCode + i) * 31) + Float.floatToIntBits(this.fQ)) * 31)) * 31) + pl.hashCode(this.fS)) * 31) + this.fT) * 31) + qz();
        }

        public C2463f m4172k() {
            this.fE = pq.axb;
            this.fF = pq.axb;
            this.fG = C2468a.m4215r();
            this.fH = C2462e.m4161i();
            this.fI = C2459b.m4144d();
            this.fJ = C2459b.m4144d();
            this.fK = C2459b.m4144d();
            this.fL = C2464g.m4173l();
            this.fM = BuildConfig.FLAVOR;
            this.fN = BuildConfig.FLAVOR;
            this.fO = "0";
            this.version = BuildConfig.FLAVOR;
            this.fP = null;
            this.fQ = 0.0f;
            this.fR = false;
            this.fS = pq.axb;
            this.fT = 0;
            this.awJ = null;
            this.awU = -1;
            return this;
        }
    }

    /* renamed from: com.google.android.gms.internal.c.g */
    public static final class C2464g extends ph<C2464g> {
        private static volatile C2464g[] fU;
        public int[] fV;
        public int[] fW;
        public int[] fX;
        public int[] fY;
        public int[] fZ;
        public int[] ga;
        public int[] gb;
        public int[] gc;
        public int[] gd;
        public int[] ge;

        public C2464g() {
            m4178m();
        }

        public static C2464g[] m4173l() {
            if (fU == null) {
                synchronized (pl.awT) {
                    if (fU == null) {
                        fU = new C2464g[0];
                    }
                }
            }
            return fU;
        }

        public void m4174a(pg pgVar) throws IOException {
            int i = 0;
            if (this.fV != null && this.fV.length > 0) {
                for (int s : this.fV) {
                    pgVar.m1812s(1, s);
                }
            }
            if (this.fW != null && this.fW.length > 0) {
                for (int s2 : this.fW) {
                    pgVar.m1812s(2, s2);
                }
            }
            if (this.fX != null && this.fX.length > 0) {
                for (int s22 : this.fX) {
                    pgVar.m1812s(3, s22);
                }
            }
            if (this.fY != null && this.fY.length > 0) {
                for (int s222 : this.fY) {
                    pgVar.m1812s(4, s222);
                }
            }
            if (this.fZ != null && this.fZ.length > 0) {
                for (int s2222 : this.fZ) {
                    pgVar.m1812s(5, s2222);
                }
            }
            if (this.ga != null && this.ga.length > 0) {
                for (int s22222 : this.ga) {
                    pgVar.m1812s(6, s22222);
                }
            }
            if (this.gb != null && this.gb.length > 0) {
                for (int s222222 : this.gb) {
                    pgVar.m1812s(7, s222222);
                }
            }
            if (this.gc != null && this.gc.length > 0) {
                for (int s2222222 : this.gc) {
                    pgVar.m1812s(8, s2222222);
                }
            }
            if (this.gd != null && this.gd.length > 0) {
                for (int s22222222 : this.gd) {
                    pgVar.m1812s(9, s22222222);
                }
            }
            if (this.ge != null && this.ge.length > 0) {
                while (i < this.ge.length) {
                    pgVar.m1812s(10, this.ge[i]);
                    i++;
                }
            }
            super.m3435a(pgVar);
        }

        public /* synthetic */ pn m4175b(pf pfVar) throws IOException {
            return m4177h(pfVar);
        }

        protected int m4176c() {
            int i;
            int i2;
            int i3 = 0;
            int c = super.m3438c();
            if (this.fV == null || this.fV.length <= 0) {
                i = c;
            } else {
                i2 = 0;
                for (int gw : this.fV) {
                    i2 += pg.gw(gw);
                }
                i = (c + i2) + (this.fV.length * 1);
            }
            if (this.fW != null && this.fW.length > 0) {
                c = 0;
                for (int gw2 : this.fW) {
                    c += pg.gw(gw2);
                }
                i = (i + c) + (this.fW.length * 1);
            }
            if (this.fX != null && this.fX.length > 0) {
                c = 0;
                for (int gw22 : this.fX) {
                    c += pg.gw(gw22);
                }
                i = (i + c) + (this.fX.length * 1);
            }
            if (this.fY != null && this.fY.length > 0) {
                c = 0;
                for (int gw222 : this.fY) {
                    c += pg.gw(gw222);
                }
                i = (i + c) + (this.fY.length * 1);
            }
            if (this.fZ != null && this.fZ.length > 0) {
                c = 0;
                for (int gw2222 : this.fZ) {
                    c += pg.gw(gw2222);
                }
                i = (i + c) + (this.fZ.length * 1);
            }
            if (this.ga != null && this.ga.length > 0) {
                c = 0;
                for (int gw22222 : this.ga) {
                    c += pg.gw(gw22222);
                }
                i = (i + c) + (this.ga.length * 1);
            }
            if (this.gb != null && this.gb.length > 0) {
                c = 0;
                for (int gw222222 : this.gb) {
                    c += pg.gw(gw222222);
                }
                i = (i + c) + (this.gb.length * 1);
            }
            if (this.gc != null && this.gc.length > 0) {
                c = 0;
                for (int gw2222222 : this.gc) {
                    c += pg.gw(gw2222222);
                }
                i = (i + c) + (this.gc.length * 1);
            }
            if (this.gd != null && this.gd.length > 0) {
                c = 0;
                for (int gw22222222 : this.gd) {
                    c += pg.gw(gw22222222);
                }
                i = (i + c) + (this.gd.length * 1);
            }
            if (this.ge == null || this.ge.length <= 0) {
                return i;
            }
            i2 = 0;
            while (i3 < this.ge.length) {
                i2 += pg.gw(this.ge[i3]);
                i3++;
            }
            return (i + i2) + (this.ge.length * 1);
        }

        public boolean equals(Object o) {
            if (o == this) {
                return true;
            }
            if (!(o instanceof C2464g)) {
                return false;
            }
            C2464g c2464g = (C2464g) o;
            return (pl.equals(this.fV, c2464g.fV) && pl.equals(this.fW, c2464g.fW) && pl.equals(this.fX, c2464g.fX) && pl.equals(this.fY, c2464g.fY) && pl.equals(this.fZ, c2464g.fZ) && pl.equals(this.ga, c2464g.ga) && pl.equals(this.gb, c2464g.gb) && pl.equals(this.gc, c2464g.gc) && pl.equals(this.gd, c2464g.gd) && pl.equals(this.ge, c2464g.ge)) ? m3437a((ph) c2464g) : false;
        }

        public C2464g m4177h(pf pfVar) throws IOException {
            while (true) {
                int qi = pfVar.qi();
                int b;
                Object obj;
                int gp;
                Object obj2;
                switch (qi) {
                    case FastDatePrinter.FULL /*0*/:
                        break;
                    case XtraBox.MP4_XTRA_BT_UNICODE /*8*/:
                        b = pq.m1847b(pfVar, 8);
                        qi = this.fV == null ? 0 : this.fV.length;
                        obj = new int[(b + qi)];
                        if (qi != 0) {
                            System.arraycopy(this.fV, 0, obj, 0, qi);
                        }
                        while (qi < obj.length - 1) {
                            obj[qi] = pfVar.ql();
                            pfVar.qi();
                            qi++;
                        }
                        obj[qi] = pfVar.ql();
                        this.fV = obj;
                        continue;
                    case C0811R.styleable.WalletFragmentStyle_maskedWalletDetailsLogoImageType /*10*/:
                        gp = pfVar.gp(pfVar.qp());
                        b = pfVar.getPosition();
                        qi = 0;
                        while (pfVar.qu() > 0) {
                            pfVar.ql();
                            qi++;
                        }
                        pfVar.gr(b);
                        b = this.fV == null ? 0 : this.fV.length;
                        obj2 = new int[(qi + b)];
                        if (b != 0) {
                            System.arraycopy(this.fV, 0, obj2, 0, b);
                        }
                        while (b < obj2.length) {
                            obj2[b] = pfVar.ql();
                            b++;
                        }
                        this.fV = obj2;
                        pfVar.gq(gp);
                        continue;
                    case ItemTouchHelper.START /*16*/:
                        b = pq.m1847b(pfVar, 16);
                        qi = this.fW == null ? 0 : this.fW.length;
                        obj = new int[(b + qi)];
                        if (qi != 0) {
                            System.arraycopy(this.fW, 0, obj, 0, qi);
                        }
                        while (qi < obj.length - 1) {
                            obj[qi] = pfVar.ql();
                            pfVar.qi();
                            qi++;
                        }
                        obj[qi] = pfVar.ql();
                        this.fW = obj;
                        continue;
                    case NalUnitTypes.NAL_TYPE_BLA_N_LP /*18*/:
                        gp = pfVar.gp(pfVar.qp());
                        b = pfVar.getPosition();
                        qi = 0;
                        while (pfVar.qu() > 0) {
                            pfVar.ql();
                            qi++;
                        }
                        pfVar.gr(b);
                        b = this.fW == null ? 0 : this.fW.length;
                        obj2 = new int[(qi + b)];
                        if (b != 0) {
                            System.arraycopy(this.fW, 0, obj2, 0, b);
                        }
                        while (b < obj2.length) {
                            obj2[b] = pfVar.ql();
                            b++;
                        }
                        this.fW = obj2;
                        pfVar.gq(gp);
                        continue;
                    case NalUnitTypes.NAL_TYPE_RSV_VCL24 /*24*/:
                        b = pq.m1847b(pfVar, 24);
                        qi = this.fX == null ? 0 : this.fX.length;
                        obj = new int[(b + qi)];
                        if (qi != 0) {
                            System.arraycopy(this.fX, 0, obj, 0, qi);
                        }
                        while (qi < obj.length - 1) {
                            obj[qi] = pfVar.ql();
                            pfVar.qi();
                            qi++;
                        }
                        obj[qi] = pfVar.ql();
                        this.fX = obj;
                        continue;
                    case NalUnitTypes.NAL_TYPE_RSV_VCL26 /*26*/:
                        gp = pfVar.gp(pfVar.qp());
                        b = pfVar.getPosition();
                        qi = 0;
                        while (pfVar.qu() > 0) {
                            pfVar.ql();
                            qi++;
                        }
                        pfVar.gr(b);
                        b = this.fX == null ? 0 : this.fX.length;
                        obj2 = new int[(qi + b)];
                        if (b != 0) {
                            System.arraycopy(this.fX, 0, obj2, 0, b);
                        }
                        while (b < obj2.length) {
                            obj2[b] = pfVar.ql();
                            b++;
                        }
                        this.fX = obj2;
                        pfVar.gq(gp);
                        continue;
                    case ItemTouchHelper.END /*32*/:
                        b = pq.m1847b(pfVar, 32);
                        qi = this.fY == null ? 0 : this.fY.length;
                        obj = new int[(b + qi)];
                        if (qi != 0) {
                            System.arraycopy(this.fY, 0, obj, 0, qi);
                        }
                        while (qi < obj.length - 1) {
                            obj[qi] = pfVar.ql();
                            pfVar.qi();
                            qi++;
                        }
                        obj[qi] = pfVar.ql();
                        this.fY = obj;
                        continue;
                    case TLRPC.LAYER /*34*/:
                        gp = pfVar.gp(pfVar.qp());
                        b = pfVar.getPosition();
                        qi = 0;
                        while (pfVar.qu() > 0) {
                            pfVar.ql();
                            qi++;
                        }
                        pfVar.gr(b);
                        b = this.fY == null ? 0 : this.fY.length;
                        obj2 = new int[(qi + b)];
                        if (b != 0) {
                            System.arraycopy(this.fY, 0, obj2, 0, b);
                        }
                        while (b < obj2.length) {
                            obj2[b] = pfVar.ql();
                            b++;
                        }
                        this.fY = obj2;
                        pfVar.gq(gp);
                        continue;
                    case MotionEventCompat.AXIS_GENERIC_9 /*40*/:
                        b = pq.m1847b(pfVar, 40);
                        qi = this.fZ == null ? 0 : this.fZ.length;
                        obj = new int[(b + qi)];
                        if (qi != 0) {
                            System.arraycopy(this.fZ, 0, obj, 0, qi);
                        }
                        while (qi < obj.length - 1) {
                            obj[qi] = pfVar.ql();
                            pfVar.qi();
                            qi++;
                        }
                        obj[qi] = pfVar.ql();
                        this.fZ = obj;
                        continue;
                    case NalUnitTypes.NAL_TYPE_RSV_NVCL42 /*42*/:
                        gp = pfVar.gp(pfVar.qp());
                        b = pfVar.getPosition();
                        qi = 0;
                        while (pfVar.qu() > 0) {
                            pfVar.ql();
                            qi++;
                        }
                        pfVar.gr(b);
                        b = this.fZ == null ? 0 : this.fZ.length;
                        obj2 = new int[(qi + b)];
                        if (b != 0) {
                            System.arraycopy(this.fZ, 0, obj2, 0, b);
                        }
                        while (b < obj2.length) {
                            obj2[b] = pfVar.ql();
                            b++;
                        }
                        this.fZ = obj2;
                        pfVar.gq(gp);
                        continue;
                    case NalUnitTypes.NAL_TYPE_UNSPEC48 /*48*/:
                        b = pq.m1847b(pfVar, 48);
                        qi = this.ga == null ? 0 : this.ga.length;
                        obj = new int[(b + qi)];
                        if (qi != 0) {
                            System.arraycopy(this.ga, 0, obj, 0, qi);
                        }
                        while (qi < obj.length - 1) {
                            obj[qi] = pfVar.ql();
                            pfVar.qi();
                            qi++;
                        }
                        obj[qi] = pfVar.ql();
                        this.ga = obj;
                        continue;
                    case NalUnitTypes.NAL_TYPE_UNSPEC50 /*50*/:
                        gp = pfVar.gp(pfVar.qp());
                        b = pfVar.getPosition();
                        qi = 0;
                        while (pfVar.qu() > 0) {
                            pfVar.ql();
                            qi++;
                        }
                        pfVar.gr(b);
                        b = this.ga == null ? 0 : this.ga.length;
                        obj2 = new int[(qi + b)];
                        if (b != 0) {
                            System.arraycopy(this.ga, 0, obj2, 0, b);
                        }
                        while (b < obj2.length) {
                            obj2[b] = pfVar.ql();
                            b++;
                        }
                        this.ga = obj2;
                        pfVar.gq(gp);
                        continue;
                    case 56:
                        b = pq.m1847b(pfVar, 56);
                        qi = this.gb == null ? 0 : this.gb.length;
                        obj = new int[(b + qi)];
                        if (qi != 0) {
                            System.arraycopy(this.gb, 0, obj, 0, qi);
                        }
                        while (qi < obj.length - 1) {
                            obj[qi] = pfVar.ql();
                            pfVar.qi();
                            qi++;
                        }
                        obj[qi] = pfVar.ql();
                        this.gb = obj;
                        continue;
                    case 58:
                        gp = pfVar.gp(pfVar.qp());
                        b = pfVar.getPosition();
                        qi = 0;
                        while (pfVar.qu() > 0) {
                            pfVar.ql();
                            qi++;
                        }
                        pfVar.gr(b);
                        b = this.gb == null ? 0 : this.gb.length;
                        obj2 = new int[(qi + b)];
                        if (b != 0) {
                            System.arraycopy(this.gb, 0, obj2, 0, b);
                        }
                        while (b < obj2.length) {
                            obj2[b] = pfVar.ql();
                            b++;
                        }
                        this.gb = obj2;
                        pfVar.gq(gp);
                        continue;
                    case MessagesController.UPDATE_MASK_USER_PRINT /*64*/:
                        b = pq.m1847b(pfVar, 64);
                        qi = this.gc == null ? 0 : this.gc.length;
                        obj = new int[(b + qi)];
                        if (qi != 0) {
                            System.arraycopy(this.gc, 0, obj, 0, qi);
                        }
                        while (qi < obj.length - 1) {
                            obj[qi] = pfVar.ql();
                            pfVar.qi();
                            qi++;
                        }
                        obj[qi] = pfVar.ql();
                        this.gc = obj;
                        continue;
                    case 66:
                        gp = pfVar.gp(pfVar.qp());
                        b = pfVar.getPosition();
                        qi = 0;
                        while (pfVar.qu() > 0) {
                            pfVar.ql();
                            qi++;
                        }
                        pfVar.gr(b);
                        b = this.gc == null ? 0 : this.gc.length;
                        obj2 = new int[(qi + b)];
                        if (b != 0) {
                            System.arraycopy(this.gc, 0, obj2, 0, b);
                        }
                        while (b < obj2.length) {
                            obj2[b] = pfVar.ql();
                            b++;
                        }
                        this.gc = obj2;
                        pfVar.gq(gp);
                        continue;
                    case XtraBox.MP4_XTRA_BT_GUID /*72*/:
                        b = pq.m1847b(pfVar, 72);
                        qi = this.gd == null ? 0 : this.gd.length;
                        obj = new int[(b + qi)];
                        if (qi != 0) {
                            System.arraycopy(this.gd, 0, obj, 0, qi);
                        }
                        while (qi < obj.length - 1) {
                            obj[qi] = pfVar.ql();
                            pfVar.qi();
                            qi++;
                        }
                        obj[qi] = pfVar.ql();
                        this.gd = obj;
                        continue;
                    case 74:
                        gp = pfVar.gp(pfVar.qp());
                        b = pfVar.getPosition();
                        qi = 0;
                        while (pfVar.qu() > 0) {
                            pfVar.ql();
                            qi++;
                        }
                        pfVar.gr(b);
                        b = this.gd == null ? 0 : this.gd.length;
                        obj2 = new int[(qi + b)];
                        if (b != 0) {
                            System.arraycopy(this.gd, 0, obj2, 0, b);
                        }
                        while (b < obj2.length) {
                            obj2[b] = pfVar.ql();
                            b++;
                        }
                        this.gd = obj2;
                        pfVar.gq(gp);
                        continue;
                    case 80:
                        b = pq.m1847b(pfVar, 80);
                        qi = this.ge == null ? 0 : this.ge.length;
                        obj = new int[(b + qi)];
                        if (qi != 0) {
                            System.arraycopy(this.ge, 0, obj, 0, qi);
                        }
                        while (qi < obj.length - 1) {
                            obj[qi] = pfVar.ql();
                            pfVar.qi();
                            qi++;
                        }
                        obj[qi] = pfVar.ql();
                        this.ge = obj;
                        continue;
                    case 82:
                        gp = pfVar.gp(pfVar.qp());
                        b = pfVar.getPosition();
                        qi = 0;
                        while (pfVar.qu() > 0) {
                            pfVar.ql();
                            qi++;
                        }
                        pfVar.gr(b);
                        b = this.ge == null ? 0 : this.ge.length;
                        obj2 = new int[(qi + b)];
                        if (b != 0) {
                            System.arraycopy(this.ge, 0, obj2, 0, b);
                        }
                        while (b < obj2.length) {
                            obj2[b] = pfVar.ql();
                            b++;
                        }
                        this.ge = obj2;
                        pfVar.gq(gp);
                        continue;
                    default:
                        if (!m3436a(pfVar, qi)) {
                            break;
                        }
                        continue;
                }
                return this;
            }
        }

        public int hashCode() {
            return ((((((((((((((((((((pl.hashCode(this.fV) + 527) * 31) + pl.hashCode(this.fW)) * 31) + pl.hashCode(this.fX)) * 31) + pl.hashCode(this.fY)) * 31) + pl.hashCode(this.fZ)) * 31) + pl.hashCode(this.ga)) * 31) + pl.hashCode(this.gb)) * 31) + pl.hashCode(this.gc)) * 31) + pl.hashCode(this.gd)) * 31) + pl.hashCode(this.ge)) * 31) + qz();
        }

        public C2464g m4178m() {
            this.fV = pq.awW;
            this.fW = pq.awW;
            this.fX = pq.awW;
            this.fY = pq.awW;
            this.fZ = pq.awW;
            this.ga = pq.awW;
            this.gb = pq.awW;
            this.gc = pq.awW;
            this.gd = pq.awW;
            this.ge = pq.awW;
            this.awJ = null;
            this.awU = -1;
            return this;
        }
    }

    /* renamed from: com.google.android.gms.internal.c.h */
    public static final class C2465h extends ph<C2465h> {
        public static final pi<C2468a, C2465h> gf;
        private static final C2465h[] gg;
        public int[] gh;
        public int[] gi;
        public int[] gj;
        public int gk;
        public int[] gl;
        public int gm;
        public int gn;

        static {
            gf = pi.m1816a(11, C2465h.class, 810);
            gg = new C2465h[0];
        }

        public C2465h() {
            m4183n();
        }

        public void m4179a(pg pgVar) throws IOException {
            int i = 0;
            if (this.gh != null && this.gh.length > 0) {
                for (int s : this.gh) {
                    pgVar.m1812s(1, s);
                }
            }
            if (this.gi != null && this.gi.length > 0) {
                for (int s2 : this.gi) {
                    pgVar.m1812s(2, s2);
                }
            }
            if (this.gj != null && this.gj.length > 0) {
                for (int s22 : this.gj) {
                    pgVar.m1812s(3, s22);
                }
            }
            if (this.gk != 0) {
                pgVar.m1812s(4, this.gk);
            }
            if (this.gl != null && this.gl.length > 0) {
                while (i < this.gl.length) {
                    pgVar.m1812s(5, this.gl[i]);
                    i++;
                }
            }
            if (this.gm != 0) {
                pgVar.m1812s(6, this.gm);
            }
            if (this.gn != 0) {
                pgVar.m1812s(7, this.gn);
            }
            super.m3435a(pgVar);
        }

        public /* synthetic */ pn m4180b(pf pfVar) throws IOException {
            return m4182i(pfVar);
        }

        protected int m4181c() {
            int i;
            int i2;
            int i3 = 0;
            int c = super.m3438c();
            if (this.gh == null || this.gh.length <= 0) {
                i = c;
            } else {
                i2 = 0;
                for (int gw : this.gh) {
                    i2 += pg.gw(gw);
                }
                i = (c + i2) + (this.gh.length * 1);
            }
            if (this.gi != null && this.gi.length > 0) {
                c = 0;
                for (int gw2 : this.gi) {
                    c += pg.gw(gw2);
                }
                i = (i + c) + (this.gi.length * 1);
            }
            if (this.gj != null && this.gj.length > 0) {
                c = 0;
                for (int gw22 : this.gj) {
                    c += pg.gw(gw22);
                }
                i = (i + c) + (this.gj.length * 1);
            }
            if (this.gk != 0) {
                i += pg.m1790u(4, this.gk);
            }
            if (this.gl != null && this.gl.length > 0) {
                i2 = 0;
                while (i3 < this.gl.length) {
                    i2 += pg.gw(this.gl[i3]);
                    i3++;
                }
                i = (i + i2) + (this.gl.length * 1);
            }
            if (this.gm != 0) {
                i += pg.m1790u(6, this.gm);
            }
            return this.gn != 0 ? i + pg.m1790u(7, this.gn) : i;
        }

        public boolean equals(Object o) {
            if (o == this) {
                return true;
            }
            if (!(o instanceof C2465h)) {
                return false;
            }
            C2465h c2465h = (C2465h) o;
            return (pl.equals(this.gh, c2465h.gh) && pl.equals(this.gi, c2465h.gi) && pl.equals(this.gj, c2465h.gj) && this.gk == c2465h.gk && pl.equals(this.gl, c2465h.gl) && this.gm == c2465h.gm && this.gn == c2465h.gn) ? m3437a((ph) c2465h) : false;
        }

        public int hashCode() {
            return ((((((((((((((pl.hashCode(this.gh) + 527) * 31) + pl.hashCode(this.gi)) * 31) + pl.hashCode(this.gj)) * 31) + this.gk) * 31) + pl.hashCode(this.gl)) * 31) + this.gm) * 31) + this.gn) * 31) + qz();
        }

        public C2465h m4182i(pf pfVar) throws IOException {
            while (true) {
                int qi = pfVar.qi();
                int b;
                Object obj;
                int gp;
                Object obj2;
                switch (qi) {
                    case FastDatePrinter.FULL /*0*/:
                        break;
                    case XtraBox.MP4_XTRA_BT_UNICODE /*8*/:
                        b = pq.m1847b(pfVar, 8);
                        qi = this.gh == null ? 0 : this.gh.length;
                        obj = new int[(b + qi)];
                        if (qi != 0) {
                            System.arraycopy(this.gh, 0, obj, 0, qi);
                        }
                        while (qi < obj.length - 1) {
                            obj[qi] = pfVar.ql();
                            pfVar.qi();
                            qi++;
                        }
                        obj[qi] = pfVar.ql();
                        this.gh = obj;
                        continue;
                    case C0811R.styleable.WalletFragmentStyle_maskedWalletDetailsLogoImageType /*10*/:
                        gp = pfVar.gp(pfVar.qp());
                        b = pfVar.getPosition();
                        qi = 0;
                        while (pfVar.qu() > 0) {
                            pfVar.ql();
                            qi++;
                        }
                        pfVar.gr(b);
                        b = this.gh == null ? 0 : this.gh.length;
                        obj2 = new int[(qi + b)];
                        if (b != 0) {
                            System.arraycopy(this.gh, 0, obj2, 0, b);
                        }
                        while (b < obj2.length) {
                            obj2[b] = pfVar.ql();
                            b++;
                        }
                        this.gh = obj2;
                        pfVar.gq(gp);
                        continue;
                    case ItemTouchHelper.START /*16*/:
                        b = pq.m1847b(pfVar, 16);
                        qi = this.gi == null ? 0 : this.gi.length;
                        obj = new int[(b + qi)];
                        if (qi != 0) {
                            System.arraycopy(this.gi, 0, obj, 0, qi);
                        }
                        while (qi < obj.length - 1) {
                            obj[qi] = pfVar.ql();
                            pfVar.qi();
                            qi++;
                        }
                        obj[qi] = pfVar.ql();
                        this.gi = obj;
                        continue;
                    case NalUnitTypes.NAL_TYPE_BLA_N_LP /*18*/:
                        gp = pfVar.gp(pfVar.qp());
                        b = pfVar.getPosition();
                        qi = 0;
                        while (pfVar.qu() > 0) {
                            pfVar.ql();
                            qi++;
                        }
                        pfVar.gr(b);
                        b = this.gi == null ? 0 : this.gi.length;
                        obj2 = new int[(qi + b)];
                        if (b != 0) {
                            System.arraycopy(this.gi, 0, obj2, 0, b);
                        }
                        while (b < obj2.length) {
                            obj2[b] = pfVar.ql();
                            b++;
                        }
                        this.gi = obj2;
                        pfVar.gq(gp);
                        continue;
                    case NalUnitTypes.NAL_TYPE_RSV_VCL24 /*24*/:
                        b = pq.m1847b(pfVar, 24);
                        qi = this.gj == null ? 0 : this.gj.length;
                        obj = new int[(b + qi)];
                        if (qi != 0) {
                            System.arraycopy(this.gj, 0, obj, 0, qi);
                        }
                        while (qi < obj.length - 1) {
                            obj[qi] = pfVar.ql();
                            pfVar.qi();
                            qi++;
                        }
                        obj[qi] = pfVar.ql();
                        this.gj = obj;
                        continue;
                    case NalUnitTypes.NAL_TYPE_RSV_VCL26 /*26*/:
                        gp = pfVar.gp(pfVar.qp());
                        b = pfVar.getPosition();
                        qi = 0;
                        while (pfVar.qu() > 0) {
                            pfVar.ql();
                            qi++;
                        }
                        pfVar.gr(b);
                        b = this.gj == null ? 0 : this.gj.length;
                        obj2 = new int[(qi + b)];
                        if (b != 0) {
                            System.arraycopy(this.gj, 0, obj2, 0, b);
                        }
                        while (b < obj2.length) {
                            obj2[b] = pfVar.ql();
                            b++;
                        }
                        this.gj = obj2;
                        pfVar.gq(gp);
                        continue;
                    case ItemTouchHelper.END /*32*/:
                        this.gk = pfVar.ql();
                        continue;
                    case MotionEventCompat.AXIS_GENERIC_9 /*40*/:
                        b = pq.m1847b(pfVar, 40);
                        qi = this.gl == null ? 0 : this.gl.length;
                        obj = new int[(b + qi)];
                        if (qi != 0) {
                            System.arraycopy(this.gl, 0, obj, 0, qi);
                        }
                        while (qi < obj.length - 1) {
                            obj[qi] = pfVar.ql();
                            pfVar.qi();
                            qi++;
                        }
                        obj[qi] = pfVar.ql();
                        this.gl = obj;
                        continue;
                    case NalUnitTypes.NAL_TYPE_RSV_NVCL42 /*42*/:
                        gp = pfVar.gp(pfVar.qp());
                        b = pfVar.getPosition();
                        qi = 0;
                        while (pfVar.qu() > 0) {
                            pfVar.ql();
                            qi++;
                        }
                        pfVar.gr(b);
                        b = this.gl == null ? 0 : this.gl.length;
                        obj2 = new int[(qi + b)];
                        if (b != 0) {
                            System.arraycopy(this.gl, 0, obj2, 0, b);
                        }
                        while (b < obj2.length) {
                            obj2[b] = pfVar.ql();
                            b++;
                        }
                        this.gl = obj2;
                        pfVar.gq(gp);
                        continue;
                    case NalUnitTypes.NAL_TYPE_UNSPEC48 /*48*/:
                        this.gm = pfVar.ql();
                        continue;
                    case 56:
                        this.gn = pfVar.ql();
                        continue;
                    default:
                        if (!m3436a(pfVar, qi)) {
                            break;
                        }
                        continue;
                }
                return this;
            }
        }

        public C2465h m4183n() {
            this.gh = pq.awW;
            this.gi = pq.awW;
            this.gj = pq.awW;
            this.gk = 0;
            this.gl = pq.awW;
            this.gm = 0;
            this.gn = 0;
            this.awJ = null;
            this.awU = -1;
            return this;
        }
    }

    /* renamed from: com.google.android.gms.internal.c.i */
    public static final class C2466i extends ph<C2466i> {
        private static volatile C2466i[] go;
        public C2468a gp;
        public C2461d gq;
        public String name;

        public C2466i() {
            m4189p();
        }

        public static C2466i[] m4184o() {
            if (go == null) {
                synchronized (pl.awT) {
                    if (go == null) {
                        go = new C2466i[0];
                    }
                }
            }
            return go;
        }

        public void m4185a(pg pgVar) throws IOException {
            if (!this.name.equals(BuildConfig.FLAVOR)) {
                pgVar.m1803b(1, this.name);
            }
            if (this.gp != null) {
                pgVar.m1798a(2, this.gp);
            }
            if (this.gq != null) {
                pgVar.m1798a(3, this.gq);
            }
            super.m3435a(pgVar);
        }

        public /* synthetic */ pn m4186b(pf pfVar) throws IOException {
            return m4188j(pfVar);
        }

        protected int m4187c() {
            int c = super.m3438c();
            if (!this.name.equals(BuildConfig.FLAVOR)) {
                c += pg.m1787j(1, this.name);
            }
            if (this.gp != null) {
                c += pg.m1779c(2, this.gp);
            }
            return this.gq != null ? c + pg.m1779c(3, this.gq) : c;
        }

        public boolean equals(Object o) {
            if (o == this) {
                return true;
            }
            if (!(o instanceof C2466i)) {
                return false;
            }
            C2466i c2466i = (C2466i) o;
            if (this.name == null) {
                if (c2466i.name != null) {
                    return false;
                }
            } else if (!this.name.equals(c2466i.name)) {
                return false;
            }
            if (this.gp == null) {
                if (c2466i.gp != null) {
                    return false;
                }
            } else if (!this.gp.equals(c2466i.gp)) {
                return false;
            }
            if (this.gq == null) {
                if (c2466i.gq != null) {
                    return false;
                }
            } else if (!this.gq.equals(c2466i.gq)) {
                return false;
            }
            return m3437a((ph) c2466i);
        }

        public int hashCode() {
            int i = 0;
            int hashCode = ((this.gp == null ? 0 : this.gp.hashCode()) + (((this.name == null ? 0 : this.name.hashCode()) + 527) * 31)) * 31;
            if (this.gq != null) {
                i = this.gq.hashCode();
            }
            return ((hashCode + i) * 31) + qz();
        }

        public C2466i m4188j(pf pfVar) throws IOException {
            while (true) {
                int qi = pfVar.qi();
                switch (qi) {
                    case FastDatePrinter.FULL /*0*/:
                        break;
                    case C0811R.styleable.WalletFragmentStyle_maskedWalletDetailsLogoImageType /*10*/:
                        this.name = pfVar.readString();
                        continue;
                    case NalUnitTypes.NAL_TYPE_BLA_N_LP /*18*/:
                        if (this.gp == null) {
                            this.gp = new C2468a();
                        }
                        pfVar.m1766a(this.gp);
                        continue;
                    case NalUnitTypes.NAL_TYPE_RSV_VCL26 /*26*/:
                        if (this.gq == null) {
                            this.gq = new C2461d();
                        }
                        pfVar.m1766a(this.gq);
                        continue;
                    default:
                        if (!m3436a(pfVar, qi)) {
                            break;
                        }
                        continue;
                }
                return this;
            }
        }

        public C2466i m4189p() {
            this.name = BuildConfig.FLAVOR;
            this.gp = null;
            this.gq = null;
            this.awJ = null;
            this.awU = -1;
            return this;
        }
    }

    /* renamed from: com.google.android.gms.internal.c.j */
    public static final class C2467j extends ph<C2467j> {
        public C2466i[] gr;
        public C2463f gs;
        public String gt;

        public C2467j() {
            m4195q();
        }

        public static C2467j m4190b(byte[] bArr) throws pm {
            return (C2467j) pn.m1835a(new C2467j(), bArr);
        }

        public void m4191a(pg pgVar) throws IOException {
            if (this.gr != null && this.gr.length > 0) {
                for (pn pnVar : this.gr) {
                    if (pnVar != null) {
                        pgVar.m1798a(1, pnVar);
                    }
                }
            }
            if (this.gs != null) {
                pgVar.m1798a(2, this.gs);
            }
            if (!this.gt.equals(BuildConfig.FLAVOR)) {
                pgVar.m1803b(3, this.gt);
            }
            super.m3435a(pgVar);
        }

        public /* synthetic */ pn m4192b(pf pfVar) throws IOException {
            return m4194k(pfVar);
        }

        protected int m4193c() {
            int c = super.m3438c();
            if (this.gr != null && this.gr.length > 0) {
                for (pn pnVar : this.gr) {
                    if (pnVar != null) {
                        c += pg.m1779c(1, pnVar);
                    }
                }
            }
            if (this.gs != null) {
                c += pg.m1779c(2, this.gs);
            }
            return !this.gt.equals(BuildConfig.FLAVOR) ? c + pg.m1787j(3, this.gt) : c;
        }

        public boolean equals(Object o) {
            if (o == this) {
                return true;
            }
            if (!(o instanceof C2467j)) {
                return false;
            }
            C2467j c2467j = (C2467j) o;
            if (!pl.equals(this.gr, c2467j.gr)) {
                return false;
            }
            if (this.gs == null) {
                if (c2467j.gs != null) {
                    return false;
                }
            } else if (!this.gs.equals(c2467j.gs)) {
                return false;
            }
            if (this.gt == null) {
                if (c2467j.gt != null) {
                    return false;
                }
            } else if (!this.gt.equals(c2467j.gt)) {
                return false;
            }
            return m3437a((ph) c2467j);
        }

        public int hashCode() {
            int i = 0;
            int hashCode = ((this.gs == null ? 0 : this.gs.hashCode()) + ((pl.hashCode(this.gr) + 527) * 31)) * 31;
            if (this.gt != null) {
                i = this.gt.hashCode();
            }
            return ((hashCode + i) * 31) + qz();
        }

        public C2467j m4194k(pf pfVar) throws IOException {
            while (true) {
                int qi = pfVar.qi();
                switch (qi) {
                    case FastDatePrinter.FULL /*0*/:
                        break;
                    case C0811R.styleable.WalletFragmentStyle_maskedWalletDetailsLogoImageType /*10*/:
                        int b = pq.m1847b(pfVar, 10);
                        qi = this.gr == null ? 0 : this.gr.length;
                        Object obj = new C2466i[(b + qi)];
                        if (qi != 0) {
                            System.arraycopy(this.gr, 0, obj, 0, qi);
                        }
                        while (qi < obj.length - 1) {
                            obj[qi] = new C2466i();
                            pfVar.m1766a(obj[qi]);
                            pfVar.qi();
                            qi++;
                        }
                        obj[qi] = new C2466i();
                        pfVar.m1766a(obj[qi]);
                        this.gr = obj;
                        continue;
                    case NalUnitTypes.NAL_TYPE_BLA_N_LP /*18*/:
                        if (this.gs == null) {
                            this.gs = new C2463f();
                        }
                        pfVar.m1766a(this.gs);
                        continue;
                    case NalUnitTypes.NAL_TYPE_RSV_VCL26 /*26*/:
                        this.gt = pfVar.readString();
                        continue;
                    default:
                        if (!m3436a(pfVar, qi)) {
                            break;
                        }
                        continue;
                }
                return this;
            }
        }

        public C2467j m4195q() {
            this.gr = C2466i.m4184o();
            this.gs = null;
            this.gt = BuildConfig.FLAVOR;
            this.awJ = null;
            this.awU = -1;
            return this;
        }
    }
}
