package com.google.android.gms.internal;

public final class jx {
    public static boolean aQ(int i) {
        return i >= 3200000;
    }
}
