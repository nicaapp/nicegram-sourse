package com.google.android.gms.internal;

import com.google.android.gms.common.api.PendingResult;
import com.google.android.gms.common.api.PendingResult.C0192a;
import com.google.android.gms.common.api.Result;
import com.google.android.gms.common.api.ResultCallback;
import java.util.concurrent.TimeUnit;

class ku<T extends Result> implements PendingResult<T> {
    private final T Tx;

    ku(T t) {
        this.Tx = t;
    }

    public void m3345a(C0192a c0192a) {
        c0192a.m154n(this.Tx.getStatus());
    }

    public T await() {
        return this.Tx;
    }

    public T await(long time, TimeUnit units) {
        return this.Tx;
    }

    public void cancel() {
    }

    public boolean isCanceled() {
        return false;
    }

    public void setResultCallback(ResultCallback<T> callback) {
        callback.onResult(this.Tx);
    }

    public void setResultCallback(ResultCallback<T> callback, long time, TimeUnit units) {
        callback.onResult(this.Tx);
    }
}
