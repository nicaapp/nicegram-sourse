package com.google.android.gms.internal;

import android.os.IBinder;
import android.os.Parcel;
import android.os.Parcelable.Creator;
import com.google.android.gms.common.internal.safeparcel.C0242a;
import com.google.android.gms.common.internal.safeparcel.C0242a.C0241a;
import com.google.android.gms.common.internal.safeparcel.C0243b;
import com.google.android.gms.drive.events.CompletionEvent;
import com.google.android.gms.location.DetectedActivity;
import org.telegram.android.support.widget.helper.ItemTouchHelper;
import org.telegram.android.time.FastDatePrinter;

public class du implements Creator<dv> {
    static void m1220a(dv dvVar, Parcel parcel, int i) {
        int D = C0243b.m329D(parcel);
        C0243b.m356c(parcel, 1, dvVar.versionCode);
        C0243b.m338a(parcel, 2, dvVar.ck(), false);
        C0243b.m338a(parcel, 3, dvVar.cl(), false);
        C0243b.m338a(parcel, 4, dvVar.cm(), false);
        C0243b.m338a(parcel, 5, dvVar.cn(), false);
        C0243b.m332H(parcel, D);
    }

    public /* synthetic */ Object createFromParcel(Parcel x0) {
        return m1221g(x0);
    }

    public dv m1221g(Parcel parcel) {
        IBinder iBinder = null;
        int C = C0242a.m293C(parcel);
        int i = 0;
        IBinder iBinder2 = null;
        IBinder iBinder3 = null;
        IBinder iBinder4 = null;
        while (parcel.dataPosition() < C) {
            int B = C0242a.m291B(parcel);
            switch (C0242a.aD(B)) {
                case CompletionEvent.STATUS_FAILURE /*1*/:
                    i = C0242a.m309g(parcel, B);
                    break;
                case CompletionEvent.STATUS_CONFLICT /*2*/:
                    iBinder4 = C0242a.m318p(parcel, B);
                    break;
                case FastDatePrinter.SHORT /*3*/:
                    iBinder3 = C0242a.m318p(parcel, B);
                    break;
                case ItemTouchHelper.LEFT /*4*/:
                    iBinder2 = C0242a.m318p(parcel, B);
                    break;
                case DetectedActivity.TILTING /*5*/:
                    iBinder = C0242a.m318p(parcel, B);
                    break;
                default:
                    C0242a.m302b(parcel, B);
                    break;
            }
        }
        if (parcel.dataPosition() == C) {
            return new dv(i, iBinder4, iBinder3, iBinder2, iBinder);
        }
        throw new C0241a("Overread allowed size end=" + C, parcel);
    }

    public dv[] m1222n(int i) {
        return new dv[i];
    }

    public /* synthetic */ Object[] newArray(int x0) {
        return m1222n(x0);
    }
}
