package com.google.android.gms.internal;

/* renamed from: com.google.android.gms.internal.t */
public interface C0553t {
    void onAdClicked();
}
