package com.google.android.gms.internal;

import android.content.Context;
import com.google.android.gms.internal.ah.C0425a;
import com.google.android.gms.internal.gw.C0505a;
import org.json.JSONObject;

@ez
public class aj implements ah {
    private final gv md;

    /* renamed from: com.google.android.gms.internal.aj.1 */
    class C04271 implements Runnable {
        final /* synthetic */ String nb;
        final /* synthetic */ JSONObject nc;
        final /* synthetic */ aj nd;

        C04271(aj ajVar, String str, JSONObject jSONObject) {
            this.nd = ajVar;
            this.nb = str;
            this.nc = jSONObject;
        }

        public void run() {
            this.nd.md.m1428a(this.nb, this.nc);
        }
    }

    /* renamed from: com.google.android.gms.internal.aj.2 */
    class C04282 implements Runnable {
        final /* synthetic */ String mY;
        final /* synthetic */ aj nd;

        C04282(aj ajVar, String str) {
            this.nd = ajVar;
            this.mY = str;
        }

        public void run() {
            this.nd.md.loadUrl(this.mY);
        }
    }

    /* renamed from: com.google.android.gms.internal.aj.3 */
    class C17933 implements C0505a {
        final /* synthetic */ aj nd;
        final /* synthetic */ C0425a ne;

        C17933(aj ajVar, C0425a c0425a) {
            this.nd = ajVar;
            this.ne = c0425a;
        }

        public void m3029a(gv gvVar) {
            this.ne.aM();
        }
    }

    public aj(Context context, gt gtVar) {
        this.md = gv.m1421a(context, new ay(), false, false, null, gtVar);
    }

    private void runOnUiThread(Runnable runnable) {
        if (gr.ds()) {
            runnable.run();
        } else {
            gr.wC.post(runnable);
        }
    }

    public void m3031a(C0425a c0425a) {
        this.md.du().m1437a(new C17933(this, c0425a));
    }

    public void m3032a(C0553t c0553t, dn dnVar, bw bwVar, dq dqVar, boolean z, bz bzVar) {
        this.md.du().m1439a(c0553t, dnVar, bwVar, dqVar, z, bzVar, new C0560v(false));
    }

    public void m3033a(String str, by byVar) {
        this.md.du().m1440a(str, byVar);
    }

    public void m3034a(String str, JSONObject jSONObject) {
        runOnUiThread(new C04271(this, str, jSONObject));
    }

    public void destroy() {
        this.md.destroy();
    }

    public void m3035f(String str) {
        runOnUiThread(new C04282(this, str));
    }

    public void m3036g(String str) {
        this.md.du().m1440a(str, null);
    }

    public void pause() {
        gj.m1368a(this.md);
    }

    public void resume() {
        gj.m1373b(this.md);
    }
}
