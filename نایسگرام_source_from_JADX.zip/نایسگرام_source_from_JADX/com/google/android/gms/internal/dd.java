package com.google.android.gms.internal;

import android.app.Activity;
import android.content.Context;
import android.text.TextUtils;
import android.util.DisplayMetrics;
import android.view.View;
import android.view.ViewGroup;
import android.view.ViewParent;
import android.view.WindowManager;
import android.widget.LinearLayout;
import android.widget.PopupWindow;
import com.google.android.gms.ads.AdSize;
import java.util.Arrays;
import java.util.HashSet;
import java.util.Map;
import java.util.Set;
import org.json.JSONObject;

@ez
public class dd {
    static final Set<String> qT;
    private int lf;
    private int lg;
    private final Context mContext;
    private final gv md;
    private final Map<String, String> qM;
    private int qU;
    private int qV;
    private boolean qW;
    private String qX;

    static {
        qT = new HashSet(Arrays.asList(new String[]{"top-left", "top-right", "top-center", "center", "bottom-left", "bottom-right", "bottom-center"}));
    }

    public dd(gv gvVar, Map<String, String> map) {
        this.lf = -1;
        this.lg = -1;
        this.qU = 0;
        this.qV = 0;
        this.qW = true;
        this.qX = "top-right";
        this.md = gvVar;
        this.qM = map;
        this.mContext = gvVar.dz();
    }

    private void bG() {
        int M;
        int[] t = gj.m1384t(this.mContext);
        if (!TextUtils.isEmpty((CharSequence) this.qM.get("width"))) {
            M = gj.m1355M((String) this.qM.get("width"));
            if (m1186b(M, t[0])) {
                this.lf = M;
            }
        }
        if (!TextUtils.isEmpty((CharSequence) this.qM.get("height"))) {
            M = gj.m1355M((String) this.qM.get("height"));
            if (m1187c(M, t[1])) {
                this.lg = M;
            }
        }
        if (!TextUtils.isEmpty((CharSequence) this.qM.get("offsetX"))) {
            this.qU = gj.m1355M((String) this.qM.get("offsetX"));
        }
        if (!TextUtils.isEmpty((CharSequence) this.qM.get("offsetY"))) {
            this.qV = gj.m1355M((String) this.qM.get("offsetY"));
        }
        if (!TextUtils.isEmpty((CharSequence) this.qM.get("allowOffscreen"))) {
            this.qW = Boolean.parseBoolean((String) this.qM.get("allowOffscreen"));
        }
        String str = (String) this.qM.get("customClosePosition");
        if (!TextUtils.isEmpty(str) && qT.contains(str)) {
            this.qX = str;
        }
    }

    boolean m1186b(int i, int i2) {
        return i >= 50 && i < i2;
    }

    boolean bH() {
        return this.lf > -1 && this.lg > -1;
    }

    void bI() {
        try {
            this.md.m1429b("onSizeChanged", new JSONObject().put("x", this.qU).put("y", this.qV).put("width", this.lf).put("height", this.lg));
        } catch (Throwable e) {
            gs.m1414b("Error occured while dispatching size change.", e);
        }
    }

    void bJ() {
        try {
            this.md.m1429b("onStateChanged", new JSONObject().put("state", "resized"));
        } catch (Throwable e) {
            gs.m1414b("Error occured while dispatching state change.", e);
        }
    }

    boolean m1187c(int i, int i2) {
        return i >= 50 && i < i2;
    }

    public void execute() {
        gs.m1410U("PLEASE IMPLEMENT mraid.resize()");
        if (this.mContext == null) {
            gs.m1412W("Not an activity context. Cannot resize.");
        } else if (this.md.m1423Y().og) {
            gs.m1412W("Is interstitial. Cannot resize an interstitial.");
        } else if (this.md.dy()) {
            gs.m1412W("Is expanded. Cannot resize an expanded banner.");
        } else {
            bG();
            if (bH()) {
                WindowManager windowManager = (WindowManager) this.mContext.getSystemService("window");
                DisplayMetrics displayMetrics = new DisplayMetrics();
                windowManager.getDefaultDisplay().getMetrics(displayMetrics);
                int a = gr.m1403a(displayMetrics, this.lf) + 16;
                int a2 = gr.m1403a(displayMetrics, this.lg) + 16;
                ViewParent parent = this.md.getParent();
                if (parent != null && (parent instanceof ViewGroup)) {
                    ((ViewGroup) parent).removeView(this.md);
                }
                View linearLayout = new LinearLayout(this.mContext);
                linearLayout.setBackgroundColor(0);
                PopupWindow popupWindow = new PopupWindow(this.mContext);
                popupWindow.setHeight(a2);
                popupWindow.setWidth(a);
                popupWindow.setClippingEnabled(!this.qW);
                popupWindow.setContentView(linearLayout);
                linearLayout.addView(this.md, -1, -1);
                popupWindow.showAtLocation(((Activity) this.mContext).getWindow().getDecorView(), 0, this.qU, this.qV);
                this.md.m1425a(new ay(this.mContext, new AdSize(this.lf, this.lg)));
                bI();
                bJ();
                return;
            }
            gs.m1412W("Invalid width and height options. Cannot resize.");
        }
    }
}
