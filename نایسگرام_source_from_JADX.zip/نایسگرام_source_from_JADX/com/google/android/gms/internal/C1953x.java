package com.google.android.gms.internal;

import android.os.Parcel;
import com.google.android.gms.common.internal.safeparcel.SafeParcelable;

@ez
/* renamed from: com.google.android.gms.internal.x */
public final class C1953x implements SafeParcelable {
    public static final C0561y CREATOR;
    public final boolean lX;
    public final boolean mh;
    public final int versionCode;

    static {
        CREATOR = new C0561y();
    }

    C1953x(int i, boolean z, boolean z2) {
        this.versionCode = i;
        this.lX = z;
        this.mh = z2;
    }

    public C1953x(boolean z, boolean z2) {
        this.versionCode = 1;
        this.lX = z;
        this.mh = z2;
    }

    public int describeContents() {
        return 0;
    }

    public void writeToParcel(Parcel out, int flags) {
        C0561y.m1879a(this, out, flags);
    }
}
