package com.google.android.gms.internal;

import android.os.Parcel;
import com.google.android.gms.common.internal.safeparcel.SafeParcelable;
import com.google.android.gms.drive.events.CompletionEvent;
import com.google.android.gms.location.Geofence;
import com.google.android.gms.location.GeofenceStatusCodes;
import java.util.Locale;

public class mc implements SafeParcelable, Geofence {
    public static final md CREATOR;
    private final int BR;
    private final String XC;
    private final int aeh;
    private final short aej;
    private final double aek;
    private final double ael;
    private final float aem;
    private final int aen;
    private final int aeo;
    private final long afm;

    static {
        CREATOR = new md();
    }

    public mc(int i, String str, int i2, short s, double d, double d2, float f, long j, int i3, int i4) {
        bY(str);
        m3389b(f);
        m3388a(d, d2);
        int ek = ek(i2);
        this.BR = i;
        this.aej = s;
        this.XC = str;
        this.aek = d;
        this.ael = d2;
        this.aem = f;
        this.afm = j;
        this.aeh = ek;
        this.aen = i3;
        this.aeo = i4;
    }

    public mc(String str, int i, short s, double d, double d2, float f, long j, int i2, int i3) {
        this(1, str, i, s, d, d2, f, j, i2, i3);
    }

    private static void m3388a(double d, double d2) {
        if (d > 90.0d || d < -90.0d) {
            throw new IllegalArgumentException("invalid latitude: " + d);
        } else if (d2 > 180.0d || d2 < -180.0d) {
            throw new IllegalArgumentException("invalid longitude: " + d2);
        }
    }

    private static void m3389b(float f) {
        if (f <= 0.0f) {
            throw new IllegalArgumentException("invalid radius: " + f);
        }
    }

    private static void bY(String str) {
        if (str == null || str.length() > 100) {
            throw new IllegalArgumentException("requestId is null or too long: " + str);
        }
    }

    private static int ek(int i) {
        int i2 = i & 7;
        if (i2 != 0) {
            return i2;
        }
        throw new IllegalArgumentException("No supported transition specified: " + i);
    }

    private static String el(int i) {
        switch (i) {
            case CompletionEvent.STATUS_FAILURE /*1*/:
                return "CIRCLE";
            default:
                return null;
        }
    }

    public static mc m3390h(byte[] bArr) {
        Parcel obtain = Parcel.obtain();
        obtain.unmarshall(bArr, 0, bArr.length);
        obtain.setDataPosition(0);
        mc cw = CREATOR.cw(obtain);
        obtain.recycle();
        return cw;
    }

    public int describeContents() {
        md mdVar = CREATOR;
        return 0;
    }

    public boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (obj == null) {
            return false;
        }
        if (!(obj instanceof mc)) {
            return false;
        }
        mc mcVar = (mc) obj;
        if (this.aem != mcVar.aem) {
            return false;
        }
        if (this.aek != mcVar.aek) {
            return false;
        }
        if (this.ael != mcVar.ael) {
            return false;
        }
        return this.aej == mcVar.aej;
    }

    public long getExpirationTime() {
        return this.afm;
    }

    public double getLatitude() {
        return this.aek;
    }

    public double getLongitude() {
        return this.ael;
    }

    public int getNotificationResponsiveness() {
        return this.aen;
    }

    public String getRequestId() {
        return this.XC;
    }

    public int getVersionCode() {
        return this.BR;
    }

    public int hashCode() {
        long doubleToLongBits = Double.doubleToLongBits(this.aek);
        int i = ((int) (doubleToLongBits ^ (doubleToLongBits >>> 32))) + 31;
        long doubleToLongBits2 = Double.doubleToLongBits(this.ael);
        return (((((((i * 31) + ((int) (doubleToLongBits2 ^ (doubleToLongBits2 >>> 32)))) * 31) + Float.floatToIntBits(this.aem)) * 31) + this.aej) * 31) + this.aeh;
    }

    public short ma() {
        return this.aej;
    }

    public float mb() {
        return this.aem;
    }

    public int mc() {
        return this.aeh;
    }

    public int md() {
        return this.aeo;
    }

    public String toString() {
        return String.format(Locale.US, "Geofence[%s id:%s transitions:%d %.6f, %.6f %.0fm, resp=%ds, dwell=%dms, @%d]", new Object[]{el(this.aej), this.XC, Integer.valueOf(this.aeh), Double.valueOf(this.aek), Double.valueOf(this.ael), Float.valueOf(this.aem), Integer.valueOf(this.aen / GeofenceStatusCodes.GEOFENCE_NOT_AVAILABLE), Integer.valueOf(this.aeo), Long.valueOf(this.afm)});
    }

    public void writeToParcel(Parcel parcel, int flags) {
        md mdVar = CREATOR;
        md.m1692a(this, parcel, flags);
    }
}
