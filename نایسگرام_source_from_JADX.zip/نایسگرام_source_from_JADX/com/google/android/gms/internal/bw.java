package com.google.android.gms.internal;

public interface bw {
    void onAppEvent(String str, String str2);
}
