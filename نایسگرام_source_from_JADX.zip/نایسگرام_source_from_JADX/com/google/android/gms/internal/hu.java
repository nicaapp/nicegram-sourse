package com.google.android.gms.internal;

import com.google.android.gms.common.api.Result;

public interface hu {

    /* renamed from: com.google.android.gms.internal.hu.a */
    public interface C1871a extends Result {
    }
}
