package com.google.android.gms.internal;

import android.support.v4.view.MotionEventCompat;
import java.security.MessageDigest;

public class ar extends ao {
    private MessageDigest nP;

    byte[] m3037a(String[] strArr) {
        byte[] bArr = new byte[strArr.length];
        for (int i = 0; i < strArr.length; i++) {
            bArr[i] = (byte) (aq.m1093o(strArr[i]) & MotionEventCompat.ACTION_MASK);
        }
        return bArr;
    }

    public byte[] m3038l(String str) {
        byte[] a = m3037a(str.split(" "));
        this.nP = ba();
        synchronized (this.mw) {
            if (this.nP == null) {
                a = new byte[0];
            } else {
                this.nP.reset();
                this.nP.update(a);
                Object digest = this.nP.digest();
                int i = 4;
                if (digest.length <= 4) {
                    i = digest.length;
                }
                a = new byte[i];
                System.arraycopy(digest, 0, a, 0, a.length);
            }
        }
        return a;
    }
}
