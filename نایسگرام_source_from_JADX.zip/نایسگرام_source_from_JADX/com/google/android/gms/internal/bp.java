package com.google.android.gms.internal;

import android.graphics.drawable.Drawable;
import com.google.android.gms.dynamic.C0330d;
import com.google.android.gms.dynamic.C2413e;
import com.google.android.gms.internal.bq.C0438a;
import com.google.android.gms.internal.bs.C1803a;

@ez
public class bp extends C1803a implements C0438a {
    private final Object mw;
    private final String pl;
    private final Drawable pm;
    private final String pn;
    private final String pp;
    private bq pt;
    private final Drawable pu;
    private final String pv;

    public bp(String str, Drawable drawable, String str2, Drawable drawable2, String str3, String str4) {
        this.mw = new Object();
        this.pl = str;
        this.pm = drawable;
        this.pn = str2;
        this.pu = drawable2;
        this.pp = str3;
        this.pv = str4;
    }

    public void m4137a(bq bqVar) {
        synchronized (this.mw) {
            this.pt = bqVar;
        }
    }

    public void as() {
        synchronized (this.mw) {
            if (this.pt == null) {
                gs.m1409T("Attempt to record impression before content ad initialized.");
                return;
            }
            this.pt.as();
        }
    }

    public C0330d bA() {
        return C2413e.m3897k(this.pu);
    }

    public String bB() {
        return this.pv;
    }

    public String bt() {
        return this.pl;
    }

    public C0330d bu() {
        return C2413e.m3897k(this.pm);
    }

    public String bw() {
        return this.pp;
    }

    public String getBody() {
        return this.pn;
    }

    public void m4138i(int i) {
        synchronized (this.mw) {
            if (this.pt == null) {
                gs.m1409T("Attempt to perform click before content ad initialized.");
                return;
            }
            this.pt.m1157b("1", i);
        }
    }
}
