package com.google.android.gms.internal;

import android.content.Context;
import android.os.Bundle;
import com.google.android.gms.common.ConnectionResult;
import com.google.android.gms.common.GooglePlayServicesClient.ConnectionCallbacks;
import com.google.android.gms.common.GooglePlayServicesClient.OnConnectionFailedListener;
import com.google.android.gms.common.GooglePlayServicesUtil;

@ez
public final class cf {

    /* renamed from: com.google.android.gms.internal.cf.b */
    public interface C0440b {
        void m1165a(Bundle bundle);
    }

    /* renamed from: com.google.android.gms.internal.cf.a */
    public static final class C1812a implements ConnectionCallbacks, OnConnectionFailedListener {
        private final Object mw;
        private final C0440b pN;
        private final cg pO;

        public C1812a(Context context, C0440b c0440b) {
            this(context, c0440b, false);
        }

        C1812a(Context context, C0440b c0440b, boolean z) {
            this.mw = new Object();
            this.pN = c0440b;
            this.pO = new cg(context, this, this, GooglePlayServicesUtil.GOOGLE_PLAY_SERVICES_VERSION_CODE);
            if (!z) {
                this.pO.connect();
            }
        }

        public void onConnected(Bundle connectionHint) {
            Bundle bD;
            Bundle bs = bn.bs();
            synchronized (this.mw) {
                try {
                    ch bC = this.pO.bC();
                    bD = bC != null ? bC.bD() : bs;
                    if (this.pO.isConnected() || this.pO.isConnecting()) {
                        this.pO.disconnect();
                    }
                } catch (Throwable e) {
                    gs.m1416d("Error when get Gservice values", e);
                    if (this.pO.isConnected() || this.pO.isConnecting()) {
                        this.pO.disconnect();
                        bD = bs;
                    }
                    bD = bs;
                } catch (Throwable e2) {
                    gs.m1416d("Error when get Gservice values", e2);
                    if (this.pO.isConnected() || this.pO.isConnecting()) {
                        this.pO.disconnect();
                        bD = bs;
                    }
                    bD = bs;
                } catch (Throwable th) {
                    if (this.pO.isConnected() || this.pO.isConnecting()) {
                        this.pO.disconnect();
                    }
                }
            }
            this.pN.m1165a(bD);
        }

        public void onConnectionFailed(ConnectionResult result) {
            this.pN.m1165a(bn.bs());
        }

        public void onDisconnected() {
            gs.m1408S("Disconnected from remote ad request service.");
        }
    }

    public static void m1166a(Context context, C0440b c0440b) {
        if (GooglePlayServicesUtil.isGooglePlayServicesAvailable(context) != 0) {
            c0440b.m1165a(bn.bs());
        } else {
            C1812a c1812a = new C1812a(context, c0440b);
        }
    }
}
