package com.google.android.gms.internal;

import android.content.Context;
import android.os.Bundle;
import com.google.android.gms.common.ConnectionResult;
import com.google.android.gms.common.GooglePlayServicesClient.ConnectionCallbacks;
import com.google.android.gms.common.GooglePlayServicesClient.OnConnectionFailedListener;
import com.google.android.gms.internal.ff.C0485a;

@ez
public abstract class fg extends gg {
    private final fi pQ;
    private final C0485a tu;

    @ez
    /* renamed from: com.google.android.gms.internal.fg.a */
    public static final class C2469a extends fg {
        private final Context mContext;

        public C2469a(Context context, fi fiVar, C0485a c0485a) {
            super(fiVar, c0485a);
            this.mContext = context;
        }

        public void cC() {
        }

        public fm cD() {
            Bundle bD = gb.bD();
            return fr.m4247a(this.mContext, new bm(bD.getString("gads:sdk_core_location"), bD.getString("gads:sdk_core_experiment_id"), bD.getString("gads:block_autoclicks_experiment_id")), new cj(), new fy());
        }
    }

    @ez
    /* renamed from: com.google.android.gms.internal.fg.b */
    public static final class C2470b extends fg implements ConnectionCallbacks, OnConnectionFailedListener {
        private final Object mw;
        private final C0485a tu;
        private final fh tv;

        public C2470b(Context context, fi fiVar, C0485a c0485a) {
            super(fiVar, c0485a);
            this.mw = new Object();
            this.tu = c0485a;
            this.tv = new fh(context, this, this, fiVar.lD.wF);
            this.tv.connect();
        }

        public void cC() {
            synchronized (this.mw) {
                if (this.tv.isConnected() || this.tv.isConnecting()) {
                    this.tv.disconnect();
                }
            }
        }

        public fm cD() {
            fm cE;
            synchronized (this.mw) {
                try {
                    cE = this.tv.cE();
                } catch (IllegalStateException e) {
                    cE = null;
                }
            }
            return cE;
        }

        public void onConnected(Bundle connectionHint) {
            start();
        }

        public void onConnectionFailed(ConnectionResult result) {
            this.tu.m1275a(new fk(0));
        }

        public void onDisconnected() {
            gs.m1408S("Disconnected from remote ad request service.");
        }
    }

    public fg(fi fiVar, C0485a c0485a) {
        this.pQ = fiVar;
        this.tu = c0485a;
    }

    private static fk m3173a(fm fmVar, fi fiVar) {
        fk fkVar = null;
        try {
            fkVar = fmVar.m1285b(fiVar);
        } catch (Throwable e) {
            gs.m1416d("Could not fetch ad response from ad request service.", e);
        } catch (Throwable e2) {
            gs.m1416d("Could not fetch ad response from ad request service due to an Exception.", e2);
        } catch (Throwable e22) {
            gs.m1416d("Could not fetch ad response from ad request service due to an Exception.", e22);
        } catch (Throwable e222) {
            gb.m3194e(e222);
        }
        return fkVar;
    }

    public abstract void cC();

    public abstract fm cD();

    public final void co() {
        try {
            fk fkVar;
            fm cD = cD();
            if (cD == null) {
                fkVar = new fk(0);
            } else {
                fkVar = m3173a(cD, this.pQ);
                if (fkVar == null) {
                    fkVar = new fk(0);
                }
            }
            cC();
            this.tu.m1275a(fkVar);
        } catch (Throwable th) {
            cC();
        }
    }

    public final void onStop() {
        cC();
    }
}
