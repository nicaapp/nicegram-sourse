package com.google.android.gms.internal;

import android.os.Parcel;
import android.os.Parcelable.Creator;
import com.google.android.gms.common.internal.C0237n;
import com.google.android.gms.common.internal.safeparcel.SafeParcelable;

public class ig implements SafeParcelable {
    public static final Creator<ig> CREATOR;
    private final int BR;
    private String Gn;

    static {
        CREATOR = new ih();
    }

    public ig() {
        this(1, null);
    }

    ig(int i, String str) {
        this.BR = i;
        this.Gn = str;
    }

    public int describeContents() {
        return 0;
    }

    public boolean equals(Object obj) {
        if (obj == this) {
            return true;
        }
        if (!(obj instanceof ig)) {
            return false;
        }
        return ik.m1511a(this.Gn, ((ig) obj).Gn);
    }

    public String fy() {
        return this.Gn;
    }

    public int getVersionCode() {
        return this.BR;
    }

    public int hashCode() {
        return C0237n.hashCode(this.Gn);
    }

    public void writeToParcel(Parcel out, int flags) {
        ih.m1506a(this, out, flags);
    }
}
