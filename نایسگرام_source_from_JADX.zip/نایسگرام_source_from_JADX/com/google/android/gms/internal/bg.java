package com.google.android.gms.internal;

import android.content.Context;
import android.location.Location;
import android.os.Bundle;
import com.google.ads.mediation.admob.AdMobAdapter;
import com.google.android.gms.ads.mediation.MediationAdapter;
import com.google.android.gms.ads.mediation.NetworkExtras;
import com.google.android.gms.ads.mediation.admob.AdMobExtras;
import com.google.android.gms.ads.mediation.customevent.CustomEvent;
import com.google.android.gms.ads.search.SearchAdRequest;
import java.util.Collections;
import java.util.Date;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Map;
import java.util.Set;

@ez
public final class bg {
    public static final String DEVICE_ID_EMULATOR;
    private final Date f44d;
    private final Set<String> f45f;
    private final Location f46h;
    private final String ol;
    private final int om;
    private final boolean on;
    private final Bundle oo;
    private final Map<Class<? extends NetworkExtras>, NetworkExtras> op;
    private final String oq;
    private final SearchAdRequest or;
    private final int os;
    private final Set<String> ot;

    /* renamed from: com.google.android.gms.internal.bg.a */
    public static final class C0437a {
        private Date f42d;
        private Location f43h;
        private String ol;
        private int om;
        private boolean on;
        private final Bundle oo;
        private String oq;
        private int os;
        private final HashSet<String> ou;
        private final HashMap<Class<? extends NetworkExtras>, NetworkExtras> ov;
        private final HashSet<String> ow;

        public C0437a() {
            this.ou = new HashSet();
            this.oo = new Bundle();
            this.ov = new HashMap();
            this.ow = new HashSet();
            this.om = -1;
            this.on = false;
            this.os = -1;
        }

        public void m1132a(Location location) {
            this.f43h = location;
        }

        @Deprecated
        public void m1133a(NetworkExtras networkExtras) {
            if (networkExtras instanceof AdMobExtras) {
                m1134a(AdMobAdapter.class, ((AdMobExtras) networkExtras).getExtras());
            } else {
                this.ov.put(networkExtras.getClass(), networkExtras);
            }
        }

        public void m1134a(Class<? extends MediationAdapter> cls, Bundle bundle) {
            this.oo.putBundle(cls.getName(), bundle);
        }

        public void m1135a(Date date) {
            this.f42d = date;
        }

        public void m1136b(Class<? extends CustomEvent> cls, Bundle bundle) {
            if (this.oo.getBundle("com.google.android.gms.ads.mediation.customevent.CustomEventAdapter") == null) {
                this.oo.putBundle("com.google.android.gms.ads.mediation.customevent.CustomEventAdapter", new Bundle());
            }
            this.oo.getBundle("com.google.android.gms.ads.mediation.customevent.CustomEventAdapter").putBundle(cls.getName(), bundle);
        }

        public void m1137g(int i) {
            this.om = i;
        }

        public void m1138g(boolean z) {
            this.on = z;
        }

        public void m1139h(boolean z) {
            this.os = z ? 1 : 0;
        }

        public void m1140r(String str) {
            this.ou.add(str);
        }

        public void m1141s(String str) {
            this.ow.add(str);
        }

        public void m1142t(String str) {
            this.ol = str;
        }

        public void m1143u(String str) {
            this.oq = str;
        }
    }

    static {
        DEVICE_ID_EMULATOR = gr.m1401R("emulator");
    }

    public bg(C0437a c0437a) {
        this(c0437a, null);
    }

    public bg(C0437a c0437a, SearchAdRequest searchAdRequest) {
        this.f44d = c0437a.f42d;
        this.ol = c0437a.ol;
        this.om = c0437a.om;
        this.f45f = Collections.unmodifiableSet(c0437a.ou);
        this.f46h = c0437a.f43h;
        this.on = c0437a.on;
        this.oo = c0437a.oo;
        this.op = Collections.unmodifiableMap(c0437a.ov);
        this.oq = c0437a.oq;
        this.or = searchAdRequest;
        this.os = c0437a.os;
        this.ot = Collections.unmodifiableSet(c0437a.ow);
    }

    public SearchAdRequest bd() {
        return this.or;
    }

    public Map<Class<? extends NetworkExtras>, NetworkExtras> be() {
        return this.op;
    }

    public Bundle bf() {
        return this.oo;
    }

    public int bg() {
        return this.os;
    }

    public Date getBirthday() {
        return this.f44d;
    }

    public String getContentUrl() {
        return this.ol;
    }

    public Bundle getCustomEventExtrasBundle(Class<? extends CustomEvent> adapterClass) {
        Bundle bundle = this.oo.getBundle("com.google.android.gms.ads.mediation.customevent.CustomEventAdapter");
        return bundle != null ? bundle.getBundle(adapterClass.getClass().getName()) : null;
    }

    public int getGender() {
        return this.om;
    }

    public Set<String> getKeywords() {
        return this.f45f;
    }

    public Location getLocation() {
        return this.f46h;
    }

    public boolean getManualImpressionsEnabled() {
        return this.on;
    }

    @Deprecated
    public <T extends NetworkExtras> T getNetworkExtras(Class<T> networkExtrasClass) {
        return (NetworkExtras) this.op.get(networkExtrasClass);
    }

    public Bundle getNetworkExtrasBundle(Class<? extends MediationAdapter> adapterClass) {
        return this.oo.getBundle(adapterClass.getName());
    }

    public String getPublisherProvidedId() {
        return this.oq;
    }

    public boolean isTestDevice(Context context) {
        return this.ot.contains(gr.m1407v(context));
    }
}
