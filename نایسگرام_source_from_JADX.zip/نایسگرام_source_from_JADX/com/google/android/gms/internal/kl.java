package com.google.android.gms.internal;

import android.content.Context;
import android.os.Bundle;
import android.os.IBinder;
import android.os.IInterface;
import android.os.Looper;
import android.os.RemoteException;
import com.google.android.gms.common.GooglePlayServicesUtil;
import com.google.android.gms.common.api.GoogleApiClient.ConnectionCallbacks;
import com.google.android.gms.common.api.GoogleApiClient.OnConnectionFailedListener;
import com.google.android.gms.common.internal.C0232k;
import com.google.android.gms.common.internal.C0233l;
import com.google.android.gms.common.internal.C1702e;
import com.google.android.gms.common.internal.C1702e.C2386e;
import com.google.android.gms.internal.kp.C1899a;

public class kl extends C1702e<kp> implements kk {
    private final String Dd;

    public kl(Context context, Looper looper, ConnectionCallbacks connectionCallbacks, OnConnectionFailedListener onConnectionFailedListener, String str, String[] strArr) {
        super(context, looper, connectionCallbacks, onConnectionFailedListener, strArr);
        this.Dd = str;
    }

    protected void m4329a(C0233l c0233l, C2386e c2386e) throws RemoteException {
        c0233l.m238a((C0232k) c2386e, (int) GooglePlayServicesUtil.GOOGLE_PLAY_SERVICES_VERSION_CODE, getContext().getPackageName(), this.Dd, gR(), new Bundle());
    }

    protected kp ao(IBinder iBinder) {
        return C1899a.as(iBinder);
    }

    protected String getServiceDescriptor() {
        return "com.google.android.gms.fitness.internal.IGoogleFitnessService";
    }

    protected String getStartServiceAction() {
        return "com.google.android.gms.fitness.GoogleFitnessService.START";
    }

    protected /* synthetic */ IInterface m4330j(IBinder iBinder) {
        return ao(iBinder);
    }

    public kp jb() {
        return (kp) gS();
    }
}
