package com.google.android.gms.internal;

import java.io.IOException;

public abstract class ph<M extends ph<M>> extends pn {
    protected pj awJ;

    public final <T> T m3434a(pi<M, T> piVar) {
        if (this.awJ == null) {
            return null;
        }
        pk gE = this.awJ.gE(pq.gI(piVar.tag));
        return gE != null ? gE.m1833b(piVar) : null;
    }

    public void m3435a(pg pgVar) throws IOException {
        if (this.awJ != null) {
            for (int i = 0; i < this.awJ.size(); i++) {
                this.awJ.gF(i).m1831a(pgVar);
            }
        }
    }

    protected final boolean m3436a(pf pfVar, int i) throws IOException {
        int position = pfVar.getPosition();
        if (!pfVar.gn(i)) {
            return false;
        }
        int gI = pq.gI(i);
        pp ppVar = new pp(i, pfVar.m1768r(position, pfVar.getPosition() - position));
        pk pkVar = null;
        if (this.awJ == null) {
            this.awJ = new pj();
        } else {
            pkVar = this.awJ.gE(gI);
        }
        if (pkVar == null) {
            pkVar = new pk();
            this.awJ.m1830a(gI, pkVar);
        }
        pkVar.m1832a(ppVar);
        return true;
    }

    protected final boolean m3437a(M m) {
        return (this.awJ == null || this.awJ.isEmpty()) ? m.awJ == null || m.awJ.isEmpty() : this.awJ.equals(m.awJ);
    }

    protected int m3438c() {
        int i = 0;
        if (this.awJ == null) {
            return 0;
        }
        int i2 = 0;
        while (i < this.awJ.size()) {
            i2 += this.awJ.gF(i).m1834c();
            i++;
        }
        return i2;
    }

    protected final int qz() {
        return (this.awJ == null || this.awJ.isEmpty()) ? 0 : this.awJ.hashCode();
    }
}
