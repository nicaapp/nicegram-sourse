package com.google.android.gms.internal;

import android.content.Context;
import com.google.android.gms.common.api.Api.C0188a;
import com.google.android.gms.common.api.BaseImplementation.C0191b;
import com.google.android.gms.common.api.BaseImplementation.C2381a;
import com.google.android.gms.common.api.Result;
import com.google.android.gms.common.api.Status;
import com.google.android.gms.common.internal.C0238o;
import com.google.android.gms.fitness.Fitness;
import com.google.android.gms.internal.kt.C1907a;

public interface kk extends C0188a {

    /* renamed from: com.google.android.gms.internal.kk.b */
    public static class C2479b extends C1907a {
        private final C0191b<Status> De;

        public C2479b(C0191b<Status> c0191b) {
            this.De = c0191b;
        }

        public void m4328k(Status status) {
            this.De.m147b(status);
        }
    }

    /* renamed from: com.google.android.gms.internal.kk.a */
    public static abstract class C2626a<R extends Result> extends C2381a<R, kk> {
        public C2626a() {
            super(Fitness.CU);
        }
    }

    /* renamed from: com.google.android.gms.internal.kk.c */
    public static abstract class C2677c extends C2626a<Status> {
        protected /* synthetic */ Result m4944c(Status status) {
            return m4945d(status);
        }

        protected Status m4945d(Status status) {
            C0238o.m276K(!status.isSuccess());
            return status;
        }
    }

    Context getContext();

    kp jb();
}
