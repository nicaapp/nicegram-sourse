package com.google.android.gms.internal;

import android.os.IInterface;
import android.os.RemoteException;

public interface bu extends IInterface {
    void m1161a(bs bsVar) throws RemoteException;
}
