package com.google.android.gms.internal;

import android.os.Parcel;
import android.os.Parcelable.Creator;
import com.google.android.gms.common.internal.safeparcel.SafeParcelable;
import com.google.android.gms.maps.model.LatLng;
import java.util.ArrayList;
import java.util.List;

public class mr implements SafeParcelable {
    public static final Creator<mr> CREATOR;
    final int BR;
    private final String Sz;
    private final LatLng ahY;
    private final List<mp> ahZ;
    private final String aia;
    private final String aib;
    private final String mName;

    static {
        CREATOR = new ms();
    }

    mr(int i, String str, LatLng latLng, String str2, List<mp> list, String str3, String str4) {
        this.BR = i;
        this.mName = str;
        this.ahY = latLng;
        this.Sz = str2;
        this.ahZ = new ArrayList(list);
        this.aia = str3;
        this.aib = str4;
    }

    public int describeContents() {
        return 0;
    }

    public String getAddress() {
        return this.Sz;
    }

    public String getName() {
        return this.mName;
    }

    public String getPhoneNumber() {
        return this.aia;
    }

    public LatLng ml() {
        return this.ahY;
    }

    public List<mp> mm() {
        return this.ahZ;
    }

    public String mn() {
        return this.aib;
    }

    public void writeToParcel(Parcel parcel, int flags) {
        ms.m1699a(this, parcel, flags);
    }
}
