package com.google.android.gms.internal;

import android.text.TextUtils;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import com.google.android.gms.common.internal.C0237n;
import java.net.URI;
import java.net.URISyntaxException;

@ez
public class ha extends WebViewClient {
    private final gv md;
    private final String xc;
    private boolean xd;
    private final fc xe;

    public ha(fc fcVar, gv gvVar, String str) {
        this.xc = m1450Z(str);
        this.xd = false;
        this.md = gvVar;
        this.xe = fcVar;
    }

    private String m1450Z(String str) {
        if (!TextUtils.isEmpty(str)) {
            try {
                if (str.endsWith("/")) {
                    str = str.substring(0, str.length() - 1);
                }
            } catch (IndexOutOfBoundsException e) {
                gs.m1409T(e.getMessage());
            }
        }
        return str;
    }

    protected boolean m1451Y(String str) {
        Object Z = m1450Z(str);
        if (TextUtils.isEmpty(Z)) {
            return false;
        }
        try {
            URI uri = new URI(Z);
            if ("passback".equals(uri.getScheme())) {
                gs.m1408S("Passback received");
                this.xe.cz();
                return true;
            } else if (TextUtils.isEmpty(this.xc)) {
                return false;
            } else {
                URI uri2 = new URI(this.xc);
                String host = uri2.getHost();
                String host2 = uri.getHost();
                String path = uri2.getPath();
                String path2 = uri.getPath();
                if (!C0237n.equal(host, host2) || !C0237n.equal(path, path2)) {
                    return false;
                }
                gs.m1408S("Passback received");
                this.xe.cz();
                return true;
            }
        } catch (URISyntaxException e) {
            gs.m1409T(e.getMessage());
            return false;
        }
    }

    public void onLoadResource(WebView view, String url) {
        gs.m1408S("JavascriptAdWebViewClient::onLoadResource: " + url);
        if (!m1451Y(url)) {
            this.md.du().onLoadResource(this.md, url);
        }
    }

    public void onPageFinished(WebView view, String url) {
        gs.m1408S("JavascriptAdWebViewClient::onPageFinished: " + url);
        if (!this.xd) {
            this.xe.cy();
            this.xd = true;
        }
    }

    public boolean shouldOverrideUrlLoading(WebView view, String url) {
        gs.m1408S("JavascriptAdWebViewClient::shouldOverrideUrlLoading: " + url);
        if (!m1451Y(url)) {
            return this.md.du().shouldOverrideUrlLoading(this.md, url);
        }
        gs.m1408S("shouldOverrideUrlLoading: received passback url");
        return true;
    }
}
