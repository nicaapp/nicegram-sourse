package com.google.android.gms.internal;

import android.os.Binder;
import android.os.IBinder;
import android.os.IInterface;
import android.os.Parcel;
import android.os.RemoteException;
import com.google.android.gms.drive.events.CompletionEvent;
import com.google.android.gms.dynamic.C0330d;
import com.google.android.gms.dynamic.C0330d.C1766a;

public interface ej extends IInterface {

    /* renamed from: com.google.android.gms.internal.ej.a */
    public static abstract class C1834a extends Binder implements ej {

        /* renamed from: com.google.android.gms.internal.ej.a.a */
        private static class C1833a implements ej {
            private IBinder lb;

            C1833a(IBinder iBinder) {
                this.lb = iBinder;
            }

            public IBinder asBinder() {
                return this.lb;
            }

            public IBinder m3126b(C0330d c0330d) throws RemoteException {
                Parcel obtain = Parcel.obtain();
                Parcel obtain2 = Parcel.obtain();
                try {
                    obtain.writeInterfaceToken("com.google.android.gms.ads.internal.purchase.client.IInAppPurchaseManagerCreator");
                    obtain.writeStrongBinder(c0330d != null ? c0330d.asBinder() : null);
                    this.lb.transact(1, obtain, obtain2, 0);
                    obtain2.readException();
                    IBinder readStrongBinder = obtain2.readStrongBinder();
                    return readStrongBinder;
                } finally {
                    obtain2.recycle();
                    obtain.recycle();
                }
            }
        }

        public static ej m3127v(IBinder iBinder) {
            if (iBinder == null) {
                return null;
            }
            IInterface queryLocalInterface = iBinder.queryLocalInterface("com.google.android.gms.ads.internal.purchase.client.IInAppPurchaseManagerCreator");
            return (queryLocalInterface == null || !(queryLocalInterface instanceof ej)) ? new C1833a(iBinder) : (ej) queryLocalInterface;
        }

        public boolean onTransact(int code, Parcel data, Parcel reply, int flags) throws RemoteException {
            switch (code) {
                case CompletionEvent.STATUS_FAILURE /*1*/:
                    data.enforceInterface("com.google.android.gms.ads.internal.purchase.client.IInAppPurchaseManagerCreator");
                    IBinder b = m1243b(C1766a.am(data.readStrongBinder()));
                    reply.writeNoException();
                    reply.writeStrongBinder(b);
                    return true;
                case 1598968902:
                    reply.writeString("com.google.android.gms.ads.internal.purchase.client.IInAppPurchaseManagerCreator");
                    return true;
                default:
                    return super.onTransact(code, data, reply, flags);
            }
        }
    }

    IBinder m1243b(C0330d c0330d) throws RemoteException;
}
