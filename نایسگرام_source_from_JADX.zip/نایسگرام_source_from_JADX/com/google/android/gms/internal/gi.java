package com.google.android.gms.internal;

import android.os.Process;
import java.util.concurrent.Callable;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.Future;
import java.util.concurrent.ThreadFactory;
import java.util.concurrent.atomic.AtomicInteger;

@ez
public final class gi {
    private static final ThreadFactory wh;
    private static final ExecutorService wi;

    /* renamed from: com.google.android.gms.internal.gi.1 */
    static class C04941 implements Callable<Void> {
        final /* synthetic */ Runnable wj;

        C04941(Runnable runnable) {
            this.wj = runnable;
        }

        public /* synthetic */ Object call() throws Exception {
            return dj();
        }

        public Void dj() {
            this.wj.run();
            return null;
        }
    }

    /* renamed from: com.google.android.gms.internal.gi.2 */
    static class C04952 implements Callable<T> {
        final /* synthetic */ Callable wk;

        C04952(Callable callable) {
            this.wk = callable;
        }

        public T call() throws Exception {
            try {
                Process.setThreadPriority(10);
                return this.wk.call();
            } catch (Throwable e) {
                gb.m3194e(e);
                return null;
            }
        }
    }

    /* renamed from: com.google.android.gms.internal.gi.3 */
    static class C04963 implements ThreadFactory {
        private final AtomicInteger wl;

        C04963() {
            this.wl = new AtomicInteger(1);
        }

        public Thread newThread(Runnable runnable) {
            return new Thread(runnable, "AdWorker #" + this.wl.getAndIncrement());
        }
    }

    static {
        wh = new C04963();
        wi = Executors.newFixedThreadPool(10, wh);
    }

    public static Future<Void> m1353a(Runnable runnable) {
        return submit(new C04941(runnable));
    }

    public static <T> Future<T> submit(Callable<T> callable) {
        try {
            return wi.submit(new C04952(callable));
        } catch (Throwable e) {
            gs.m1416d("Thread execution is rejected.", e);
            return new gl(null);
        }
    }
}
