package com.google.android.gms.internal;

import android.content.Context;
import android.os.RemoteException;
import android.os.SystemClock;
import android.text.TextUtils;
import com.google.android.gms.dynamic.C2413e;
import com.google.android.gms.internal.cq.C0443a;

@ez
public final class cp implements C0443a {
    private final ct lq;
    private final Context mContext;
    private final av ml;
    private final Object mw;
    private final String qo;
    private final long qp;
    private final cl qq;
    private final ay qr;
    private final gt qs;
    private cu qt;
    private int qu;

    /* renamed from: com.google.android.gms.internal.cp.1 */
    class C04421 implements Runnable {
        final /* synthetic */ co qv;
        final /* synthetic */ cp qw;

        C04421(cp cpVar, co coVar) {
            this.qw = cpVar;
            this.qv = coVar;
        }

        public void run() {
            synchronized (this.qw.mw) {
                if (this.qw.qu != -2) {
                    return;
                }
                this.qw.qt = this.qw.bF();
                if (this.qw.qt == null) {
                    this.qw.m3089j(4);
                    return;
                }
                this.qv.m4200a(this.qw);
                this.qw.m3082a(this.qv);
            }
        }
    }

    public cp(Context context, String str, ct ctVar, cm cmVar, cl clVar, av avVar, ay ayVar, gt gtVar) {
        this.mw = new Object();
        this.qu = -2;
        this.mContext = context;
        this.lq = ctVar;
        this.qq = clVar;
        if ("com.google.ads.mediation.customevent.CustomEventAdapter".equals(str)) {
            this.qo = bE();
        } else {
            this.qo = str;
        }
        this.qp = cmVar.qe != -1 ? cmVar.qe : 10000;
        this.ml = avVar;
        this.qr = ayVar;
        this.qs = gtVar;
    }

    private void m3081a(long j, long j2, long j3, long j4) {
        while (this.qu == -2) {
            m3085b(j, j2, j3, j4);
        }
    }

    private void m3082a(co coVar) {
        try {
            if (this.qs.wF < 4100000) {
                if (this.qr.og) {
                    this.qt.m1175a(C2413e.m3897k(this.mContext), this.ml, this.qq.qc, coVar);
                } else {
                    this.qt.m1177a(C2413e.m3897k(this.mContext), this.qr, this.ml, this.qq.qc, (cv) coVar);
                }
            } else if (this.qr.og) {
                this.qt.m1176a(C2413e.m3897k(this.mContext), this.ml, this.qq.qc, this.qq.pW, (cv) coVar);
            } else {
                this.qt.m1178a(C2413e.m3897k(this.mContext), this.qr, this.ml, this.qq.qc, this.qq.pW, coVar);
            }
        } catch (Throwable e) {
            gs.m1416d("Could not request ad from mediation adapter.", e);
            m3089j(5);
        }
    }

    private void m3085b(long j, long j2, long j3, long j4) {
        long elapsedRealtime = SystemClock.elapsedRealtime();
        long j5 = j2 - (elapsedRealtime - j);
        elapsedRealtime = j4 - (elapsedRealtime - j3);
        if (j5 <= 0 || elapsedRealtime <= 0) {
            gs.m1410U("Timed out waiting for adapter.");
            this.qu = 3;
            return;
        }
        try {
            this.mw.wait(Math.min(j5, elapsedRealtime));
        } catch (InterruptedException e) {
            this.qu = -1;
        }
    }

    private String bE() {
        try {
            if (!TextUtils.isEmpty(this.qq.qa)) {
                return this.lq.m1174y(this.qq.qa) ? "com.google.android.gms.ads.mediation.customevent.CustomEventAdapter" : "com.google.ads.mediation.customevent.CustomEventAdapter";
            }
        } catch (RemoteException e) {
            gs.m1412W("Fail to determine the custom event's version, assuming the old one.");
        }
        return "com.google.ads.mediation.customevent.CustomEventAdapter";
    }

    private cu bF() {
        gs.m1410U("Instantiating mediation adapter: " + this.qo);
        try {
            return this.lq.m1173x(this.qo);
        } catch (Throwable e) {
            gs.m1413a("Could not instantiate mediation adapter: " + this.qo, e);
            return null;
        }
    }

    public cq m3088b(long j, long j2) {
        cq cqVar;
        synchronized (this.mw) {
            long elapsedRealtime = SystemClock.elapsedRealtime();
            co coVar = new co();
            gr.wC.post(new C04421(this, coVar));
            m3081a(elapsedRealtime, this.qp, j, j2);
            cqVar = new cq(this.qq, this.qt, this.qo, coVar, this.qu);
        }
        return cqVar;
    }

    public void cancel() {
        synchronized (this.mw) {
            try {
                if (this.qt != null) {
                    this.qt.destroy();
                }
            } catch (Throwable e) {
                gs.m1416d("Could not destroy mediation adapter.", e);
            }
            this.qu = -1;
            this.mw.notify();
        }
    }

    public void m3089j(int i) {
        synchronized (this.mw) {
            this.qu = i;
            this.mw.notify();
        }
    }
}
