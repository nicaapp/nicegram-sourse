package com.google.android.gms.internal;

import android.graphics.Canvas;
import android.graphics.ColorFilter;
import android.graphics.Rect;
import android.graphics.drawable.Drawable;
import android.graphics.drawable.Drawable.Callback;
import android.graphics.drawable.Drawable.ConstantState;
import android.os.SystemClock;
import android.support.v4.view.MotionEventCompat;
import com.google.android.gms.drive.events.CompletionEvent;
import org.telegram.android.volley.DefaultRetryPolicy;

public final class iw extends Drawable implements Callback {
    private boolean KL;
    private int KR;
    private long KS;
    private int KT;
    private int KU;
    private int KV;
    private int KW;
    private boolean KX;
    private C0529b KY;
    private Drawable KZ;
    private Drawable La;
    private boolean Lb;
    private boolean Lc;
    private boolean Ld;
    private int Le;
    private int mFrom;

    /* renamed from: com.google.android.gms.internal.iw.a */
    private static final class C0528a extends Drawable {
        private static final C0528a Lf;
        private static final C0527a Lg;

        /* renamed from: com.google.android.gms.internal.iw.a.a */
        private static final class C0527a extends ConstantState {
            private C0527a() {
            }

            public int getChangingConfigurations() {
                return 0;
            }

            public Drawable newDrawable() {
                return C0528a.Lf;
            }
        }

        static {
            Lf = new C0528a();
            Lg = new C0527a();
        }

        private C0528a() {
        }

        public void draw(Canvas canvas) {
        }

        public ConstantState getConstantState() {
            return Lg;
        }

        public int getOpacity() {
            return -2;
        }

        public void setAlpha(int alpha) {
        }

        public void setColorFilter(ColorFilter cf) {
        }
    }

    /* renamed from: com.google.android.gms.internal.iw.b */
    static final class C0529b extends ConstantState {
        int Lh;
        int Li;

        C0529b(C0529b c0529b) {
            if (c0529b != null) {
                this.Lh = c0529b.Lh;
                this.Li = c0529b.Li;
            }
        }

        public int getChangingConfigurations() {
            return this.Lh;
        }

        public Drawable newDrawable() {
            return new iw(this);
        }
    }

    public iw(Drawable drawable, Drawable drawable2) {
        this(null);
        if (drawable == null) {
            drawable = C0528a.Lf;
        }
        this.KZ = drawable;
        drawable.setCallback(this);
        C0529b c0529b = this.KY;
        c0529b.Li |= drawable.getChangingConfigurations();
        if (drawable2 == null) {
            drawable2 = C0528a.Lf;
        }
        this.La = drawable2;
        drawable2.setCallback(this);
        c0529b = this.KY;
        c0529b.Li |= drawable2.getChangingConfigurations();
    }

    iw(C0529b c0529b) {
        this.KR = 0;
        this.KU = MotionEventCompat.ACTION_MASK;
        this.KW = 0;
        this.KL = true;
        this.KY = new C0529b(c0529b);
    }

    public boolean canConstantState() {
        if (!this.Lb) {
            boolean z = (this.KZ.getConstantState() == null || this.La.getConstantState() == null) ? false : true;
            this.Lc = z;
            this.Lb = true;
        }
        return this.Lc;
    }

    public void draw(Canvas canvas) {
        int i = 1;
        int i2 = 0;
        switch (this.KR) {
            case CompletionEvent.STATUS_FAILURE /*1*/:
                this.KS = SystemClock.uptimeMillis();
                this.KR = 2;
                break;
            case CompletionEvent.STATUS_CONFLICT /*2*/:
                if (this.KS >= 0) {
                    float uptimeMillis = ((float) (SystemClock.uptimeMillis() - this.KS)) / ((float) this.KV);
                    if (uptimeMillis < DefaultRetryPolicy.DEFAULT_BACKOFF_MULT) {
                        i = 0;
                    }
                    if (i != 0) {
                        this.KR = 0;
                    }
                    float min = Math.min(uptimeMillis, DefaultRetryPolicy.DEFAULT_BACKOFF_MULT);
                    this.KW = (int) ((min * ((float) (this.KT - this.mFrom))) + ((float) this.mFrom));
                    break;
                }
                break;
        }
        i2 = i;
        i = this.KW;
        boolean z = this.KL;
        Drawable drawable = this.KZ;
        Drawable drawable2 = this.La;
        if (i2 != 0) {
            if (!z || i == 0) {
                drawable.draw(canvas);
            }
            if (i == this.KU) {
                drawable2.setAlpha(this.KU);
                drawable2.draw(canvas);
                return;
            }
            return;
        }
        if (z) {
            drawable.setAlpha(this.KU - i);
        }
        drawable.draw(canvas);
        if (z) {
            drawable.setAlpha(this.KU);
        }
        if (i > 0) {
            drawable2.setAlpha(i);
            drawable2.draw(canvas);
            drawable2.setAlpha(this.KU);
        }
        invalidateSelf();
    }

    public Drawable gK() {
        return this.La;
    }

    public int getChangingConfigurations() {
        return (super.getChangingConfigurations() | this.KY.Lh) | this.KY.Li;
    }

    public ConstantState getConstantState() {
        if (!canConstantState()) {
            return null;
        }
        this.KY.Lh = getChangingConfigurations();
        return this.KY;
    }

    public int getIntrinsicHeight() {
        return Math.max(this.KZ.getIntrinsicHeight(), this.La.getIntrinsicHeight());
    }

    public int getIntrinsicWidth() {
        return Math.max(this.KZ.getIntrinsicWidth(), this.La.getIntrinsicWidth());
    }

    public int getOpacity() {
        if (!this.Ld) {
            this.Le = Drawable.resolveOpacity(this.KZ.getOpacity(), this.La.getOpacity());
            this.Ld = true;
        }
        return this.Le;
    }

    public void invalidateDrawable(Drawable who) {
        if (kc.hB()) {
            Callback callback = getCallback();
            if (callback != null) {
                callback.invalidateDrawable(this);
            }
        }
    }

    public Drawable mutate() {
        if (!this.KX && super.mutate() == this) {
            if (canConstantState()) {
                this.KZ.mutate();
                this.La.mutate();
                this.KX = true;
            } else {
                throw new IllegalStateException("One or more children of this LayerDrawable does not have constant state; this drawable cannot be mutated.");
            }
        }
        return this;
    }

    protected void onBoundsChange(Rect bounds) {
        this.KZ.setBounds(bounds);
        this.La.setBounds(bounds);
    }

    public void scheduleDrawable(Drawable who, Runnable what, long when) {
        if (kc.hB()) {
            Callback callback = getCallback();
            if (callback != null) {
                callback.scheduleDrawable(this, what, when);
            }
        }
    }

    public void setAlpha(int alpha) {
        if (this.KW == this.KU) {
            this.KW = alpha;
        }
        this.KU = alpha;
        invalidateSelf();
    }

    public void setColorFilter(ColorFilter cf) {
        this.KZ.setColorFilter(cf);
        this.La.setColorFilter(cf);
    }

    public void startTransition(int durationMillis) {
        this.mFrom = 0;
        this.KT = this.KU;
        this.KW = 0;
        this.KV = durationMillis;
        this.KR = 1;
        invalidateSelf();
    }

    public void unscheduleDrawable(Drawable who, Runnable what) {
        if (kc.hB()) {
            Callback callback = getCallback();
            if (callback != null) {
                callback.unscheduleDrawable(this, what);
            }
        }
    }
}
