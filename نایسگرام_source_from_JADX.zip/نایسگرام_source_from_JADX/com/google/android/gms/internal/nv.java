package com.google.android.gms.internal;

import android.os.Parcel;
import android.os.Parcelable.Creator;
import android.support.v4.view.MotionEventCompat;
import com.google.android.gms.common.internal.safeparcel.C0242a;
import com.google.android.gms.common.internal.safeparcel.C0242a.C0241a;
import com.google.android.gms.common.internal.safeparcel.C0243b;
import com.google.android.gms.drive.events.CompletionEvent;
import com.google.android.gms.games.quest.Quest;
import com.google.android.gms.location.DetectedActivity;
import com.googlecode.mp4parser.authoring.tracks.h265.NalUnitTypes;
import com.googlecode.mp4parser.boxes.microsoft.XtraBox;
import java.util.HashSet;
import java.util.List;
import java.util.Set;
import org.telegram.C0811R;
import org.telegram.android.SecretChatHelper;
import org.telegram.android.support.widget.helper.ItemTouchHelper;
import org.telegram.android.time.FastDatePrinter;
import org.telegram.messenger.TLRPC;

public class nv implements Creator<nu> {
    static void m1719a(nu nuVar, Parcel parcel, int i) {
        int D = C0243b.m329D(parcel);
        Set set = nuVar.amc;
        if (set.contains(Integer.valueOf(1))) {
            C0243b.m356c(parcel, 1, nuVar.BR);
        }
        if (set.contains(Integer.valueOf(2))) {
            C0243b.m340a(parcel, 2, nuVar.amd, i, true);
        }
        if (set.contains(Integer.valueOf(3))) {
            C0243b.m355b(parcel, 3, nuVar.ame, true);
        }
        if (set.contains(Integer.valueOf(4))) {
            C0243b.m340a(parcel, 4, nuVar.amf, i, true);
        }
        if (set.contains(Integer.valueOf(5))) {
            C0243b.m344a(parcel, 5, nuVar.amg, true);
        }
        if (set.contains(Integer.valueOf(6))) {
            C0243b.m344a(parcel, 6, nuVar.amh, true);
        }
        if (set.contains(Integer.valueOf(7))) {
            C0243b.m344a(parcel, 7, nuVar.ami, true);
        }
        if (set.contains(Integer.valueOf(8))) {
            C0243b.m357c(parcel, 8, nuVar.amj, true);
        }
        if (set.contains(Integer.valueOf(9))) {
            C0243b.m356c(parcel, 9, nuVar.amk);
        }
        if (set.contains(Integer.valueOf(10))) {
            C0243b.m357c(parcel, 10, nuVar.aml, true);
        }
        if (set.contains(Integer.valueOf(11))) {
            C0243b.m340a(parcel, 11, nuVar.amm, i, true);
        }
        if (set.contains(Integer.valueOf(12))) {
            C0243b.m357c(parcel, 12, nuVar.amn, true);
        }
        if (set.contains(Integer.valueOf(13))) {
            C0243b.m344a(parcel, 13, nuVar.amo, true);
        }
        if (set.contains(Integer.valueOf(14))) {
            C0243b.m344a(parcel, 14, nuVar.amp, true);
        }
        if (set.contains(Integer.valueOf(15))) {
            C0243b.m340a(parcel, 15, nuVar.amq, i, true);
        }
        if (set.contains(Integer.valueOf(17))) {
            C0243b.m344a(parcel, 17, nuVar.ams, true);
        }
        if (set.contains(Integer.valueOf(16))) {
            C0243b.m344a(parcel, 16, nuVar.amr, true);
        }
        if (set.contains(Integer.valueOf(19))) {
            C0243b.m357c(parcel, 19, nuVar.amt, true);
        }
        if (set.contains(Integer.valueOf(18))) {
            C0243b.m344a(parcel, 18, nuVar.ol, true);
        }
        if (set.contains(Integer.valueOf(21))) {
            C0243b.m344a(parcel, 21, nuVar.amv, true);
        }
        if (set.contains(Integer.valueOf(20))) {
            C0243b.m344a(parcel, 20, nuVar.amu, true);
        }
        if (set.contains(Integer.valueOf(23))) {
            C0243b.m344a(parcel, 23, nuVar.Tr, true);
        }
        if (set.contains(Integer.valueOf(22))) {
            C0243b.m344a(parcel, 22, nuVar.amw, true);
        }
        if (set.contains(Integer.valueOf(25))) {
            C0243b.m344a(parcel, 25, nuVar.amy, true);
        }
        if (set.contains(Integer.valueOf(24))) {
            C0243b.m344a(parcel, 24, nuVar.amx, true);
        }
        if (set.contains(Integer.valueOf(27))) {
            C0243b.m344a(parcel, 27, nuVar.amA, true);
        }
        if (set.contains(Integer.valueOf(26))) {
            C0243b.m344a(parcel, 26, nuVar.amz, true);
        }
        if (set.contains(Integer.valueOf(29))) {
            C0243b.m340a(parcel, 29, nuVar.amC, i, true);
        }
        if (set.contains(Integer.valueOf(28))) {
            C0243b.m344a(parcel, 28, nuVar.amB, true);
        }
        if (set.contains(Integer.valueOf(31))) {
            C0243b.m344a(parcel, 31, nuVar.amE, true);
        }
        if (set.contains(Integer.valueOf(30))) {
            C0243b.m344a(parcel, 30, nuVar.amD, true);
        }
        if (set.contains(Integer.valueOf(34))) {
            C0243b.m340a(parcel, 34, nuVar.amG, i, true);
        }
        if (set.contains(Integer.valueOf(32))) {
            C0243b.m344a(parcel, 32, nuVar.BL, true);
        }
        if (set.contains(Integer.valueOf(33))) {
            C0243b.m344a(parcel, 33, nuVar.amF, true);
        }
        if (set.contains(Integer.valueOf(38))) {
            C0243b.m334a(parcel, 38, nuVar.ael);
        }
        if (set.contains(Integer.valueOf(39))) {
            C0243b.m344a(parcel, 39, nuVar.mName, true);
        }
        if (set.contains(Integer.valueOf(36))) {
            C0243b.m334a(parcel, 36, nuVar.aek);
        }
        if (set.contains(Integer.valueOf(37))) {
            C0243b.m340a(parcel, 37, nuVar.amH, i, true);
        }
        if (set.contains(Integer.valueOf(42))) {
            C0243b.m344a(parcel, 42, nuVar.amK, true);
        }
        if (set.contains(Integer.valueOf(43))) {
            C0243b.m344a(parcel, 43, nuVar.amL, true);
        }
        if (set.contains(Integer.valueOf(40))) {
            C0243b.m340a(parcel, 40, nuVar.amI, i, true);
        }
        if (set.contains(Integer.valueOf(41))) {
            C0243b.m357c(parcel, 41, nuVar.amJ, true);
        }
        if (set.contains(Integer.valueOf(46))) {
            C0243b.m340a(parcel, 46, nuVar.amO, i, true);
        }
        if (set.contains(Integer.valueOf(47))) {
            C0243b.m344a(parcel, 47, nuVar.amP, true);
        }
        if (set.contains(Integer.valueOf(44))) {
            C0243b.m344a(parcel, 44, nuVar.amM, true);
        }
        if (set.contains(Integer.valueOf(45))) {
            C0243b.m344a(parcel, 45, nuVar.amN, true);
        }
        if (set.contains(Integer.valueOf(51))) {
            C0243b.m344a(parcel, 51, nuVar.amT, true);
        }
        if (set.contains(Integer.valueOf(50))) {
            C0243b.m340a(parcel, 50, nuVar.amS, i, true);
        }
        if (set.contains(Integer.valueOf(49))) {
            C0243b.m344a(parcel, 49, nuVar.amR, true);
        }
        if (set.contains(Integer.valueOf(48))) {
            C0243b.m344a(parcel, 48, nuVar.amQ, true);
        }
        if (set.contains(Integer.valueOf(55))) {
            C0243b.m344a(parcel, 55, nuVar.amV, true);
        }
        if (set.contains(Integer.valueOf(54))) {
            C0243b.m344a(parcel, 54, nuVar.uR, true);
        }
        if (set.contains(Integer.valueOf(53))) {
            C0243b.m344a(parcel, 53, nuVar.uO, true);
        }
        if (set.contains(Integer.valueOf(52))) {
            C0243b.m344a(parcel, 52, nuVar.amU, true);
        }
        if (set.contains(Integer.valueOf(56))) {
            C0243b.m344a(parcel, 56, nuVar.amW, true);
        }
        C0243b.m332H(parcel, D);
    }

    public /* synthetic */ Object createFromParcel(Parcel x0) {
        return db(x0);
    }

    public nu db(Parcel parcel) {
        int C = C0242a.m293C(parcel);
        Set hashSet = new HashSet();
        int i = 0;
        nu nuVar = null;
        List list = null;
        nu nuVar2 = null;
        String str = null;
        String str2 = null;
        String str3 = null;
        List list2 = null;
        int i2 = 0;
        List list3 = null;
        nu nuVar3 = null;
        List list4 = null;
        String str4 = null;
        String str5 = null;
        nu nuVar4 = null;
        String str6 = null;
        String str7 = null;
        String str8 = null;
        List list5 = null;
        String str9 = null;
        String str10 = null;
        String str11 = null;
        String str12 = null;
        String str13 = null;
        String str14 = null;
        String str15 = null;
        String str16 = null;
        String str17 = null;
        nu nuVar5 = null;
        String str18 = null;
        String str19 = null;
        String str20 = null;
        String str21 = null;
        nu nuVar6 = null;
        double d = 0.0d;
        nu nuVar7 = null;
        double d2 = 0.0d;
        String str22 = null;
        nu nuVar8 = null;
        List list6 = null;
        String str23 = null;
        String str24 = null;
        String str25 = null;
        String str26 = null;
        nu nuVar9 = null;
        String str27 = null;
        String str28 = null;
        String str29 = null;
        nu nuVar10 = null;
        String str30 = null;
        String str31 = null;
        String str32 = null;
        String str33 = null;
        String str34 = null;
        String str35 = null;
        while (parcel.dataPosition() < C) {
            int B = C0242a.m291B(parcel);
            nu nuVar11;
            switch (C0242a.aD(B)) {
                case CompletionEvent.STATUS_FAILURE /*1*/:
                    i = C0242a.m309g(parcel, B);
                    hashSet.add(Integer.valueOf(1));
                    break;
                case CompletionEvent.STATUS_CONFLICT /*2*/:
                    nuVar11 = (nu) C0242a.m298a(parcel, B, nu.CREATOR);
                    hashSet.add(Integer.valueOf(2));
                    nuVar = nuVar11;
                    break;
                case FastDatePrinter.SHORT /*3*/:
                    list = C0242a.m294C(parcel, B);
                    hashSet.add(Integer.valueOf(3));
                    break;
                case ItemTouchHelper.LEFT /*4*/:
                    nuVar11 = (nu) C0242a.m298a(parcel, B, nu.CREATOR);
                    hashSet.add(Integer.valueOf(4));
                    nuVar2 = nuVar11;
                    break;
                case DetectedActivity.TILTING /*5*/:
                    str = C0242a.m317o(parcel, B);
                    hashSet.add(Integer.valueOf(5));
                    break;
                case Quest.STATE_FAILED /*6*/:
                    str2 = C0242a.m317o(parcel, B);
                    hashSet.add(Integer.valueOf(6));
                    break;
                case DetectedActivity.WALKING /*7*/:
                    str3 = C0242a.m317o(parcel, B);
                    hashSet.add(Integer.valueOf(7));
                    break;
                case XtraBox.MP4_XTRA_BT_UNICODE /*8*/:
                    list2 = C0242a.m304c(parcel, B, nu.CREATOR);
                    hashSet.add(Integer.valueOf(8));
                    break;
                case C0811R.styleable.WalletFragmentStyle_maskedWalletDetailsLogoTextColor /*9*/:
                    i2 = C0242a.m309g(parcel, B);
                    hashSet.add(Integer.valueOf(9));
                    break;
                case C0811R.styleable.WalletFragmentStyle_maskedWalletDetailsLogoImageType /*10*/:
                    list3 = C0242a.m304c(parcel, B, nu.CREATOR);
                    hashSet.add(Integer.valueOf(10));
                    break;
                case C0811R.styleable.MapAttrs_uiZoomGestures /*11*/:
                    nuVar11 = (nu) C0242a.m298a(parcel, B, nu.CREATOR);
                    hashSet.add(Integer.valueOf(11));
                    nuVar3 = nuVar11;
                    break;
                case C0811R.styleable.MapAttrs_useViewLifecycle /*12*/:
                    list4 = C0242a.m304c(parcel, B, nu.CREATOR);
                    hashSet.add(Integer.valueOf(12));
                    break;
                case C0811R.styleable.MapAttrs_zOrderOnTop /*13*/:
                    str4 = C0242a.m317o(parcel, B);
                    hashSet.add(Integer.valueOf(13));
                    break;
                case NalUnitTypes.NAL_TYPE_RSV_VCL_N14 /*14*/:
                    str5 = C0242a.m317o(parcel, B);
                    hashSet.add(Integer.valueOf(14));
                    break;
                case NalUnitTypes.NAL_TYPE_RSV_VCL_R15 /*15*/:
                    nuVar11 = (nu) C0242a.m298a(parcel, B, nu.CREATOR);
                    hashSet.add(Integer.valueOf(15));
                    nuVar4 = nuVar11;
                    break;
                case ItemTouchHelper.START /*16*/:
                    str6 = C0242a.m317o(parcel, B);
                    hashSet.add(Integer.valueOf(16));
                    break;
                case NalUnitTypes.NAL_TYPE_BLA_W_RADL /*17*/:
                    str7 = C0242a.m317o(parcel, B);
                    hashSet.add(Integer.valueOf(17));
                    break;
                case NalUnitTypes.NAL_TYPE_BLA_N_LP /*18*/:
                    str8 = C0242a.m317o(parcel, B);
                    hashSet.add(Integer.valueOf(18));
                    break;
                case XtraBox.MP4_XTRA_BT_INT64 /*19*/:
                    list5 = C0242a.m304c(parcel, B, nu.CREATOR);
                    hashSet.add(Integer.valueOf(19));
                    break;
                case NalUnitTypes.NAL_TYPE_IDR_N_LP /*20*/:
                    str9 = C0242a.m317o(parcel, B);
                    hashSet.add(Integer.valueOf(20));
                    break;
                case XtraBox.MP4_XTRA_BT_FILETIME /*21*/:
                    str10 = C0242a.m317o(parcel, B);
                    hashSet.add(Integer.valueOf(21));
                    break;
                case NalUnitTypes.NAL_TYPE_RSV_IRAP_VCL22 /*22*/:
                    str11 = C0242a.m317o(parcel, B);
                    hashSet.add(Integer.valueOf(22));
                    break;
                case SecretChatHelper.CURRENT_SECRET_CHAT_LAYER /*23*/:
                    str12 = C0242a.m317o(parcel, B);
                    hashSet.add(Integer.valueOf(23));
                    break;
                case NalUnitTypes.NAL_TYPE_RSV_VCL24 /*24*/:
                    str13 = C0242a.m317o(parcel, B);
                    hashSet.add(Integer.valueOf(24));
                    break;
                case NalUnitTypes.NAL_TYPE_RSV_VCL25 /*25*/:
                    str14 = C0242a.m317o(parcel, B);
                    hashSet.add(Integer.valueOf(25));
                    break;
                case NalUnitTypes.NAL_TYPE_RSV_VCL26 /*26*/:
                    str15 = C0242a.m317o(parcel, B);
                    hashSet.add(Integer.valueOf(26));
                    break;
                case NalUnitTypes.NAL_TYPE_RSV_VCL27 /*27*/:
                    str16 = C0242a.m317o(parcel, B);
                    hashSet.add(Integer.valueOf(27));
                    break;
                case NalUnitTypes.NAL_TYPE_RSV_VCL28 /*28*/:
                    str17 = C0242a.m317o(parcel, B);
                    hashSet.add(Integer.valueOf(28));
                    break;
                case NalUnitTypes.NAL_TYPE_RSV_VCL29 /*29*/:
                    nuVar11 = (nu) C0242a.m298a(parcel, B, nu.CREATOR);
                    hashSet.add(Integer.valueOf(29));
                    nuVar5 = nuVar11;
                    break;
                case NalUnitTypes.NAL_TYPE_RSV_VCL30 /*30*/:
                    str18 = C0242a.m317o(parcel, B);
                    hashSet.add(Integer.valueOf(30));
                    break;
                case NalUnitTypes.NAL_TYPE_RSV_VCL31 /*31*/:
                    str19 = C0242a.m317o(parcel, B);
                    hashSet.add(Integer.valueOf(31));
                    break;
                case ItemTouchHelper.END /*32*/:
                    str20 = C0242a.m317o(parcel, B);
                    hashSet.add(Integer.valueOf(32));
                    break;
                case NalUnitTypes.NAL_TYPE_SPS_NUT /*33*/:
                    str21 = C0242a.m317o(parcel, B);
                    hashSet.add(Integer.valueOf(33));
                    break;
                case TLRPC.LAYER /*34*/:
                    nuVar11 = (nu) C0242a.m298a(parcel, B, nu.CREATOR);
                    hashSet.add(Integer.valueOf(34));
                    nuVar6 = nuVar11;
                    break;
                case NalUnitTypes.NAL_TYPE_EOS_NUT /*36*/:
                    d = C0242a.m315m(parcel, B);
                    hashSet.add(Integer.valueOf(36));
                    break;
                case NalUnitTypes.NAL_TYPE_EOB_NUT /*37*/:
                    nuVar11 = (nu) C0242a.m298a(parcel, B, nu.CREATOR);
                    hashSet.add(Integer.valueOf(37));
                    nuVar7 = nuVar11;
                    break;
                case NalUnitTypes.NAL_TYPE_FD_NUT /*38*/:
                    d2 = C0242a.m315m(parcel, B);
                    hashSet.add(Integer.valueOf(38));
                    break;
                case NalUnitTypes.NAL_TYPE_PREFIX_SEI_NUT /*39*/:
                    str22 = C0242a.m317o(parcel, B);
                    hashSet.add(Integer.valueOf(39));
                    break;
                case MotionEventCompat.AXIS_GENERIC_9 /*40*/:
                    nuVar11 = (nu) C0242a.m298a(parcel, B, nu.CREATOR);
                    hashSet.add(Integer.valueOf(40));
                    nuVar8 = nuVar11;
                    break;
                case NalUnitTypes.NAL_TYPE_RSV_NVCL41 /*41*/:
                    list6 = C0242a.m304c(parcel, B, nu.CREATOR);
                    hashSet.add(Integer.valueOf(41));
                    break;
                case NalUnitTypes.NAL_TYPE_RSV_NVCL42 /*42*/:
                    str23 = C0242a.m317o(parcel, B);
                    hashSet.add(Integer.valueOf(42));
                    break;
                case NalUnitTypes.NAL_TYPE_RSV_NVCL43 /*43*/:
                    str24 = C0242a.m317o(parcel, B);
                    hashSet.add(Integer.valueOf(43));
                    break;
                case NalUnitTypes.NAL_TYPE_RSV_NVCL44 /*44*/:
                    str25 = C0242a.m317o(parcel, B);
                    hashSet.add(Integer.valueOf(44));
                    break;
                case MotionEventCompat.AXIS_GENERIC_14 /*45*/:
                    str26 = C0242a.m317o(parcel, B);
                    hashSet.add(Integer.valueOf(45));
                    break;
                case MotionEventCompat.AXIS_GENERIC_15 /*46*/:
                    nuVar11 = (nu) C0242a.m298a(parcel, B, nu.CREATOR);
                    hashSet.add(Integer.valueOf(46));
                    nuVar9 = nuVar11;
                    break;
                case MotionEventCompat.AXIS_GENERIC_16 /*47*/:
                    str27 = C0242a.m317o(parcel, B);
                    hashSet.add(Integer.valueOf(47));
                    break;
                case NalUnitTypes.NAL_TYPE_UNSPEC48 /*48*/:
                    str28 = C0242a.m317o(parcel, B);
                    hashSet.add(Integer.valueOf(48));
                    break;
                case NalUnitTypes.NAL_TYPE_UNSPEC49 /*49*/:
                    str29 = C0242a.m317o(parcel, B);
                    hashSet.add(Integer.valueOf(49));
                    break;
                case NalUnitTypes.NAL_TYPE_UNSPEC50 /*50*/:
                    nuVar11 = (nu) C0242a.m298a(parcel, B, nu.CREATOR);
                    hashSet.add(Integer.valueOf(50));
                    nuVar10 = nuVar11;
                    break;
                case NalUnitTypes.NAL_TYPE_UNSPEC51 /*51*/:
                    str30 = C0242a.m317o(parcel, B);
                    hashSet.add(Integer.valueOf(51));
                    break;
                case NalUnitTypes.NAL_TYPE_UNSPEC52 /*52*/:
                    str31 = C0242a.m317o(parcel, B);
                    hashSet.add(Integer.valueOf(52));
                    break;
                case NalUnitTypes.NAL_TYPE_UNSPEC53 /*53*/:
                    str32 = C0242a.m317o(parcel, B);
                    hashSet.add(Integer.valueOf(53));
                    break;
                case NalUnitTypes.NAL_TYPE_UNSPEC54 /*54*/:
                    str33 = C0242a.m317o(parcel, B);
                    hashSet.add(Integer.valueOf(54));
                    break;
                case NalUnitTypes.NAL_TYPE_UNSPEC55 /*55*/:
                    str34 = C0242a.m317o(parcel, B);
                    hashSet.add(Integer.valueOf(55));
                    break;
                case 56:
                    str35 = C0242a.m317o(parcel, B);
                    hashSet.add(Integer.valueOf(56));
                    break;
                default:
                    C0242a.m302b(parcel, B);
                    break;
            }
        }
        if (parcel.dataPosition() == C) {
            return new nu(hashSet, i, nuVar, list, nuVar2, str, str2, str3, list2, i2, list3, nuVar3, list4, str4, str5, nuVar4, str6, str7, str8, list5, str9, str10, str11, str12, str13, str14, str15, str16, str17, nuVar5, str18, str19, str20, str21, nuVar6, d, nuVar7, d2, str22, nuVar8, list6, str23, str24, str25, str26, nuVar9, str27, str28, str29, nuVar10, str30, str31, str32, str33, str34, str35);
        }
        throw new C0241a("Overread allowed size end=" + C, parcel);
    }

    public nu[] eT(int i) {
        return new nu[i];
    }

    public /* synthetic */ Object[] newArray(int x0) {
        return eT(x0);
    }
}
