package com.google.android.gms.internal;

@ez
public final class fy implements fx {
    public String m3188K(String str) {
        return null;
    }
}
