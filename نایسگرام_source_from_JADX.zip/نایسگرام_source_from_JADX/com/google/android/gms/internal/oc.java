package com.google.android.gms.internal;

import android.os.Parcel;
import android.os.Parcelable.Creator;
import com.google.android.gms.common.internal.safeparcel.C0242a;
import com.google.android.gms.common.internal.safeparcel.C0242a.C0241a;
import com.google.android.gms.common.internal.safeparcel.C0243b;
import com.google.android.gms.drive.events.CompletionEvent;
import com.google.android.gms.internal.nz.C2501b;
import com.google.android.gms.internal.nz.C2501b.C2499a;
import com.google.android.gms.internal.nz.C2501b.C2500b;
import java.util.HashSet;
import java.util.Set;
import org.telegram.android.support.widget.helper.ItemTouchHelper;
import org.telegram.android.time.FastDatePrinter;

public class oc implements Creator<C2501b> {
    static void m1726a(C2501b c2501b, Parcel parcel, int i) {
        int D = C0243b.m329D(parcel);
        Set set = c2501b.amc;
        if (set.contains(Integer.valueOf(1))) {
            C0243b.m356c(parcel, 1, c2501b.BR);
        }
        if (set.contains(Integer.valueOf(2))) {
            C0243b.m340a(parcel, 2, c2501b.anv, i, true);
        }
        if (set.contains(Integer.valueOf(3))) {
            C0243b.m340a(parcel, 3, c2501b.anw, i, true);
        }
        if (set.contains(Integer.valueOf(4))) {
            C0243b.m356c(parcel, 4, c2501b.anx);
        }
        C0243b.m332H(parcel, D);
    }

    public /* synthetic */ Object createFromParcel(Parcel x0) {
        return df(x0);
    }

    public C2501b df(Parcel parcel) {
        C2500b c2500b = null;
        int i = 0;
        int C = C0242a.m293C(parcel);
        Set hashSet = new HashSet();
        C2499a c2499a = null;
        int i2 = 0;
        while (parcel.dataPosition() < C) {
            int B = C0242a.m291B(parcel);
            switch (C0242a.aD(B)) {
                case CompletionEvent.STATUS_FAILURE /*1*/:
                    i2 = C0242a.m309g(parcel, B);
                    hashSet.add(Integer.valueOf(1));
                    break;
                case CompletionEvent.STATUS_CONFLICT /*2*/:
                    C2499a c2499a2 = (C2499a) C0242a.m298a(parcel, B, C2499a.CREATOR);
                    hashSet.add(Integer.valueOf(2));
                    c2499a = c2499a2;
                    break;
                case FastDatePrinter.SHORT /*3*/:
                    C2500b c2500b2 = (C2500b) C0242a.m298a(parcel, B, C2500b.CREATOR);
                    hashSet.add(Integer.valueOf(3));
                    c2500b = c2500b2;
                    break;
                case ItemTouchHelper.LEFT /*4*/:
                    i = C0242a.m309g(parcel, B);
                    hashSet.add(Integer.valueOf(4));
                    break;
                default:
                    C0242a.m302b(parcel, B);
                    break;
            }
        }
        if (parcel.dataPosition() == C) {
            return new C2501b(hashSet, i2, c2499a, c2500b, i);
        }
        throw new C0241a("Overread allowed size end=" + C, parcel);
    }

    public C2501b[] eX(int i) {
        return new C2501b[i];
    }

    public /* synthetic */ Object[] newArray(int x0) {
        return eX(x0);
    }
}
