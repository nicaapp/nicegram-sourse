package com.google.android.gms.internal;

import java.io.IOException;

public interface ir {
    void m1538a(String str, String str2, long j, String str3) throws IOException;

    long fx();
}
