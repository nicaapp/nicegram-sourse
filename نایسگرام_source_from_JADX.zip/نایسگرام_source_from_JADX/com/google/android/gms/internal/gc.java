package com.google.android.gms.internal;

import android.content.ComponentName;
import android.content.Context;
import android.content.pm.PackageManager.NameNotFoundException;
import android.os.Bundle;
import com.google.android.gms.ads.AdActivity;

@ez
public class gc {
    private final Object mw;
    private final String vL;
    private int vX;
    private long vY;
    private long vZ;
    private int wa;
    private int wb;

    public gc(String str) {
        this.mw = new Object();
        this.vX = 0;
        this.vY = -1;
        this.vZ = -1;
        this.wa = 0;
        this.wb = -1;
        this.vL = str;
    }

    public static boolean m1342m(Context context) {
        int identifier = context.getResources().getIdentifier("Theme.Translucent", "style", "android");
        if (identifier == 0) {
            gs.m1410U("Please set theme of AdActivity to @android:style/Theme.Translucent to enable transparent background interstitial ad.");
            return false;
        }
        try {
            if (identifier == context.getPackageManager().getActivityInfo(new ComponentName(context.getPackageName(), AdActivity.CLASS_NAME), 0).theme) {
                return true;
            }
            gs.m1410U("Please set theme of AdActivity to @android:style/Theme.Translucent to enable transparent background interstitial ad.");
            return false;
        } catch (NameNotFoundException e) {
            gs.m1412W("Fail to fetch AdActivity theme");
            gs.m1410U("Please set theme of AdActivity to @android:style/Theme.Translucent to enable transparent background interstitial ad.");
            return false;
        }
    }

    public Bundle m1343b(Context context, String str) {
        Bundle bundle;
        synchronized (this.mw) {
            bundle = new Bundle();
            bundle.putString("session_id", this.vL);
            bundle.putLong("basets", this.vZ);
            bundle.putLong("currts", this.vY);
            bundle.putString("seq_num", str);
            bundle.putInt("preqs", this.wb);
            bundle.putInt("pclick", this.vX);
            bundle.putInt("pimp", this.wa);
            bundle.putBoolean("support_transparent_background", m1342m(context));
        }
        return bundle;
    }

    public void m1344b(av avVar, long j) {
        synchronized (this.mw) {
            if (this.vZ == -1) {
                this.vZ = j;
                this.vY = this.vZ;
            } else {
                this.vY = j;
            }
            if (avVar.extras == null || avVar.extras.getInt("gw", 2) != 1) {
                this.wb++;
                return;
            }
        }
    }

    public void cO() {
        synchronized (this.mw) {
            this.wa++;
        }
    }

    public void cP() {
        synchronized (this.mw) {
            this.vX++;
        }
    }

    public long dh() {
        return this.vZ;
    }
}
