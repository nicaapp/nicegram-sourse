package com.google.android.gms.internal;

import android.os.Parcel;
import com.google.android.gms.common.internal.safeparcel.SafeParcelable;

@ez
public final class gt implements SafeParcelable {
    public static final gu CREATOR;
    public final int versionCode;
    public String wD;
    public int wE;
    public int wF;
    public boolean wG;

    static {
        CREATOR = new gu();
    }

    public gt(int i, int i2, boolean z) {
        this(1, "afma-sdk-a-v" + i + "." + i2 + "." + (z ? "0" : "1"), i, i2, z);
    }

    gt(int i, String str, int i2, int i3, boolean z) {
        this.versionCode = i;
        this.wD = str;
        this.wE = i2;
        this.wF = i3;
        this.wG = z;
    }

    public int describeContents() {
        return 0;
    }

    public void writeToParcel(Parcel out, int flags) {
        gu.m1418a(this, out, flags);
    }
}
