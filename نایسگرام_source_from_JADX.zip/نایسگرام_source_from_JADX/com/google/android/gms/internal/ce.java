package com.google.android.gms.internal;

import android.os.SystemClock;
import android.util.DisplayMetrics;
import android.view.MotionEvent;
import com.google.android.gms.analytics.ecommerce.Promotion;
import com.googlecode.mp4parser.boxes.apple.TrackLoadSettingsAtom;
import java.util.Map;

@ez
public final class ce implements by {
    private static int m3075a(DisplayMetrics displayMetrics, Map<String, String> map, String str, int i) {
        String str2 = (String) map.get(str);
        if (str2 != null) {
            try {
                i = gr.m1403a(displayMetrics, Integer.parseInt(str2));
            } catch (NumberFormatException e) {
                gs.m1412W("Could not parse " + str + " in a video GMSG: " + str2);
            }
        }
        return i;
    }

    public void m3076a(gv gvVar, Map<String, String> map) {
        String str = (String) map.get("action");
        if (str == null) {
            gs.m1412W("Action missing from video GMSG.");
            return;
        }
        dk dt = gvVar.dt();
        if (dt == null) {
            gs.m1412W("Could not get ad overlay for a video GMSG.");
            return;
        }
        boolean equalsIgnoreCase = "new".equalsIgnoreCase(str);
        boolean equalsIgnoreCase2 = "position".equalsIgnoreCase(str);
        int a;
        if (equalsIgnoreCase || equalsIgnoreCase2) {
            DisplayMetrics displayMetrics = gvVar.getContext().getResources().getDisplayMetrics();
            a = m3075a(displayMetrics, map, "x", 0);
            int a2 = m3075a(displayMetrics, map, "y", 0);
            int a3 = m3075a(displayMetrics, map, "w", -1);
            int a4 = m3075a(displayMetrics, map, "h", -1);
            if (equalsIgnoreCase && dt.bV() == null) {
                dt.m4226c(a, a2, a3, a4);
                return;
            } else {
                dt.m4225b(a, a2, a3, a4);
                return;
            }
        }
        C0466do bV = dt.bV();
        if (bV == null) {
            C0466do.m1211a(gvVar, "no_video_view", null);
        } else if (Promotion.ACTION_CLICK.equalsIgnoreCase(str)) {
            displayMetrics = gvVar.getContext().getResources().getDisplayMetrics();
            int a5 = m3075a(displayMetrics, map, "x", 0);
            a = m3075a(displayMetrics, map, "y", 0);
            long uptimeMillis = SystemClock.uptimeMillis();
            MotionEvent obtain = MotionEvent.obtain(uptimeMillis, uptimeMillis, 0, (float) a5, (float) a, 0);
            bV.m1215b(obtain);
            obtain.recycle();
        } else if ("controls".equalsIgnoreCase(str)) {
            str = (String) map.get("enabled");
            if (str == null) {
                gs.m1412W("Enabled parameter missing from controls video GMSG.");
            } else {
                bV.m1216q(Boolean.parseBoolean(str));
            }
        } else if ("currentTime".equalsIgnoreCase(str)) {
            str = (String) map.get("time");
            if (str == null) {
                gs.m1412W("Time parameter missing from currentTime video GMSG.");
                return;
            }
            try {
                bV.seekTo((int) (Float.parseFloat(str) * 1000.0f));
            } catch (NumberFormatException e) {
                gs.m1412W("Could not parse time parameter from currentTime video GMSG: " + str);
            }
        } else if ("hide".equalsIgnoreCase(str)) {
            bV.setVisibility(4);
        } else if (TrackLoadSettingsAtom.TYPE.equalsIgnoreCase(str)) {
            bV.ch();
        } else if ("pause".equalsIgnoreCase(str)) {
            bV.pause();
        } else if ("play".equalsIgnoreCase(str)) {
            bV.play();
        } else if ("show".equalsIgnoreCase(str)) {
            bV.setVisibility(0);
        } else if ("src".equalsIgnoreCase(str)) {
            bV.m1214C((String) map.get("src"));
        } else {
            gs.m1412W("Unknown video action: " + str);
        }
    }
}
