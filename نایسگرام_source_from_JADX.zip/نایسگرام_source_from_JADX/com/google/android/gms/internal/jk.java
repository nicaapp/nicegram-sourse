package com.google.android.gms.internal;

import android.os.Parcel;
import android.os.Parcelable.Creator;
import com.google.android.gms.common.internal.safeparcel.C0242a;
import com.google.android.gms.common.internal.safeparcel.C0242a.C0241a;
import com.google.android.gms.common.internal.safeparcel.C0243b;
import com.google.android.gms.drive.events.CompletionEvent;
import com.google.android.gms.games.quest.Quest;
import com.google.android.gms.internal.ji.C1889a;
import com.google.android.gms.location.DetectedActivity;
import com.googlecode.mp4parser.boxes.microsoft.XtraBox;
import org.telegram.C0811R;
import org.telegram.android.support.widget.helper.ItemTouchHelper;
import org.telegram.android.time.FastDatePrinter;

public class jk implements Creator<C1889a> {
    static void m1572a(C1889a c1889a, Parcel parcel, int i) {
        int D = C0243b.m329D(parcel);
        C0243b.m356c(parcel, 1, c1889a.getVersionCode());
        C0243b.m356c(parcel, 2, c1889a.hd());
        C0243b.m347a(parcel, 3, c1889a.hj());
        C0243b.m356c(parcel, 4, c1889a.he());
        C0243b.m347a(parcel, 5, c1889a.hk());
        C0243b.m344a(parcel, 6, c1889a.hl(), false);
        C0243b.m356c(parcel, 7, c1889a.hm());
        C0243b.m344a(parcel, 8, c1889a.ho(), false);
        C0243b.m340a(parcel, 9, c1889a.hq(), i, false);
        C0243b.m332H(parcel, D);
    }

    public C1889a m1573I(Parcel parcel) {
        jd jdVar = null;
        int i = 0;
        int C = C0242a.m293C(parcel);
        String str = null;
        String str2 = null;
        boolean z = false;
        int i2 = 0;
        boolean z2 = false;
        int i3 = 0;
        int i4 = 0;
        while (parcel.dataPosition() < C) {
            int B = C0242a.m291B(parcel);
            switch (C0242a.aD(B)) {
                case CompletionEvent.STATUS_FAILURE /*1*/:
                    i4 = C0242a.m309g(parcel, B);
                    break;
                case CompletionEvent.STATUS_CONFLICT /*2*/:
                    i3 = C0242a.m309g(parcel, B);
                    break;
                case FastDatePrinter.SHORT /*3*/:
                    z2 = C0242a.m305c(parcel, B);
                    break;
                case ItemTouchHelper.LEFT /*4*/:
                    i2 = C0242a.m309g(parcel, B);
                    break;
                case DetectedActivity.TILTING /*5*/:
                    z = C0242a.m305c(parcel, B);
                    break;
                case Quest.STATE_FAILED /*6*/:
                    str2 = C0242a.m317o(parcel, B);
                    break;
                case DetectedActivity.WALKING /*7*/:
                    i = C0242a.m309g(parcel, B);
                    break;
                case XtraBox.MP4_XTRA_BT_UNICODE /*8*/:
                    str = C0242a.m317o(parcel, B);
                    break;
                case C0811R.styleable.WalletFragmentStyle_maskedWalletDetailsLogoTextColor /*9*/:
                    jdVar = (jd) C0242a.m298a(parcel, B, jd.CREATOR);
                    break;
                default:
                    C0242a.m302b(parcel, B);
                    break;
            }
        }
        if (parcel.dataPosition() == C) {
            return new C1889a(i4, i3, z2, i2, z, str2, i, str, jdVar);
        }
        throw new C0241a("Overread allowed size end=" + C, parcel);
    }

    public C1889a[] aI(int i) {
        return new C1889a[i];
    }

    public /* synthetic */ Object createFromParcel(Parcel x0) {
        return m1573I(x0);
    }

    public /* synthetic */ Object[] newArray(int x0) {
        return aI(x0);
    }
}
