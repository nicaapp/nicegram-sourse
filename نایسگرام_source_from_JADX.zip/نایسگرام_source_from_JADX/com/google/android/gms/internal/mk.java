package com.google.android.gms.internal;

import android.os.Parcel;
import android.os.Parcelable.Creator;
import com.google.android.gms.common.internal.safeparcel.C0242a;
import com.google.android.gms.common.internal.safeparcel.C0242a.C0241a;
import com.google.android.gms.common.internal.safeparcel.C0243b;
import com.google.android.gms.drive.events.CompletionEvent;
import com.google.android.gms.games.quest.Quest;
import com.google.android.gms.location.GeofenceStatusCodes;
import java.util.List;
import org.telegram.android.support.widget.helper.ItemTouchHelper;
import org.telegram.android.time.FastDatePrinter;

public class mk implements Creator<mj> {
    static void m1695a(mj mjVar, Parcel parcel, int i) {
        int D = C0243b.m329D(parcel);
        C0243b.m357c(parcel, 1, mjVar.afr, false);
        C0243b.m356c(parcel, GeofenceStatusCodes.GEOFENCE_NOT_AVAILABLE, mjVar.BR);
        C0243b.m344a(parcel, 2, mjVar.mi(), false);
        C0243b.m347a(parcel, 3, mjVar.mj());
        C0243b.m357c(parcel, 4, mjVar.afu, false);
        C0243b.m355b(parcel, 6, mjVar.afv, false);
        C0243b.m332H(parcel, D);
    }

    public /* synthetic */ Object createFromParcel(Parcel x0) {
        return cz(x0);
    }

    public mj cz(Parcel parcel) {
        boolean z = false;
        List list = null;
        int C = C0242a.m293C(parcel);
        List list2 = null;
        String str = null;
        List list3 = null;
        int i = 0;
        while (parcel.dataPosition() < C) {
            int B = C0242a.m291B(parcel);
            switch (C0242a.aD(B)) {
                case CompletionEvent.STATUS_FAILURE /*1*/:
                    list3 = C0242a.m304c(parcel, B, mp.CREATOR);
                    break;
                case CompletionEvent.STATUS_CONFLICT /*2*/:
                    str = C0242a.m317o(parcel, B);
                    break;
                case FastDatePrinter.SHORT /*3*/:
                    z = C0242a.m305c(parcel, B);
                    break;
                case ItemTouchHelper.LEFT /*4*/:
                    list2 = C0242a.m304c(parcel, B, mt.CREATOR);
                    break;
                case Quest.STATE_FAILED /*6*/:
                    list = C0242a.m294C(parcel, B);
                    break;
                case GeofenceStatusCodes.GEOFENCE_NOT_AVAILABLE /*1000*/:
                    i = C0242a.m309g(parcel, B);
                    break;
                default:
                    C0242a.m302b(parcel, B);
                    break;
            }
        }
        if (parcel.dataPosition() == C) {
            return new mj(i, list3, str, z, list2, list);
        }
        throw new C0241a("Overread allowed size end=" + C, parcel);
    }

    public mj[] ep(int i) {
        return new mj[i];
    }

    public /* synthetic */ Object[] newArray(int x0) {
        return ep(x0);
    }
}
