package com.google.android.gms.internal;

import android.app.Activity;
import android.app.Application;
import android.app.Application.ActivityLifecycleCallbacks;
import android.content.Context;
import android.os.Bundle;

@ez
public class am implements ActivityLifecycleCallbacks {
    private Context mContext;
    private final Object mw;
    private Activity nr;

    public am(Application application, Activity activity) {
        this.mw = new Object();
        application.registerActivityLifecycleCallbacks(this);
        setActivity(activity);
        this.mContext = application.getApplicationContext();
    }

    private void setActivity(Activity activity) {
        synchronized (this.mw) {
            if (!activity.getClass().getName().startsWith("com.google.android.gms.ads")) {
                this.nr = activity;
            }
        }
    }

    public Activity getActivity() {
        return this.nr;
    }

    public Context getContext() {
        return this.mContext;
    }

    public void onActivityCreated(Activity activity, Bundle savedInstanceState) {
    }

    public void onActivityDestroyed(Activity activity) {
        synchronized (this.mw) {
            if (this.nr == null) {
                return;
            }
            if (this.nr.equals(activity)) {
                this.nr = null;
            }
        }
    }

    public void onActivityPaused(Activity activity) {
        setActivity(activity);
    }

    public void onActivityResumed(Activity activity) {
        setActivity(activity);
    }

    public void onActivitySaveInstanceState(Activity activity, Bundle savedInstanceState) {
    }

    public void onActivityStarted(Activity activity) {
        setActivity(activity);
    }

    public void onActivityStopped(Activity activity) {
    }
}
