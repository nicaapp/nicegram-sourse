package com.google.android.gms.internal;

import android.content.ComponentName;
import android.content.Context;
import android.content.Intent;
import android.content.ServiceConnection;
import android.os.IBinder;
import android.os.RemoteException;
import android.os.SystemClock;
import java.util.List;

@ez
public class dx extends gg implements ServiceConnection {
    private Context mContext;
    private final Object mw;
    private boolean sl;
    private el sm;
    private dw sn;
    private ec so;
    private List<ea> sp;
    private ee sq;

    /* renamed from: com.google.android.gms.internal.dx.1 */
    class C04681 implements Runnable {
        final /* synthetic */ ea sr;
        final /* synthetic */ Intent ss;
        final /* synthetic */ dx st;

        C04681(dx dxVar, ea eaVar, Intent intent) {
            this.st = dxVar;
            this.sr = eaVar;
            this.ss = intent;
        }

        public void run() {
            try {
                if (this.st.sq.m1238a(this.sr.sB, -1, this.ss)) {
                    this.st.sm.m1244a(new eb(this.st.mContext, this.sr.sC, true, -1, this.ss, this.sr));
                } else {
                    this.st.sm.m1244a(new eb(this.st.mContext, this.sr.sC, false, -1, this.ss, this.sr));
                }
            } catch (RemoteException e) {
                gs.m1412W("Fail to verify and dispatch pending transaction");
            }
        }
    }

    public dx(Context context, el elVar, ee eeVar) {
        this.mw = new Object();
        this.sl = false;
        this.sp = null;
        this.mContext = context;
        this.sm = elVar;
        this.sq = eeVar;
        this.sn = new dw(context);
        this.so = ec.m1227j(this.mContext);
        this.sp = this.so.m1231d(10);
    }

    private void m3115a(ea eaVar, String str, String str2) {
        Intent intent = new Intent();
        intent.putExtra("RESPONSE_CODE", 0);
        intent.putExtra("INAPP_PURCHASE_DATA", str);
        intent.putExtra("INAPP_DATA_SIGNATURE", str2);
        gr.wC.post(new C04681(this, eaVar, intent));
    }

    private void m3117b(long j) {
        do {
            if (!m3119c(j)) {
                gs.m1412W("Timeout waiting for pending transaction to be processed.");
            }
        } while (!this.sl);
    }

    private boolean m3119c(long j) {
        long elapsedRealtime = 60000 - (SystemClock.elapsedRealtime() - j);
        if (elapsedRealtime <= 0) {
            return false;
        }
        try {
            this.mw.wait(elapsedRealtime);
        } catch (InterruptedException e) {
            gs.m1412W("waitWithTimeout_lock interrupted");
        }
        return true;
    }

    /* JADX WARNING: inconsistent code. */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    private void cp() {
        /*
        r12 = this;
        r0 = r12.sp;
        r0 = r0.isEmpty();
        if (r0 == 0) goto L_0x0009;
    L_0x0008:
        return;
    L_0x0009:
        r6 = new java.util.HashMap;
        r6.<init>();
        r0 = r12.sp;
        r1 = r0.iterator();
    L_0x0014:
        r0 = r1.hasNext();
        if (r0 == 0) goto L_0x0026;
    L_0x001a:
        r0 = r1.next();
        r0 = (com.google.android.gms.internal.ea) r0;
        r2 = r0.sC;
        r6.put(r2, r0);
        goto L_0x0014;
    L_0x0026:
        r0 = 0;
    L_0x0027:
        r1 = r12.sn;
        r2 = r12.mContext;
        r2 = r2.getPackageName();
        r0 = r1.m1225d(r2, r0);
        if (r0 != 0) goto L_0x0055;
    L_0x0035:
        r0 = r6.keySet();
        r1 = r0.iterator();
    L_0x003d:
        r0 = r1.hasNext();
        if (r0 == 0) goto L_0x0008;
    L_0x0043:
        r0 = r1.next();
        r0 = (java.lang.String) r0;
        r2 = r12.so;
        r0 = r6.get(r0);
        r0 = (com.google.android.gms.internal.ea) r0;
        r2.m1229a(r0);
        goto L_0x003d;
    L_0x0055:
        r1 = com.google.android.gms.internal.ed.m1234b(r0);
        if (r1 != 0) goto L_0x0035;
    L_0x005b:
        r1 = "INAPP_PURCHASE_ITEM_LIST";
        r7 = r0.getStringArrayList(r1);
        r1 = "INAPP_PURCHASE_DATA_LIST";
        r8 = r0.getStringArrayList(r1);
        r1 = "INAPP_DATA_SIGNATURE_LIST";
        r9 = r0.getStringArrayList(r1);
        r1 = "INAPP_CONTINUATION_TOKEN";
        r5 = r0.getString(r1);
        r0 = 0;
        r4 = r0;
    L_0x0075:
        r0 = r7.size();
        if (r4 >= r0) goto L_0x00b3;
    L_0x007b:
        r0 = r7.get(r4);
        r0 = r6.containsKey(r0);
        if (r0 == 0) goto L_0x00af;
    L_0x0085:
        r0 = r7.get(r4);
        r0 = (java.lang.String) r0;
        r1 = r8.get(r4);
        r1 = (java.lang.String) r1;
        r2 = r9.get(r4);
        r2 = (java.lang.String) r2;
        r3 = r6.get(r0);
        r3 = (com.google.android.gms.internal.ea) r3;
        r10 = com.google.android.gms.internal.ed.m1232D(r1);
        r11 = r3.sB;
        r10 = r11.equals(r10);
        if (r10 == 0) goto L_0x00af;
    L_0x00a9:
        r12.m3115a(r3, r1, r2);
        r6.remove(r0);
    L_0x00af:
        r0 = r4 + 1;
        r4 = r0;
        goto L_0x0075;
    L_0x00b3:
        if (r5 == 0) goto L_0x0035;
    L_0x00b5:
        r0 = r6.isEmpty();
        if (r0 != 0) goto L_0x0035;
    L_0x00bb:
        r0 = r5;
        goto L_0x0027;
        */
        throw new UnsupportedOperationException("Method not decompiled: com.google.android.gms.internal.dx.cp():void");
    }

    public void co() {
        synchronized (this.mw) {
            Context context = this.mContext;
            Intent intent = new Intent("com.android.vending.billing.InAppBillingService.BIND");
            Context context2 = this.mContext;
            context.bindService(intent, this, 1);
            m3117b(SystemClock.elapsedRealtime());
            this.mContext.unbindService(this);
            this.sn.destroy();
        }
    }

    public void onServiceConnected(ComponentName name, IBinder service) {
        synchronized (this.mw) {
            this.sn.m1226r(service);
            cp();
            this.sl = true;
            this.mw.notify();
        }
    }

    public void onServiceDisconnected(ComponentName name) {
        gs.m1410U("In-app billing service disconnected.");
        this.sn.destroy();
    }

    public void onStop() {
        synchronized (this.mw) {
            this.mContext.unbindService(this);
            this.sn.destroy();
        }
    }
}
