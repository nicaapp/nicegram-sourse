package com.google.android.gms.internal;

import android.content.Context;
import android.view.MotionEvent;
import com.google.android.gms.internal.C2516u.C0558b;
import java.util.List;
import java.util.Vector;
import java.util.concurrent.CountDownLatch;
import java.util.concurrent.atomic.AtomicReference;
import org.telegram.messenger.BuildConfig;

@ez
/* renamed from: com.google.android.gms.internal.w */
class C1952w implements C0491g, Runnable {
    private C0558b lr;
    private final List<Object[]> me;
    private final AtomicReference<C0491g> mf;
    CountDownLatch mg;

    public C1952w(C0558b c0558b) {
        this.me = new Vector();
        this.mf = new AtomicReference();
        this.mg = new CountDownLatch(1);
        this.lr = c0558b;
        if (gr.ds()) {
            gi.m1353a(this);
        } else {
            run();
        }
    }

    private void ax() {
        if (!this.me.isEmpty()) {
            for (Object[] objArr : this.me) {
                if (objArr.length == 1) {
                    ((C0491g) this.mf.get()).m1336a((MotionEvent) objArr[0]);
                } else if (objArr.length == 3) {
                    ((C0491g) this.mf.get()).m1335a(((Integer) objArr[0]).intValue(), ((Integer) objArr[1]).intValue(), ((Integer) objArr[2]).intValue());
                }
            }
        }
    }

    public String m3448a(Context context) {
        aw();
        C0491g c0491g = (C0491g) this.mf.get();
        if (c0491g == null) {
            return BuildConfig.FLAVOR;
        }
        ax();
        return c0491g.m1333a(context);
    }

    public String m3449a(Context context, String str) {
        aw();
        C0491g c0491g = (C0491g) this.mf.get();
        if (c0491g == null) {
            return BuildConfig.FLAVOR;
        }
        ax();
        return c0491g.m1334a(context, str);
    }

    public void m3450a(int i, int i2, int i3) {
        C0491g c0491g = (C0491g) this.mf.get();
        if (c0491g != null) {
            ax();
            c0491g.m1335a(i, i2, i3);
            return;
        }
        this.me.add(new Object[]{Integer.valueOf(i), Integer.valueOf(i2), Integer.valueOf(i3)});
    }

    public void m3451a(MotionEvent motionEvent) {
        C0491g c0491g = (C0491g) this.mf.get();
        if (c0491g != null) {
            ax();
            c0491g.m1336a(motionEvent);
            return;
        }
        this.me.add(new Object[]{motionEvent});
    }

    protected void m3452a(C0491g c0491g) {
        this.mf.set(c0491g);
    }

    protected void aw() {
        try {
            this.mg.await();
        } catch (Throwable e) {
            gs.m1416d("Interrupted during GADSignals creation.", e);
        }
    }

    public void run() {
        try {
            m3452a(C2618j.m4784a(this.lr.lD.wD, this.lr.lB));
        } finally {
            this.mg.countDown();
            this.lr = null;
        }
    }
}
