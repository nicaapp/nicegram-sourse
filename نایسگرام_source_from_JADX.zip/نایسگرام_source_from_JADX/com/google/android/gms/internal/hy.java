package com.google.android.gms.internal;

import android.content.Context;
import android.os.IBinder;
import android.os.IInterface;
import android.os.Looper;
import android.os.RemoteException;
import com.google.android.gms.common.GooglePlayServicesUtil;
import com.google.android.gms.common.api.GoogleApiClient.ConnectionCallbacks;
import com.google.android.gms.common.api.GoogleApiClient.OnConnectionFailedListener;
import com.google.android.gms.common.internal.C0233l;
import com.google.android.gms.common.internal.C1702e;
import com.google.android.gms.common.internal.C1702e.C2386e;
import com.google.android.gms.internal.hv.C1873a;

public class hy extends C1702e<hv> {
    public hy(Context context, Looper looper, ConnectionCallbacks connectionCallbacks, OnConnectionFailedListener onConnectionFailedListener) {
        super(context, looper, connectionCallbacks, onConnectionFailedListener, new String[0]);
    }

    protected hv m4254H(IBinder iBinder) {
        return C1873a.m3239F(iBinder);
    }

    protected void m4255a(C0233l c0233l, C2386e c2386e) throws RemoteException {
        c0233l.m242b(c2386e, GooglePlayServicesUtil.GOOGLE_PLAY_SERVICES_VERSION_CODE, getContext().getPackageName());
    }

    public hv fn() {
        return (hv) gS();
    }

    protected String getServiceDescriptor() {
        return "com.google.android.gms.appdatasearch.internal.ILightweightAppDataSearch";
    }

    protected String getStartServiceAction() {
        return "com.google.android.gms.icing.LIGHTWEIGHT_INDEX_SERVICE";
    }

    protected /* synthetic */ IInterface m4256j(IBinder iBinder) {
        return m4254H(iBinder);
    }
}
