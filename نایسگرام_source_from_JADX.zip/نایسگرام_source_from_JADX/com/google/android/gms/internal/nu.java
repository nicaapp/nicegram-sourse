package com.google.android.gms.internal;

import android.os.Parcel;
import android.support.v4.view.MotionEventCompat;
import com.google.android.gms.drive.events.CompletionEvent;
import com.google.android.gms.games.quest.Quest;
import com.google.android.gms.internal.ji.C1889a;
import com.google.android.gms.location.DetectedActivity;
import com.google.android.gms.plus.PlusShare;
import com.google.android.gms.plus.model.moments.ItemScope;
import com.googlecode.mp4parser.authoring.tracks.h265.NalUnitTypes;
import com.googlecode.mp4parser.boxes.apple.QuicktimeTextSampleEntry;
import com.googlecode.mp4parser.boxes.microsoft.XtraBox;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Set;
import org.telegram.C0811R;
import org.telegram.android.SecretChatHelper;
import org.telegram.android.support.widget.helper.ItemTouchHelper;
import org.telegram.android.time.FastDatePrinter;
import org.telegram.messenger.TLRPC;

public final class nu extends jj implements ItemScope {
    public static final nv CREATOR;
    private static final HashMap<String, C1889a<?, ?>> amb;
    String BL;
    final int BR;
    String Tr;
    double aek;
    double ael;
    String amA;
    String amB;
    nu amC;
    String amD;
    String amE;
    String amF;
    nu amG;
    nu amH;
    nu amI;
    List<nu> amJ;
    String amK;
    String amL;
    String amM;
    String amN;
    nu amO;
    String amP;
    String amQ;
    String amR;
    nu amS;
    String amT;
    String amU;
    String amV;
    String amW;
    final Set<Integer> amc;
    nu amd;
    List<String> ame;
    nu amf;
    String amg;
    String amh;
    String ami;
    List<nu> amj;
    int amk;
    List<nu> aml;
    nu amm;
    List<nu> amn;
    String amo;
    String amp;
    nu amq;
    String amr;
    String ams;
    List<nu> amt;
    String amu;
    String amv;
    String amw;
    String amx;
    String amy;
    String amz;
    String mName;
    String ol;
    String uO;
    String uR;

    static {
        CREATOR = new nv();
        amb = new HashMap();
        amb.put("about", C1889a.m3289a("about", 2, nu.class));
        amb.put("additionalName", C1889a.m3296m("additionalName", 3));
        amb.put("address", C1889a.m3289a("address", 4, nu.class));
        amb.put("addressCountry", C1889a.m3295l("addressCountry", 5));
        amb.put("addressLocality", C1889a.m3295l("addressLocality", 6));
        amb.put("addressRegion", C1889a.m3295l("addressRegion", 7));
        amb.put("associated_media", C1889a.m3290b("associated_media", 8, nu.class));
        amb.put("attendeeCount", C1889a.m3292i("attendeeCount", 9));
        amb.put("attendees", C1889a.m3290b("attendees", 10, nu.class));
        amb.put("audio", C1889a.m3289a("audio", 11, nu.class));
        amb.put("author", C1889a.m3290b("author", 12, nu.class));
        amb.put("bestRating", C1889a.m3295l("bestRating", 13));
        amb.put("birthDate", C1889a.m3295l("birthDate", 14));
        amb.put("byArtist", C1889a.m3289a("byArtist", 15, nu.class));
        amb.put("caption", C1889a.m3295l("caption", 16));
        amb.put("contentSize", C1889a.m3295l("contentSize", 17));
        amb.put("contentUrl", C1889a.m3295l("contentUrl", 18));
        amb.put("contributor", C1889a.m3290b("contributor", 19, nu.class));
        amb.put("dateCreated", C1889a.m3295l("dateCreated", 20));
        amb.put("dateModified", C1889a.m3295l("dateModified", 21));
        amb.put("datePublished", C1889a.m3295l("datePublished", 22));
        amb.put(PlusShare.KEY_CONTENT_DEEP_LINK_METADATA_DESCRIPTION, C1889a.m3295l(PlusShare.KEY_CONTENT_DEEP_LINK_METADATA_DESCRIPTION, 23));
        amb.put("duration", C1889a.m3295l("duration", 24));
        amb.put("embedUrl", C1889a.m3295l("embedUrl", 25));
        amb.put("endDate", C1889a.m3295l("endDate", 26));
        amb.put("familyName", C1889a.m3295l("familyName", 27));
        amb.put("gender", C1889a.m3295l("gender", 28));
        amb.put("geo", C1889a.m3289a("geo", 29, nu.class));
        amb.put("givenName", C1889a.m3295l("givenName", 30));
        amb.put("height", C1889a.m3295l("height", 31));
        amb.put("id", C1889a.m3295l("id", 32));
        amb.put("image", C1889a.m3295l("image", 33));
        amb.put("inAlbum", C1889a.m3289a("inAlbum", 34, nu.class));
        amb.put("latitude", C1889a.m3293j("latitude", 36));
        amb.put("location", C1889a.m3289a("location", 37, nu.class));
        amb.put("longitude", C1889a.m3293j("longitude", 38));
        amb.put("name", C1889a.m3295l("name", 39));
        amb.put("partOfTVSeries", C1889a.m3289a("partOfTVSeries", 40, nu.class));
        amb.put("performers", C1889a.m3290b("performers", 41, nu.class));
        amb.put("playerType", C1889a.m3295l("playerType", 42));
        amb.put("postOfficeBoxNumber", C1889a.m3295l("postOfficeBoxNumber", 43));
        amb.put("postalCode", C1889a.m3295l("postalCode", 44));
        amb.put("ratingValue", C1889a.m3295l("ratingValue", 45));
        amb.put("reviewRating", C1889a.m3289a("reviewRating", 46, nu.class));
        amb.put("startDate", C1889a.m3295l("startDate", 47));
        amb.put("streetAddress", C1889a.m3295l("streetAddress", 48));
        amb.put(QuicktimeTextSampleEntry.TYPE, C1889a.m3295l(QuicktimeTextSampleEntry.TYPE, 49));
        amb.put("thumbnail", C1889a.m3289a("thumbnail", 50, nu.class));
        amb.put(PlusShare.KEY_CONTENT_DEEP_LINK_METADATA_THUMBNAIL_URL, C1889a.m3295l(PlusShare.KEY_CONTENT_DEEP_LINK_METADATA_THUMBNAIL_URL, 51));
        amb.put("tickerSymbol", C1889a.m3295l("tickerSymbol", 52));
        amb.put("type", C1889a.m3295l("type", 53));
        amb.put(PlusShare.KEY_CALL_TO_ACTION_URL, C1889a.m3295l(PlusShare.KEY_CALL_TO_ACTION_URL, 54));
        amb.put("width", C1889a.m3295l("width", 55));
        amb.put("worstRating", C1889a.m3295l("worstRating", 56));
    }

    public nu() {
        this.BR = 1;
        this.amc = new HashSet();
    }

    nu(Set<Integer> set, int i, nu nuVar, List<String> list, nu nuVar2, String str, String str2, String str3, List<nu> list2, int i2, List<nu> list3, nu nuVar3, List<nu> list4, String str4, String str5, nu nuVar4, String str6, String str7, String str8, List<nu> list5, String str9, String str10, String str11, String str12, String str13, String str14, String str15, String str16, String str17, nu nuVar5, String str18, String str19, String str20, String str21, nu nuVar6, double d, nu nuVar7, double d2, String str22, nu nuVar8, List<nu> list6, String str23, String str24, String str25, String str26, nu nuVar9, String str27, String str28, String str29, nu nuVar10, String str30, String str31, String str32, String str33, String str34, String str35) {
        this.amc = set;
        this.BR = i;
        this.amd = nuVar;
        this.ame = list;
        this.amf = nuVar2;
        this.amg = str;
        this.amh = str2;
        this.ami = str3;
        this.amj = list2;
        this.amk = i2;
        this.aml = list3;
        this.amm = nuVar3;
        this.amn = list4;
        this.amo = str4;
        this.amp = str5;
        this.amq = nuVar4;
        this.amr = str6;
        this.ams = str7;
        this.ol = str8;
        this.amt = list5;
        this.amu = str9;
        this.amv = str10;
        this.amw = str11;
        this.Tr = str12;
        this.amx = str13;
        this.amy = str14;
        this.amz = str15;
        this.amA = str16;
        this.amB = str17;
        this.amC = nuVar5;
        this.amD = str18;
        this.amE = str19;
        this.BL = str20;
        this.amF = str21;
        this.amG = nuVar6;
        this.aek = d;
        this.amH = nuVar7;
        this.ael = d2;
        this.mName = str22;
        this.amI = nuVar8;
        this.amJ = list6;
        this.amK = str23;
        this.amL = str24;
        this.amM = str25;
        this.amN = str26;
        this.amO = nuVar9;
        this.amP = str27;
        this.amQ = str28;
        this.amR = str29;
        this.amS = nuVar10;
        this.amT = str30;
        this.amU = str31;
        this.uO = str32;
        this.uR = str33;
        this.amV = str34;
        this.amW = str35;
    }

    public nu(Set<Integer> set, nu nuVar, List<String> list, nu nuVar2, String str, String str2, String str3, List<nu> list2, int i, List<nu> list3, nu nuVar3, List<nu> list4, String str4, String str5, nu nuVar4, String str6, String str7, String str8, List<nu> list5, String str9, String str10, String str11, String str12, String str13, String str14, String str15, String str16, String str17, nu nuVar5, String str18, String str19, String str20, String str21, nu nuVar6, double d, nu nuVar7, double d2, String str22, nu nuVar8, List<nu> list6, String str23, String str24, String str25, String str26, nu nuVar9, String str27, String str28, String str29, nu nuVar10, String str30, String str31, String str32, String str33, String str34, String str35) {
        this.amc = set;
        this.BR = 1;
        this.amd = nuVar;
        this.ame = list;
        this.amf = nuVar2;
        this.amg = str;
        this.amh = str2;
        this.ami = str3;
        this.amj = list2;
        this.amk = i;
        this.aml = list3;
        this.amm = nuVar3;
        this.amn = list4;
        this.amo = str4;
        this.amp = str5;
        this.amq = nuVar4;
        this.amr = str6;
        this.ams = str7;
        this.ol = str8;
        this.amt = list5;
        this.amu = str9;
        this.amv = str10;
        this.amw = str11;
        this.Tr = str12;
        this.amx = str13;
        this.amy = str14;
        this.amz = str15;
        this.amA = str16;
        this.amB = str17;
        this.amC = nuVar5;
        this.amD = str18;
        this.amE = str19;
        this.BL = str20;
        this.amF = str21;
        this.amG = nuVar6;
        this.aek = d;
        this.amH = nuVar7;
        this.ael = d2;
        this.mName = str22;
        this.amI = nuVar8;
        this.amJ = list6;
        this.amK = str23;
        this.amL = str24;
        this.amM = str25;
        this.amN = str26;
        this.amO = nuVar9;
        this.amP = str27;
        this.amQ = str28;
        this.amR = str29;
        this.amS = nuVar10;
        this.amT = str30;
        this.amU = str31;
        this.uO = str32;
        this.uR = str33;
        this.amV = str34;
        this.amW = str35;
    }

    protected boolean m4369a(C1889a c1889a) {
        return this.amc.contains(Integer.valueOf(c1889a.hm()));
    }

    protected Object m4370b(C1889a c1889a) {
        switch (c1889a.hm()) {
            case CompletionEvent.STATUS_CONFLICT /*2*/:
                return this.amd;
            case FastDatePrinter.SHORT /*3*/:
                return this.ame;
            case ItemTouchHelper.LEFT /*4*/:
                return this.amf;
            case DetectedActivity.TILTING /*5*/:
                return this.amg;
            case Quest.STATE_FAILED /*6*/:
                return this.amh;
            case DetectedActivity.WALKING /*7*/:
                return this.ami;
            case XtraBox.MP4_XTRA_BT_UNICODE /*8*/:
                return this.amj;
            case C0811R.styleable.WalletFragmentStyle_maskedWalletDetailsLogoTextColor /*9*/:
                return Integer.valueOf(this.amk);
            case C0811R.styleable.WalletFragmentStyle_maskedWalletDetailsLogoImageType /*10*/:
                return this.aml;
            case C0811R.styleable.MapAttrs_uiZoomGestures /*11*/:
                return this.amm;
            case C0811R.styleable.MapAttrs_useViewLifecycle /*12*/:
                return this.amn;
            case C0811R.styleable.MapAttrs_zOrderOnTop /*13*/:
                return this.amo;
            case NalUnitTypes.NAL_TYPE_RSV_VCL_N14 /*14*/:
                return this.amp;
            case NalUnitTypes.NAL_TYPE_RSV_VCL_R15 /*15*/:
                return this.amq;
            case ItemTouchHelper.START /*16*/:
                return this.amr;
            case NalUnitTypes.NAL_TYPE_BLA_W_RADL /*17*/:
                return this.ams;
            case NalUnitTypes.NAL_TYPE_BLA_N_LP /*18*/:
                return this.ol;
            case XtraBox.MP4_XTRA_BT_INT64 /*19*/:
                return this.amt;
            case NalUnitTypes.NAL_TYPE_IDR_N_LP /*20*/:
                return this.amu;
            case XtraBox.MP4_XTRA_BT_FILETIME /*21*/:
                return this.amv;
            case NalUnitTypes.NAL_TYPE_RSV_IRAP_VCL22 /*22*/:
                return this.amw;
            case SecretChatHelper.CURRENT_SECRET_CHAT_LAYER /*23*/:
                return this.Tr;
            case NalUnitTypes.NAL_TYPE_RSV_VCL24 /*24*/:
                return this.amx;
            case NalUnitTypes.NAL_TYPE_RSV_VCL25 /*25*/:
                return this.amy;
            case NalUnitTypes.NAL_TYPE_RSV_VCL26 /*26*/:
                return this.amz;
            case NalUnitTypes.NAL_TYPE_RSV_VCL27 /*27*/:
                return this.amA;
            case NalUnitTypes.NAL_TYPE_RSV_VCL28 /*28*/:
                return this.amB;
            case NalUnitTypes.NAL_TYPE_RSV_VCL29 /*29*/:
                return this.amC;
            case NalUnitTypes.NAL_TYPE_RSV_VCL30 /*30*/:
                return this.amD;
            case NalUnitTypes.NAL_TYPE_RSV_VCL31 /*31*/:
                return this.amE;
            case ItemTouchHelper.END /*32*/:
                return this.BL;
            case NalUnitTypes.NAL_TYPE_SPS_NUT /*33*/:
                return this.amF;
            case TLRPC.LAYER /*34*/:
                return this.amG;
            case NalUnitTypes.NAL_TYPE_EOS_NUT /*36*/:
                return Double.valueOf(this.aek);
            case NalUnitTypes.NAL_TYPE_EOB_NUT /*37*/:
                return this.amH;
            case NalUnitTypes.NAL_TYPE_FD_NUT /*38*/:
                return Double.valueOf(this.ael);
            case NalUnitTypes.NAL_TYPE_PREFIX_SEI_NUT /*39*/:
                return this.mName;
            case MotionEventCompat.AXIS_GENERIC_9 /*40*/:
                return this.amI;
            case NalUnitTypes.NAL_TYPE_RSV_NVCL41 /*41*/:
                return this.amJ;
            case NalUnitTypes.NAL_TYPE_RSV_NVCL42 /*42*/:
                return this.amK;
            case NalUnitTypes.NAL_TYPE_RSV_NVCL43 /*43*/:
                return this.amL;
            case NalUnitTypes.NAL_TYPE_RSV_NVCL44 /*44*/:
                return this.amM;
            case MotionEventCompat.AXIS_GENERIC_14 /*45*/:
                return this.amN;
            case MotionEventCompat.AXIS_GENERIC_15 /*46*/:
                return this.amO;
            case MotionEventCompat.AXIS_GENERIC_16 /*47*/:
                return this.amP;
            case NalUnitTypes.NAL_TYPE_UNSPEC48 /*48*/:
                return this.amQ;
            case NalUnitTypes.NAL_TYPE_UNSPEC49 /*49*/:
                return this.amR;
            case NalUnitTypes.NAL_TYPE_UNSPEC50 /*50*/:
                return this.amS;
            case NalUnitTypes.NAL_TYPE_UNSPEC51 /*51*/:
                return this.amT;
            case NalUnitTypes.NAL_TYPE_UNSPEC52 /*52*/:
                return this.amU;
            case NalUnitTypes.NAL_TYPE_UNSPEC53 /*53*/:
                return this.uO;
            case NalUnitTypes.NAL_TYPE_UNSPEC54 /*54*/:
                return this.uR;
            case NalUnitTypes.NAL_TYPE_UNSPEC55 /*55*/:
                return this.amV;
            case 56:
                return this.amW;
            default:
                throw new IllegalStateException("Unknown safe parcelable id=" + c1889a.hm());
        }
    }

    public int describeContents() {
        nv nvVar = CREATOR;
        return 0;
    }

    public boolean equals(Object obj) {
        if (!(obj instanceof nu)) {
            return false;
        }
        if (this == obj) {
            return true;
        }
        nu nuVar = (nu) obj;
        for (C1889a c1889a : amb.values()) {
            if (m4369a(c1889a)) {
                if (!nuVar.m4369a(c1889a)) {
                    return false;
                }
                if (!m4370b(c1889a).equals(nuVar.m4370b(c1889a))) {
                    return false;
                }
            } else if (nuVar.m4369a(c1889a)) {
                return false;
            }
        }
        return true;
    }

    public /* synthetic */ Object freeze() {
        return nr();
    }

    public ItemScope getAbout() {
        return this.amd;
    }

    public List<String> getAdditionalName() {
        return this.ame;
    }

    public ItemScope getAddress() {
        return this.amf;
    }

    public String getAddressCountry() {
        return this.amg;
    }

    public String getAddressLocality() {
        return this.amh;
    }

    public String getAddressRegion() {
        return this.ami;
    }

    public List<ItemScope> getAssociated_media() {
        return (ArrayList) this.amj;
    }

    public int getAttendeeCount() {
        return this.amk;
    }

    public List<ItemScope> getAttendees() {
        return (ArrayList) this.aml;
    }

    public ItemScope getAudio() {
        return this.amm;
    }

    public List<ItemScope> getAuthor() {
        return (ArrayList) this.amn;
    }

    public String getBestRating() {
        return this.amo;
    }

    public String getBirthDate() {
        return this.amp;
    }

    public ItemScope getByArtist() {
        return this.amq;
    }

    public String getCaption() {
        return this.amr;
    }

    public String getContentSize() {
        return this.ams;
    }

    public String getContentUrl() {
        return this.ol;
    }

    public List<ItemScope> getContributor() {
        return (ArrayList) this.amt;
    }

    public String getDateCreated() {
        return this.amu;
    }

    public String getDateModified() {
        return this.amv;
    }

    public String getDatePublished() {
        return this.amw;
    }

    public String getDescription() {
        return this.Tr;
    }

    public String getDuration() {
        return this.amx;
    }

    public String getEmbedUrl() {
        return this.amy;
    }

    public String getEndDate() {
        return this.amz;
    }

    public String getFamilyName() {
        return this.amA;
    }

    public String getGender() {
        return this.amB;
    }

    public ItemScope getGeo() {
        return this.amC;
    }

    public String getGivenName() {
        return this.amD;
    }

    public String getHeight() {
        return this.amE;
    }

    public String getId() {
        return this.BL;
    }

    public String getImage() {
        return this.amF;
    }

    public ItemScope getInAlbum() {
        return this.amG;
    }

    public double getLatitude() {
        return this.aek;
    }

    public ItemScope getLocation() {
        return this.amH;
    }

    public double getLongitude() {
        return this.ael;
    }

    public String getName() {
        return this.mName;
    }

    public ItemScope getPartOfTVSeries() {
        return this.amI;
    }

    public List<ItemScope> getPerformers() {
        return (ArrayList) this.amJ;
    }

    public String getPlayerType() {
        return this.amK;
    }

    public String getPostOfficeBoxNumber() {
        return this.amL;
    }

    public String getPostalCode() {
        return this.amM;
    }

    public String getRatingValue() {
        return this.amN;
    }

    public ItemScope getReviewRating() {
        return this.amO;
    }

    public String getStartDate() {
        return this.amP;
    }

    public String getStreetAddress() {
        return this.amQ;
    }

    public String getText() {
        return this.amR;
    }

    public ItemScope getThumbnail() {
        return this.amS;
    }

    public String getThumbnailUrl() {
        return this.amT;
    }

    public String getTickerSymbol() {
        return this.amU;
    }

    public String getType() {
        return this.uO;
    }

    public String getUrl() {
        return this.uR;
    }

    public String getWidth() {
        return this.amV;
    }

    public String getWorstRating() {
        return this.amW;
    }

    public boolean hasAbout() {
        return this.amc.contains(Integer.valueOf(2));
    }

    public boolean hasAdditionalName() {
        return this.amc.contains(Integer.valueOf(3));
    }

    public boolean hasAddress() {
        return this.amc.contains(Integer.valueOf(4));
    }

    public boolean hasAddressCountry() {
        return this.amc.contains(Integer.valueOf(5));
    }

    public boolean hasAddressLocality() {
        return this.amc.contains(Integer.valueOf(6));
    }

    public boolean hasAddressRegion() {
        return this.amc.contains(Integer.valueOf(7));
    }

    public boolean hasAssociated_media() {
        return this.amc.contains(Integer.valueOf(8));
    }

    public boolean hasAttendeeCount() {
        return this.amc.contains(Integer.valueOf(9));
    }

    public boolean hasAttendees() {
        return this.amc.contains(Integer.valueOf(10));
    }

    public boolean hasAudio() {
        return this.amc.contains(Integer.valueOf(11));
    }

    public boolean hasAuthor() {
        return this.amc.contains(Integer.valueOf(12));
    }

    public boolean hasBestRating() {
        return this.amc.contains(Integer.valueOf(13));
    }

    public boolean hasBirthDate() {
        return this.amc.contains(Integer.valueOf(14));
    }

    public boolean hasByArtist() {
        return this.amc.contains(Integer.valueOf(15));
    }

    public boolean hasCaption() {
        return this.amc.contains(Integer.valueOf(16));
    }

    public boolean hasContentSize() {
        return this.amc.contains(Integer.valueOf(17));
    }

    public boolean hasContentUrl() {
        return this.amc.contains(Integer.valueOf(18));
    }

    public boolean hasContributor() {
        return this.amc.contains(Integer.valueOf(19));
    }

    public boolean hasDateCreated() {
        return this.amc.contains(Integer.valueOf(20));
    }

    public boolean hasDateModified() {
        return this.amc.contains(Integer.valueOf(21));
    }

    public boolean hasDatePublished() {
        return this.amc.contains(Integer.valueOf(22));
    }

    public boolean hasDescription() {
        return this.amc.contains(Integer.valueOf(23));
    }

    public boolean hasDuration() {
        return this.amc.contains(Integer.valueOf(24));
    }

    public boolean hasEmbedUrl() {
        return this.amc.contains(Integer.valueOf(25));
    }

    public boolean hasEndDate() {
        return this.amc.contains(Integer.valueOf(26));
    }

    public boolean hasFamilyName() {
        return this.amc.contains(Integer.valueOf(27));
    }

    public boolean hasGender() {
        return this.amc.contains(Integer.valueOf(28));
    }

    public boolean hasGeo() {
        return this.amc.contains(Integer.valueOf(29));
    }

    public boolean hasGivenName() {
        return this.amc.contains(Integer.valueOf(30));
    }

    public boolean hasHeight() {
        return this.amc.contains(Integer.valueOf(31));
    }

    public boolean hasId() {
        return this.amc.contains(Integer.valueOf(32));
    }

    public boolean hasImage() {
        return this.amc.contains(Integer.valueOf(33));
    }

    public boolean hasInAlbum() {
        return this.amc.contains(Integer.valueOf(34));
    }

    public boolean hasLatitude() {
        return this.amc.contains(Integer.valueOf(36));
    }

    public boolean hasLocation() {
        return this.amc.contains(Integer.valueOf(37));
    }

    public boolean hasLongitude() {
        return this.amc.contains(Integer.valueOf(38));
    }

    public boolean hasName() {
        return this.amc.contains(Integer.valueOf(39));
    }

    public boolean hasPartOfTVSeries() {
        return this.amc.contains(Integer.valueOf(40));
    }

    public boolean hasPerformers() {
        return this.amc.contains(Integer.valueOf(41));
    }

    public boolean hasPlayerType() {
        return this.amc.contains(Integer.valueOf(42));
    }

    public boolean hasPostOfficeBoxNumber() {
        return this.amc.contains(Integer.valueOf(43));
    }

    public boolean hasPostalCode() {
        return this.amc.contains(Integer.valueOf(44));
    }

    public boolean hasRatingValue() {
        return this.amc.contains(Integer.valueOf(45));
    }

    public boolean hasReviewRating() {
        return this.amc.contains(Integer.valueOf(46));
    }

    public boolean hasStartDate() {
        return this.amc.contains(Integer.valueOf(47));
    }

    public boolean hasStreetAddress() {
        return this.amc.contains(Integer.valueOf(48));
    }

    public boolean hasText() {
        return this.amc.contains(Integer.valueOf(49));
    }

    public boolean hasThumbnail() {
        return this.amc.contains(Integer.valueOf(50));
    }

    public boolean hasThumbnailUrl() {
        return this.amc.contains(Integer.valueOf(51));
    }

    public boolean hasTickerSymbol() {
        return this.amc.contains(Integer.valueOf(52));
    }

    public boolean hasType() {
        return this.amc.contains(Integer.valueOf(53));
    }

    public boolean hasUrl() {
        return this.amc.contains(Integer.valueOf(54));
    }

    public boolean hasWidth() {
        return this.amc.contains(Integer.valueOf(55));
    }

    public boolean hasWorstRating() {
        return this.amc.contains(Integer.valueOf(56));
    }

    public int hashCode() {
        int i = 0;
        for (C1889a c1889a : amb.values()) {
            int hashCode;
            if (m4369a(c1889a)) {
                hashCode = m4370b(c1889a).hashCode() + (i + c1889a.hm());
            } else {
                hashCode = i;
            }
            i = hashCode;
        }
        return i;
    }

    public HashMap<String, C1889a<?, ?>> hf() {
        return amb;
    }

    public boolean isDataValid() {
        return true;
    }

    public nu nr() {
        return this;
    }

    public void writeToParcel(Parcel out, int flags) {
        nv nvVar = CREATOR;
        nv.m1719a(this, out, flags);
    }
}
