package com.google.android.gms.internal;

import android.os.Parcel;
import android.os.Parcelable.Creator;
import com.google.android.gms.common.internal.safeparcel.C0242a;
import com.google.android.gms.common.internal.safeparcel.C0242a.C0241a;
import com.google.android.gms.common.internal.safeparcel.C0243b;
import com.google.android.gms.drive.events.CompletionEvent;
import com.google.android.gms.games.quest.Quest;
import com.google.android.gms.location.DetectedActivity;
import com.googlecode.mp4parser.boxes.microsoft.XtraBox;
import org.telegram.android.support.widget.helper.ItemTouchHelper;
import org.telegram.android.time.FastDatePrinter;

public class di implements Creator<dj> {
    static void m1203a(dj djVar, Parcel parcel, int i) {
        int D = C0243b.m329D(parcel);
        C0243b.m356c(parcel, 1, djVar.versionCode);
        C0243b.m344a(parcel, 2, djVar.rp, false);
        C0243b.m344a(parcel, 3, djVar.rq, false);
        C0243b.m344a(parcel, 4, djVar.mimeType, false);
        C0243b.m344a(parcel, 5, djVar.packageName, false);
        C0243b.m344a(parcel, 6, djVar.rr, false);
        C0243b.m344a(parcel, 7, djVar.rs, false);
        C0243b.m344a(parcel, 8, djVar.rt, false);
        C0243b.m332H(parcel, D);
    }

    public /* synthetic */ Object createFromParcel(Parcel x0) {
        return m1204e(x0);
    }

    public dj m1204e(Parcel parcel) {
        String str = null;
        int C = C0242a.m293C(parcel);
        int i = 0;
        String str2 = null;
        String str3 = null;
        String str4 = null;
        String str5 = null;
        String str6 = null;
        String str7 = null;
        while (parcel.dataPosition() < C) {
            int B = C0242a.m291B(parcel);
            switch (C0242a.aD(B)) {
                case CompletionEvent.STATUS_FAILURE /*1*/:
                    i = C0242a.m309g(parcel, B);
                    break;
                case CompletionEvent.STATUS_CONFLICT /*2*/:
                    str7 = C0242a.m317o(parcel, B);
                    break;
                case FastDatePrinter.SHORT /*3*/:
                    str6 = C0242a.m317o(parcel, B);
                    break;
                case ItemTouchHelper.LEFT /*4*/:
                    str5 = C0242a.m317o(parcel, B);
                    break;
                case DetectedActivity.TILTING /*5*/:
                    str4 = C0242a.m317o(parcel, B);
                    break;
                case Quest.STATE_FAILED /*6*/:
                    str3 = C0242a.m317o(parcel, B);
                    break;
                case DetectedActivity.WALKING /*7*/:
                    str2 = C0242a.m317o(parcel, B);
                    break;
                case XtraBox.MP4_XTRA_BT_UNICODE /*8*/:
                    str = C0242a.m317o(parcel, B);
                    break;
                default:
                    C0242a.m302b(parcel, B);
                    break;
            }
        }
        if (parcel.dataPosition() == C) {
            return new dj(i, str7, str6, str5, str4, str3, str2, str);
        }
        throw new C0241a("Overread allowed size end=" + C, parcel);
    }

    public dj[] m1205l(int i) {
        return new dj[i];
    }

    public /* synthetic */ Object[] newArray(int x0) {
        return m1205l(x0);
    }
}
