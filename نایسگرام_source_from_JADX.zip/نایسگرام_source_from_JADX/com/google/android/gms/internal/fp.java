package com.google.android.gms.internal;

import android.graphics.drawable.Drawable;
import com.google.android.gms.internal.bq.C0438a;
import com.google.android.gms.internal.fo.C0488a;
import java.util.concurrent.ExecutionException;
import org.json.JSONException;
import org.json.JSONObject;

@ez
public class fp implements C0488a<bo> {
    public /* synthetic */ C0438a m3181a(fo foVar, JSONObject jSONObject) throws JSONException, InterruptedException, ExecutionException {
        return m3182b(foVar, jSONObject);
    }

    public bo m3182b(fo foVar, JSONObject jSONObject) throws JSONException, InterruptedException, ExecutionException {
        return new bo(jSONObject.getString("headline"), (Drawable) foVar.m1291a(jSONObject, "image", true).get(), jSONObject.getString("body"), (Drawable) foVar.m1291a(jSONObject, "app_icon", true).get(), jSONObject.getString("call_to_action"), jSONObject.optDouble("rating", -1.0d), jSONObject.optString("store"), jSONObject.optString("price"));
    }
}
