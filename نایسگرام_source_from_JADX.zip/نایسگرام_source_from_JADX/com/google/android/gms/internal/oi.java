package com.google.android.gms.internal;

import android.os.Parcel;
import android.os.Parcelable.Creator;
import com.google.android.gms.common.internal.safeparcel.C0242a;
import com.google.android.gms.common.internal.safeparcel.C0242a.C0241a;
import com.google.android.gms.common.internal.safeparcel.C0243b;
import com.google.android.gms.drive.events.CompletionEvent;
import com.google.android.gms.internal.nz.C2505g;
import java.util.HashSet;
import java.util.Set;
import org.telegram.android.time.FastDatePrinter;

public class oi implements Creator<C2505g> {
    static void m1732a(C2505g c2505g, Parcel parcel, int i) {
        int D = C0243b.m329D(parcel);
        Set set = c2505g.amc;
        if (set.contains(Integer.valueOf(1))) {
            C0243b.m356c(parcel, 1, c2505g.BR);
        }
        if (set.contains(Integer.valueOf(2))) {
            C0243b.m347a(parcel, 2, c2505g.anG);
        }
        if (set.contains(Integer.valueOf(3))) {
            C0243b.m344a(parcel, 3, c2505g.mValue, true);
        }
        C0243b.m332H(parcel, D);
    }

    public /* synthetic */ Object createFromParcel(Parcel x0) {
        return dl(x0);
    }

    public C2505g dl(Parcel parcel) {
        boolean z = false;
        int C = C0242a.m293C(parcel);
        Set hashSet = new HashSet();
        String str = null;
        int i = 0;
        while (parcel.dataPosition() < C) {
            int B = C0242a.m291B(parcel);
            switch (C0242a.aD(B)) {
                case CompletionEvent.STATUS_FAILURE /*1*/:
                    i = C0242a.m309g(parcel, B);
                    hashSet.add(Integer.valueOf(1));
                    break;
                case CompletionEvent.STATUS_CONFLICT /*2*/:
                    z = C0242a.m305c(parcel, B);
                    hashSet.add(Integer.valueOf(2));
                    break;
                case FastDatePrinter.SHORT /*3*/:
                    str = C0242a.m317o(parcel, B);
                    hashSet.add(Integer.valueOf(3));
                    break;
                default:
                    C0242a.m302b(parcel, B);
                    break;
            }
        }
        if (parcel.dataPosition() == C) {
            return new C2505g(hashSet, i, z, str);
        }
        throw new C0241a("Overread allowed size end=" + C, parcel);
    }

    public C2505g[] fd(int i) {
        return new C2505g[i];
    }

    public /* synthetic */ Object[] newArray(int x0) {
        return fd(x0);
    }
}
