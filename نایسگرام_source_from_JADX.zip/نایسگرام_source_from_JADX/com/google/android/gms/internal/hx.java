package com.google.android.gms.internal;

import android.os.ParcelFileDescriptor;
import com.google.android.gms.common.api.BaseImplementation.C0191b;
import com.google.android.gms.common.api.Status;
import com.google.android.gms.internal.hm.C1870b;
import com.google.android.gms.internal.hw.C1875a;

public abstract class hx<T> extends C1875a {
    protected C0191b<T> CH;

    public hx(C0191b<T> c0191b) {
        this.CH = c0191b;
    }

    public void m4250a(Status status) {
    }

    public void m4251a(Status status, ParcelFileDescriptor parcelFileDescriptor) {
    }

    public void m4252a(Status status, boolean z) {
    }

    public void m4253a(C1870b c1870b) {
    }
}
