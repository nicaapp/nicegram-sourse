package com.google.android.gms.internal;

import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.graphics.Color;
import android.os.Build.VERSION;
import android.os.Bundle;
import android.support.v4.view.ViewCompat;
import android.support.v4.view.accessibility.AccessibilityNodeInfoCompat;
import android.view.MotionEvent;
import android.view.View;
import android.view.ViewGroup;
import android.view.ViewGroup.LayoutParams;
import android.view.ViewParent;
import android.view.Window;
import android.webkit.WebChromeClient.CustomViewCallback;
import android.widget.FrameLayout;
import android.widget.RelativeLayout;
import com.google.android.gms.ads.AdActivity;
import com.google.android.gms.drive.DriveFile;
import com.google.android.gms.drive.events.CompletionEvent;
import com.google.android.gms.internal.ds.C1823a;
import com.google.android.gms.internal.gw.C0505a;
import org.telegram.android.MessagesController;
import org.telegram.android.support.widget.helper.ItemTouchHelper;
import org.telegram.android.time.FastDatePrinter;

@ez
public class dk extends C1823a {
    private static final int ru;
    private gv md;
    private final Activity nr;
    private boolean rA;
    private FrameLayout rB;
    private CustomViewCallback rC;
    private boolean rD;
    private boolean rE;
    private boolean rF;
    private RelativeLayout rG;
    private dm rv;
    private C0466do rw;
    private C0463c rx;
    private dp ry;
    private boolean rz;

    @ez
    /* renamed from: com.google.android.gms.internal.dk.a */
    private static final class C0461a extends Exception {
        public C0461a(String str) {
            super(str);
        }
    }

    @ez
    /* renamed from: com.google.android.gms.internal.dk.b */
    private static final class C0462b extends RelativeLayout {
        private final gm ly;

        public C0462b(Context context, String str) {
            super(context);
            this.ly = new gm(context, str);
        }

        public boolean onInterceptTouchEvent(MotionEvent event) {
            this.ly.m1391c(event);
            return false;
        }
    }

    @ez
    /* renamed from: com.google.android.gms.internal.dk.c */
    private static final class C0463c {
        public final int index;
        public final LayoutParams rI;
        public final ViewGroup rJ;

        public C0463c(gv gvVar) throws C0461a {
            this.rI = gvVar.getLayoutParams();
            ViewParent parent = gvVar.getParent();
            if (parent instanceof ViewGroup) {
                this.rJ = (ViewGroup) parent;
                this.index = this.rJ.indexOfChild(gvVar);
                this.rJ.removeView(gvVar);
                gvVar.m1431x(true);
                return;
            }
            throw new C0461a("Could not get the parent of the WebView for an overlay.");
        }
    }

    /* renamed from: com.google.android.gms.internal.dk.1 */
    class C18211 implements C0505a {
        final /* synthetic */ dk rH;

        C18211(dk dkVar) {
            this.rH = dkVar;
        }

        public void m3100a(gv gvVar) {
            gvVar.bZ();
        }
    }

    static {
        ru = Color.argb(0, 0, 0, 0);
    }

    public dk(Activity activity) {
        this.rA = false;
        this.rD = false;
        this.rE = false;
        this.rF = false;
        this.nr = activity;
    }

    private static RelativeLayout.LayoutParams m4221a(int i, int i2, int i3, int i4) {
        RelativeLayout.LayoutParams layoutParams = new RelativeLayout.LayoutParams(i3, i4);
        layoutParams.setMargins(i, i2, 0, 0);
        layoutParams.addRule(10);
        layoutParams.addRule(9);
        return layoutParams;
    }

    public static void m4222a(Context context, dm dmVar) {
        Intent intent = new Intent();
        intent.setClassName(context, AdActivity.CLASS_NAME);
        intent.putExtra("com.google.android.gms.ads.internal.overlay.useClientJar", dmVar.lD.wG);
        dm.m3101a(intent, dmVar);
        intent.addFlags(AccessibilityNodeInfoCompat.ACTION_COLLAPSE);
        if (!(context instanceof Activity)) {
            intent.addFlags(DriveFile.MODE_READ_ONLY);
        }
        context.startActivity(intent);
    }

    public void m4223U() {
        this.rz = true;
    }

    public void m4224a(View view, CustomViewCallback customViewCallback) {
        this.rB = new FrameLayout(this.nr);
        this.rB.setBackgroundColor(ViewCompat.MEASURED_STATE_MASK);
        this.rB.addView(view, -1, -1);
        this.nr.setContentView(this.rB);
        m4223U();
        this.rC = customViewCallback;
        this.rA = true;
    }

    public void m4225b(int i, int i2, int i3, int i4) {
        if (this.rw != null) {
            this.rw.setLayoutParams(m4221a(i, i2, i3, i4));
        }
    }

    public C0466do bV() {
        return this.rw;
    }

    public void bW() {
        if (this.rv != null && this.rA) {
            setRequestedOrientation(this.rv.orientation);
        }
        if (this.rB != null) {
            this.nr.setContentView(this.rG);
            m4223U();
            this.rB.removeAllViews();
            this.rB = null;
        }
        if (this.rC != null) {
            this.rC.onCustomViewHidden();
            this.rC = null;
        }
        this.rA = false;
    }

    public void bX() {
        this.rG.removeView(this.ry);
        m4227n(true);
    }

    void bY() {
        if (this.nr.isFinishing() && !this.rE) {
            this.rE = true;
            if (this.nr.isFinishing()) {
                if (this.md != null) {
                    ca();
                    this.rG.removeView(this.md);
                    if (this.rx != null) {
                        this.md.m1431x(false);
                        this.rx.rJ.addView(this.md, this.rx.index, this.rx.rI);
                    }
                }
                if (this.rv != null && this.rv.rM != null) {
                    this.rv.rM.ac();
                }
            }
        }
    }

    void bZ() {
        this.md.bZ();
    }

    public void m4226c(int i, int i2, int i3, int i4) {
        if (this.rw == null) {
            this.rw = new C0466do(this.nr, this.md);
            this.rG.addView(this.rw, 0, m4221a(i, i2, i3, i4));
            this.md.du().m1444y(false);
        }
    }

    void ca() {
        this.md.ca();
    }

    public void close() {
        this.nr.finish();
    }

    public void m4227n(boolean z) {
        this.ry = new dp(this.nr, z ? 50 : 32);
        LayoutParams layoutParams = new RelativeLayout.LayoutParams(-2, -2);
        layoutParams.addRule(10);
        layoutParams.addRule(z ? 11 : 9);
        this.ry.m1217o(this.rv.rQ);
        this.rG.addView(this.ry, layoutParams);
    }

    public void m4228o(boolean z) {
        if (this.ry != null) {
            this.ry.m1217o(z);
        }
    }

    public void onCreate(Bundle savedInstanceState) {
        boolean z = false;
        if (savedInstanceState != null) {
            z = savedInstanceState.getBoolean("com.google.android.gms.ads.internal.overlay.hasResumed", false);
        }
        this.rD = z;
        try {
            this.rv = dm.m3102b(this.nr.getIntent());
            if (this.rv == null) {
                throw new C0461a("Could not get info for ad overlay.");
            }
            if (this.rv.rW != null) {
                this.rF = this.rv.rW.lX;
            } else {
                this.rF = false;
            }
            if (savedInstanceState == null) {
                if (this.rv.rM != null) {
                    this.rv.rM.ad();
                }
                if (!(this.rv.rT == 1 || this.rv.rL == null)) {
                    this.rv.rL.onAdClicked();
                }
            }
            switch (this.rv.rT) {
                case CompletionEvent.STATUS_FAILURE /*1*/:
                    m4229p(false);
                case CompletionEvent.STATUS_CONFLICT /*2*/:
                    this.rx = new C0463c(this.rv.rN);
                    m4229p(false);
                case FastDatePrinter.SHORT /*3*/:
                    m4229p(true);
                case ItemTouchHelper.LEFT /*4*/:
                    if (this.rD) {
                        this.nr.finish();
                    } else if (!dh.m1202a(this.nr, this.rv.rK, this.rv.rS)) {
                        this.nr.finish();
                    }
                default:
                    throw new C0461a("Could not determine ad overlay type.");
            }
        } catch (C0461a e) {
            gs.m1412W(e.getMessage());
            this.nr.finish();
        }
    }

    public void onDestroy() {
        if (this.rw != null) {
            this.rw.destroy();
        }
        if (this.md != null) {
            this.rG.removeView(this.md);
        }
        bY();
    }

    public void onPause() {
        if (this.rw != null) {
            this.rw.pause();
        }
        bW();
        if (this.md != null && (!this.nr.isFinishing() || this.rx == null)) {
            gj.m1368a(this.md);
        }
        bY();
    }

    public void onRestart() {
    }

    public void onResume() {
        if (this.rv != null && this.rv.rT == 4) {
            if (this.rD) {
                this.nr.finish();
            } else {
                this.rD = true;
            }
        }
        if (this.md != null) {
            gj.m1373b(this.md);
        }
    }

    public void onSaveInstanceState(Bundle outBundle) {
        outBundle.putBoolean("com.google.android.gms.ads.internal.overlay.hasResumed", this.rD);
    }

    public void onStart() {
    }

    public void onStop() {
        bY();
    }

    void m4229p(boolean z) throws C0461a {
        if (!this.rz) {
            this.nr.requestWindowFeature(1);
        }
        Window window = this.nr.getWindow();
        if (!this.rF || this.rv.rW.mh) {
            window.setFlags(MessagesController.UPDATE_MASK_PHONE, MessagesController.UPDATE_MASK_PHONE);
        }
        setRequestedOrientation(this.rv.orientation);
        if (VERSION.SDK_INT >= 11) {
            gs.m1408S("Enabling hardware acceleration on the AdActivity window.");
            gn.m1393a(window);
        }
        this.rG = new C0462b(this.nr, this.rv.rV);
        if (this.rF) {
            this.rG.setBackgroundColor(ru);
        } else {
            this.rG.setBackgroundColor(ViewCompat.MEASURED_STATE_MASK);
        }
        this.nr.setContentView(this.rG);
        m4223U();
        boolean dE = this.rv.rN.du().dE();
        if (z) {
            this.md = gv.m1421a(this.nr, this.rv.rN.m1423Y(), true, dE, null, this.rv.lD);
            this.md.du().m1439a(null, null, this.rv.rO, this.rv.rS, true, this.rv.rU, this.rv.rN.du().dD());
            this.md.du().m1437a(new C18211(this));
            if (this.rv.rq != null) {
                this.md.loadUrl(this.rv.rq);
            } else if (this.rv.rR != null) {
                this.md.loadDataWithBaseURL(this.rv.rP, this.rv.rR, "text/html", "UTF-8", null);
            } else {
                throw new C0461a("No URL or HTML to display in ad overlay.");
            }
        }
        this.md = this.rv.rN;
        this.md.setContext(this.nr);
        this.md.m1426a(this);
        ViewParent parent = this.md.getParent();
        if (parent != null && (parent instanceof ViewGroup)) {
            ((ViewGroup) parent).removeView(this.md);
        }
        if (this.rF) {
            this.md.setBackgroundColor(ru);
        }
        this.rG.addView(this.md, -1, -1);
        if (!z) {
            bZ();
        }
        m4227n(dE);
        if (this.md.dv()) {
            m4228o(true);
        }
    }

    public void setRequestedOrientation(int requestedOrientation) {
        this.nr.setRequestedOrientation(requestedOrientation);
    }
}
