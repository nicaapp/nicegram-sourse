package com.google.android.gms.internal;

import com.google.android.gms.ads.mediation.MediationBannerAdapter;
import com.google.android.gms.ads.mediation.MediationBannerListener;
import com.google.android.gms.ads.mediation.MediationInterstitialAdapter;
import com.google.android.gms.ads.mediation.MediationInterstitialListener;
import com.google.android.gms.common.internal.C0238o;

@ez
public final class cy implements MediationBannerListener, MediationInterstitialListener {
    private final cv qF;

    public cy(cv cvVar) {
        this.qF = cvVar;
    }

    public void onAdClicked(MediationBannerAdapter adapter) {
        C0238o.aT("onAdClicked must be called on the main UI thread.");
        gs.m1408S("Adapter called onAdClicked.");
        try {
            this.qF.onAdClicked();
        } catch (Throwable e) {
            gs.m1416d("Could not call onAdClicked.", e);
        }
    }

    public void onAdClicked(MediationInterstitialAdapter adapter) {
        C0238o.aT("onAdClicked must be called on the main UI thread.");
        gs.m1408S("Adapter called onAdClicked.");
        try {
            this.qF.onAdClicked();
        } catch (Throwable e) {
            gs.m1416d("Could not call onAdClicked.", e);
        }
    }

    public void onAdClosed(MediationBannerAdapter adapter) {
        C0238o.aT("onAdClosed must be called on the main UI thread.");
        gs.m1408S("Adapter called onAdClosed.");
        try {
            this.qF.onAdClosed();
        } catch (Throwable e) {
            gs.m1416d("Could not call onAdClosed.", e);
        }
    }

    public void onAdClosed(MediationInterstitialAdapter adapter) {
        C0238o.aT("onAdClosed must be called on the main UI thread.");
        gs.m1408S("Adapter called onAdClosed.");
        try {
            this.qF.onAdClosed();
        } catch (Throwable e) {
            gs.m1416d("Could not call onAdClosed.", e);
        }
    }

    public void onAdFailedToLoad(MediationBannerAdapter adapter, int errorCode) {
        C0238o.aT("onAdFailedToLoad must be called on the main UI thread.");
        gs.m1408S("Adapter called onAdFailedToLoad with error. " + errorCode);
        try {
            this.qF.onAdFailedToLoad(errorCode);
        } catch (Throwable e) {
            gs.m1416d("Could not call onAdFailedToLoad.", e);
        }
    }

    public void onAdFailedToLoad(MediationInterstitialAdapter adapter, int errorCode) {
        C0238o.aT("onAdFailedToLoad must be called on the main UI thread.");
        gs.m1408S("Adapter called onAdFailedToLoad with error " + errorCode + ".");
        try {
            this.qF.onAdFailedToLoad(errorCode);
        } catch (Throwable e) {
            gs.m1416d("Could not call onAdFailedToLoad.", e);
        }
    }

    public void onAdLeftApplication(MediationBannerAdapter adapter) {
        C0238o.aT("onAdLeftApplication must be called on the main UI thread.");
        gs.m1408S("Adapter called onAdLeftApplication.");
        try {
            this.qF.onAdLeftApplication();
        } catch (Throwable e) {
            gs.m1416d("Could not call onAdLeftApplication.", e);
        }
    }

    public void onAdLeftApplication(MediationInterstitialAdapter adapter) {
        C0238o.aT("onAdLeftApplication must be called on the main UI thread.");
        gs.m1408S("Adapter called onAdLeftApplication.");
        try {
            this.qF.onAdLeftApplication();
        } catch (Throwable e) {
            gs.m1416d("Could not call onAdLeftApplication.", e);
        }
    }

    public void onAdLoaded(MediationBannerAdapter adapter) {
        C0238o.aT("onAdLoaded must be called on the main UI thread.");
        gs.m1408S("Adapter called onAdLoaded.");
        try {
            this.qF.onAdLoaded();
        } catch (Throwable e) {
            gs.m1416d("Could not call onAdLoaded.", e);
        }
    }

    public void onAdLoaded(MediationInterstitialAdapter adapter) {
        C0238o.aT("onAdLoaded must be called on the main UI thread.");
        gs.m1408S("Adapter called onAdLoaded.");
        try {
            this.qF.onAdLoaded();
        } catch (Throwable e) {
            gs.m1416d("Could not call onAdLoaded.", e);
        }
    }

    public void onAdOpened(MediationBannerAdapter adapter) {
        C0238o.aT("onAdOpened must be called on the main UI thread.");
        gs.m1408S("Adapter called onAdOpened.");
        try {
            this.qF.onAdOpened();
        } catch (Throwable e) {
            gs.m1416d("Could not call onAdOpened.", e);
        }
    }

    public void onAdOpened(MediationInterstitialAdapter adapter) {
        C0238o.aT("onAdOpened must be called on the main UI thread.");
        gs.m1408S("Adapter called onAdOpened.");
        try {
            this.qF.onAdOpened();
        } catch (Throwable e) {
            gs.m1416d("Could not call onAdOpened.", e);
        }
    }
}
