package com.google.android.gms.internal;

import android.os.Parcel;
import com.google.android.gms.common.internal.C0237n;
import com.google.android.gms.common.internal.safeparcel.SafeParcelable;

public final class mh implements SafeParcelable {
    public static final mi CREATOR;
    private final int BR;
    private final int aeh;
    private final int afp;
    private final mj afq;

    static {
        CREATOR = new mi();
    }

    mh(int i, int i2, int i3, mj mjVar) {
        this.BR = i;
        this.aeh = i2;
        this.afp = i3;
        this.afq = mjVar;
    }

    public int describeContents() {
        mi miVar = CREATOR;
        return 0;
    }

    public boolean equals(Object object) {
        if (this == object) {
            return true;
        }
        if (!(object instanceof mh)) {
            return false;
        }
        mh mhVar = (mh) object;
        return this.aeh == mhVar.aeh && this.afp == mhVar.afp && this.afq.equals(mhVar.afq);
    }

    public int getVersionCode() {
        return this.BR;
    }

    public int hashCode() {
        return C0237n.hashCode(Integer.valueOf(this.aeh), Integer.valueOf(this.afp));
    }

    public int mc() {
        return this.aeh;
    }

    public int mg() {
        return this.afp;
    }

    public mj mh() {
        return this.afq;
    }

    public String toString() {
        return C0237n.m274h(this).m273a("transitionTypes", Integer.valueOf(this.aeh)).m273a("loiteringTimeMillis", Integer.valueOf(this.afp)).m273a("placeFilter", this.afq).toString();
    }

    public void writeToParcel(Parcel parcel, int flags) {
        mi miVar = CREATOR;
        mi.m1694a(this, parcel, flags);
    }
}
