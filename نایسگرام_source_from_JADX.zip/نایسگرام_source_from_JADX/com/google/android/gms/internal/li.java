package com.google.android.gms.internal;

import android.os.Parcel;
import android.os.Parcelable.Creator;
import com.google.android.gms.common.internal.safeparcel.SafeParcelable;
import com.google.android.gms.fitness.data.DataSource;

public class li implements SafeParcelable {
    public static final Creator<li> CREATOR;
    private final int BR;
    private final DataSource Sq;

    static {
        CREATOR = new lj();
    }

    li(int i, DataSource dataSource) {
        this.BR = i;
        this.Sq = dataSource;
    }

    public int describeContents() {
        return 0;
    }

    public DataSource getDataSource() {
        return this.Sq;
    }

    int getVersionCode() {
        return this.BR;
    }

    public String toString() {
        return String.format("ApplicationUnregistrationRequest{%s}", new Object[]{this.Sq});
    }

    public void writeToParcel(Parcel parcel, int flags) {
        lj.m1651a(this, parcel, flags);
    }
}
