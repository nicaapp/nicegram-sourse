package com.google.android.gms.internal;

import com.google.android.gms.common.data.DataHolder;
import com.google.android.gms.drive.DriveId;
import com.google.android.gms.drive.metadata.internal.C2410j;
import java.util.Arrays;

public class kg extends C2410j<DriveId> {
    public static final kg Qy;

    static {
        Qy = new kg();
    }

    private kg() {
        super("driveId", Arrays.asList(new String[]{"sqlId", "resourceId"}), Arrays.asList(new String[]{"dbInstanceId"}), 4100000);
    }

    protected /* synthetic */ Object m4793c(DataHolder dataHolder, int i, int i2) {
        return m4794m(dataHolder, i, i2);
    }

    protected DriveId m4794m(DataHolder dataHolder, int i, int i2) {
        long j = dataHolder.gy().getLong("dbInstanceId");
        String c = dataHolder.m2428c("resourceId", i, i2);
        if (c != null && c.startsWith("generated-android-")) {
            c = null;
        }
        return new DriveId(c, Long.valueOf(dataHolder.m2425a("sqlId", i, i2)).longValue(), j);
    }
}
