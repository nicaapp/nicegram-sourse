package com.google.android.gms.internal;

public interface fx {
    String m1332K(String str);
}
