package com.google.android.gms.internal;

public interface cb {
    void m1164b(boolean z);
}
