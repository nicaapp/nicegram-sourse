package com.google.android.gms.internal;

import android.content.Intent;
import com.google.android.gms.common.api.Status;
import com.google.android.gms.panorama.PanoramaApi.C2531a;

public class mz extends ne implements C2531a {
    private final int akx;

    public mz(Status status, Intent intent, int i) {
        super(status, intent);
        this.akx = i;
    }

    public /* bridge */ /* synthetic */ Status getStatus() {
        return super.getStatus();
    }

    public /* bridge */ /* synthetic */ Intent getViewerIntent() {
        return super.getViewerIntent();
    }
}
