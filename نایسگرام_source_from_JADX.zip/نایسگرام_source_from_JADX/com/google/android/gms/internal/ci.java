package com.google.android.gms.internal;

import android.location.Location;

public interface ci {
    Location m1167a(long j);

    void init();
}
