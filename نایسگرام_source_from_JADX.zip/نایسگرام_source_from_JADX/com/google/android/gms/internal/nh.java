package com.google.android.gms.internal;

import android.os.Binder;
import android.os.IBinder;
import android.os.IInterface;
import android.os.Parcel;
import android.os.RemoteException;
import com.google.android.gms.drive.events.CompletionEvent;
import java.util.List;
import org.telegram.android.support.widget.helper.ItemTouchHelper;
import org.telegram.android.time.FastDatePrinter;

public interface nh extends IInterface {

    /* renamed from: com.google.android.gms.internal.nh.a */
    public static abstract class C1933a extends Binder implements nh {

        /* renamed from: com.google.android.gms.internal.nh.a.a */
        private static class C1932a implements nh {
            private IBinder lb;

            C1932a(IBinder iBinder) {
                this.lb = iBinder;
            }

            public void m3404a(String str, nm nmVar, ni niVar) throws RemoteException {
                Parcel obtain = Parcel.obtain();
                try {
                    obtain.writeInterfaceToken("com.google.android.gms.playlog.internal.IPlayLogService");
                    obtain.writeString(str);
                    if (nmVar != null) {
                        obtain.writeInt(1);
                        nmVar.writeToParcel(obtain, 0);
                    } else {
                        obtain.writeInt(0);
                    }
                    if (niVar != null) {
                        obtain.writeInt(1);
                        niVar.writeToParcel(obtain, 0);
                    } else {
                        obtain.writeInt(0);
                    }
                    this.lb.transact(2, obtain, null, 1);
                } finally {
                    obtain.recycle();
                }
            }

            public void m3405a(String str, nm nmVar, List<ni> list) throws RemoteException {
                Parcel obtain = Parcel.obtain();
                try {
                    obtain.writeInterfaceToken("com.google.android.gms.playlog.internal.IPlayLogService");
                    obtain.writeString(str);
                    if (nmVar != null) {
                        obtain.writeInt(1);
                        nmVar.writeToParcel(obtain, 0);
                    } else {
                        obtain.writeInt(0);
                    }
                    obtain.writeTypedList(list);
                    this.lb.transact(3, obtain, null, 1);
                } finally {
                    obtain.recycle();
                }
            }

            public void m3406a(String str, nm nmVar, byte[] bArr) throws RemoteException {
                Parcel obtain = Parcel.obtain();
                try {
                    obtain.writeInterfaceToken("com.google.android.gms.playlog.internal.IPlayLogService");
                    obtain.writeString(str);
                    if (nmVar != null) {
                        obtain.writeInt(1);
                        nmVar.writeToParcel(obtain, 0);
                    } else {
                        obtain.writeInt(0);
                    }
                    obtain.writeByteArray(bArr);
                    this.lb.transact(4, obtain, null, 1);
                } finally {
                    obtain.recycle();
                }
            }

            public IBinder asBinder() {
                return this.lb;
            }
        }

        public static nh bC(IBinder iBinder) {
            if (iBinder == null) {
                return null;
            }
            IInterface queryLocalInterface = iBinder.queryLocalInterface("com.google.android.gms.playlog.internal.IPlayLogService");
            return (queryLocalInterface == null || !(queryLocalInterface instanceof nh)) ? new C1932a(iBinder) : (nh) queryLocalInterface;
        }

        public boolean onTransact(int code, Parcel data, Parcel reply, int flags) throws RemoteException {
            nm nmVar = null;
            String readString;
            switch (code) {
                case CompletionEvent.STATUS_CONFLICT /*2*/:
                    ni cX;
                    data.enforceInterface("com.google.android.gms.playlog.internal.IPlayLogService");
                    String readString2 = data.readString();
                    nm cY = data.readInt() != 0 ? nm.CREATOR.cY(data) : null;
                    if (data.readInt() != 0) {
                        cX = ni.CREATOR.cX(data);
                    }
                    m1713a(readString2, cY, cX);
                    return true;
                case FastDatePrinter.SHORT /*3*/:
                    data.enforceInterface("com.google.android.gms.playlog.internal.IPlayLogService");
                    readString = data.readString();
                    if (data.readInt() != 0) {
                        nmVar = nm.CREATOR.cY(data);
                    }
                    m1714a(readString, nmVar, data.createTypedArrayList(ni.CREATOR));
                    return true;
                case ItemTouchHelper.LEFT /*4*/:
                    data.enforceInterface("com.google.android.gms.playlog.internal.IPlayLogService");
                    readString = data.readString();
                    if (data.readInt() != 0) {
                        nmVar = nm.CREATOR.cY(data);
                    }
                    m1715a(readString, nmVar, data.createByteArray());
                    return true;
                case 1598968902:
                    reply.writeString("com.google.android.gms.playlog.internal.IPlayLogService");
                    return true;
                default:
                    return super.onTransact(code, data, reply, flags);
            }
        }
    }

    void m1713a(String str, nm nmVar, ni niVar) throws RemoteException;

    void m1714a(String str, nm nmVar, List<ni> list) throws RemoteException;

    void m1715a(String str, nm nmVar, byte[] bArr) throws RemoteException;
}
