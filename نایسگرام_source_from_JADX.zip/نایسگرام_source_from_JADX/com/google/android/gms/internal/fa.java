package com.google.android.gms.internal;

import android.content.Context;
import com.google.android.gms.internal.fi.C0486a;
import com.google.android.gms.internal.fz.C0490a;

@ez
public final class fa {

    /* renamed from: com.google.android.gms.internal.fa.a */
    public interface C0474a {
        void m1260a(C0490a c0490a);
    }

    public static gg m1261a(Context context, C0486a c0486a, C0534k c0534k, C0474a c0474a) {
        gg fbVar = new fb(context, c0486a, c0534k, c0474a);
        fbVar.start();
        return fbVar;
    }
}
