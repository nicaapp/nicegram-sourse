package com.google.android.gms.internal;

import android.os.Bundle;
import android.os.Parcel;
import com.google.android.gms.common.internal.C0238o;
import com.google.android.gms.common.internal.safeparcel.C0242a;
import com.google.android.gms.common.internal.safeparcel.C0242a.C0241a;
import com.google.android.gms.common.internal.safeparcel.C0243b;
import com.google.android.gms.common.internal.safeparcel.SafeParcelable;
import com.google.android.gms.drive.events.CompletionEvent;
import com.google.android.gms.games.quest.Quest;
import com.google.android.gms.internal.ji.C1889a;
import com.google.android.gms.location.DetectedActivity;
import com.googlecode.mp4parser.boxes.microsoft.XtraBox;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map.Entry;
import java.util.Set;
import org.telegram.C0811R;
import org.telegram.android.support.widget.helper.ItemTouchHelper;
import org.telegram.android.time.FastDatePrinter;

public class jp extends ji implements SafeParcelable {
    public static final jq CREATOR;
    private final int BR;
    private final jm MG;
    private final Parcel MN;
    private final int MO;
    private int MP;
    private int MQ;
    private final String mClassName;

    static {
        CREATOR = new jq();
    }

    jp(int i, Parcel parcel, jm jmVar) {
        this.BR = i;
        this.MN = (Parcel) C0238o.m283i(parcel);
        this.MO = 2;
        this.MG = jmVar;
        if (this.MG == null) {
            this.mClassName = null;
        } else {
            this.mClassName = this.MG.hv();
        }
        this.MP = 2;
    }

    private jp(SafeParcelable safeParcelable, jm jmVar, String str) {
        this.BR = 1;
        this.MN = Parcel.obtain();
        safeParcelable.writeToParcel(this.MN, 0);
        this.MO = 1;
        this.MG = (jm) C0238o.m283i(jmVar);
        this.mClassName = (String) C0238o.m283i(str);
        this.MP = 2;
    }

    public static <T extends ji & SafeParcelable> jp m3302a(T t) {
        String canonicalName = t.getClass().getCanonicalName();
        return new jp((SafeParcelable) t, m3308b((ji) t), canonicalName);
    }

    private static void m3303a(jm jmVar, ji jiVar) {
        Class cls = jiVar.getClass();
        if (!jmVar.m3301b(cls)) {
            HashMap hf = jiVar.hf();
            jmVar.m3300a(cls, jiVar.hf());
            for (String str : hf.keySet()) {
                C1889a c1889a = (C1889a) hf.get(str);
                Class hn = c1889a.hn();
                if (hn != null) {
                    try {
                        m3303a(jmVar, (ji) hn.newInstance());
                    } catch (Throwable e) {
                        throw new IllegalStateException("Could not instantiate an object of type " + c1889a.hn().getCanonicalName(), e);
                    } catch (Throwable e2) {
                        throw new IllegalStateException("Could not access object of type " + c1889a.hn().getCanonicalName(), e2);
                    }
                }
            }
        }
    }

    private void m3304a(StringBuilder stringBuilder, int i, Object obj) {
        switch (i) {
            case FastDatePrinter.FULL /*0*/:
            case CompletionEvent.STATUS_FAILURE /*1*/:
            case CompletionEvent.STATUS_CONFLICT /*2*/:
            case FastDatePrinter.SHORT /*3*/:
            case ItemTouchHelper.LEFT /*4*/:
            case DetectedActivity.TILTING /*5*/:
            case Quest.STATE_FAILED /*6*/:
                stringBuilder.append(obj);
            case DetectedActivity.WALKING /*7*/:
                stringBuilder.append("\"").append(jz.bf(obj.toString())).append("\"");
            case XtraBox.MP4_XTRA_BT_UNICODE /*8*/:
                stringBuilder.append("\"").append(js.m1591d((byte[]) obj)).append("\"");
            case C0811R.styleable.WalletFragmentStyle_maskedWalletDetailsLogoTextColor /*9*/:
                stringBuilder.append("\"").append(js.m1592e((byte[]) obj));
                stringBuilder.append("\"");
            case C0811R.styleable.WalletFragmentStyle_maskedWalletDetailsLogoImageType /*10*/:
                ka.m1610a(stringBuilder, (HashMap) obj);
            case C0811R.styleable.MapAttrs_uiZoomGestures /*11*/:
                throw new IllegalArgumentException("Method does not accept concrete type.");
            default:
                throw new IllegalArgumentException("Unknown type = " + i);
        }
    }

    private void m3305a(StringBuilder stringBuilder, C1889a<?, ?> c1889a, Parcel parcel, int i) {
        switch (c1889a.he()) {
            case FastDatePrinter.FULL /*0*/:
                m3311b(stringBuilder, (C1889a) c1889a, m1569a(c1889a, Integer.valueOf(C0242a.m309g(parcel, i))));
            case CompletionEvent.STATUS_FAILURE /*1*/:
                m3311b(stringBuilder, (C1889a) c1889a, m1569a(c1889a, C0242a.m313k(parcel, i)));
            case CompletionEvent.STATUS_CONFLICT /*2*/:
                m3311b(stringBuilder, (C1889a) c1889a, m1569a(c1889a, Long.valueOf(C0242a.m311i(parcel, i))));
            case FastDatePrinter.SHORT /*3*/:
                m3311b(stringBuilder, (C1889a) c1889a, m1569a(c1889a, Float.valueOf(C0242a.m314l(parcel, i))));
            case ItemTouchHelper.LEFT /*4*/:
                m3311b(stringBuilder, (C1889a) c1889a, m1569a(c1889a, Double.valueOf(C0242a.m315m(parcel, i))));
            case DetectedActivity.TILTING /*5*/:
                m3311b(stringBuilder, (C1889a) c1889a, m1569a(c1889a, C0242a.m316n(parcel, i)));
            case Quest.STATE_FAILED /*6*/:
                m3311b(stringBuilder, (C1889a) c1889a, m1569a(c1889a, Boolean.valueOf(C0242a.m305c(parcel, i))));
            case DetectedActivity.WALKING /*7*/:
                m3311b(stringBuilder, (C1889a) c1889a, m1569a(c1889a, C0242a.m317o(parcel, i)));
            case XtraBox.MP4_XTRA_BT_UNICODE /*8*/:
            case C0811R.styleable.WalletFragmentStyle_maskedWalletDetailsLogoTextColor /*9*/:
                m3311b(stringBuilder, (C1889a) c1889a, m1569a(c1889a, C0242a.m320r(parcel, i)));
            case C0811R.styleable.WalletFragmentStyle_maskedWalletDetailsLogoImageType /*10*/:
                m3311b(stringBuilder, (C1889a) c1889a, m1569a(c1889a, m3313e(C0242a.m319q(parcel, i))));
            case C0811R.styleable.MapAttrs_uiZoomGestures /*11*/:
                throw new IllegalArgumentException("Method does not accept concrete type.");
            default:
                throw new IllegalArgumentException("Unknown field out type = " + c1889a.he());
        }
    }

    private void m3306a(StringBuilder stringBuilder, String str, C1889a<?, ?> c1889a, Parcel parcel, int i) {
        stringBuilder.append("\"").append(str).append("\":");
        if (c1889a.hp()) {
            m3305a(stringBuilder, c1889a, parcel, i);
        } else {
            m3310b(stringBuilder, c1889a, parcel, i);
        }
    }

    private void m3307a(StringBuilder stringBuilder, HashMap<String, C1889a<?, ?>> hashMap, Parcel parcel) {
        HashMap b = m3309b((HashMap) hashMap);
        stringBuilder.append('{');
        int C = C0242a.m293C(parcel);
        Object obj = null;
        while (parcel.dataPosition() < C) {
            int B = C0242a.m291B(parcel);
            Entry entry = (Entry) b.get(Integer.valueOf(C0242a.aD(B)));
            if (entry != null) {
                if (obj != null) {
                    stringBuilder.append(",");
                }
                m3306a(stringBuilder, (String) entry.getKey(), (C1889a) entry.getValue(), parcel, B);
                obj = 1;
            }
        }
        if (parcel.dataPosition() != C) {
            throw new C0241a("Overread allowed size end=" + C, parcel);
        }
        stringBuilder.append('}');
    }

    private static jm m3308b(ji jiVar) {
        jm jmVar = new jm(jiVar.getClass());
        m3303a(jmVar, jiVar);
        jmVar.ht();
        jmVar.hs();
        return jmVar;
    }

    private static HashMap<Integer, Entry<String, C1889a<?, ?>>> m3309b(HashMap<String, C1889a<?, ?>> hashMap) {
        HashMap<Integer, Entry<String, C1889a<?, ?>>> hashMap2 = new HashMap();
        for (Entry entry : hashMap.entrySet()) {
            hashMap2.put(Integer.valueOf(((C1889a) entry.getValue()).hm()), entry);
        }
        return hashMap2;
    }

    private void m3310b(StringBuilder stringBuilder, C1889a<?, ?> c1889a, Parcel parcel, int i) {
        if (c1889a.hk()) {
            stringBuilder.append("[");
            switch (c1889a.he()) {
                case FastDatePrinter.FULL /*0*/:
                    jr.m1584a(stringBuilder, C0242a.m323u(parcel, i));
                    break;
                case CompletionEvent.STATUS_FAILURE /*1*/:
                    jr.m1586a(stringBuilder, C0242a.m325w(parcel, i));
                    break;
                case CompletionEvent.STATUS_CONFLICT /*2*/:
                    jr.m1585a(stringBuilder, C0242a.m324v(parcel, i));
                    break;
                case FastDatePrinter.SHORT /*3*/:
                    jr.m1583a(stringBuilder, C0242a.m326x(parcel, i));
                    break;
                case ItemTouchHelper.LEFT /*4*/:
                    jr.m1582a(stringBuilder, C0242a.m327y(parcel, i));
                    break;
                case DetectedActivity.TILTING /*5*/:
                    jr.m1586a(stringBuilder, C0242a.m328z(parcel, i));
                    break;
                case Quest.STATE_FAILED /*6*/:
                    jr.m1588a(stringBuilder, C0242a.m322t(parcel, i));
                    break;
                case DetectedActivity.WALKING /*7*/:
                    jr.m1587a(stringBuilder, C0242a.m290A(parcel, i));
                    break;
                case XtraBox.MP4_XTRA_BT_UNICODE /*8*/:
                case C0811R.styleable.WalletFragmentStyle_maskedWalletDetailsLogoTextColor /*9*/:
                case C0811R.styleable.WalletFragmentStyle_maskedWalletDetailsLogoImageType /*10*/:
                    throw new UnsupportedOperationException("List of type BASE64, BASE64_URL_SAFE, or STRING_MAP is not supported");
                case C0811R.styleable.MapAttrs_uiZoomGestures /*11*/:
                    Parcel[] E = C0242a.m296E(parcel, i);
                    int length = E.length;
                    for (int i2 = 0; i2 < length; i2++) {
                        if (i2 > 0) {
                            stringBuilder.append(",");
                        }
                        E[i2].setDataPosition(0);
                        m3307a(stringBuilder, c1889a.hr(), E[i2]);
                    }
                    break;
                default:
                    throw new IllegalStateException("Unknown field type out.");
            }
            stringBuilder.append("]");
            return;
        }
        switch (c1889a.he()) {
            case FastDatePrinter.FULL /*0*/:
                stringBuilder.append(C0242a.m309g(parcel, i));
            case CompletionEvent.STATUS_FAILURE /*1*/:
                stringBuilder.append(C0242a.m313k(parcel, i));
            case CompletionEvent.STATUS_CONFLICT /*2*/:
                stringBuilder.append(C0242a.m311i(parcel, i));
            case FastDatePrinter.SHORT /*3*/:
                stringBuilder.append(C0242a.m314l(parcel, i));
            case ItemTouchHelper.LEFT /*4*/:
                stringBuilder.append(C0242a.m315m(parcel, i));
            case DetectedActivity.TILTING /*5*/:
                stringBuilder.append(C0242a.m316n(parcel, i));
            case Quest.STATE_FAILED /*6*/:
                stringBuilder.append(C0242a.m305c(parcel, i));
            case DetectedActivity.WALKING /*7*/:
                stringBuilder.append("\"").append(jz.bf(C0242a.m317o(parcel, i))).append("\"");
            case XtraBox.MP4_XTRA_BT_UNICODE /*8*/:
                stringBuilder.append("\"").append(js.m1591d(C0242a.m320r(parcel, i))).append("\"");
            case C0811R.styleable.WalletFragmentStyle_maskedWalletDetailsLogoTextColor /*9*/:
                stringBuilder.append("\"").append(js.m1592e(C0242a.m320r(parcel, i)));
                stringBuilder.append("\"");
            case C0811R.styleable.WalletFragmentStyle_maskedWalletDetailsLogoImageType /*10*/:
                Bundle q = C0242a.m319q(parcel, i);
                Set<String> keySet = q.keySet();
                keySet.size();
                stringBuilder.append("{");
                int i3 = 1;
                for (String str : keySet) {
                    if (i3 == 0) {
                        stringBuilder.append(",");
                    }
                    stringBuilder.append("\"").append(str).append("\"");
                    stringBuilder.append(":");
                    stringBuilder.append("\"").append(jz.bf(q.getString(str))).append("\"");
                    i3 = 0;
                }
                stringBuilder.append("}");
            case C0811R.styleable.MapAttrs_uiZoomGestures /*11*/:
                Parcel D = C0242a.m295D(parcel, i);
                D.setDataPosition(0);
                m3307a(stringBuilder, c1889a.hr(), D);
            default:
                throw new IllegalStateException("Unknown field type out");
        }
    }

    private void m3311b(StringBuilder stringBuilder, C1889a<?, ?> c1889a, Object obj) {
        if (c1889a.hj()) {
            m3312b(stringBuilder, (C1889a) c1889a, (ArrayList) obj);
        } else {
            m3304a(stringBuilder, c1889a.hd(), obj);
        }
    }

    private void m3312b(StringBuilder stringBuilder, C1889a<?, ?> c1889a, ArrayList<?> arrayList) {
        stringBuilder.append("[");
        int size = arrayList.size();
        for (int i = 0; i < size; i++) {
            if (i != 0) {
                stringBuilder.append(",");
            }
            m3304a(stringBuilder, c1889a.hd(), arrayList.get(i));
        }
        stringBuilder.append("]");
    }

    public static HashMap<String, String> m3313e(Bundle bundle) {
        HashMap<String, String> hashMap = new HashMap();
        for (String str : bundle.keySet()) {
            hashMap.put(str, bundle.getString(str));
        }
        return hashMap;
    }

    protected Object ba(String str) {
        throw new UnsupportedOperationException("Converting to JSON does not require this method.");
    }

    protected boolean bb(String str) {
        throw new UnsupportedOperationException("Converting to JSON does not require this method.");
    }

    public int describeContents() {
        jq jqVar = CREATOR;
        return 0;
    }

    public int getVersionCode() {
        return this.BR;
    }

    public HashMap<String, C1889a<?, ?>> hf() {
        return this.MG == null ? null : this.MG.be(this.mClassName);
    }

    public Parcel hx() {
        switch (this.MP) {
            case FastDatePrinter.FULL /*0*/:
                this.MQ = C0243b.m329D(this.MN);
                C0243b.m332H(this.MN, this.MQ);
                this.MP = 2;
                break;
            case CompletionEvent.STATUS_FAILURE /*1*/:
                C0243b.m332H(this.MN, this.MQ);
                this.MP = 2;
                break;
        }
        return this.MN;
    }

    jm hy() {
        switch (this.MO) {
            case FastDatePrinter.FULL /*0*/:
                return null;
            case CompletionEvent.STATUS_FAILURE /*1*/:
                return this.MG;
            case CompletionEvent.STATUS_CONFLICT /*2*/:
                return this.MG;
            default:
                throw new IllegalStateException("Invalid creation type: " + this.MO);
        }
    }

    public String toString() {
        C0238o.m279b(this.MG, (Object) "Cannot convert to JSON on client side.");
        Parcel hx = hx();
        hx.setDataPosition(0);
        StringBuilder stringBuilder = new StringBuilder(100);
        m3307a(stringBuilder, this.MG.be(this.mClassName), hx);
        return stringBuilder.toString();
    }

    public void writeToParcel(Parcel out, int flags) {
        jq jqVar = CREATOR;
        jq.m1580a(this, out, flags);
    }
}
