package com.google.android.gms.internal;

import java.util.concurrent.Future;
import java.util.concurrent.TimeUnit;

@ez
public class gl<T> implements Future<T> {
    private final T wq;

    public gl(T t) {
        this.wq = t;
    }

    public boolean cancel(boolean mayInterruptIfRunning) {
        return false;
    }

    public T get() {
        return this.wq;
    }

    public T get(long timeout, TimeUnit unit) {
        return this.wq;
    }

    public boolean isCancelled() {
        return false;
    }

    public boolean isDone() {
        return true;
    }
}
