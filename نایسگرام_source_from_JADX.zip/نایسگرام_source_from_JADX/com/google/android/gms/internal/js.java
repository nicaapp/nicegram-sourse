package com.google.android.gms.internal;

import android.util.Base64;

public final class js {
    public static String m1591d(byte[] bArr) {
        return bArr == null ? null : Base64.encodeToString(bArr, 0);
    }

    public static String m1592e(byte[] bArr) {
        return bArr == null ? null : Base64.encodeToString(bArr, 10);
    }
}
