package com.google.android.gms.internal;

import android.location.Location;
import android.os.Bundle;
import android.os.Parcel;
import android.os.Parcelable.Creator;
import com.google.android.gms.common.internal.safeparcel.C0242a;
import com.google.android.gms.common.internal.safeparcel.C0242a.C0241a;
import com.google.android.gms.common.internal.safeparcel.C0243b;
import com.google.android.gms.drive.events.CompletionEvent;
import com.google.android.gms.games.quest.Quest;
import com.google.android.gms.location.DetectedActivity;
import com.googlecode.mp4parser.boxes.microsoft.XtraBox;
import java.util.List;
import org.telegram.C0811R;
import org.telegram.android.support.widget.helper.ItemTouchHelper;
import org.telegram.android.time.FastDatePrinter;

public class aw implements Creator<av> {
    static void m1101a(av avVar, Parcel parcel, int i) {
        int D = C0243b.m329D(parcel);
        C0243b.m356c(parcel, 1, avVar.versionCode);
        C0243b.m336a(parcel, 2, avVar.nT);
        C0243b.m337a(parcel, 3, avVar.extras, false);
        C0243b.m356c(parcel, 4, avVar.nU);
        C0243b.m355b(parcel, 5, avVar.nV, false);
        C0243b.m347a(parcel, 6, avVar.nW);
        C0243b.m356c(parcel, 7, avVar.nX);
        C0243b.m347a(parcel, 8, avVar.nY);
        C0243b.m344a(parcel, 9, avVar.nZ, false);
        C0243b.m340a(parcel, 10, avVar.oa, i, false);
        C0243b.m340a(parcel, 11, avVar.ob, i, false);
        C0243b.m344a(parcel, 12, avVar.oc, false);
        C0243b.m337a(parcel, 13, avVar.od, false);
        C0243b.m332H(parcel, D);
    }

    public av m1102b(Parcel parcel) {
        int C = C0242a.m293C(parcel);
        int i = 0;
        long j = 0;
        Bundle bundle = null;
        int i2 = 0;
        List list = null;
        boolean z = false;
        int i3 = 0;
        boolean z2 = false;
        String str = null;
        bj bjVar = null;
        Location location = null;
        String str2 = null;
        Bundle bundle2 = null;
        while (parcel.dataPosition() < C) {
            int B = C0242a.m291B(parcel);
            switch (C0242a.aD(B)) {
                case CompletionEvent.STATUS_FAILURE /*1*/:
                    i = C0242a.m309g(parcel, B);
                    break;
                case CompletionEvent.STATUS_CONFLICT /*2*/:
                    j = C0242a.m311i(parcel, B);
                    break;
                case FastDatePrinter.SHORT /*3*/:
                    bundle = C0242a.m319q(parcel, B);
                    break;
                case ItemTouchHelper.LEFT /*4*/:
                    i2 = C0242a.m309g(parcel, B);
                    break;
                case DetectedActivity.TILTING /*5*/:
                    list = C0242a.m294C(parcel, B);
                    break;
                case Quest.STATE_FAILED /*6*/:
                    z = C0242a.m305c(parcel, B);
                    break;
                case DetectedActivity.WALKING /*7*/:
                    i3 = C0242a.m309g(parcel, B);
                    break;
                case XtraBox.MP4_XTRA_BT_UNICODE /*8*/:
                    z2 = C0242a.m305c(parcel, B);
                    break;
                case C0811R.styleable.WalletFragmentStyle_maskedWalletDetailsLogoTextColor /*9*/:
                    str = C0242a.m317o(parcel, B);
                    break;
                case C0811R.styleable.WalletFragmentStyle_maskedWalletDetailsLogoImageType /*10*/:
                    bjVar = (bj) C0242a.m298a(parcel, B, bj.CREATOR);
                    break;
                case C0811R.styleable.MapAttrs_uiZoomGestures /*11*/:
                    location = (Location) C0242a.m298a(parcel, B, Location.CREATOR);
                    break;
                case C0811R.styleable.MapAttrs_useViewLifecycle /*12*/:
                    str2 = C0242a.m317o(parcel, B);
                    break;
                case C0811R.styleable.MapAttrs_zOrderOnTop /*13*/:
                    bundle2 = C0242a.m319q(parcel, B);
                    break;
                default:
                    C0242a.m302b(parcel, B);
                    break;
            }
        }
        if (parcel.dataPosition() == C) {
            return new av(i, j, bundle, i2, list, z, i3, z2, str, bjVar, location, str2, bundle2);
        }
        throw new C0241a("Overread allowed size end=" + C, parcel);
    }

    public /* synthetic */ Object createFromParcel(Parcel x0) {
        return m1102b(x0);
    }

    public av[] m1103e(int i) {
        return new av[i];
    }

    public /* synthetic */ Object[] newArray(int x0) {
        return m1103e(x0);
    }
}
