package com.google.android.gms.internal;

import android.content.Context;

public class ie {
    private final me<lx> Dh;
    private final Context mContext;

    private ie(Context context, me<lx> meVar) {
        this.mContext = context;
        this.Dh = meVar;
    }

    public static ie m1505a(Context context, me<lx> meVar) {
        return new ie(context, meVar);
    }
}
