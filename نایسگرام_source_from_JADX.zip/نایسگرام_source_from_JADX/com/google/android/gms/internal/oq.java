package com.google.android.gms.internal;

import android.os.Parcel;
import android.os.Parcelable.Creator;
import com.google.android.gms.common.internal.safeparcel.C0242a;
import com.google.android.gms.common.internal.safeparcel.C0242a.C0241a;
import com.google.android.gms.common.internal.safeparcel.C0243b;
import com.google.android.gms.drive.events.CompletionEvent;
import org.telegram.android.time.FastDatePrinter;

public class oq implements Creator<op> {
    static void m1735a(op opVar, Parcel parcel, int i) {
        int D = C0243b.m329D(parcel);
        C0243b.m356c(parcel, 1, opVar.getVersionCode());
        C0243b.m351a(parcel, 2, opVar.atO, false);
        C0243b.m352a(parcel, 3, opVar.atP, false);
        C0243b.m332H(parcel, D);
    }

    public /* synthetic */ Object createFromParcel(Parcel x0) {
        return dC(x0);
    }

    public op dC(Parcel parcel) {
        String[] strArr = null;
        int C = C0242a.m293C(parcel);
        int i = 0;
        byte[][] bArr = (byte[][]) null;
        while (parcel.dataPosition() < C) {
            int B = C0242a.m291B(parcel);
            switch (C0242a.aD(B)) {
                case CompletionEvent.STATUS_FAILURE /*1*/:
                    i = C0242a.m309g(parcel, B);
                    break;
                case CompletionEvent.STATUS_CONFLICT /*2*/:
                    strArr = C0242a.m290A(parcel, B);
                    break;
                case FastDatePrinter.SHORT /*3*/:
                    bArr = C0242a.m321s(parcel, B);
                    break;
                default:
                    C0242a.m302b(parcel, B);
                    break;
            }
        }
        if (parcel.dataPosition() == C) {
            return new op(i, strArr, bArr);
        }
        throw new C0241a("Overread allowed size end=" + C, parcel);
    }

    public op[] fD(int i) {
        return new op[i];
    }

    public /* synthetic */ Object[] newArray(int x0) {
        return fD(x0);
    }
}
