package com.google.android.gms.internal;

import org.json.JSONObject;

public interface is {
    void m1539a(long j, int i, JSONObject jSONObject);

    void m1540n(long j);
}
