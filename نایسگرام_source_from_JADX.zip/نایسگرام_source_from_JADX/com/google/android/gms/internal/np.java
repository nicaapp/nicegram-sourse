package com.google.android.gms.internal;

import com.google.android.gms.common.api.Api.C0190c;
import com.google.android.gms.common.api.GoogleApiClient;
import com.google.android.gms.common.api.PendingResult;
import com.google.android.gms.common.api.Result;
import com.google.android.gms.common.api.Status;
import com.google.android.gms.common.internal.C0238o;
import com.google.android.gms.plus.Account;
import com.google.android.gms.plus.Plus;
import com.google.android.gms.plus.Plus.C2632a;
import com.google.android.gms.plus.internal.C2535e;

public final class np implements Account {

    /* renamed from: com.google.android.gms.internal.np.a */
    private static abstract class C2693a extends C2632a<Status> {
        private C2693a() {
        }

        public /* synthetic */ Result m4995c(Status status) {
            return m4996d(status);
        }

        public Status m4996d(Status status) {
            return status;
        }
    }

    /* renamed from: com.google.android.gms.internal.np.1 */
    class C28691 extends C2693a {
        final /* synthetic */ np alN;

        C28691(np npVar) {
            this.alN = npVar;
            super();
        }

        protected void m5447a(C2535e c2535e) {
            c2535e.m4504m(this);
        }
    }

    private static C2535e m3410a(GoogleApiClient googleApiClient, C0190c<C2535e> c0190c) {
        boolean z = true;
        C0238o.m281b(googleApiClient != null, (Object) "GoogleApiClient parameter is required.");
        C0238o.m277a(googleApiClient.isConnected(), "GoogleApiClient must be connected.");
        C2535e c2535e = (C2535e) googleApiClient.m149a((C0190c) c0190c);
        if (c2535e == null) {
            z = false;
        }
        C0238o.m277a(z, "GoogleApiClient is not configured to use the Plus.API Api. Pass this into GoogleApiClient.Builder#addApi() to use this feature.");
        return c2535e;
    }

    public void clearDefaultAccount(GoogleApiClient googleApiClient) {
        m3410a(googleApiClient, Plus.CU).clearDefaultAccount();
    }

    public String getAccountName(GoogleApiClient googleApiClient) {
        return m3410a(googleApiClient, Plus.CU).getAccountName();
    }

    public PendingResult<Status> revokeAccessAndDisconnect(GoogleApiClient googleApiClient) {
        return googleApiClient.m152b(new C28691(this));
    }
}
