package com.google.android.gms.internal;

import java.util.Map;
import java.util.concurrent.Future;

@ez
public final class ft {
    private gv md;
    private final Object mw;
    private String uq;
    private gk<fv> ur;
    public final by us;
    public final by ut;

    /* renamed from: com.google.android.gms.internal.ft.1 */
    class C18621 implements by {
        final /* synthetic */ ft uu;

        C18621(ft ftVar) {
            this.uu = ftVar;
        }

        public void m3186a(gv gvVar, Map<String, String> map) {
            synchronized (this.uu.mw) {
                if (this.uu.ur.isDone()) {
                    return;
                }
                fv fvVar = new fv(1, map);
                gs.m1412W("Invalid " + fvVar.getType() + " request error: " + fvVar.cL());
                this.uu.ur.m1387a(fvVar);
            }
        }
    }

    /* renamed from: com.google.android.gms.internal.ft.2 */
    class C18632 implements by {
        final /* synthetic */ ft uu;

        C18632(ft ftVar) {
            this.uu = ftVar;
        }

        public void m3187a(gv gvVar, Map<String, String> map) {
            synchronized (this.uu.mw) {
                if (this.uu.ur.isDone()) {
                    return;
                }
                fv fvVar = new fv(-2, map);
                String url = fvVar.getUrl();
                if (url == null) {
                    gs.m1412W("URL missing in loadAdUrl GMSG.");
                    return;
                }
                if (url.contains("%40mediation_adapters%40")) {
                    String replaceAll = url.replaceAll("%40mediation_adapters%40", gf.m1347a(gvVar.getContext(), (String) map.get("check_adapters"), this.uu.uq));
                    fvVar.setUrl(replaceAll);
                    gs.m1411V("Ad request URL modified to " + replaceAll);
                }
                this.uu.ur.m1387a(fvVar);
            }
        }
    }

    public ft(String str) {
        this.mw = new Object();
        this.ur = new gk();
        this.us = new C18621(this);
        this.ut = new C18632(this);
        this.uq = str;
    }

    public void m1306b(gv gvVar) {
        this.md = gvVar;
    }

    public Future<fv> cK() {
        return this.ur;
    }
}
