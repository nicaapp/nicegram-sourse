package com.google.android.gms.internal;

import android.os.Parcel;
import android.os.Parcelable.Creator;
import com.google.android.gms.common.internal.safeparcel.C0242a;
import com.google.android.gms.common.internal.safeparcel.C0242a.C0241a;
import com.google.android.gms.common.internal.safeparcel.C0243b;
import com.google.android.gms.drive.events.CompletionEvent;
import com.google.android.gms.location.GeofenceStatusCodes;
import com.google.android.gms.location.LocationRequest;
import org.telegram.android.support.widget.helper.ItemTouchHelper;
import org.telegram.android.time.FastDatePrinter;

public class mo implements Creator<mn> {
    static void m1697a(mn mnVar, Parcel parcel, int i) {
        int D = C0243b.m329D(parcel);
        C0243b.m356c(parcel, GeofenceStatusCodes.GEOFENCE_NOT_AVAILABLE, mnVar.BR);
        C0243b.m340a(parcel, 2, mnVar.mh(), i, false);
        C0243b.m336a(parcel, 3, mnVar.getInterval());
        C0243b.m356c(parcel, 4, mnVar.getPriority());
        C0243b.m332H(parcel, D);
    }

    public mn cB(Parcel parcel) {
        int C = C0242a.m293C(parcel);
        int i = 0;
        mj mjVar = null;
        long j = mn.afA;
        int i2 = LocationRequest.PRIORITY_BALANCED_POWER_ACCURACY;
        while (parcel.dataPosition() < C) {
            int B = C0242a.m291B(parcel);
            switch (C0242a.aD(B)) {
                case CompletionEvent.STATUS_CONFLICT /*2*/:
                    mjVar = (mj) C0242a.m298a(parcel, B, mj.CREATOR);
                    break;
                case FastDatePrinter.SHORT /*3*/:
                    j = C0242a.m311i(parcel, B);
                    break;
                case ItemTouchHelper.LEFT /*4*/:
                    i2 = C0242a.m309g(parcel, B);
                    break;
                case GeofenceStatusCodes.GEOFENCE_NOT_AVAILABLE /*1000*/:
                    i = C0242a.m309g(parcel, B);
                    break;
                default:
                    C0242a.m302b(parcel, B);
                    break;
            }
        }
        if (parcel.dataPosition() == C) {
            return new mn(i, mjVar, j, i2);
        }
        throw new C0241a("Overread allowed size end=" + C, parcel);
    }

    public /* synthetic */ Object createFromParcel(Parcel x0) {
        return cB(x0);
    }

    public mn[] er(int i) {
        return new mn[i];
    }

    public /* synthetic */ Object[] newArray(int x0) {
        return er(x0);
    }
}
