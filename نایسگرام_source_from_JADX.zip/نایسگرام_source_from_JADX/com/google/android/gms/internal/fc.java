package com.google.android.gms.internal;

import android.graphics.Bitmap;
import android.graphics.Bitmap.Config;
import android.graphics.Canvas;
import android.os.AsyncTask;
import android.os.Handler;
import android.os.Looper;
import android.text.TextUtils;
import android.view.View.MeasureSpec;
import android.webkit.WebView;
import com.google.android.gms.internal.gw.C0505a;

@ez
public class fc implements Runnable {
    private final int lf;
    private final int lg;
    protected final gv md;
    private final Handler td;
    private final long te;
    private long tf;
    private C0505a tg;
    protected boolean th;
    protected boolean ti;

    /* renamed from: com.google.android.gms.internal.fc.a */
    protected final class C0478a extends AsyncTask<Void, Void, Boolean> {
        private final WebView tj;
        private Bitmap tk;
        final /* synthetic */ fc tl;

        public C0478a(fc fcVar, WebView webView) {
            this.tl = fcVar;
            this.tj = webView;
        }

        protected synchronized Boolean m1262a(Void... voidArr) {
            Boolean valueOf;
            int width = this.tk.getWidth();
            int height = this.tk.getHeight();
            if (width == 0 || height == 0) {
                valueOf = Boolean.valueOf(false);
            } else {
                int i = 0;
                for (int i2 = 0; i2 < width; i2 += 10) {
                    for (int i3 = 0; i3 < height; i3 += 10) {
                        if (this.tk.getPixel(i2, i3) != 0) {
                            i++;
                        }
                    }
                }
                valueOf = Boolean.valueOf(((double) i) / (((double) (width * height)) / 100.0d) > 0.1d);
            }
            return valueOf;
        }

        protected void m1263a(Boolean bool) {
            fc.m1266c(this.tl);
            if (bool.booleanValue() || this.tl.cA() || this.tl.tf <= 0) {
                this.tl.ti = bool.booleanValue();
                this.tl.tg.m1432a(this.tl.md);
            } else if (this.tl.tf > 0) {
                if (gs.m1417u(2)) {
                    gs.m1408S("Ad not detected, scheduling another run.");
                }
                this.tl.td.postDelayed(this.tl, this.tl.te);
            }
        }

        protected /* synthetic */ Object doInBackground(Object[] x0) {
            return m1262a((Void[]) x0);
        }

        protected /* synthetic */ void onPostExecute(Object x0) {
            m1263a((Boolean) x0);
        }

        protected synchronized void onPreExecute() {
            this.tk = Bitmap.createBitmap(this.tl.lf, this.tl.lg, Config.ARGB_8888);
            this.tj.setVisibility(0);
            this.tj.measure(MeasureSpec.makeMeasureSpec(this.tl.lf, 0), MeasureSpec.makeMeasureSpec(this.tl.lg, 0));
            this.tj.layout(0, 0, this.tl.lf, this.tl.lg);
            this.tj.draw(new Canvas(this.tk));
            this.tj.invalidate();
        }
    }

    public fc(C0505a c0505a, gv gvVar, int i, int i2) {
        this(c0505a, gvVar, i, i2, 200, 50);
    }

    public fc(C0505a c0505a, gv gvVar, int i, int i2, long j, long j2) {
        this.te = j;
        this.tf = j2;
        this.td = new Handler(Looper.getMainLooper());
        this.md = gvVar;
        this.tg = c0505a;
        this.th = false;
        this.ti = false;
        this.lg = i2;
        this.lf = i;
    }

    static /* synthetic */ long m1266c(fc fcVar) {
        long j = fcVar.tf - 1;
        fcVar.tf = j;
        return j;
    }

    public void m1271a(fk fkVar, ha haVar) {
        this.md.setWebViewClient(haVar);
        this.md.loadDataWithBaseURL(TextUtils.isEmpty(fkVar.rP) ? null : gj.m1354L(fkVar.rP), fkVar.tG, "text/html", "UTF-8", null);
    }

    public void m1272b(fk fkVar) {
        m1271a(fkVar, new ha(this, this.md, fkVar.tP));
    }

    public synchronized boolean cA() {
        return this.th;
    }

    public boolean cB() {
        return this.ti;
    }

    public void cy() {
        this.td.postDelayed(this, this.te);
    }

    public synchronized void cz() {
        this.th = true;
    }

    public void run() {
        if (this.md == null || cA()) {
            this.tg.m1432a(this.md);
        } else {
            new C0478a(this, this.md).execute(new Void[0]);
        }
    }
}
