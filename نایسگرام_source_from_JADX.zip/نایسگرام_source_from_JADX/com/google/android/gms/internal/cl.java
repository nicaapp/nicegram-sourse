package com.google.android.gms.internal;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

@ez
public final class cl {
    public final String pW;
    public final String pX;
    public final List<String> pY;
    public final String pZ;
    public final String qa;
    public final List<String> qb;
    public final String qc;

    public cl(JSONObject jSONObject) throws JSONException {
        String str = null;
        this.pX = jSONObject.getString("id");
        JSONArray jSONArray = jSONObject.getJSONArray("adapters");
        List arrayList = new ArrayList(jSONArray.length());
        for (int i = 0; i < jSONArray.length(); i++) {
            arrayList.add(jSONArray.getString(i));
        }
        this.pY = Collections.unmodifiableList(arrayList);
        this.pZ = jSONObject.optString("allocation_id", null);
        this.qb = cr.m1171a(jSONObject, "imp_urls");
        JSONObject optJSONObject = jSONObject.optJSONObject("ad");
        this.pW = optJSONObject != null ? optJSONObject.toString() : null;
        JSONObject optJSONObject2 = jSONObject.optJSONObject("data");
        this.qc = optJSONObject2 != null ? optJSONObject2.toString() : null;
        if (optJSONObject2 != null) {
            str = optJSONObject2.optString("class_name");
        }
        this.qa = str;
    }
}
