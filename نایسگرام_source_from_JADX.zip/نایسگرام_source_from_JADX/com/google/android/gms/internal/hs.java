package com.google.android.gms.internal;

import android.content.ComponentName;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.os.Parcel;
import com.google.android.gms.appindexing.AppIndexApi.AppIndexingLink;
import com.google.android.gms.common.internal.safeparcel.SafeParcelable;
import com.google.android.gms.internal.he.C0514a;
import com.google.android.gms.internal.hq.C0515a;
import com.google.android.gms.internal.ll.C2489a;
import com.google.android.gms.internal.ll.C2489a.C2488a;
import com.google.android.gms.plus.PlusShare;
import java.util.List;
import java.util.zip.CRC32;
import org.telegram.messenger.BuildConfig;

public class hs implements SafeParcelable {
    public static final ht CREATOR;
    final int BR;
    final hg CD;
    final long CE;
    final int CF;
    final he CG;
    public final String oT;

    static {
        CREATOR = new ht();
    }

    hs(int i, hg hgVar, long j, int i2, String str, he heVar) {
        this.BR = i;
        this.CD = hgVar;
        this.CE = j;
        this.CF = i2;
        this.oT = str;
        this.CG = heVar;
    }

    public hs(hg hgVar, long j, int i) {
        this(1, hgVar, j, i, null, null);
    }

    public hs(String str, Intent intent, String str2, Uri uri, String str3, List<AppIndexingLink> list) {
        this(1, m3228a(str, intent), System.currentTimeMillis(), 0, null, m3227a(intent, str2, uri, str3, list).fj());
    }

    public static C0514a m3227a(Intent intent, String str, Uri uri, String str2, List<AppIndexingLink> list) {
        C0514a c0514a = new C0514a();
        c0514a.m1456a(av(str));
        if (uri != null) {
            c0514a.m1456a(m3230f(uri));
        }
        if (list != null) {
            c0514a.m1456a(m3229b(list));
        }
        String action = intent.getAction();
        if (action != null) {
            c0514a.m1456a(m3233j("intent_action", action));
        }
        action = intent.getDataString();
        if (action != null) {
            c0514a.m1456a(m3233j("intent_data", action));
        }
        ComponentName component = intent.getComponent();
        if (component != null) {
            c0514a.m1456a(m3233j("intent_activity", component.getClassName()));
        }
        Bundle extras = intent.getExtras();
        if (extras != null) {
            action = extras.getString("intent_extra_data_key");
            if (action != null) {
                c0514a.m1456a(m3233j("intent_extra_data", action));
            }
        }
        return c0514a.ar(str2).m1455D(true);
    }

    public static hg m3228a(String str, Intent intent) {
        return m3232i(str, m3231g(intent));
    }

    private static hi av(String str) {
        return new hi(str, new C0515a(PlusShare.KEY_CONTENT_DEEP_LINK_METADATA_TITLE).m1478P(1).m1477F(true).au("name").fm(), "text1");
    }

    private static hi m3229b(List<AppIndexingLink> list) {
        pn c2489a = new C2489a();
        C2488a[] c2488aArr = new C2488a[list.size()];
        for (int i = 0; i < c2488aArr.length; i++) {
            c2488aArr[i] = new C2488a();
            AppIndexingLink appIndexingLink = (AppIndexingLink) list.get(i);
            c2488aArr[i].adG = appIndexingLink.appIndexingUrl.toString();
            c2488aArr[i].adH = appIndexingLink.webUrl.toString();
            c2488aArr[i].viewId = appIndexingLink.viewId;
        }
        c2489a.adE = c2488aArr;
        return new hi(pn.m1838f(c2489a), new C0515a("outlinks").m1476E(true).au(".private:outLinks").at("blob").fm());
    }

    private static hi m3230f(Uri uri) {
        return new hi(uri.toString(), new C0515a("web_url").m1478P(4).m1476E(true).au(PlusShare.KEY_CALL_TO_ACTION_URL).fm());
    }

    private static String m3231g(Intent intent) {
        String toUri = intent.toUri(1);
        CRC32 crc32 = new CRC32();
        try {
            crc32.update(toUri.getBytes("UTF-8"));
            return Long.toHexString(crc32.getValue());
        } catch (Throwable e) {
            throw new IllegalStateException(e);
        }
    }

    private static hg m3232i(String str, String str2) {
        return new hg(str, BuildConfig.FLAVOR, str2);
    }

    private static hi m3233j(String str, String str2) {
        return new hi(str2, new C0515a(str).m1476E(true).fm(), str);
    }

    public int describeContents() {
        ht htVar = CREATOR;
        return 0;
    }

    public String toString() {
        return String.format("UsageInfo[documentId=%s, timestamp=%d, usageType=%d]", new Object[]{this.CD, Long.valueOf(this.CE), Integer.valueOf(this.CF)});
    }

    public void writeToParcel(Parcel dest, int flags) {
        ht htVar = CREATOR;
        ht.m1482a(this, dest, flags);
    }
}
