package com.google.android.gms.internal;

import com.google.android.gms.drive.events.CompletionEvent;
import com.google.android.gms.games.quest.Quest;
import com.google.android.gms.location.DetectedActivity;
import com.googlecode.mp4parser.authoring.tracks.h265.NalUnitTypes;
import com.googlecode.mp4parser.boxes.microsoft.XtraBox;
import java.io.IOException;
import java.util.Arrays;
import org.telegram.C0811R;
import org.telegram.android.support.widget.helper.ItemTouchHelper;
import org.telegram.android.time.FastDatePrinter;
import org.telegram.messenger.BuildConfig;

public interface pr {

    /* renamed from: com.google.android.gms.internal.pr.a */
    public static final class C2512a extends ph<C2512a> {
        public String[] axe;
        public String[] axf;
        public int[] axg;

        public C2512a() {
            qJ();
        }

        public void m4429a(pg pgVar) throws IOException {
            int i = 0;
            if (this.axe != null && this.axe.length > 0) {
                for (String str : this.axe) {
                    if (str != null) {
                        pgVar.m1803b(1, str);
                    }
                }
            }
            if (this.axf != null && this.axf.length > 0) {
                for (String str2 : this.axf) {
                    if (str2 != null) {
                        pgVar.m1803b(2, str2);
                    }
                }
            }
            if (this.axg != null && this.axg.length > 0) {
                while (i < this.axg.length) {
                    pgVar.m1812s(3, this.axg[i]);
                    i++;
                }
            }
            super.m3435a(pgVar);
        }

        public /* synthetic */ pn m4430b(pf pfVar) throws IOException {
            return m4432v(pfVar);
        }

        protected int m4431c() {
            int i;
            int i2;
            int i3;
            int i4 = 0;
            int c = super.m3438c();
            if (this.axe == null || this.axe.length <= 0) {
                i = c;
            } else {
                i2 = 0;
                i3 = 0;
                for (String str : this.axe) {
                    if (str != null) {
                        i3++;
                        i2 += pg.di(str);
                    }
                }
                i = (c + i2) + (i3 * 1);
            }
            if (this.axf != null && this.axf.length > 0) {
                i3 = 0;
                c = 0;
                for (String str2 : this.axf) {
                    if (str2 != null) {
                        c++;
                        i3 += pg.di(str2);
                    }
                }
                i = (i + i3) + (c * 1);
            }
            if (this.axg == null || this.axg.length <= 0) {
                return i;
            }
            i2 = 0;
            while (i4 < this.axg.length) {
                i2 += pg.gw(this.axg[i4]);
                i4++;
            }
            return (i + i2) + (this.axg.length * 1);
        }

        public boolean equals(Object o) {
            if (o == this) {
                return true;
            }
            if (!(o instanceof C2512a)) {
                return false;
            }
            C2512a c2512a = (C2512a) o;
            return (pl.equals(this.axe, c2512a.axe) && pl.equals(this.axf, c2512a.axf) && pl.equals(this.axg, c2512a.axg)) ? m3437a((ph) c2512a) : false;
        }

        public int hashCode() {
            return ((((((pl.hashCode(this.axe) + 527) * 31) + pl.hashCode(this.axf)) * 31) + pl.hashCode(this.axg)) * 31) + qz();
        }

        public C2512a qJ() {
            this.axe = pq.axb;
            this.axf = pq.axb;
            this.axg = pq.awW;
            this.awJ = null;
            this.awU = -1;
            return this;
        }

        public C2512a m4432v(pf pfVar) throws IOException {
            while (true) {
                int qi = pfVar.qi();
                int b;
                Object obj;
                switch (qi) {
                    case FastDatePrinter.FULL /*0*/:
                        break;
                    case C0811R.styleable.WalletFragmentStyle_maskedWalletDetailsLogoImageType /*10*/:
                        b = pq.m1847b(pfVar, 10);
                        qi = this.axe == null ? 0 : this.axe.length;
                        obj = new String[(b + qi)];
                        if (qi != 0) {
                            System.arraycopy(this.axe, 0, obj, 0, qi);
                        }
                        while (qi < obj.length - 1) {
                            obj[qi] = pfVar.readString();
                            pfVar.qi();
                            qi++;
                        }
                        obj[qi] = pfVar.readString();
                        this.axe = obj;
                        continue;
                    case NalUnitTypes.NAL_TYPE_BLA_N_LP /*18*/:
                        b = pq.m1847b(pfVar, 18);
                        qi = this.axf == null ? 0 : this.axf.length;
                        obj = new String[(b + qi)];
                        if (qi != 0) {
                            System.arraycopy(this.axf, 0, obj, 0, qi);
                        }
                        while (qi < obj.length - 1) {
                            obj[qi] = pfVar.readString();
                            pfVar.qi();
                            qi++;
                        }
                        obj[qi] = pfVar.readString();
                        this.axf = obj;
                        continue;
                    case NalUnitTypes.NAL_TYPE_RSV_VCL24 /*24*/:
                        b = pq.m1847b(pfVar, 24);
                        qi = this.axg == null ? 0 : this.axg.length;
                        obj = new int[(b + qi)];
                        if (qi != 0) {
                            System.arraycopy(this.axg, 0, obj, 0, qi);
                        }
                        while (qi < obj.length - 1) {
                            obj[qi] = pfVar.ql();
                            pfVar.qi();
                            qi++;
                        }
                        obj[qi] = pfVar.ql();
                        this.axg = obj;
                        continue;
                    case NalUnitTypes.NAL_TYPE_RSV_VCL26 /*26*/:
                        int gp = pfVar.gp(pfVar.qp());
                        b = pfVar.getPosition();
                        qi = 0;
                        while (pfVar.qu() > 0) {
                            pfVar.ql();
                            qi++;
                        }
                        pfVar.gr(b);
                        b = this.axg == null ? 0 : this.axg.length;
                        Object obj2 = new int[(qi + b)];
                        if (b != 0) {
                            System.arraycopy(this.axg, 0, obj2, 0, b);
                        }
                        while (b < obj2.length) {
                            obj2[b] = pfVar.ql();
                            b++;
                        }
                        this.axg = obj2;
                        pfVar.gq(gp);
                        continue;
                    default:
                        if (!m3436a(pfVar, qi)) {
                            break;
                        }
                        continue;
                }
                return this;
            }
        }
    }

    /* renamed from: com.google.android.gms.internal.pr.b */
    public static final class C2513b extends ph<C2513b> {
        public int axh;
        public String axi;
        public String version;

        public C2513b() {
            qK();
        }

        public void m4433a(pg pgVar) throws IOException {
            if (this.axh != 0) {
                pgVar.m1812s(1, this.axh);
            }
            if (!this.axi.equals(BuildConfig.FLAVOR)) {
                pgVar.m1803b(2, this.axi);
            }
            if (!this.version.equals(BuildConfig.FLAVOR)) {
                pgVar.m1803b(3, this.version);
            }
            super.m3435a(pgVar);
        }

        public /* synthetic */ pn m4434b(pf pfVar) throws IOException {
            return m4436w(pfVar);
        }

        protected int m4435c() {
            int c = super.m3438c();
            if (this.axh != 0) {
                c += pg.m1790u(1, this.axh);
            }
            if (!this.axi.equals(BuildConfig.FLAVOR)) {
                c += pg.m1787j(2, this.axi);
            }
            return !this.version.equals(BuildConfig.FLAVOR) ? c + pg.m1787j(3, this.version) : c;
        }

        public boolean equals(Object o) {
            if (o == this) {
                return true;
            }
            if (!(o instanceof C2513b)) {
                return false;
            }
            C2513b c2513b = (C2513b) o;
            if (this.axh != c2513b.axh) {
                return false;
            }
            if (this.axi == null) {
                if (c2513b.axi != null) {
                    return false;
                }
            } else if (!this.axi.equals(c2513b.axi)) {
                return false;
            }
            if (this.version == null) {
                if (c2513b.version != null) {
                    return false;
                }
            } else if (!this.version.equals(c2513b.version)) {
                return false;
            }
            return m3437a((ph) c2513b);
        }

        public int hashCode() {
            int i = 0;
            int hashCode = ((this.axi == null ? 0 : this.axi.hashCode()) + ((this.axh + 527) * 31)) * 31;
            if (this.version != null) {
                i = this.version.hashCode();
            }
            return ((hashCode + i) * 31) + qz();
        }

        public C2513b qK() {
            this.axh = 0;
            this.axi = BuildConfig.FLAVOR;
            this.version = BuildConfig.FLAVOR;
            this.awJ = null;
            this.awU = -1;
            return this;
        }

        public C2513b m4436w(pf pfVar) throws IOException {
            while (true) {
                int qi = pfVar.qi();
                switch (qi) {
                    case FastDatePrinter.FULL /*0*/:
                        break;
                    case XtraBox.MP4_XTRA_BT_UNICODE /*8*/:
                        qi = pfVar.ql();
                        switch (qi) {
                            case FastDatePrinter.FULL /*0*/:
                            case CompletionEvent.STATUS_FAILURE /*1*/:
                            case CompletionEvent.STATUS_CONFLICT /*2*/:
                            case FastDatePrinter.SHORT /*3*/:
                            case ItemTouchHelper.LEFT /*4*/:
                            case DetectedActivity.TILTING /*5*/:
                            case Quest.STATE_FAILED /*6*/:
                            case DetectedActivity.WALKING /*7*/:
                            case XtraBox.MP4_XTRA_BT_UNICODE /*8*/:
                            case C0811R.styleable.WalletFragmentStyle_maskedWalletDetailsLogoTextColor /*9*/:
                            case C0811R.styleable.WalletFragmentStyle_maskedWalletDetailsLogoImageType /*10*/:
                            case C0811R.styleable.MapAttrs_uiZoomGestures /*11*/:
                            case C0811R.styleable.MapAttrs_useViewLifecycle /*12*/:
                            case C0811R.styleable.MapAttrs_zOrderOnTop /*13*/:
                            case NalUnitTypes.NAL_TYPE_RSV_VCL_N14 /*14*/:
                            case NalUnitTypes.NAL_TYPE_RSV_VCL_R15 /*15*/:
                            case ItemTouchHelper.START /*16*/:
                            case NalUnitTypes.NAL_TYPE_BLA_W_RADL /*17*/:
                            case NalUnitTypes.NAL_TYPE_BLA_N_LP /*18*/:
                            case XtraBox.MP4_XTRA_BT_INT64 /*19*/:
                            case NalUnitTypes.NAL_TYPE_IDR_N_LP /*20*/:
                            case XtraBox.MP4_XTRA_BT_FILETIME /*21*/:
                            case NalUnitTypes.NAL_TYPE_RSV_IRAP_VCL22 /*22*/:
                                this.axh = qi;
                                break;
                            default:
                                continue;
                        }
                    case NalUnitTypes.NAL_TYPE_BLA_N_LP /*18*/:
                        this.axi = pfVar.readString();
                        continue;
                    case NalUnitTypes.NAL_TYPE_RSV_VCL26 /*26*/:
                        this.version = pfVar.readString();
                        continue;
                    default:
                        if (!m3436a(pfVar, qi)) {
                            break;
                        }
                        continue;
                }
                return this;
            }
        }
    }

    /* renamed from: com.google.android.gms.internal.pr.c */
    public static final class C2514c extends ph<C2514c> {
        public long axj;
        public int axk;
        public int axl;
        public boolean axm;
        public C2515d[] axn;
        public C2513b axo;
        public byte[] axp;
        public byte[] axq;
        public byte[] axr;
        public C2512a axs;
        public String axt;
        public String tag;

        public C2514c() {
            qL();
        }

        public void m4437a(pg pgVar) throws IOException {
            if (this.axj != 0) {
                pgVar.m1802b(1, this.axj);
            }
            if (!this.tag.equals(BuildConfig.FLAVOR)) {
                pgVar.m1803b(2, this.tag);
            }
            if (this.axn != null && this.axn.length > 0) {
                for (pn pnVar : this.axn) {
                    if (pnVar != null) {
                        pgVar.m1798a(3, pnVar);
                    }
                }
            }
            if (!Arrays.equals(this.axp, pq.axd)) {
                pgVar.m1799a(6, this.axp);
            }
            if (this.axs != null) {
                pgVar.m1798a(7, this.axs);
            }
            if (!Arrays.equals(this.axq, pq.axd)) {
                pgVar.m1799a(8, this.axq);
            }
            if (this.axo != null) {
                pgVar.m1798a(9, this.axo);
            }
            if (this.axm) {
                pgVar.m1804b(10, this.axm);
            }
            if (this.axk != 0) {
                pgVar.m1812s(11, this.axk);
            }
            if (this.axl != 0) {
                pgVar.m1812s(12, this.axl);
            }
            if (!Arrays.equals(this.axr, pq.axd)) {
                pgVar.m1799a(13, this.axr);
            }
            if (!this.axt.equals(BuildConfig.FLAVOR)) {
                pgVar.m1803b(14, this.axt);
            }
            super.m3435a(pgVar);
        }

        public /* synthetic */ pn m4438b(pf pfVar) throws IOException {
            return m4440x(pfVar);
        }

        protected int m4439c() {
            int c = super.m3438c();
            if (this.axj != 0) {
                c += pg.m1781d(1, this.axj);
            }
            if (!this.tag.equals(BuildConfig.FLAVOR)) {
                c += pg.m1787j(2, this.tag);
            }
            if (this.axn != null && this.axn.length > 0) {
                int i = c;
                for (pn pnVar : this.axn) {
                    if (pnVar != null) {
                        i += pg.m1779c(3, pnVar);
                    }
                }
                c = i;
            }
            if (!Arrays.equals(this.axp, pq.axd)) {
                c += pg.m1776b(6, this.axp);
            }
            if (this.axs != null) {
                c += pg.m1779c(7, this.axs);
            }
            if (!Arrays.equals(this.axq, pq.axd)) {
                c += pg.m1776b(8, this.axq);
            }
            if (this.axo != null) {
                c += pg.m1779c(9, this.axo);
            }
            if (this.axm) {
                c += pg.m1780c(10, this.axm);
            }
            if (this.axk != 0) {
                c += pg.m1790u(11, this.axk);
            }
            if (this.axl != 0) {
                c += pg.m1790u(12, this.axl);
            }
            if (!Arrays.equals(this.axr, pq.axd)) {
                c += pg.m1776b(13, this.axr);
            }
            return !this.axt.equals(BuildConfig.FLAVOR) ? c + pg.m1787j(14, this.axt) : c;
        }

        public boolean equals(Object o) {
            if (o == this) {
                return true;
            }
            if (!(o instanceof C2514c)) {
                return false;
            }
            C2514c c2514c = (C2514c) o;
            if (this.axj != c2514c.axj) {
                return false;
            }
            if (this.tag == null) {
                if (c2514c.tag != null) {
                    return false;
                }
            } else if (!this.tag.equals(c2514c.tag)) {
                return false;
            }
            if (this.axk != c2514c.axk || this.axl != c2514c.axl || this.axm != c2514c.axm || !pl.equals(this.axn, c2514c.axn)) {
                return false;
            }
            if (this.axo == null) {
                if (c2514c.axo != null) {
                    return false;
                }
            } else if (!this.axo.equals(c2514c.axo)) {
                return false;
            }
            if (!Arrays.equals(this.axp, c2514c.axp) || !Arrays.equals(this.axq, c2514c.axq) || !Arrays.equals(this.axr, c2514c.axr)) {
                return false;
            }
            if (this.axs == null) {
                if (c2514c.axs != null) {
                    return false;
                }
            } else if (!this.axs.equals(c2514c.axs)) {
                return false;
            }
            if (this.axt == null) {
                if (c2514c.axt != null) {
                    return false;
                }
            } else if (!this.axt.equals(c2514c.axt)) {
                return false;
            }
            return m3437a((ph) c2514c);
        }

        public int hashCode() {
            int i = 0;
            int hashCode = ((this.axs == null ? 0 : this.axs.hashCode()) + (((((((((this.axo == null ? 0 : this.axo.hashCode()) + (((((this.axm ? 1231 : 1237) + (((((((this.tag == null ? 0 : this.tag.hashCode()) + ((((int) (this.axj ^ (this.axj >>> 32))) + 527) * 31)) * 31) + this.axk) * 31) + this.axl) * 31)) * 31) + pl.hashCode(this.axn)) * 31)) * 31) + Arrays.hashCode(this.axp)) * 31) + Arrays.hashCode(this.axq)) * 31) + Arrays.hashCode(this.axr)) * 31)) * 31;
            if (this.axt != null) {
                i = this.axt.hashCode();
            }
            return ((hashCode + i) * 31) + qz();
        }

        public C2514c qL() {
            this.axj = 0;
            this.tag = BuildConfig.FLAVOR;
            this.axk = 0;
            this.axl = 0;
            this.axm = false;
            this.axn = C2515d.qM();
            this.axo = null;
            this.axp = pq.axd;
            this.axq = pq.axd;
            this.axr = pq.axd;
            this.axs = null;
            this.axt = BuildConfig.FLAVOR;
            this.awJ = null;
            this.awU = -1;
            return this;
        }

        public C2514c m4440x(pf pfVar) throws IOException {
            while (true) {
                int qi = pfVar.qi();
                switch (qi) {
                    case FastDatePrinter.FULL /*0*/:
                        break;
                    case XtraBox.MP4_XTRA_BT_UNICODE /*8*/:
                        this.axj = pfVar.qk();
                        continue;
                    case NalUnitTypes.NAL_TYPE_BLA_N_LP /*18*/:
                        this.tag = pfVar.readString();
                        continue;
                    case NalUnitTypes.NAL_TYPE_RSV_VCL26 /*26*/:
                        int b = pq.m1847b(pfVar, 26);
                        qi = this.axn == null ? 0 : this.axn.length;
                        Object obj = new C2515d[(b + qi)];
                        if (qi != 0) {
                            System.arraycopy(this.axn, 0, obj, 0, qi);
                        }
                        while (qi < obj.length - 1) {
                            obj[qi] = new C2515d();
                            pfVar.m1766a(obj[qi]);
                            pfVar.qi();
                            qi++;
                        }
                        obj[qi] = new C2515d();
                        pfVar.m1766a(obj[qi]);
                        this.axn = obj;
                        continue;
                    case NalUnitTypes.NAL_TYPE_UNSPEC50 /*50*/:
                        this.axp = pfVar.readBytes();
                        continue;
                    case 58:
                        if (this.axs == null) {
                            this.axs = new C2512a();
                        }
                        pfVar.m1766a(this.axs);
                        continue;
                    case 66:
                        this.axq = pfVar.readBytes();
                        continue;
                    case 74:
                        if (this.axo == null) {
                            this.axo = new C2513b();
                        }
                        pfVar.m1766a(this.axo);
                        continue;
                    case 80:
                        this.axm = pfVar.qm();
                        continue;
                    case 88:
                        this.axk = pfVar.ql();
                        continue;
                    case 96:
                        this.axl = pfVar.ql();
                        continue;
                    case 106:
                        this.axr = pfVar.readBytes();
                        continue;
                    case 114:
                        this.axt = pfVar.readString();
                        continue;
                    default:
                        if (!m3436a(pfVar, qi)) {
                            break;
                        }
                        continue;
                }
                return this;
            }
        }
    }

    /* renamed from: com.google.android.gms.internal.pr.d */
    public static final class C2515d extends ph<C2515d> {
        private static volatile C2515d[] axu;
        public String fv;
        public String value;

        public C2515d() {
            qN();
        }

        public static C2515d[] qM() {
            if (axu == null) {
                synchronized (pl.awT) {
                    if (axu == null) {
                        axu = new C2515d[0];
                    }
                }
            }
            return axu;
        }

        public void m4441a(pg pgVar) throws IOException {
            if (!this.fv.equals(BuildConfig.FLAVOR)) {
                pgVar.m1803b(1, this.fv);
            }
            if (!this.value.equals(BuildConfig.FLAVOR)) {
                pgVar.m1803b(2, this.value);
            }
            super.m3435a(pgVar);
        }

        public /* synthetic */ pn m4442b(pf pfVar) throws IOException {
            return m4444y(pfVar);
        }

        protected int m4443c() {
            int c = super.m3438c();
            if (!this.fv.equals(BuildConfig.FLAVOR)) {
                c += pg.m1787j(1, this.fv);
            }
            return !this.value.equals(BuildConfig.FLAVOR) ? c + pg.m1787j(2, this.value) : c;
        }

        public boolean equals(Object o) {
            if (o == this) {
                return true;
            }
            if (!(o instanceof C2515d)) {
                return false;
            }
            C2515d c2515d = (C2515d) o;
            if (this.fv == null) {
                if (c2515d.fv != null) {
                    return false;
                }
            } else if (!this.fv.equals(c2515d.fv)) {
                return false;
            }
            if (this.value == null) {
                if (c2515d.value != null) {
                    return false;
                }
            } else if (!this.value.equals(c2515d.value)) {
                return false;
            }
            return m3437a((ph) c2515d);
        }

        public int hashCode() {
            int i = 0;
            int hashCode = ((this.fv == null ? 0 : this.fv.hashCode()) + 527) * 31;
            if (this.value != null) {
                i = this.value.hashCode();
            }
            return ((hashCode + i) * 31) + qz();
        }

        public C2515d qN() {
            this.fv = BuildConfig.FLAVOR;
            this.value = BuildConfig.FLAVOR;
            this.awJ = null;
            this.awU = -1;
            return this;
        }

        public C2515d m4444y(pf pfVar) throws IOException {
            while (true) {
                int qi = pfVar.qi();
                switch (qi) {
                    case FastDatePrinter.FULL /*0*/:
                        break;
                    case C0811R.styleable.WalletFragmentStyle_maskedWalletDetailsLogoImageType /*10*/:
                        this.fv = pfVar.readString();
                        continue;
                    case NalUnitTypes.NAL_TYPE_BLA_N_LP /*18*/:
                        this.value = pfVar.readString();
                        continue;
                    default:
                        if (!m3436a(pfVar, qi)) {
                            break;
                        }
                        continue;
                }
                return this;
            }
        }
    }
}
