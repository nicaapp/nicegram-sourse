package com.google.android.gms.internal;

import android.os.Binder;
import android.os.IBinder;
import android.os.IInterface;
import android.os.Parcel;
import android.os.RemoteException;
import com.google.android.gms.drive.events.CompletionEvent;
import com.google.android.gms.fitness.service.FitnessSensorServiceRequest;
import com.google.android.gms.internal.kn.C1895a;
import com.google.android.gms.internal.kt.C1907a;
import org.telegram.android.time.FastDatePrinter;

public interface lk extends IInterface {

    /* renamed from: com.google.android.gms.internal.lk.a */
    public static abstract class C1911a extends Binder implements lk {
        public C1911a() {
            attachInterface(this, "com.google.android.gms.fitness.internal.service.IFitnessSensorService");
        }

        public IBinder asBinder() {
            return this;
        }

        public boolean onTransact(int code, Parcel data, Parcel reply, int flags) throws RemoteException {
            li liVar = null;
            switch (code) {
                case CompletionEvent.STATUS_FAILURE /*1*/:
                    lg lgVar;
                    data.enforceInterface("com.google.android.gms.fitness.internal.service.IFitnessSensorService");
                    if (data.readInt() != 0) {
                        lgVar = (lg) lg.CREATOR.createFromParcel(data);
                    }
                    m1653a(lgVar, C1895a.aq(data.readStrongBinder()));
                    return true;
                case CompletionEvent.STATUS_CONFLICT /*2*/:
                    FitnessSensorServiceRequest fitnessSensorServiceRequest;
                    data.enforceInterface("com.google.android.gms.fitness.internal.service.IFitnessSensorService");
                    if (data.readInt() != 0) {
                        fitnessSensorServiceRequest = (FitnessSensorServiceRequest) FitnessSensorServiceRequest.CREATOR.createFromParcel(data);
                    }
                    m1652a(fitnessSensorServiceRequest, C1907a.aw(data.readStrongBinder()));
                    return true;
                case FastDatePrinter.SHORT /*3*/:
                    data.enforceInterface("com.google.android.gms.fitness.internal.service.IFitnessSensorService");
                    if (data.readInt() != 0) {
                        liVar = (li) li.CREATOR.createFromParcel(data);
                    }
                    m1654a(liVar, C1907a.aw(data.readStrongBinder()));
                    return true;
                case 1598968902:
                    reply.writeString("com.google.android.gms.fitness.internal.service.IFitnessSensorService");
                    return true;
                default:
                    return super.onTransact(code, data, reply, flags);
            }
        }
    }

    void m1652a(FitnessSensorServiceRequest fitnessSensorServiceRequest, kt ktVar) throws RemoteException;

    void m1653a(lg lgVar, kn knVar) throws RemoteException;

    void m1654a(li liVar, kt ktVar) throws RemoteException;
}
