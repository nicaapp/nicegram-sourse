package com.google.android.gms.internal;

import android.app.PendingIntent;
import android.content.Context;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.os.RemoteException;
import com.google.android.gms.common.GooglePlayServicesUtil;
import com.google.android.gms.common.api.BaseImplementation.C0191b;
import com.google.android.gms.common.api.BaseImplementation.C2381a;
import com.google.android.gms.common.api.GoogleApiClient;
import com.google.android.gms.common.api.PendingResult;
import com.google.android.gms.common.api.Result;
import com.google.android.gms.common.api.Status;
import com.google.android.gms.internal.na.C1929a;
import com.google.android.gms.panorama.Panorama;
import com.google.android.gms.panorama.PanoramaApi;
import com.google.android.gms.panorama.PanoramaApi.C2531a;
import com.google.android.gms.panorama.PanoramaApi.PanoramaResult;

public class nc implements PanoramaApi {

    /* renamed from: com.google.android.gms.internal.nc.4 */
    static class C24934 extends C1929a {
        final /* synthetic */ na akB;
        final /* synthetic */ Uri aky;
        final /* synthetic */ Context mV;

        C24934(Context context, Uri uri, na naVar) {
            this.mV = context;
            this.aky = uri;
            this.akB = naVar;
        }

        public void m4358a(int i, Bundle bundle, int i2, Intent intent) throws RemoteException {
            nc.m3398a(this.mV, this.aky);
            this.akB.m1708a(i, bundle, i2, intent);
        }
    }

    /* renamed from: com.google.android.gms.internal.nc.a */
    private static final class C2494a extends C1929a {
        private final C0191b<C2531a> De;

        public C2494a(C0191b<C2531a> c0191b) {
            this.De = c0191b;
        }

        public void m4359a(int i, Bundle bundle, int i2, Intent intent) {
            this.De.m147b(new mz(new Status(i, null, bundle != null ? (PendingIntent) bundle.getParcelable("pendingIntent") : null), intent, i2));
        }
    }

    /* renamed from: com.google.android.gms.internal.nc.c */
    private static final class C2495c extends C1929a {
        private final C0191b<PanoramaResult> De;

        public C2495c(C0191b<PanoramaResult> c0191b) {
            this.De = c0191b;
        }

        public void m4360a(int i, Bundle bundle, int i2, Intent intent) {
            this.De.m147b(new ne(new Status(i, null, bundle != null ? (PendingIntent) bundle.getParcelable("pendingIntent") : null), intent));
        }
    }

    /* renamed from: com.google.android.gms.internal.nc.d */
    private static abstract class C2628d<R extends Result> extends C2381a<R, nd> {
        protected C2628d() {
            super(Panorama.CU);
        }

        protected abstract void m4795a(Context context, nb nbVar) throws RemoteException;

        protected final void m4797a(nd ndVar) throws RemoteException {
            m4795a(ndVar.getContext(), (nb) ndVar.gS());
        }
    }

    /* renamed from: com.google.android.gms.internal.nc.1 */
    class C26911 extends C2628d<C2531a> {
        final /* synthetic */ Uri aky;
        final /* synthetic */ Bundle akz;

        protected void m4992a(Context context, nb nbVar) throws RemoteException {
            nc.m3399a(context, nbVar, new C2494a(this), this.aky, this.akz);
        }

        protected C2531a ay(Status status) {
            return new mz(status, null, 0);
        }

        protected /* synthetic */ Result m4993c(Status status) {
            return ay(status);
        }
    }

    /* renamed from: com.google.android.gms.internal.nc.b */
    private static abstract class C2692b extends C2628d<PanoramaResult> {
        private C2692b() {
        }

        protected PanoramaResult az(Status status) {
            return new ne(status, null);
        }

        protected /* synthetic */ Result m4994c(Status status) {
            return az(status);
        }
    }

    /* renamed from: com.google.android.gms.internal.nc.2 */
    class C28672 extends C2692b {
        final /* synthetic */ nc akA;
        final /* synthetic */ Uri aky;

        C28672(nc ncVar, Uri uri) {
            this.akA = ncVar;
            this.aky = uri;
            super();
        }

        protected void m5444a(Context context, nb nbVar) throws RemoteException {
            nbVar.m1709a(new C2495c(this), this.aky, null, false);
        }
    }

    /* renamed from: com.google.android.gms.internal.nc.3 */
    class C28683 extends C2692b {
        final /* synthetic */ nc akA;
        final /* synthetic */ Uri aky;

        C28683(nc ncVar, Uri uri) {
            this.akA = ncVar;
            this.aky = uri;
            super();
        }

        protected void m5445a(Context context, nb nbVar) throws RemoteException {
            nc.m3399a(context, nbVar, new C2495c(this), this.aky, null);
        }
    }

    private static void m3398a(Context context, Uri uri) {
        context.revokeUriPermission(uri, 1);
    }

    private static void m3399a(Context context, nb nbVar, na naVar, Uri uri, Bundle bundle) throws RemoteException {
        context.grantUriPermission(GooglePlayServicesUtil.GOOGLE_PLAY_SERVICES_PACKAGE, uri, 1);
        try {
            nbVar.m1709a(new C24934(context, uri, naVar), uri, bundle, true);
        } catch (RemoteException e) {
            m3398a(context, uri);
            throw e;
        } catch (RuntimeException e2) {
            m3398a(context, uri);
            throw e2;
        }
    }

    public PendingResult<PanoramaResult> loadPanoramaInfo(GoogleApiClient client, Uri uri) {
        return client.m150a(new C28672(this, uri));
    }

    public PendingResult<PanoramaResult> loadPanoramaInfoAndGrantAccess(GoogleApiClient client, Uri uri) {
        return client.m150a(new C28683(this, uri));
    }
}
