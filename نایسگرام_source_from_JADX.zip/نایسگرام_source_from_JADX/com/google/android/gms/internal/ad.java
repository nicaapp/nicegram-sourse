package com.google.android.gms.internal;

import org.json.JSONObject;

@ez
public final class ad {
    private final String ms;
    private final JSONObject mt;
    private final String mu;
    private final String mv;

    public ad(String str, gt gtVar, String str2, JSONObject jSONObject) {
        this.mv = gtVar.wD;
        this.mt = jSONObject;
        this.mu = str;
        this.ms = str2;
    }

    public String aA() {
        return this.mv;
    }

    public JSONObject aB() {
        return this.mt;
    }

    public String aC() {
        return this.mu;
    }

    public String az() {
        return this.ms;
    }
}
