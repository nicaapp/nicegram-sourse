package com.google.android.gms.internal;

import android.app.Activity;
import android.content.Intent;
import android.os.IBinder;
import com.google.android.gms.dynamic.C0333g;
import com.google.android.gms.dynamic.C2413e;
import com.google.android.gms.internal.ei.C1832a;
import com.google.android.gms.internal.ej.C1834a;

@ez
public final class en extends C0333g<ej> {
    private static final en sK;

    /* renamed from: com.google.android.gms.internal.en.a */
    private static final class C0470a extends Exception {
        public C0470a(String str) {
            super(str);
        }
    }

    static {
        sK = new en();
    }

    private en() {
        super("com.google.android.gms.ads.InAppPurchaseManagerCreatorImpl");
    }

    private static boolean m3131c(Activity activity) throws C0470a {
        Intent intent = activity.getIntent();
        if (intent.hasExtra("com.google.android.gms.ads.internal.purchase.useClientJar")) {
            return intent.getBooleanExtra("com.google.android.gms.ads.internal.purchase.useClientJar", false);
        }
        throw new C0470a("InAppPurchaseManager requires the useClientJar flag in intent extras.");
    }

    public static ei m3132e(Activity activity) {
        try {
            if (!m3131c(activity)) {
                return sK.m3133f(activity);
            }
            gs.m1408S("Using AdOverlay from the client jar.");
            return new dz(activity);
        } catch (C0470a e) {
            gs.m1412W(e.getMessage());
            return null;
        }
    }

    private ei m3133f(Activity activity) {
        try {
            return C1832a.m3125u(((ej) m594L(activity)).m1243b(C2413e.m3897k(activity)));
        } catch (Throwable e) {
            gs.m1416d("Could not create remote InAppPurchaseManager.", e);
            return null;
        } catch (Throwable e2) {
            gs.m1416d("Could not create remote InAppPurchaseManager.", e2);
            return null;
        }
    }

    protected /* synthetic */ Object m3134d(IBinder iBinder) {
        return m3135y(iBinder);
    }

    protected ej m3135y(IBinder iBinder) {
        return C1834a.m3127v(iBinder);
    }
}
