package com.google.android.gms.internal;

import android.os.SystemClock;
import org.json.JSONObject;

public final class it {
    private static final ip Gr;
    public static final Object Hz;
    private long Hv;
    private long Hw;
    private long Hx;
    private is Hy;

    static {
        Gr = new ip("RequestTracker");
        Hz = new Object();
    }

    public it(long j) {
        this.Hv = j;
        this.Hw = -1;
        this.Hx = 0;
    }

    private void fU() {
        this.Hw = -1;
        this.Hy = null;
        this.Hx = 0;
    }

    public void m1541a(long j, is isVar) {
        synchronized (Hz) {
            is isVar2 = this.Hy;
            long j2 = this.Hw;
            this.Hw = j;
            this.Hy = isVar;
            this.Hx = SystemClock.elapsedRealtime();
        }
        if (isVar2 != null) {
            isVar2.m1540n(j2);
        }
    }

    public boolean m1542b(long j, int i, JSONObject jSONObject) {
        boolean z = true;
        is isVar = null;
        synchronized (Hz) {
            if (this.Hw == -1 || this.Hw != j) {
                z = false;
            } else {
                Gr.m1535b("request %d completed", Long.valueOf(this.Hw));
                isVar = this.Hy;
                fU();
            }
        }
        if (isVar != null) {
            isVar.m1539a(j, i, jSONObject);
        }
        return z;
    }

    public void clear() {
        synchronized (Hz) {
            if (this.Hw != -1) {
                fU();
            }
        }
    }

    public boolean m1543d(long j, int i) {
        return m1542b(j, i, null);
    }

    public boolean m1544e(long j, int i) {
        is isVar;
        boolean z = true;
        long j2 = 0;
        synchronized (Hz) {
            if (this.Hw == -1 || j - this.Hx < this.Hv) {
                z = false;
                isVar = null;
            } else {
                Gr.m1535b("request %d timed out", Long.valueOf(this.Hw));
                j2 = this.Hw;
                isVar = this.Hy;
                fU();
            }
        }
        if (isVar != null) {
            isVar.m1539a(j2, i, null);
        }
        return z;
    }

    public boolean fV() {
        boolean z;
        synchronized (Hz) {
            z = this.Hw != -1;
        }
        return z;
    }

    public boolean m1545p(long j) {
        boolean z;
        synchronized (Hz) {
            z = this.Hw != -1 && this.Hw == j;
        }
        return z;
    }
}
