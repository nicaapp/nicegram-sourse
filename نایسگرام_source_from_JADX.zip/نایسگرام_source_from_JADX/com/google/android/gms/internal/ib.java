package com.google.android.gms.internal;

import android.content.Context;
import android.os.IBinder;
import android.os.IInterface;
import android.os.Looper;
import android.os.RemoteException;
import android.util.Log;
import com.google.android.gms.appstate.AppStateBuffer;
import com.google.android.gms.appstate.AppStateManager.StateConflictResult;
import com.google.android.gms.appstate.AppStateManager.StateDeletedResult;
import com.google.android.gms.appstate.AppStateManager.StateListResult;
import com.google.android.gms.appstate.AppStateManager.StateLoadedResult;
import com.google.android.gms.appstate.AppStateManager.StateResult;
import com.google.android.gms.common.GooglePlayServicesUtil;
import com.google.android.gms.common.Scopes;
import com.google.android.gms.common.api.BaseImplementation.C0191b;
import com.google.android.gms.common.api.C1686a;
import com.google.android.gms.common.api.GoogleApiClient.ConnectionCallbacks;
import com.google.android.gms.common.api.GoogleApiClient.OnConnectionFailedListener;
import com.google.android.gms.common.api.Status;
import com.google.android.gms.common.data.DataHolder;
import com.google.android.gms.common.internal.C0232k;
import com.google.android.gms.common.internal.C0233l;
import com.google.android.gms.common.internal.C0238o;
import com.google.android.gms.common.internal.C1702e;
import com.google.android.gms.common.internal.C1702e.C2386e;
import com.google.android.gms.games.GamesStatusCodes;
import com.google.android.gms.internal.id.C1880a;

public final class ib extends C1702e<id> {
    private final String Dd;

    /* renamed from: com.google.android.gms.internal.ib.b */
    private static final class C2473b implements StateDeletedResult {
        private final Status CM;
        private final int Df;

        public C2473b(Status status, int i) {
            this.CM = status;
            this.Df = i;
        }

        public int getStateKey() {
            return this.Df;
        }

        public Status getStatus() {
            return this.CM;
        }
    }

    /* renamed from: com.google.android.gms.internal.ib.d */
    private static final class C2474d extends C1686a implements StateListResult {
        private final AppStateBuffer Dg;

        public C2474d(DataHolder dataHolder) {
            super(dataHolder);
            this.Dg = new AppStateBuffer(dataHolder);
        }

        public AppStateBuffer getStateBuffer() {
            return this.Dg;
        }
    }

    /* renamed from: com.google.android.gms.internal.ib.f */
    private static final class C2475f extends C1686a implements StateConflictResult, StateLoadedResult, StateResult {
        private final int Df;
        private final AppStateBuffer Dg;

        public C2475f(int i, DataHolder dataHolder) {
            super(dataHolder);
            this.Df = i;
            this.Dg = new AppStateBuffer(dataHolder);
        }

        private boolean fs() {
            return this.CM.getStatusCode() == GamesStatusCodes.STATUS_REQUEST_UPDATE_PARTIAL_SUCCESS;
        }

        public StateConflictResult getConflictResult() {
            return fs() ? this : null;
        }

        public StateLoadedResult getLoadedResult() {
            return fs() ? null : this;
        }

        public byte[] getLocalData() {
            return this.Dg.getCount() == 0 ? null : this.Dg.get(0).getLocalData();
        }

        public String getResolvedVersion() {
            return this.Dg.getCount() == 0 ? null : this.Dg.get(0).getConflictVersion();
        }

        public byte[] getServerData() {
            return this.Dg.getCount() == 0 ? null : this.Dg.get(0).getConflictData();
        }

        public int getStateKey() {
            return this.Df;
        }

        public void release() {
            this.Dg.close();
        }
    }

    /* renamed from: com.google.android.gms.internal.ib.a */
    private static final class C2614a extends ia {
        private final C0191b<StateDeletedResult> De;

        public C2614a(C0191b<StateDeletedResult> c0191b) {
            this.De = (C0191b) C0238o.m279b((Object) c0191b, (Object) "Result holder must not be null");
        }

        public void m4781e(int i, int i2) {
            this.De.m147b(new C2473b(new Status(i), i2));
        }
    }

    /* renamed from: com.google.android.gms.internal.ib.c */
    private static final class C2615c extends ia {
        private final C0191b<StateListResult> De;

        public C2615c(C0191b<StateListResult> c0191b) {
            this.De = (C0191b) C0238o.m279b((Object) c0191b, (Object) "Result holder must not be null");
        }

        public void m4782a(DataHolder dataHolder) {
            this.De.m147b(new C2474d(dataHolder));
        }
    }

    /* renamed from: com.google.android.gms.internal.ib.e */
    private static final class C2616e extends ia {
        private final C0191b<StateResult> De;

        public C2616e(C0191b<StateResult> c0191b) {
            this.De = (C0191b) C0238o.m279b((Object) c0191b, (Object) "Result holder must not be null");
        }

        public void m4783a(int i, DataHolder dataHolder) {
            this.De.m147b(new C2475f(i, dataHolder));
        }
    }

    /* renamed from: com.google.android.gms.internal.ib.g */
    private static final class C2617g extends ia {
        private final C0191b<Status> De;

        public C2617g(C0191b<Status> c0191b) {
            this.De = (C0191b) C0238o.m279b((Object) c0191b, (Object) "Holder must not be null");
        }

        public void fp() {
            this.De.m147b(new Status(0));
        }
    }

    public ib(Context context, Looper looper, ConnectionCallbacks connectionCallbacks, OnConnectionFailedListener onConnectionFailedListener, String str, String[] strArr) {
        super(context, looper, connectionCallbacks, onConnectionFailedListener, strArr);
        this.Dd = (String) C0238o.m283i(str);
    }

    protected id m4276I(IBinder iBinder) {
        return C1880a.m3259K(iBinder);
    }

    public void m4277a(C0191b<StateListResult> c0191b) {
        try {
            ((id) gS()).m1498a(new C2615c(c0191b));
        } catch (RemoteException e) {
            Log.w("AppStateClient", "service died");
        }
    }

    public void m4278a(C0191b<StateDeletedResult> c0191b, int i) {
        try {
            ((id) gS()).m1503b(new C2614a(c0191b), i);
        } catch (RemoteException e) {
            Log.w("AppStateClient", "service died");
        }
    }

    public void m4279a(C0191b<StateResult> c0191b, int i, String str, byte[] bArr) {
        try {
            ((id) gS()).m1500a(new C2616e(c0191b), i, str, bArr);
        } catch (RemoteException e) {
            Log.w("AppStateClient", "service died");
        }
    }

    public void m4280a(C0191b<StateResult> c0191b, int i, byte[] bArr) {
        if (c0191b == null) {
            ic icVar = null;
        } else {
            Object c2616e = new C2616e(c0191b);
        }
        try {
            ((id) gS()).m1501a(icVar, i, bArr);
        } catch (RemoteException e) {
            Log.w("AppStateClient", "service died");
        }
    }

    protected void m4281a(C0233l c0233l, C2386e c2386e) throws RemoteException {
        c0233l.m237a((C0232k) c2386e, (int) GooglePlayServicesUtil.GOOGLE_PLAY_SERVICES_VERSION_CODE, getContext().getPackageName(), this.Dd, gR());
    }

    public void m4282b(C0191b<Status> c0191b) {
        try {
            ((id) gS()).m1502b(new C2617g(c0191b));
        } catch (RemoteException e) {
            Log.w("AppStateClient", "service died");
        }
    }

    public void m4283b(C0191b<StateResult> c0191b, int i) {
        try {
            ((id) gS()).m1499a(new C2616e(c0191b), i);
        } catch (RemoteException e) {
            Log.w("AppStateClient", "service died");
        }
    }

    protected void m4284c(String... strArr) {
        boolean z = false;
        for (String equals : strArr) {
            if (equals.equals(Scopes.APP_STATE)) {
                z = true;
            }
        }
        C0238o.m277a(z, String.format("App State APIs requires %s to function.", new Object[]{Scopes.APP_STATE}));
    }

    public int fq() {
        try {
            return ((id) gS()).fq();
        } catch (RemoteException e) {
            Log.w("AppStateClient", "service died");
            return 2;
        }
    }

    public int fr() {
        try {
            return ((id) gS()).fr();
        } catch (RemoteException e) {
            Log.w("AppStateClient", "service died");
            return 2;
        }
    }

    protected String getServiceDescriptor() {
        return "com.google.android.gms.appstate.internal.IAppStateService";
    }

    protected String getStartServiceAction() {
        return "com.google.android.gms.appstate.service.START";
    }

    protected /* synthetic */ IInterface m4285j(IBinder iBinder) {
        return m4276I(iBinder);
    }
}
