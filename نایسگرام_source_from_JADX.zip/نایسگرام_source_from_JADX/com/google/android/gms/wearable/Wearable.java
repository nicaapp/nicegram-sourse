package com.google.android.gms.wearable;

import android.content.Context;
import android.os.Looper;
import com.google.android.gms.common.api.Api;
import com.google.android.gms.common.api.Api.ApiOptions.Optional;
import com.google.android.gms.common.api.Api.C0189b;
import com.google.android.gms.common.api.Api.C0190c;
import com.google.android.gms.common.api.GoogleApiClient.ConnectionCallbacks;
import com.google.android.gms.common.api.GoogleApiClient.OnConnectionFailedListener;
import com.google.android.gms.common.api.Scope;
import com.google.android.gms.common.internal.ClientSettings;
import com.google.android.gms.wearable.internal.C2136e;
import com.google.android.gms.wearable.internal.C2137f;
import com.google.android.gms.wearable.internal.ag;
import com.google.android.gms.wearable.internal.aj;
import com.google.android.gms.wearable.internal.aw;
import org.telegram.messenger.ConnectionsManager;

public class Wearable {
    public static final Api<WearableOptions> API;
    public static final C0190c<aw> CU;
    private static final C0189b<aw, WearableOptions> CV;
    public static final DataApi DataApi;
    public static final MessageApi MessageApi;
    public static final NodeApi NodeApi;
    public static final C0736b avb;

    /* renamed from: com.google.android.gms.wearable.Wearable.1 */
    static class C21271 implements C0189b<aw, WearableOptions> {
        C21271() {
        }

        public aw m3743a(Context context, Looper looper, ClientSettings clientSettings, WearableOptions wearableOptions, ConnectionCallbacks connectionCallbacks, OnConnectionFailedListener onConnectionFailedListener) {
            if (wearableOptions == null) {
                WearableOptions wearableOptions2 = new WearableOptions(null);
            }
            return new aw(context, looper, connectionCallbacks, onConnectionFailedListener);
        }

        public int getPriority() {
            return ConnectionsManager.DEFAULT_DATACENTER_ID;
        }
    }

    public static final class WearableOptions implements Optional {

        public static class Builder {
            public WearableOptions build() {
                return new WearableOptions();
            }
        }

        private WearableOptions(Builder builder) {
        }
    }

    static {
        DataApi = new C2137f();
        MessageApi = new ag();
        NodeApi = new aj();
        avb = new C2136e();
        CU = new C0190c();
        CV = new C21271();
        API = new Api(CV, CU, new Scope[0]);
    }

    private Wearable() {
    }
}
