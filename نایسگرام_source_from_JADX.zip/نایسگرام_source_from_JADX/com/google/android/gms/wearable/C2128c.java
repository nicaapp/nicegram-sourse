package com.google.android.gms.wearable;

import android.os.Parcel;
import android.os.Parcelable.Creator;
import com.google.android.gms.common.internal.C0237n;
import com.google.android.gms.common.internal.safeparcel.SafeParcelable;

/* renamed from: com.google.android.gms.wearable.c */
public class C2128c implements SafeParcelable {
    public static final Creator<C2128c> CREATOR;
    final int BR;
    private final int FD;
    private final String Sz;
    private final int auS;
    private final boolean auT;
    private boolean auU;
    private String auV;
    private final String mName;

    static {
        CREATOR = new C0737d();
    }

    C2128c(int i, String str, String str2, int i2, int i3, boolean z, boolean z2, String str3) {
        this.BR = i;
        this.mName = str;
        this.Sz = str2;
        this.FD = i2;
        this.auS = i3;
        this.auT = z;
        this.auU = z2;
        this.auV = str3;
    }

    public int describeContents() {
        return 0;
    }

    public boolean equals(Object o) {
        if (!(o instanceof C2128c)) {
            return false;
        }
        C2128c c2128c = (C2128c) o;
        return C0237n.equal(Integer.valueOf(this.BR), Integer.valueOf(c2128c.BR)) && C0237n.equal(this.mName, c2128c.mName) && C0237n.equal(this.Sz, c2128c.Sz) && C0237n.equal(Integer.valueOf(this.FD), Integer.valueOf(c2128c.FD)) && C0237n.equal(Integer.valueOf(this.auS), Integer.valueOf(c2128c.auS)) && C0237n.equal(Boolean.valueOf(this.auT), Boolean.valueOf(c2128c.auT));
    }

    public String getAddress() {
        return this.Sz;
    }

    public String getName() {
        return this.mName;
    }

    public int getRole() {
        return this.auS;
    }

    public int getType() {
        return this.FD;
    }

    public int hashCode() {
        return C0237n.hashCode(Integer.valueOf(this.BR), this.mName, this.Sz, Integer.valueOf(this.FD), Integer.valueOf(this.auS), Boolean.valueOf(this.auT));
    }

    public boolean isConnected() {
        return this.auU;
    }

    public boolean isEnabled() {
        return this.auT;
    }

    public String pS() {
        return this.auV;
    }

    public String toString() {
        StringBuilder stringBuilder = new StringBuilder("ConnectionConfiguration[ ");
        stringBuilder.append("mName=" + this.mName);
        stringBuilder.append(", mAddress=" + this.Sz);
        stringBuilder.append(", mType=" + this.FD);
        stringBuilder.append(", mRole=" + this.auS);
        stringBuilder.append(", mEnabled=" + this.auT);
        stringBuilder.append(", mIsConnected=" + this.auU);
        stringBuilder.append(", mEnabled=" + this.auV);
        stringBuilder.append("]");
        return stringBuilder.toString();
    }

    public void writeToParcel(Parcel dest, int flags) {
        C0737d.m2209a(this, dest, flags);
    }
}
