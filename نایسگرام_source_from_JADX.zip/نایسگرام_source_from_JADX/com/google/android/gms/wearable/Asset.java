package com.google.android.gms.wearable;

import android.net.Uri;
import android.os.Parcel;
import android.os.ParcelFileDescriptor;
import android.os.Parcelable.Creator;
import com.google.android.gms.common.internal.C0237n;
import com.google.android.gms.common.internal.safeparcel.SafeParcelable;

public class Asset implements SafeParcelable {
    public static final Creator<Asset> CREATOR;
    final int BR;
    private byte[] acH;
    private String auQ;
    public ParcelFileDescriptor auR;
    public Uri uri;

    static {
        CREATOR = new C0735a();
    }

    Asset(int versionCode, byte[] data, String digest, ParcelFileDescriptor fd, Uri uri) {
        this.BR = versionCode;
        this.acH = data;
        this.auQ = digest;
        this.auR = fd;
        this.uri = uri;
    }

    public static Asset createFromBytes(byte[] assetData) {
        if (assetData != null) {
            return new Asset(1, assetData, null, null, null);
        }
        throw new IllegalArgumentException("Asset data cannot be null");
    }

    public static Asset createFromFd(ParcelFileDescriptor fd) {
        if (fd != null) {
            return new Asset(1, null, null, fd, null);
        }
        throw new IllegalArgumentException("Asset fd cannot be null");
    }

    public static Asset createFromRef(String digest) {
        if (digest != null) {
            return new Asset(1, null, digest, null, null);
        }
        throw new IllegalArgumentException("Asset digest cannot be null");
    }

    public static Asset createFromUri(Uri uri) {
        if (uri != null) {
            return new Asset(1, null, null, null, uri);
        }
        throw new IllegalArgumentException("Asset uri cannot be null");
    }

    public int describeContents() {
        return 0;
    }

    public boolean equals(Object o) {
        if (this == o) {
            return true;
        }
        if (!(o instanceof Asset)) {
            return false;
        }
        Asset asset = (Asset) o;
        return C0237n.equal(this.acH, asset.acH) && C0237n.equal(this.auQ, asset.auQ) && C0237n.equal(this.auR, asset.auR) && C0237n.equal(this.uri, asset.uri);
    }

    public byte[] getData() {
        return this.acH;
    }

    public String getDigest() {
        return this.auQ;
    }

    public ParcelFileDescriptor getFd() {
        return this.auR;
    }

    public Uri getUri() {
        return this.uri;
    }

    public int hashCode() {
        return C0237n.hashCode(this.acH, this.auQ, this.auR, this.uri);
    }

    public String toString() {
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append("Asset[@");
        stringBuilder.append(Integer.toHexString(hashCode()));
        if (this.auQ == null) {
            stringBuilder.append(", nodigest");
        } else {
            stringBuilder.append(", ");
            stringBuilder.append(this.auQ);
        }
        if (this.acH != null) {
            stringBuilder.append(", size=");
            stringBuilder.append(this.acH.length);
        }
        if (this.auR != null) {
            stringBuilder.append(", fd=");
            stringBuilder.append(this.auR);
        }
        if (this.uri != null) {
            stringBuilder.append(", uri=");
            stringBuilder.append(this.uri);
        }
        stringBuilder.append("]");
        return stringBuilder.toString();
    }

    public void writeToParcel(Parcel dest, int flags) {
        C0735a.m2208a(this, dest, flags | 1);
    }
}
