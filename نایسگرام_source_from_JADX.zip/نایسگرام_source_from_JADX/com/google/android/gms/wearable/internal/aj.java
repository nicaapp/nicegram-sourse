package com.google.android.gms.wearable.internal;

import android.os.RemoteException;
import com.google.android.gms.common.api.BaseImplementation.C0191b;
import com.google.android.gms.common.api.GoogleApiClient;
import com.google.android.gms.common.api.PendingResult;
import com.google.android.gms.common.api.Result;
import com.google.android.gms.common.api.Status;
import com.google.android.gms.wearable.Node;
import com.google.android.gms.wearable.NodeApi;
import com.google.android.gms.wearable.NodeApi.GetConnectedNodesResult;
import com.google.android.gms.wearable.NodeApi.GetLocalNodeResult;
import com.google.android.gms.wearable.NodeApi.NodeListener;
import java.util.List;

public final class aj implements NodeApi {

    /* renamed from: com.google.android.gms.wearable.internal.aj.a */
    public static class C2545a implements GetConnectedNodesResult {
        private final Status CM;
        private final List<Node> avL;

        public C2545a(Status status, List<Node> list) {
            this.CM = status;
            this.avL = list;
        }

        public List<Node> getNodes() {
            return this.avL;
        }

        public Status getStatus() {
            return this.CM;
        }
    }

    /* renamed from: com.google.android.gms.wearable.internal.aj.b */
    public static class C2546b implements GetLocalNodeResult {
        private final Status CM;
        private final Node avM;

        public C2546b(Status status, Node node) {
            this.CM = status;
            this.avM = node;
        }

        public Node getNode() {
            return this.avM;
        }

        public Status getStatus() {
            return this.CM;
        }
    }

    /* renamed from: com.google.android.gms.wearable.internal.aj.1 */
    class C27021 extends C2648d<GetLocalNodeResult> {
        final /* synthetic */ aj avJ;

        C27021(aj ajVar) {
            this.avJ = ajVar;
        }

        protected void m5017a(aw awVar) throws RemoteException {
            awVar.m4595p(this);
        }

        protected GetLocalNodeResult aK(Status status) {
            return new C2546b(status, null);
        }

        protected /* synthetic */ Result m5018c(Status status) {
            return aK(status);
        }
    }

    /* renamed from: com.google.android.gms.wearable.internal.aj.2 */
    class C27032 extends C2648d<GetConnectedNodesResult> {
        final /* synthetic */ aj avJ;

        C27032(aj ajVar) {
            this.avJ = ajVar;
        }

        protected void m5020a(aw awVar) throws RemoteException {
            awVar.m4596q(this);
        }

        protected GetConnectedNodesResult aL(Status status) {
            return new C2545a(status, null);
        }

        protected /* synthetic */ Result m5021c(Status status) {
            return aL(status);
        }
    }

    /* renamed from: com.google.android.gms.wearable.internal.aj.3 */
    class C27043 extends C2648d<Status> {
        final /* synthetic */ aj avJ;
        final /* synthetic */ NodeListener avK;

        C27043(aj ajVar, NodeListener nodeListener) {
            this.avJ = ajVar;
            this.avK = nodeListener;
        }

        protected void m5023a(aw awVar) throws RemoteException {
            awVar.m4585a((C0191b) this, this.avK);
        }

        public /* synthetic */ Result m5024c(Status status) {
            return m5025d(status);
        }

        public Status m5025d(Status status) {
            return new Status(13);
        }
    }

    /* renamed from: com.google.android.gms.wearable.internal.aj.4 */
    class C27054 extends C2648d<Status> {
        final /* synthetic */ aj avJ;
        final /* synthetic */ NodeListener avK;

        C27054(aj ajVar, NodeListener nodeListener) {
            this.avJ = ajVar;
            this.avK = nodeListener;
        }

        protected void m5027a(aw awVar) throws RemoteException {
            awVar.m4591b((C0191b) this, this.avK);
        }

        public /* synthetic */ Result m5028c(Status status) {
            return m5029d(status);
        }

        public Status m5029d(Status status) {
            return new Status(13);
        }
    }

    public PendingResult<Status> addListener(GoogleApiClient client, NodeListener listener) {
        return client.m150a(new C27043(this, listener));
    }

    public PendingResult<GetConnectedNodesResult> getConnectedNodes(GoogleApiClient client) {
        return client.m150a(new C27032(this));
    }

    public PendingResult<GetLocalNodeResult> getLocalNode(GoogleApiClient client) {
        return client.m150a(new C27021(this));
    }

    public PendingResult<Status> removeListener(GoogleApiClient client, NodeListener listener) {
        return client.m150a(new C27054(this, listener));
    }
}
