package com.google.android.gms.wearable.internal;

import android.os.Parcel;
import android.os.Parcelable.Creator;
import com.google.android.gms.common.internal.safeparcel.C0242a;
import com.google.android.gms.common.internal.safeparcel.C0242a.C0241a;
import com.google.android.gms.common.internal.safeparcel.C0243b;
import com.google.android.gms.drive.events.CompletionEvent;
import com.google.android.gms.wearable.C2128c;
import org.telegram.android.time.FastDatePrinter;

/* renamed from: com.google.android.gms.wearable.internal.u */
public class C0745u implements Creator<C2140t> {
    static void m2262a(C2140t c2140t, Parcel parcel, int i) {
        int D = C0243b.m329D(parcel);
        C0243b.m356c(parcel, 1, c2140t.versionCode);
        C0243b.m356c(parcel, 2, c2140t.statusCode);
        C0243b.m350a(parcel, 3, c2140t.avy, i, false);
        C0243b.m332H(parcel, D);
    }

    public /* synthetic */ Object createFromParcel(Parcel x0) {
        return dX(x0);
    }

    public C2140t dX(Parcel parcel) {
        int i = 0;
        int C = C0242a.m293C(parcel);
        C2128c[] c2128cArr = null;
        int i2 = 0;
        while (parcel.dataPosition() < C) {
            int B = C0242a.m291B(parcel);
            switch (C0242a.aD(B)) {
                case CompletionEvent.STATUS_FAILURE /*1*/:
                    i2 = C0242a.m309g(parcel, B);
                    break;
                case CompletionEvent.STATUS_CONFLICT /*2*/:
                    i = C0242a.m309g(parcel, B);
                    break;
                case FastDatePrinter.SHORT /*3*/:
                    c2128cArr = (C2128c[]) C0242a.m303b(parcel, B, C2128c.CREATOR);
                    break;
                default:
                    C0242a.m302b(parcel, B);
                    break;
            }
        }
        if (parcel.dataPosition() == C) {
            return new C2140t(i2, i, c2128cArr);
        }
        throw new C0241a("Overread allowed size end=" + C, parcel);
    }

    public C2140t[] ga(int i) {
        return new C2140t[i];
    }

    public /* synthetic */ Object[] newArray(int x0) {
        return ga(x0);
    }
}
