package com.google.android.gms.wearable.internal;

import com.google.android.gms.wearable.C0736b;

/* renamed from: com.google.android.gms.wearable.internal.e */
public final class C2136e implements C0736b {
}
