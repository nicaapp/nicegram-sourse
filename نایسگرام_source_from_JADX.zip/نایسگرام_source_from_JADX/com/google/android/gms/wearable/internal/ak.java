package com.google.android.gms.wearable.internal;

import android.os.Parcel;
import android.os.Parcelable.Creator;
import com.google.android.gms.common.internal.safeparcel.SafeParcelable;
import com.google.android.gms.wearable.Node;

public class ak implements SafeParcelable, Node {
    public static final Creator<ak> CREATOR;
    private final String BL;
    final int BR;
    private final String NH;

    static {
        CREATOR = new al();
    }

    ak(int i, String str, String str2) {
        this.BR = i;
        this.BL = str;
        this.NH = str2;
    }

    public int describeContents() {
        return 0;
    }

    public boolean equals(Object o) {
        if (!(o instanceof ak)) {
            return false;
        }
        ak akVar = (ak) o;
        return akVar.BL.equals(this.BL) && akVar.NH.equals(this.NH);
    }

    public String getDisplayName() {
        return this.NH;
    }

    public String getId() {
        return this.BL;
    }

    public int hashCode() {
        return ((this.BL.hashCode() + 629) * 37) + this.NH.hashCode();
    }

    public String toString() {
        return "NodeParcelable{" + this.BL + "," + this.NH + "}";
    }

    public void writeToParcel(Parcel dest, int flags) {
        al.m2251a(this, dest, flags);
    }
}
