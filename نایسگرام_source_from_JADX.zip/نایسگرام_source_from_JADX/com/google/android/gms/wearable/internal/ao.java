package com.google.android.gms.wearable.internal;

import android.os.Parcel;
import android.os.Parcelable.Creator;
import com.google.android.gms.common.internal.safeparcel.SafeParcelable;

public class ao implements SafeParcelable {
    public static final Creator<ao> CREATOR;
    public final C2555m avA;
    public final int statusCode;
    public final int versionCode;

    static {
        CREATOR = new ap();
    }

    ao(int i, int i2, C2555m c2555m) {
        this.versionCode = i;
        this.statusCode = i2;
        this.avA = c2555m;
    }

    public int describeContents() {
        return 0;
    }

    public void writeToParcel(Parcel dest, int flags) {
        ap.m2253a(this, dest, flags);
    }
}
