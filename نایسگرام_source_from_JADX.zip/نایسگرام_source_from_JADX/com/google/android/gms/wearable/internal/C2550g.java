package com.google.android.gms.wearable.internal;

import com.google.android.gms.wearable.DataEvent;
import com.google.android.gms.wearable.DataItem;

/* renamed from: com.google.android.gms.wearable.internal.g */
public class C2550g implements DataEvent {
    private int FD;
    private DataItem avs;

    public C2550g(DataEvent dataEvent) {
        this.FD = dataEvent.getType();
        this.avs = (DataItem) dataEvent.getDataItem().freeze();
    }

    public /* synthetic */ Object freeze() {
        return pW();
    }

    public DataItem getDataItem() {
        return this.avs;
    }

    public int getType() {
        return this.FD;
    }

    public boolean isDataValid() {
        return true;
    }

    public DataEvent pW() {
        return this;
    }
}
