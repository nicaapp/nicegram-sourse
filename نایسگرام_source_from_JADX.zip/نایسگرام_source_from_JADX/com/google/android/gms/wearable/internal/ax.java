package com.google.android.gms.wearable.internal;

import android.content.IntentFilter;
import com.google.android.gms.common.data.DataHolder;
import com.google.android.gms.wearable.DataApi.DataListener;
import com.google.android.gms.wearable.DataEventBuffer;
import com.google.android.gms.wearable.MessageApi.MessageListener;
import com.google.android.gms.wearable.NodeApi.NodeListener;
import com.google.android.gms.wearable.internal.ae.C2132a;

public class ax extends C2132a {
    private final DataListener avX;
    private final MessageListener avY;
    private final NodeListener avZ;
    private final IntentFilter[] awa;

    public ax(DataListener dataListener, MessageListener messageListener, NodeListener nodeListener, IntentFilter[] intentFilterArr) {
        this.avX = dataListener;
        this.avY = messageListener;
        this.avZ = nodeListener;
        this.awa = intentFilterArr;
    }

    public static ax m4597a(DataListener dataListener, IntentFilter[] intentFilterArr) {
        return new ax(dataListener, null, null, intentFilterArr);
    }

    public static ax m4598a(MessageListener messageListener, IntentFilter[] intentFilterArr) {
        return new ax(null, messageListener, null, intentFilterArr);
    }

    public static ax m4599a(NodeListener nodeListener) {
        return new ax(null, null, nodeListener, null);
    }

    public void m4600Z(DataHolder dataHolder) {
        if (this.avX != null) {
            try {
                this.avX.onDataChanged(new DataEventBuffer(dataHolder));
            } finally {
                dataHolder.close();
            }
        } else {
            dataHolder.close();
        }
    }

    public void m4601a(ah ahVar) {
        if (this.avY != null) {
            this.avY.onMessageReceived(ahVar);
        }
    }

    public void m4602a(ak akVar) {
        if (this.avZ != null) {
            this.avZ.onPeerConnected(akVar);
        }
    }

    public void m4603b(ak akVar) {
        if (this.avZ != null) {
            this.avZ.onPeerDisconnected(akVar);
        }
    }

    public IntentFilter[] qb() {
        return this.awa;
    }
}
