package com.google.android.gms.wearable.internal;

import android.content.IntentFilter;
import android.net.Uri;
import android.os.ParcelFileDescriptor;
import android.os.ParcelFileDescriptor.AutoCloseInputStream;
import android.os.RemoteException;
import com.google.android.gms.common.api.BaseImplementation.C0191b;
import com.google.android.gms.common.api.GoogleApiClient;
import com.google.android.gms.common.api.PendingResult;
import com.google.android.gms.common.api.Result;
import com.google.android.gms.common.api.Status;
import com.google.android.gms.common.data.DataHolder;
import com.google.android.gms.wearable.Asset;
import com.google.android.gms.wearable.DataApi;
import com.google.android.gms.wearable.DataApi.DataItemResult;
import com.google.android.gms.wearable.DataApi.DataListener;
import com.google.android.gms.wearable.DataApi.DeleteDataItemsResult;
import com.google.android.gms.wearable.DataApi.GetFdForAssetResult;
import com.google.android.gms.wearable.DataItem;
import com.google.android.gms.wearable.DataItemAsset;
import com.google.android.gms.wearable.DataItemBuffer;
import com.google.android.gms.wearable.PutDataRequest;
import java.io.IOException;
import java.io.InputStream;

/* renamed from: com.google.android.gms.wearable.internal.f */
public final class C2137f implements DataApi {

    /* renamed from: com.google.android.gms.wearable.internal.f.a */
    public static class C2547a implements DataItemResult {
        private final Status CM;
        private final DataItem avs;

        public C2547a(Status status, DataItem dataItem) {
            this.CM = status;
            this.avs = dataItem;
        }

        public DataItem getDataItem() {
            return this.avs;
        }

        public Status getStatus() {
            return this.CM;
        }
    }

    /* renamed from: com.google.android.gms.wearable.internal.f.b */
    public static class C2548b implements DeleteDataItemsResult {
        private final Status CM;
        private final int avt;

        public C2548b(Status status, int i) {
            this.CM = status;
            this.avt = i;
        }

        public int getNumDeleted() {
            return this.avt;
        }

        public Status getStatus() {
            return this.CM;
        }
    }

    /* renamed from: com.google.android.gms.wearable.internal.f.c */
    public static class C2549c implements GetFdForAssetResult {
        private final Status CM;
        private volatile InputStream XX;
        private volatile ParcelFileDescriptor avu;
        private volatile boolean mClosed;

        public C2549c(Status status, ParcelFileDescriptor parcelFileDescriptor) {
            this.mClosed = false;
            this.CM = status;
            this.avu = parcelFileDescriptor;
        }

        public ParcelFileDescriptor getFd() {
            if (!this.mClosed) {
                return this.avu;
            }
            throw new IllegalStateException("Cannot access the file descriptor after release().");
        }

        public InputStream getInputStream() {
            if (this.mClosed) {
                throw new IllegalStateException("Cannot access the input stream after release().");
            } else if (this.avu == null) {
                return null;
            } else {
                if (this.XX == null) {
                    this.XX = new AutoCloseInputStream(this.avu);
                }
                return this.XX;
            }
        }

        public Status getStatus() {
            return this.CM;
        }

        public void release() {
            if (this.avu != null) {
                if (this.mClosed) {
                    throw new IllegalStateException("releasing an already released result.");
                }
                try {
                    if (this.XX != null) {
                        this.XX.close();
                    } else {
                        this.avu.close();
                    }
                    this.mClosed = true;
                    this.avu = null;
                    this.XX = null;
                } catch (IOException e) {
                }
            }
        }
    }

    /* renamed from: com.google.android.gms.wearable.internal.f.1 */
    class C27061 extends C2648d<DataItemResult> {
        final /* synthetic */ PutDataRequest avm;
        final /* synthetic */ C2137f avn;

        C27061(C2137f c2137f, PutDataRequest putDataRequest) {
            this.avn = c2137f;
            this.avm = putDataRequest;
        }

        protected void m5031a(aw awVar) throws RemoteException {
            awVar.m4586a((C0191b) this, this.avm);
        }

        public DataItemResult aF(Status status) {
            return new C2547a(status, null);
        }

        public /* synthetic */ Result m5032c(Status status) {
            return aF(status);
        }
    }

    /* renamed from: com.google.android.gms.wearable.internal.f.2 */
    class C27072 extends C2648d<DataItemResult> {
        final /* synthetic */ Uri aky;
        final /* synthetic */ C2137f avn;

        C27072(C2137f c2137f, Uri uri) {
            this.avn = c2137f;
            this.aky = uri;
        }

        protected void m5034a(aw awVar) throws RemoteException {
            awVar.m4578a((C0191b) this, this.aky);
        }

        protected DataItemResult aF(Status status) {
            return new C2547a(status, null);
        }

        protected /* synthetic */ Result m5035c(Status status) {
            return aF(status);
        }
    }

    /* renamed from: com.google.android.gms.wearable.internal.f.3 */
    class C27083 extends C2648d<DataItemBuffer> {
        final /* synthetic */ C2137f avn;

        C27083(C2137f c2137f) {
            this.avn = c2137f;
        }

        protected void m5037a(aw awVar) throws RemoteException {
            awVar.m4594o(this);
        }

        protected DataItemBuffer aG(Status status) {
            return new DataItemBuffer(DataHolder.as(status.getStatusCode()));
        }

        protected /* synthetic */ Result m5038c(Status status) {
            return aG(status);
        }
    }

    /* renamed from: com.google.android.gms.wearable.internal.f.4 */
    class C27094 extends C2648d<DataItemBuffer> {
        final /* synthetic */ Uri aky;
        final /* synthetic */ C2137f avn;

        C27094(C2137f c2137f, Uri uri) {
            this.avn = c2137f;
            this.aky = uri;
        }

        protected void m5040a(aw awVar) throws RemoteException {
            awVar.m4590b((C0191b) this, this.aky);
        }

        protected DataItemBuffer aG(Status status) {
            return new DataItemBuffer(DataHolder.as(status.getStatusCode()));
        }

        protected /* synthetic */ Result m5041c(Status status) {
            return aG(status);
        }
    }

    /* renamed from: com.google.android.gms.wearable.internal.f.5 */
    class C27105 extends C2648d<DeleteDataItemsResult> {
        final /* synthetic */ Uri aky;
        final /* synthetic */ C2137f avn;

        C27105(C2137f c2137f, Uri uri) {
            this.avn = c2137f;
            this.aky = uri;
        }

        protected void m5043a(aw awVar) throws RemoteException {
            awVar.m4592c(this, this.aky);
        }

        protected DeleteDataItemsResult aH(Status status) {
            return new C2548b(status, 0);
        }

        protected /* synthetic */ Result m5044c(Status status) {
            return aH(status);
        }
    }

    /* renamed from: com.google.android.gms.wearable.internal.f.6 */
    class C27116 extends C2648d<GetFdForAssetResult> {
        final /* synthetic */ C2137f avn;
        final /* synthetic */ Asset avo;

        C27116(C2137f c2137f, Asset asset) {
            this.avn = c2137f;
            this.avo = asset;
        }

        protected void m5046a(aw awVar) throws RemoteException {
            awVar.m4579a((C0191b) this, this.avo);
        }

        protected GetFdForAssetResult aI(Status status) {
            return new C2549c(status, null);
        }

        protected /* synthetic */ Result m5047c(Status status) {
            return aI(status);
        }
    }

    /* renamed from: com.google.android.gms.wearable.internal.f.7 */
    class C27127 extends C2648d<GetFdForAssetResult> {
        final /* synthetic */ C2137f avn;
        final /* synthetic */ DataItemAsset avp;

        C27127(C2137f c2137f, DataItemAsset dataItemAsset) {
            this.avn = c2137f;
            this.avp = dataItemAsset;
        }

        protected void m5049a(aw awVar) throws RemoteException {
            awVar.m4582a((C0191b) this, this.avp);
        }

        protected GetFdForAssetResult aI(Status status) {
            return new C2549c(status, null);
        }

        protected /* synthetic */ Result m5050c(Status status) {
            return aI(status);
        }
    }

    /* renamed from: com.google.android.gms.wearable.internal.f.8 */
    class C27138 extends C2648d<Status> {
        final /* synthetic */ C2137f avn;
        final /* synthetic */ DataListener avq;
        final /* synthetic */ IntentFilter[] avr;

        C27138(C2137f c2137f, DataListener dataListener, IntentFilter[] intentFilterArr) {
            this.avn = c2137f;
            this.avq = dataListener;
            this.avr = intentFilterArr;
        }

        protected void m5052a(aw awVar) throws RemoteException {
            awVar.m4581a((C0191b) this, this.avq, this.avr);
        }

        public /* synthetic */ Result m5053c(Status status) {
            return m5054d(status);
        }

        public Status m5054d(Status status) {
            return new Status(13);
        }
    }

    /* renamed from: com.google.android.gms.wearable.internal.f.9 */
    class C27149 extends C2648d<Status> {
        final /* synthetic */ C2137f avn;
        final /* synthetic */ DataListener avq;

        C27149(C2137f c2137f, DataListener dataListener) {
            this.avn = c2137f;
            this.avq = dataListener;
        }

        protected void m5056a(aw awVar) throws RemoteException {
            awVar.m4580a((C0191b) this, this.avq);
        }

        public /* synthetic */ Result m5057c(Status status) {
            return m5058d(status);
        }

        public Status m5058d(Status status) {
            return new Status(13);
        }
    }

    private PendingResult<Status> m3787a(GoogleApiClient googleApiClient, DataListener dataListener, IntentFilter[] intentFilterArr) {
        return googleApiClient.m150a(new C27138(this, dataListener, intentFilterArr));
    }

    private void m3788a(Asset asset) {
        if (asset == null) {
            throw new IllegalArgumentException("asset is null");
        } else if (asset.getDigest() == null) {
            throw new IllegalArgumentException("invalid asset");
        } else if (asset.getData() != null) {
            throw new IllegalArgumentException("invalid asset");
        }
    }

    public PendingResult<Status> addListener(GoogleApiClient client, DataListener listener) {
        return m3787a(client, listener, null);
    }

    public PendingResult<DeleteDataItemsResult> deleteDataItems(GoogleApiClient client, Uri uri) {
        return client.m150a(new C27105(this, uri));
    }

    public PendingResult<DataItemResult> getDataItem(GoogleApiClient client, Uri uri) {
        return client.m150a(new C27072(this, uri));
    }

    public PendingResult<DataItemBuffer> getDataItems(GoogleApiClient client) {
        return client.m150a(new C27083(this));
    }

    public PendingResult<DataItemBuffer> getDataItems(GoogleApiClient client, Uri uri) {
        return client.m150a(new C27094(this, uri));
    }

    public PendingResult<GetFdForAssetResult> getFdForAsset(GoogleApiClient client, Asset asset) {
        m3788a(asset);
        return client.m150a(new C27116(this, asset));
    }

    public PendingResult<GetFdForAssetResult> getFdForAsset(GoogleApiClient client, DataItemAsset asset) {
        return client.m150a(new C27127(this, asset));
    }

    public PendingResult<DataItemResult> putDataItem(GoogleApiClient client, PutDataRequest request) {
        return client.m150a(new C27061(this, request));
    }

    public PendingResult<Status> removeListener(GoogleApiClient client, DataListener listener) {
        return client.m150a(new C27149(this, listener));
    }
}
