package com.google.android.gms.wearable.internal;

import android.os.Parcel;
import android.os.Parcelable.Creator;
import com.google.android.gms.common.internal.safeparcel.C0242a;
import com.google.android.gms.common.internal.safeparcel.C0242a.C0241a;
import com.google.android.gms.common.internal.safeparcel.C0243b;
import com.google.android.gms.drive.events.CompletionEvent;
import java.util.List;
import org.telegram.android.time.FastDatePrinter;

/* renamed from: com.google.android.gms.wearable.internal.w */
public class C0746w implements Creator<C2141v> {
    static void m2263a(C2141v c2141v, Parcel parcel, int i) {
        int D = C0243b.m329D(parcel);
        C0243b.m356c(parcel, 1, c2141v.versionCode);
        C0243b.m356c(parcel, 2, c2141v.statusCode);
        C0243b.m357c(parcel, 3, c2141v.avz, false);
        C0243b.m332H(parcel, D);
    }

    public /* synthetic */ Object createFromParcel(Parcel x0) {
        return dY(x0);
    }

    public C2141v dY(Parcel parcel) {
        int i = 0;
        int C = C0242a.m293C(parcel);
        List list = null;
        int i2 = 0;
        while (parcel.dataPosition() < C) {
            int B = C0242a.m291B(parcel);
            switch (C0242a.aD(B)) {
                case CompletionEvent.STATUS_FAILURE /*1*/:
                    i2 = C0242a.m309g(parcel, B);
                    break;
                case CompletionEvent.STATUS_CONFLICT /*2*/:
                    i = C0242a.m309g(parcel, B);
                    break;
                case FastDatePrinter.SHORT /*3*/:
                    list = C0242a.m304c(parcel, B, ak.CREATOR);
                    break;
                default:
                    C0242a.m302b(parcel, B);
                    break;
            }
        }
        if (parcel.dataPosition() == C) {
            return new C2141v(i2, i, list);
        }
        throw new C0241a("Overread allowed size end=" + C, parcel);
    }

    public C2141v[] gb(int i) {
        return new C2141v[i];
    }

    public /* synthetic */ Object[] newArray(int x0) {
        return gb(x0);
    }
}
