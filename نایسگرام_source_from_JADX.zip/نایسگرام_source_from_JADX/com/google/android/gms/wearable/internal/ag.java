package com.google.android.gms.wearable.internal;

import android.content.IntentFilter;
import android.os.RemoteException;
import com.google.android.gms.common.api.BaseImplementation.C0191b;
import com.google.android.gms.common.api.GoogleApiClient;
import com.google.android.gms.common.api.PendingResult;
import com.google.android.gms.common.api.Result;
import com.google.android.gms.common.api.Status;
import com.google.android.gms.wearable.MessageApi;
import com.google.android.gms.wearable.MessageApi.MessageListener;
import com.google.android.gms.wearable.MessageApi.SendMessageResult;

public final class ag implements MessageApi {

    /* renamed from: com.google.android.gms.wearable.internal.ag.a */
    public static class C2544a implements SendMessageResult {
        private final Status CM;
        private final int uQ;

        public C2544a(Status status, int i) {
            this.CM = status;
            this.uQ = i;
        }

        public int getRequestId() {
            return this.uQ;
        }

        public Status getStatus() {
            return this.CM;
        }
    }

    /* renamed from: com.google.android.gms.wearable.internal.ag.1 */
    class C26991 extends C2648d<SendMessageResult> {
        final /* synthetic */ byte[] CY;
        final /* synthetic */ String avD;
        final /* synthetic */ String avE;
        final /* synthetic */ ag avF;

        C26991(ag agVar, String str, String str2, byte[] bArr) {
            this.avF = agVar;
            this.avD = str;
            this.avE = str2;
            this.CY = bArr;
        }

        protected void m5006a(aw awVar) throws RemoteException {
            awVar.m4588a(this, this.avD, this.avE, this.CY);
        }

        protected SendMessageResult aJ(Status status) {
            return new C2544a(status, -1);
        }

        protected /* synthetic */ Result m5007c(Status status) {
            return aJ(status);
        }
    }

    /* renamed from: com.google.android.gms.wearable.internal.ag.2 */
    class C27002 extends C2648d<Status> {
        final /* synthetic */ ag avF;
        final /* synthetic */ MessageListener avG;
        final /* synthetic */ IntentFilter[] avr;

        C27002(ag agVar, MessageListener messageListener, IntentFilter[] intentFilterArr) {
            this.avF = agVar;
            this.avG = messageListener;
            this.avr = intentFilterArr;
        }

        protected void m5009a(aw awVar) throws RemoteException {
            awVar.m4584a((C0191b) this, this.avG, this.avr);
        }

        public /* synthetic */ Result m5010c(Status status) {
            return m5011d(status);
        }

        public Status m5011d(Status status) {
            return new Status(13);
        }
    }

    /* renamed from: com.google.android.gms.wearable.internal.ag.3 */
    class C27013 extends C2648d<Status> {
        final /* synthetic */ ag avF;
        final /* synthetic */ MessageListener avG;

        C27013(ag agVar, MessageListener messageListener) {
            this.avF = agVar;
            this.avG = messageListener;
        }

        protected void m5013a(aw awVar) throws RemoteException {
            awVar.m4583a((C0191b) this, this.avG);
        }

        public /* synthetic */ Result m5014c(Status status) {
            return m5015d(status);
        }

        public Status m5015d(Status status) {
            return new Status(13);
        }
    }

    private PendingResult<Status> m3786a(GoogleApiClient googleApiClient, MessageListener messageListener, IntentFilter[] intentFilterArr) {
        return googleApiClient.m150a(new C27002(this, messageListener, intentFilterArr));
    }

    public PendingResult<Status> addListener(GoogleApiClient client, MessageListener listener) {
        return m3786a(client, listener, null);
    }

    public PendingResult<Status> removeListener(GoogleApiClient client, MessageListener listener) {
        return client.m150a(new C27013(this, listener));
    }

    public PendingResult<SendMessageResult> sendMessage(GoogleApiClient client, String nodeId, String action, byte[] data) {
        return client.m150a(new C26991(this, nodeId, action, data));
    }
}
