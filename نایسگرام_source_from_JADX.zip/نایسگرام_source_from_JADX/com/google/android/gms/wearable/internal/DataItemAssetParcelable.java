package com.google.android.gms.wearable.internal;

import android.os.Parcel;
import android.os.Parcelable.Creator;
import com.google.android.gms.common.internal.C0238o;
import com.google.android.gms.common.internal.safeparcel.SafeParcelable;
import com.google.android.gms.wearable.DataItemAsset;

public class DataItemAssetParcelable implements SafeParcelable, DataItemAsset {
    public static final Creator<DataItemAssetParcelable> CREATOR;
    private final String BL;
    final int BR;
    private final String JO;

    static {
        CREATOR = new C0741j();
    }

    DataItemAssetParcelable(int versionCode, String id, String key) {
        this.BR = versionCode;
        this.BL = id;
        this.JO = key;
    }

    public DataItemAssetParcelable(DataItemAsset value) {
        this.BR = 1;
        this.BL = (String) C0238o.m283i(value.getId());
        this.JO = (String) C0238o.m283i(value.getDataItemKey());
    }

    public int describeContents() {
        return 0;
    }

    public /* synthetic */ Object freeze() {
        return pX();
    }

    public String getDataItemKey() {
        return this.JO;
    }

    public String getId() {
        return this.BL;
    }

    public boolean isDataValid() {
        return true;
    }

    public DataItemAsset pX() {
        return this;
    }

    public String toString() {
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append("DataItemAssetParcelable[");
        stringBuilder.append("@");
        stringBuilder.append(Integer.toHexString(hashCode()));
        if (this.BL == null) {
            stringBuilder.append(",noid");
        } else {
            stringBuilder.append(",");
            stringBuilder.append(this.BL);
        }
        stringBuilder.append(", key=");
        stringBuilder.append(this.JO);
        stringBuilder.append("]");
        return stringBuilder.toString();
    }

    public void writeToParcel(Parcel dest, int flags) {
        C0741j.m2258a(this, dest, flags);
    }
}
