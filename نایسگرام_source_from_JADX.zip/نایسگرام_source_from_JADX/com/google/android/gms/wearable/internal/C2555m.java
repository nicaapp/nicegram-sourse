package com.google.android.gms.wearable.internal;

import android.net.Uri;
import android.os.Bundle;
import android.os.Parcel;
import android.os.Parcelable.Creator;
import android.util.Log;
import com.google.android.gms.common.internal.safeparcel.SafeParcelable;
import com.google.android.gms.wearable.DataItem;
import com.google.android.gms.wearable.DataItemAsset;
import java.util.HashMap;
import java.util.Map;
import java.util.Map.Entry;

/* renamed from: com.google.android.gms.wearable.internal.m */
public class C2555m implements SafeParcelable, DataItem {
    public static final Creator<C2555m> CREATOR;
    final int BR;
    private byte[] acH;
    private final Map<String, DataItemAsset> avv;
    private final Uri mUri;

    static {
        CREATOR = new C0742n();
    }

    C2555m(int i, Uri uri, Bundle bundle, byte[] bArr) {
        this.BR = i;
        this.mUri = uri;
        Map hashMap = new HashMap();
        bundle.setClassLoader(DataItemAssetParcelable.class.getClassLoader());
        for (String str : bundle.keySet()) {
            hashMap.put(str, (DataItemAssetParcelable) bundle.getParcelable(str));
        }
        this.avv = hashMap;
        this.acH = bArr;
    }

    public int describeContents() {
        return 0;
    }

    public /* synthetic */ Object freeze() {
        return pZ();
    }

    public Map<String, DataItemAsset> getAssets() {
        return this.avv;
    }

    public byte[] getData() {
        return this.acH;
    }

    public Uri getUri() {
        return this.mUri;
    }

    public boolean isDataValid() {
        return true;
    }

    public C2555m m4604m(byte[] bArr) {
        this.acH = bArr;
        return this;
    }

    public Bundle pT() {
        Bundle bundle = new Bundle();
        bundle.setClassLoader(DataItemAssetParcelable.class.getClassLoader());
        for (Entry entry : this.avv.entrySet()) {
            bundle.putParcelable((String) entry.getKey(), new DataItemAssetParcelable((DataItemAsset) entry.getValue()));
        }
        return bundle;
    }

    public C2555m pZ() {
        return this;
    }

    public /* synthetic */ DataItem setData(byte[] x0) {
        return m4604m(x0);
    }

    public String toString() {
        return toString(Log.isLoggable("DataItem", 3));
    }

    public String toString(boolean verbose) {
        StringBuilder stringBuilder = new StringBuilder("DataItemParcelable[");
        stringBuilder.append("@");
        stringBuilder.append(Integer.toHexString(hashCode()));
        stringBuilder.append(",dataSz=" + (this.acH == null ? "null" : Integer.valueOf(this.acH.length)));
        stringBuilder.append(", numAssets=" + this.avv.size());
        stringBuilder.append(", uri=" + this.mUri);
        if (verbose) {
            stringBuilder.append("]\n  assets: ");
            for (String str : this.avv.keySet()) {
                stringBuilder.append("\n    " + str + ": " + this.avv.get(str));
            }
            stringBuilder.append("\n  ]");
            return stringBuilder.toString();
        }
        stringBuilder.append("]");
        return stringBuilder.toString();
    }

    public void writeToParcel(Parcel dest, int flags) {
        C0742n.m2259a(this, dest, flags);
    }
}
