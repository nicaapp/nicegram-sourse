package com.google.android.gms.wearable.internal;

import android.os.Parcel;
import android.os.ParcelFileDescriptor;
import android.os.Parcelable.Creator;
import com.google.android.gms.common.internal.safeparcel.C0242a;
import com.google.android.gms.common.internal.safeparcel.C0242a.C0241a;
import com.google.android.gms.common.internal.safeparcel.C0243b;
import com.google.android.gms.drive.events.CompletionEvent;
import org.telegram.android.time.FastDatePrinter;

public class aa implements Creator<C2143z> {
    static void m2211a(C2143z c2143z, Parcel parcel, int i) {
        int D = C0243b.m329D(parcel);
        C0243b.m356c(parcel, 1, c2143z.versionCode);
        C0243b.m356c(parcel, 2, c2143z.statusCode);
        C0243b.m340a(parcel, 3, c2143z.avB, i, false);
        C0243b.m332H(parcel, D);
    }

    public /* synthetic */ Object createFromParcel(Parcel x0) {
        return ea(x0);
    }

    public C2143z ea(Parcel parcel) {
        int i = 0;
        int C = C0242a.m293C(parcel);
        ParcelFileDescriptor parcelFileDescriptor = null;
        int i2 = 0;
        while (parcel.dataPosition() < C) {
            int B = C0242a.m291B(parcel);
            switch (C0242a.aD(B)) {
                case CompletionEvent.STATUS_FAILURE /*1*/:
                    i2 = C0242a.m309g(parcel, B);
                    break;
                case CompletionEvent.STATUS_CONFLICT /*2*/:
                    i = C0242a.m309g(parcel, B);
                    break;
                case FastDatePrinter.SHORT /*3*/:
                    parcelFileDescriptor = (ParcelFileDescriptor) C0242a.m298a(parcel, B, ParcelFileDescriptor.CREATOR);
                    break;
                default:
                    C0242a.m302b(parcel, B);
                    break;
            }
        }
        if (parcel.dataPosition() == C) {
            return new C2143z(i2, i, parcelFileDescriptor);
        }
        throw new C0241a("Overread allowed size end=" + C, parcel);
    }

    public C2143z[] gd(int i) {
        return new C2143z[i];
    }

    public /* synthetic */ Object[] newArray(int x0) {
        return gd(x0);
    }
}
