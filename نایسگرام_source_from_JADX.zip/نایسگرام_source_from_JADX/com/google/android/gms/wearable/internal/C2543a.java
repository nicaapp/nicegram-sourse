package com.google.android.gms.wearable.internal;

import com.google.android.gms.common.api.Status;
import com.google.android.gms.common.data.DataHolder;
import com.google.android.gms.wearable.internal.ad.C2130a;

/* renamed from: com.google.android.gms.wearable.internal.a */
public abstract class C2543a extends C2130a {
    public void m4562a(Status status) {
        throw new UnsupportedOperationException();
    }

    public void m4563a(ab abVar) {
        throw new UnsupportedOperationException();
    }

    public void m4564a(ao aoVar) {
        throw new UnsupportedOperationException();
    }

    public void m4565a(as asVar) {
        throw new UnsupportedOperationException();
    }

    public void m4566a(au auVar) {
        throw new UnsupportedOperationException();
    }

    public void m4567a(C2138p c2138p) {
        throw new UnsupportedOperationException();
    }

    public void m4568a(C2139r c2139r) {
        throw new UnsupportedOperationException();
    }

    public void m4569a(C2140t c2140t) {
        throw new UnsupportedOperationException();
    }

    public void m4570a(C2141v c2141v) {
        throw new UnsupportedOperationException();
    }

    public void m4571a(C2142x c2142x) {
        throw new UnsupportedOperationException();
    }

    public void m4572a(C2143z c2143z) {
        throw new UnsupportedOperationException();
    }

    public void aa(DataHolder dataHolder) {
        throw new UnsupportedOperationException();
    }
}
