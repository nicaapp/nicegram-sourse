package com.google.android.gms.wearable.internal;

import com.google.android.gms.common.data.C0207d;
import com.google.android.gms.common.data.DataHolder;
import com.google.android.gms.wearable.DataItemAsset;

/* renamed from: com.google.android.gms.wearable.internal.k */
public class C2553k extends C0207d implements DataItemAsset {
    public C2553k(DataHolder dataHolder, int i) {
        super(dataHolder, i);
    }

    public /* synthetic */ Object freeze() {
        return pX();
    }

    public String getDataItemKey() {
        return getString("asset_key");
    }

    public String getId() {
        return getString("asset_id");
    }

    public DataItemAsset pX() {
        return new C2552i(this);
    }
}
