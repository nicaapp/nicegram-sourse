package com.google.android.gms.wearable.internal;

import android.os.IBinder;
import android.os.Parcel;
import android.os.Parcelable.Creator;
import com.google.android.gms.common.internal.safeparcel.SafeParcelable;
import com.google.android.gms.wearable.internal.ae.C2132a;

public class aq implements SafeParcelable {
    public static final Creator<aq> CREATOR;
    final int BR;
    public final ae avk;

    static {
        CREATOR = new ar();
    }

    aq(int i, IBinder iBinder) {
        this.BR = i;
        if (iBinder != null) {
            this.avk = C2132a.bS(iBinder);
        } else {
            this.avk = null;
        }
    }

    public aq(ae aeVar) {
        this.BR = 1;
        this.avk = aeVar;
    }

    public int describeContents() {
        return 0;
    }

    IBinder pV() {
        return this.avk == null ? null : this.avk.asBinder();
    }

    public void writeToParcel(Parcel dest, int flags) {
        ar.m2254a(this, dest, flags);
    }
}
