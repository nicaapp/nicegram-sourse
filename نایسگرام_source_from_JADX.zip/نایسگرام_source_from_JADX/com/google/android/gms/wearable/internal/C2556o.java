package com.google.android.gms.wearable.internal;

import android.net.Uri;
import com.google.android.gms.common.data.C0207d;
import com.google.android.gms.common.data.DataHolder;
import com.google.android.gms.wearable.DataItem;
import com.google.android.gms.wearable.DataItemAsset;
import java.util.HashMap;
import java.util.Map;

/* renamed from: com.google.android.gms.wearable.internal.o */
public final class C2556o extends C0207d implements DataItem {
    private final int aaK;

    public C2556o(DataHolder dataHolder, int i, int i2) {
        super(dataHolder, i);
        this.aaK = i2;
    }

    public /* synthetic */ Object freeze() {
        return pY();
    }

    public Map<String, DataItemAsset> getAssets() {
        Map<String, DataItemAsset> hashMap = new HashMap(this.aaK);
        for (int i = 0; i < this.aaK; i++) {
            C2553k c2553k = new C2553k(this.II, this.JX + i);
            if (c2553k.getDataItemKey() != null) {
                hashMap.put(c2553k.getDataItemKey(), c2553k);
            }
        }
        return hashMap;
    }

    public byte[] getData() {
        return getByteArray("data");
    }

    public Uri getUri() {
        return Uri.parse(getString("path"));
    }

    public DataItem pY() {
        return new C2554l(this);
    }

    public DataItem setData(byte[] data) {
        throw new UnsupportedOperationException();
    }
}
