package com.google.android.gms.wearable.internal;

import android.os.Parcel;
import android.os.Parcelable.Creator;
import com.google.android.gms.common.internal.safeparcel.SafeParcelable;
import com.google.android.gms.wearable.MessageEvent;

public class ah implements SafeParcelable, MessageEvent {
    public static final Creator<ah> CREATOR;
    final int BR;
    private final byte[] acH;
    private final String avH;
    private final String avI;
    private final int uQ;

    static {
        CREATOR = new ai();
    }

    ah(int i, int i2, String str, byte[] bArr, String str2) {
        this.BR = i;
        this.uQ = i2;
        this.avH = str;
        this.acH = bArr;
        this.avI = str2;
    }

    public int describeContents() {
        return 0;
    }

    public byte[] getData() {
        return this.acH;
    }

    public String getPath() {
        return this.avH;
    }

    public int getRequestId() {
        return this.uQ;
    }

    public String getSourceNodeId() {
        return this.avI;
    }

    public String toString() {
        return "MessageEventParcelable[" + this.uQ + "," + this.avH + ", size=" + (this.acH == null ? "null" : Integer.valueOf(this.acH.length)) + "]";
    }

    public void writeToParcel(Parcel dest, int flags) {
        ai.m2250a(this, dest, flags);
    }
}
