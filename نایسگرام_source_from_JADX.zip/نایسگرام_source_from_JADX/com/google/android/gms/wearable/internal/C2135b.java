package com.google.android.gms.wearable.internal;

import android.content.IntentFilter;
import android.os.IBinder;
import android.os.Parcel;
import android.os.Parcelable.Creator;
import com.google.android.gms.common.internal.safeparcel.SafeParcelable;
import com.google.android.gms.wearable.internal.ae.C2132a;

/* renamed from: com.google.android.gms.wearable.internal.b */
public class C2135b implements SafeParcelable {
    public static final Creator<C2135b> CREATOR;
    final int BR;
    public final ae avk;
    public final IntentFilter[] avl;

    static {
        CREATOR = new C0740c();
    }

    C2135b(int i, IBinder iBinder, IntentFilter[] intentFilterArr) {
        this.BR = i;
        if (iBinder != null) {
            this.avk = C2132a.bS(iBinder);
        } else {
            this.avk = null;
        }
        this.avl = intentFilterArr;
    }

    public C2135b(ax axVar) {
        this.BR = 1;
        this.avk = axVar;
        this.avl = axVar.qb();
    }

    public int describeContents() {
        return 0;
    }

    IBinder pV() {
        return this.avk == null ? null : this.avk.asBinder();
    }

    public void writeToParcel(Parcel dest, int flags) {
        C0740c.m2257a(this, dest, flags);
    }
}
