package com.google.android.gms.wearable.internal;

import com.google.android.gms.wearable.DataItemAsset;

/* renamed from: com.google.android.gms.wearable.internal.i */
public class C2552i implements DataItemAsset {
    private final String BL;
    private final String JO;

    public C2552i(DataItemAsset dataItemAsset) {
        this.BL = dataItemAsset.getId();
        this.JO = dataItemAsset.getDataItemKey();
    }

    public /* synthetic */ Object freeze() {
        return pX();
    }

    public String getDataItemKey() {
        return this.JO;
    }

    public String getId() {
        return this.BL;
    }

    public boolean isDataValid() {
        return true;
    }

    public DataItemAsset pX() {
        return this;
    }

    public String toString() {
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append("DataItemAssetEntity[");
        stringBuilder.append("@");
        stringBuilder.append(Integer.toHexString(hashCode()));
        if (this.BL == null) {
            stringBuilder.append(",noid");
        } else {
            stringBuilder.append(",");
            stringBuilder.append(this.BL);
        }
        stringBuilder.append(", key=");
        stringBuilder.append(this.JO);
        stringBuilder.append("]");
        return stringBuilder.toString();
    }
}
