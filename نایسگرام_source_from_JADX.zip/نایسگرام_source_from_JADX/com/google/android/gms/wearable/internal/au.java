package com.google.android.gms.wearable.internal;

import android.os.Parcel;
import android.os.Parcelable.Creator;
import com.google.android.gms.common.internal.safeparcel.SafeParcelable;
import java.util.List;

public class au implements SafeParcelable {
    public static final Creator<au> CREATOR;
    public final long avN;
    public final List<am> avP;
    public final int statusCode;
    public final int versionCode;

    static {
        CREATOR = new av();
    }

    au(int i, int i2, long j, List<am> list) {
        this.versionCode = i;
        this.statusCode = i2;
        this.avN = j;
        this.avP = list;
    }

    public int describeContents() {
        return 0;
    }

    public void writeToParcel(Parcel out, int flags) {
        av.m2256a(this, out, flags);
    }
}
