package com.google.android.gms.wearable.internal;

import android.os.Parcel;
import android.os.Parcelable.Creator;
import com.google.android.gms.common.internal.safeparcel.C0242a;
import com.google.android.gms.common.internal.safeparcel.C0242a.C0241a;
import com.google.android.gms.common.internal.safeparcel.C0243b;
import com.google.android.gms.drive.events.CompletionEvent;
import com.google.android.gms.wearable.C2128c;
import org.telegram.android.time.FastDatePrinter;

/* renamed from: com.google.android.gms.wearable.internal.s */
public class C0744s implements Creator<C2139r> {
    static void m2261a(C2139r c2139r, Parcel parcel, int i) {
        int D = C0243b.m329D(parcel);
        C0243b.m356c(parcel, 1, c2139r.versionCode);
        C0243b.m356c(parcel, 2, c2139r.statusCode);
        C0243b.m340a(parcel, 3, c2139r.avx, i, false);
        C0243b.m332H(parcel, D);
    }

    public /* synthetic */ Object createFromParcel(Parcel x0) {
        return dW(x0);
    }

    public C2139r dW(Parcel parcel) {
        int i = 0;
        int C = C0242a.m293C(parcel);
        C2128c c2128c = null;
        int i2 = 0;
        while (parcel.dataPosition() < C) {
            int B = C0242a.m291B(parcel);
            switch (C0242a.aD(B)) {
                case CompletionEvent.STATUS_FAILURE /*1*/:
                    i2 = C0242a.m309g(parcel, B);
                    break;
                case CompletionEvent.STATUS_CONFLICT /*2*/:
                    i = C0242a.m309g(parcel, B);
                    break;
                case FastDatePrinter.SHORT /*3*/:
                    c2128c = (C2128c) C0242a.m298a(parcel, B, C2128c.CREATOR);
                    break;
                default:
                    C0242a.m302b(parcel, B);
                    break;
            }
        }
        if (parcel.dataPosition() == C) {
            return new C2139r(i2, i, c2128c);
        }
        throw new C0241a("Overread allowed size end=" + C, parcel);
    }

    public C2139r[] fZ(int i) {
        return new C2139r[i];
    }

    public /* synthetic */ Object[] newArray(int x0) {
        return fZ(x0);
    }
}
