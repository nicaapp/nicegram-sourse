package com.google.android.gms.wearable.internal;

import android.net.Uri;
import android.os.Binder;
import android.os.IBinder;
import android.os.IInterface;
import android.os.Parcel;
import android.os.RemoteException;
import com.google.android.gms.drive.events.CompletionEvent;
import com.google.android.gms.games.quest.Quest;
import com.google.android.gms.location.DetectedActivity;
import com.google.android.gms.wearable.Asset;
import com.google.android.gms.wearable.C2128c;
import com.google.android.gms.wearable.PutDataRequest;
import com.google.android.gms.wearable.internal.ad.C2130a;
import com.googlecode.mp4parser.authoring.tracks.h265.NalUnitTypes;
import com.googlecode.mp4parser.boxes.microsoft.XtraBox;
import org.telegram.C0811R;
import org.telegram.android.SecretChatHelper;
import org.telegram.android.support.widget.helper.ItemTouchHelper;
import org.telegram.android.time.FastDatePrinter;

public interface af extends IInterface {

    /* renamed from: com.google.android.gms.wearable.internal.af.a */
    public static abstract class C2134a extends Binder implements af {

        /* renamed from: com.google.android.gms.wearable.internal.af.a.a */
        private static class C2133a implements af {
            private IBinder lb;

            C2133a(IBinder iBinder) {
                this.lb = iBinder;
            }

            public void m3764a(ad adVar) throws RemoteException {
                Parcel obtain = Parcel.obtain();
                Parcel obtain2 = Parcel.obtain();
                try {
                    obtain.writeInterfaceToken("com.google.android.gms.wearable.internal.IWearableService");
                    obtain.writeStrongBinder(adVar != null ? adVar.asBinder() : null);
                    this.lb.transact(22, obtain, obtain2, 0);
                    obtain2.readException();
                } finally {
                    obtain2.recycle();
                    obtain.recycle();
                }
            }

            public void m3765a(ad adVar, Uri uri) throws RemoteException {
                Parcel obtain = Parcel.obtain();
                Parcel obtain2 = Parcel.obtain();
                try {
                    obtain.writeInterfaceToken("com.google.android.gms.wearable.internal.IWearableService");
                    obtain.writeStrongBinder(adVar != null ? adVar.asBinder() : null);
                    if (uri != null) {
                        obtain.writeInt(1);
                        uri.writeToParcel(obtain, 0);
                    } else {
                        obtain.writeInt(0);
                    }
                    this.lb.transact(7, obtain, obtain2, 0);
                    obtain2.readException();
                } finally {
                    obtain2.recycle();
                    obtain.recycle();
                }
            }

            public void m3766a(ad adVar, Asset asset) throws RemoteException {
                Parcel obtain = Parcel.obtain();
                Parcel obtain2 = Parcel.obtain();
                try {
                    obtain.writeInterfaceToken("com.google.android.gms.wearable.internal.IWearableService");
                    obtain.writeStrongBinder(adVar != null ? adVar.asBinder() : null);
                    if (asset != null) {
                        obtain.writeInt(1);
                        asset.writeToParcel(obtain, 0);
                    } else {
                        obtain.writeInt(0);
                    }
                    this.lb.transact(13, obtain, obtain2, 0);
                    obtain2.readException();
                } finally {
                    obtain2.recycle();
                    obtain.recycle();
                }
            }

            public void m3767a(ad adVar, PutDataRequest putDataRequest) throws RemoteException {
                Parcel obtain = Parcel.obtain();
                Parcel obtain2 = Parcel.obtain();
                try {
                    obtain.writeInterfaceToken("com.google.android.gms.wearable.internal.IWearableService");
                    obtain.writeStrongBinder(adVar != null ? adVar.asBinder() : null);
                    if (putDataRequest != null) {
                        obtain.writeInt(1);
                        putDataRequest.writeToParcel(obtain, 0);
                    } else {
                        obtain.writeInt(0);
                    }
                    this.lb.transact(6, obtain, obtain2, 0);
                    obtain2.readException();
                } finally {
                    obtain2.recycle();
                    obtain.recycle();
                }
            }

            public void m3768a(ad adVar, C2128c c2128c) throws RemoteException {
                Parcel obtain = Parcel.obtain();
                Parcel obtain2 = Parcel.obtain();
                try {
                    obtain.writeInterfaceToken("com.google.android.gms.wearable.internal.IWearableService");
                    obtain.writeStrongBinder(adVar != null ? adVar.asBinder() : null);
                    if (c2128c != null) {
                        obtain.writeInt(1);
                        c2128c.writeToParcel(obtain, 0);
                    } else {
                        obtain.writeInt(0);
                    }
                    this.lb.transact(20, obtain, obtain2, 0);
                    obtain2.readException();
                } finally {
                    obtain2.recycle();
                    obtain.recycle();
                }
            }

            public void m3769a(ad adVar, aq aqVar) throws RemoteException {
                Parcel obtain = Parcel.obtain();
                Parcel obtain2 = Parcel.obtain();
                try {
                    obtain.writeInterfaceToken("com.google.android.gms.wearable.internal.IWearableService");
                    obtain.writeStrongBinder(adVar != null ? adVar.asBinder() : null);
                    if (aqVar != null) {
                        obtain.writeInt(1);
                        aqVar.writeToParcel(obtain, 0);
                    } else {
                        obtain.writeInt(0);
                    }
                    this.lb.transact(17, obtain, obtain2, 0);
                    obtain2.readException();
                } finally {
                    obtain2.recycle();
                    obtain.recycle();
                }
            }

            public void m3770a(ad adVar, C2135b c2135b) throws RemoteException {
                Parcel obtain = Parcel.obtain();
                Parcel obtain2 = Parcel.obtain();
                try {
                    obtain.writeInterfaceToken("com.google.android.gms.wearable.internal.IWearableService");
                    obtain.writeStrongBinder(adVar != null ? adVar.asBinder() : null);
                    if (c2135b != null) {
                        obtain.writeInt(1);
                        c2135b.writeToParcel(obtain, 0);
                    } else {
                        obtain.writeInt(0);
                    }
                    this.lb.transact(16, obtain, obtain2, 0);
                    obtain2.readException();
                } finally {
                    obtain2.recycle();
                    obtain.recycle();
                }
            }

            public void m3771a(ad adVar, String str) throws RemoteException {
                Parcel obtain = Parcel.obtain();
                Parcel obtain2 = Parcel.obtain();
                try {
                    obtain.writeInterfaceToken("com.google.android.gms.wearable.internal.IWearableService");
                    obtain.writeStrongBinder(adVar != null ? adVar.asBinder() : null);
                    obtain.writeString(str);
                    this.lb.transact(21, obtain, obtain2, 0);
                    obtain2.readException();
                } finally {
                    obtain2.recycle();
                    obtain.recycle();
                }
            }

            public void m3772a(ad adVar, String str, String str2, byte[] bArr) throws RemoteException {
                Parcel obtain = Parcel.obtain();
                Parcel obtain2 = Parcel.obtain();
                try {
                    obtain.writeInterfaceToken("com.google.android.gms.wearable.internal.IWearableService");
                    obtain.writeStrongBinder(adVar != null ? adVar.asBinder() : null);
                    obtain.writeString(str);
                    obtain.writeString(str2);
                    obtain.writeByteArray(bArr);
                    this.lb.transact(12, obtain, obtain2, 0);
                    obtain2.readException();
                } finally {
                    obtain2.recycle();
                    obtain.recycle();
                }
            }

            public IBinder asBinder() {
                return this.lb;
            }

            public void m3773b(ad adVar) throws RemoteException {
                Parcel obtain = Parcel.obtain();
                Parcel obtain2 = Parcel.obtain();
                try {
                    obtain.writeInterfaceToken("com.google.android.gms.wearable.internal.IWearableService");
                    obtain.writeStrongBinder(adVar != null ? adVar.asBinder() : null);
                    this.lb.transact(8, obtain, obtain2, 0);
                    obtain2.readException();
                } finally {
                    obtain2.recycle();
                    obtain.recycle();
                }
            }

            public void m3774b(ad adVar, Uri uri) throws RemoteException {
                Parcel obtain = Parcel.obtain();
                Parcel obtain2 = Parcel.obtain();
                try {
                    obtain.writeInterfaceToken("com.google.android.gms.wearable.internal.IWearableService");
                    obtain.writeStrongBinder(adVar != null ? adVar.asBinder() : null);
                    if (uri != null) {
                        obtain.writeInt(1);
                        uri.writeToParcel(obtain, 0);
                    } else {
                        obtain.writeInt(0);
                    }
                    this.lb.transact(9, obtain, obtain2, 0);
                    obtain2.readException();
                } finally {
                    obtain2.recycle();
                    obtain.recycle();
                }
            }

            public void m3775b(ad adVar, C2128c c2128c) throws RemoteException {
                Parcel obtain = Parcel.obtain();
                Parcel obtain2 = Parcel.obtain();
                try {
                    obtain.writeInterfaceToken("com.google.android.gms.wearable.internal.IWearableService");
                    obtain.writeStrongBinder(adVar != null ? adVar.asBinder() : null);
                    if (c2128c != null) {
                        obtain.writeInt(1);
                        c2128c.writeToParcel(obtain, 0);
                    } else {
                        obtain.writeInt(0);
                    }
                    this.lb.transact(2, obtain, obtain2, 0);
                    obtain2.readException();
                } finally {
                    obtain2.recycle();
                    obtain.recycle();
                }
            }

            public void m3776b(ad adVar, String str) throws RemoteException {
                Parcel obtain = Parcel.obtain();
                Parcel obtain2 = Parcel.obtain();
                try {
                    obtain.writeInterfaceToken("com.google.android.gms.wearable.internal.IWearableService");
                    obtain.writeStrongBinder(adVar != null ? adVar.asBinder() : null);
                    obtain.writeString(str);
                    this.lb.transact(23, obtain, obtain2, 0);
                    obtain2.readException();
                } finally {
                    obtain2.recycle();
                    obtain.recycle();
                }
            }

            public void m3777c(ad adVar) throws RemoteException {
                Parcel obtain = Parcel.obtain();
                Parcel obtain2 = Parcel.obtain();
                try {
                    obtain.writeInterfaceToken("com.google.android.gms.wearable.internal.IWearableService");
                    obtain.writeStrongBinder(adVar != null ? adVar.asBinder() : null);
                    this.lb.transact(14, obtain, obtain2, 0);
                    obtain2.readException();
                } finally {
                    obtain2.recycle();
                    obtain.recycle();
                }
            }

            public void m3778c(ad adVar, Uri uri) throws RemoteException {
                Parcel obtain = Parcel.obtain();
                Parcel obtain2 = Parcel.obtain();
                try {
                    obtain.writeInterfaceToken("com.google.android.gms.wearable.internal.IWearableService");
                    obtain.writeStrongBinder(adVar != null ? adVar.asBinder() : null);
                    if (uri != null) {
                        obtain.writeInt(1);
                        uri.writeToParcel(obtain, 0);
                    } else {
                        obtain.writeInt(0);
                    }
                    this.lb.transact(11, obtain, obtain2, 0);
                    obtain2.readException();
                } finally {
                    obtain2.recycle();
                    obtain.recycle();
                }
            }

            public void m3779c(ad adVar, String str) throws RemoteException {
                Parcel obtain = Parcel.obtain();
                Parcel obtain2 = Parcel.obtain();
                try {
                    obtain.writeInterfaceToken("com.google.android.gms.wearable.internal.IWearableService");
                    obtain.writeStrongBinder(adVar != null ? adVar.asBinder() : null);
                    obtain.writeString(str);
                    this.lb.transact(24, obtain, obtain2, 0);
                    obtain2.readException();
                } finally {
                    obtain2.recycle();
                    obtain.recycle();
                }
            }

            public void m3780d(ad adVar) throws RemoteException {
                Parcel obtain = Parcel.obtain();
                Parcel obtain2 = Parcel.obtain();
                try {
                    obtain.writeInterfaceToken("com.google.android.gms.wearable.internal.IWearableService");
                    obtain.writeStrongBinder(adVar != null ? adVar.asBinder() : null);
                    this.lb.transact(15, obtain, obtain2, 0);
                    obtain2.readException();
                } finally {
                    obtain2.recycle();
                    obtain.recycle();
                }
            }

            public void m3781e(ad adVar) throws RemoteException {
                Parcel obtain = Parcel.obtain();
                Parcel obtain2 = Parcel.obtain();
                try {
                    obtain.writeInterfaceToken("com.google.android.gms.wearable.internal.IWearableService");
                    obtain.writeStrongBinder(adVar != null ? adVar.asBinder() : null);
                    this.lb.transact(18, obtain, obtain2, 0);
                    obtain2.readException();
                } finally {
                    obtain2.recycle();
                    obtain.recycle();
                }
            }

            public void m3782f(ad adVar) throws RemoteException {
                Parcel obtain = Parcel.obtain();
                Parcel obtain2 = Parcel.obtain();
                try {
                    obtain.writeInterfaceToken("com.google.android.gms.wearable.internal.IWearableService");
                    obtain.writeStrongBinder(adVar != null ? adVar.asBinder() : null);
                    this.lb.transact(19, obtain, obtain2, 0);
                    obtain2.readException();
                } finally {
                    obtain2.recycle();
                    obtain.recycle();
                }
            }

            public void m3783g(ad adVar) throws RemoteException {
                Parcel obtain = Parcel.obtain();
                Parcel obtain2 = Parcel.obtain();
                try {
                    obtain.writeInterfaceToken("com.google.android.gms.wearable.internal.IWearableService");
                    obtain.writeStrongBinder(adVar != null ? adVar.asBinder() : null);
                    this.lb.transact(3, obtain, obtain2, 0);
                    obtain2.readException();
                } finally {
                    obtain2.recycle();
                    obtain.recycle();
                }
            }

            public void m3784h(ad adVar) throws RemoteException {
                Parcel obtain = Parcel.obtain();
                Parcel obtain2 = Parcel.obtain();
                try {
                    obtain.writeInterfaceToken("com.google.android.gms.wearable.internal.IWearableService");
                    obtain.writeStrongBinder(adVar != null ? adVar.asBinder() : null);
                    this.lb.transact(4, obtain, obtain2, 0);
                    obtain2.readException();
                } finally {
                    obtain2.recycle();
                    obtain.recycle();
                }
            }

            public void m3785i(ad adVar) throws RemoteException {
                Parcel obtain = Parcel.obtain();
                Parcel obtain2 = Parcel.obtain();
                try {
                    obtain.writeInterfaceToken("com.google.android.gms.wearable.internal.IWearableService");
                    obtain.writeStrongBinder(adVar != null ? adVar.asBinder() : null);
                    this.lb.transact(5, obtain, obtain2, 0);
                    obtain2.readException();
                } finally {
                    obtain2.recycle();
                    obtain.recycle();
                }
            }
        }

        public static af bT(IBinder iBinder) {
            if (iBinder == null) {
                return null;
            }
            IInterface queryLocalInterface = iBinder.queryLocalInterface("com.google.android.gms.wearable.internal.IWearableService");
            return (queryLocalInterface == null || !(queryLocalInterface instanceof af)) ? new C2133a(iBinder) : (af) queryLocalInterface;
        }

        public boolean onTransact(int code, Parcel data, Parcel reply, int flags) throws RemoteException {
            C2128c c2128c = null;
            ad bR;
            Uri uri;
            switch (code) {
                case CompletionEvent.STATUS_CONFLICT /*2*/:
                    data.enforceInterface("com.google.android.gms.wearable.internal.IWearableService");
                    bR = C2130a.bR(data.readStrongBinder());
                    if (data.readInt() != 0) {
                        c2128c = (C2128c) C2128c.CREATOR.createFromParcel(data);
                    }
                    m2239b(bR, c2128c);
                    reply.writeNoException();
                    return true;
                case FastDatePrinter.SHORT /*3*/:
                    data.enforceInterface("com.google.android.gms.wearable.internal.IWearableService");
                    m2247g(C2130a.bR(data.readStrongBinder()));
                    reply.writeNoException();
                    return true;
                case ItemTouchHelper.LEFT /*4*/:
                    data.enforceInterface("com.google.android.gms.wearable.internal.IWearableService");
                    m2248h(C2130a.bR(data.readStrongBinder()));
                    reply.writeNoException();
                    return true;
                case DetectedActivity.TILTING /*5*/:
                    data.enforceInterface("com.google.android.gms.wearable.internal.IWearableService");
                    m2249i(C2130a.bR(data.readStrongBinder()));
                    reply.writeNoException();
                    return true;
                case Quest.STATE_FAILED /*6*/:
                    PutDataRequest putDataRequest;
                    data.enforceInterface("com.google.android.gms.wearable.internal.IWearableService");
                    bR = C2130a.bR(data.readStrongBinder());
                    if (data.readInt() != 0) {
                        putDataRequest = (PutDataRequest) PutDataRequest.CREATOR.createFromParcel(data);
                    }
                    m2231a(bR, putDataRequest);
                    reply.writeNoException();
                    return true;
                case DetectedActivity.WALKING /*7*/:
                    data.enforceInterface("com.google.android.gms.wearable.internal.IWearableService");
                    bR = C2130a.bR(data.readStrongBinder());
                    if (data.readInt() != 0) {
                        uri = (Uri) Uri.CREATOR.createFromParcel(data);
                    }
                    m2229a(bR, uri);
                    reply.writeNoException();
                    return true;
                case XtraBox.MP4_XTRA_BT_UNICODE /*8*/:
                    data.enforceInterface("com.google.android.gms.wearable.internal.IWearableService");
                    m2237b(C2130a.bR(data.readStrongBinder()));
                    reply.writeNoException();
                    return true;
                case C0811R.styleable.WalletFragmentStyle_maskedWalletDetailsLogoTextColor /*9*/:
                    data.enforceInterface("com.google.android.gms.wearable.internal.IWearableService");
                    bR = C2130a.bR(data.readStrongBinder());
                    if (data.readInt() != 0) {
                        uri = (Uri) Uri.CREATOR.createFromParcel(data);
                    }
                    m2238b(bR, uri);
                    reply.writeNoException();
                    return true;
                case C0811R.styleable.MapAttrs_uiZoomGestures /*11*/:
                    data.enforceInterface("com.google.android.gms.wearable.internal.IWearableService");
                    bR = C2130a.bR(data.readStrongBinder());
                    if (data.readInt() != 0) {
                        uri = (Uri) Uri.CREATOR.createFromParcel(data);
                    }
                    m2242c(bR, uri);
                    reply.writeNoException();
                    return true;
                case C0811R.styleable.MapAttrs_useViewLifecycle /*12*/:
                    data.enforceInterface("com.google.android.gms.wearable.internal.IWearableService");
                    m2236a(C2130a.bR(data.readStrongBinder()), data.readString(), data.readString(), data.createByteArray());
                    reply.writeNoException();
                    return true;
                case C0811R.styleable.MapAttrs_zOrderOnTop /*13*/:
                    Asset asset;
                    data.enforceInterface("com.google.android.gms.wearable.internal.IWearableService");
                    bR = C2130a.bR(data.readStrongBinder());
                    if (data.readInt() != 0) {
                        asset = (Asset) Asset.CREATOR.createFromParcel(data);
                    }
                    m2230a(bR, asset);
                    reply.writeNoException();
                    return true;
                case NalUnitTypes.NAL_TYPE_RSV_VCL_N14 /*14*/:
                    data.enforceInterface("com.google.android.gms.wearable.internal.IWearableService");
                    m2241c(C2130a.bR(data.readStrongBinder()));
                    reply.writeNoException();
                    return true;
                case NalUnitTypes.NAL_TYPE_RSV_VCL_R15 /*15*/:
                    data.enforceInterface("com.google.android.gms.wearable.internal.IWearableService");
                    m2244d(C2130a.bR(data.readStrongBinder()));
                    reply.writeNoException();
                    return true;
                case ItemTouchHelper.START /*16*/:
                    C2135b c2135b;
                    data.enforceInterface("com.google.android.gms.wearable.internal.IWearableService");
                    bR = C2130a.bR(data.readStrongBinder());
                    if (data.readInt() != 0) {
                        c2135b = (C2135b) C2135b.CREATOR.createFromParcel(data);
                    }
                    m2234a(bR, c2135b);
                    reply.writeNoException();
                    return true;
                case NalUnitTypes.NAL_TYPE_BLA_W_RADL /*17*/:
                    aq aqVar;
                    data.enforceInterface("com.google.android.gms.wearable.internal.IWearableService");
                    bR = C2130a.bR(data.readStrongBinder());
                    if (data.readInt() != 0) {
                        aqVar = (aq) aq.CREATOR.createFromParcel(data);
                    }
                    m2233a(bR, aqVar);
                    reply.writeNoException();
                    return true;
                case NalUnitTypes.NAL_TYPE_BLA_N_LP /*18*/:
                    data.enforceInterface("com.google.android.gms.wearable.internal.IWearableService");
                    m2245e(C2130a.bR(data.readStrongBinder()));
                    reply.writeNoException();
                    return true;
                case XtraBox.MP4_XTRA_BT_INT64 /*19*/:
                    data.enforceInterface("com.google.android.gms.wearable.internal.IWearableService");
                    m2246f(C2130a.bR(data.readStrongBinder()));
                    reply.writeNoException();
                    return true;
                case NalUnitTypes.NAL_TYPE_IDR_N_LP /*20*/:
                    data.enforceInterface("com.google.android.gms.wearable.internal.IWearableService");
                    bR = C2130a.bR(data.readStrongBinder());
                    if (data.readInt() != 0) {
                        c2128c = (C2128c) C2128c.CREATOR.createFromParcel(data);
                    }
                    m2232a(bR, c2128c);
                    reply.writeNoException();
                    return true;
                case XtraBox.MP4_XTRA_BT_FILETIME /*21*/:
                    data.enforceInterface("com.google.android.gms.wearable.internal.IWearableService");
                    m2235a(C2130a.bR(data.readStrongBinder()), data.readString());
                    reply.writeNoException();
                    return true;
                case NalUnitTypes.NAL_TYPE_RSV_IRAP_VCL22 /*22*/:
                    data.enforceInterface("com.google.android.gms.wearable.internal.IWearableService");
                    m2228a(C2130a.bR(data.readStrongBinder()));
                    reply.writeNoException();
                    return true;
                case SecretChatHelper.CURRENT_SECRET_CHAT_LAYER /*23*/:
                    data.enforceInterface("com.google.android.gms.wearable.internal.IWearableService");
                    m2240b(C2130a.bR(data.readStrongBinder()), data.readString());
                    reply.writeNoException();
                    return true;
                case NalUnitTypes.NAL_TYPE_RSV_VCL24 /*24*/:
                    data.enforceInterface("com.google.android.gms.wearable.internal.IWearableService");
                    m2243c(C2130a.bR(data.readStrongBinder()), data.readString());
                    reply.writeNoException();
                    return true;
                case 1598968902:
                    reply.writeString("com.google.android.gms.wearable.internal.IWearableService");
                    return true;
                default:
                    return super.onTransact(code, data, reply, flags);
            }
        }
    }

    void m2228a(ad adVar) throws RemoteException;

    void m2229a(ad adVar, Uri uri) throws RemoteException;

    void m2230a(ad adVar, Asset asset) throws RemoteException;

    void m2231a(ad adVar, PutDataRequest putDataRequest) throws RemoteException;

    void m2232a(ad adVar, C2128c c2128c) throws RemoteException;

    void m2233a(ad adVar, aq aqVar) throws RemoteException;

    void m2234a(ad adVar, C2135b c2135b) throws RemoteException;

    void m2235a(ad adVar, String str) throws RemoteException;

    void m2236a(ad adVar, String str, String str2, byte[] bArr) throws RemoteException;

    void m2237b(ad adVar) throws RemoteException;

    void m2238b(ad adVar, Uri uri) throws RemoteException;

    void m2239b(ad adVar, C2128c c2128c) throws RemoteException;

    void m2240b(ad adVar, String str) throws RemoteException;

    void m2241c(ad adVar) throws RemoteException;

    void m2242c(ad adVar, Uri uri) throws RemoteException;

    void m2243c(ad adVar, String str) throws RemoteException;

    void m2244d(ad adVar) throws RemoteException;

    void m2245e(ad adVar) throws RemoteException;

    void m2246f(ad adVar) throws RemoteException;

    void m2247g(ad adVar) throws RemoteException;

    void m2248h(ad adVar) throws RemoteException;

    void m2249i(ad adVar) throws RemoteException;
}
