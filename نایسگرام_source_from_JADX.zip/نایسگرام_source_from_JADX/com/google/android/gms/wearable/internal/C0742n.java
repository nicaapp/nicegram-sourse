package com.google.android.gms.wearable.internal;

import android.net.Uri;
import android.os.Bundle;
import android.os.Parcel;
import android.os.Parcelable.Creator;
import com.google.android.gms.common.internal.safeparcel.C0242a;
import com.google.android.gms.common.internal.safeparcel.C0242a.C0241a;
import com.google.android.gms.common.internal.safeparcel.C0243b;
import com.google.android.gms.drive.events.CompletionEvent;
import com.google.android.gms.location.DetectedActivity;
import org.telegram.android.support.widget.helper.ItemTouchHelper;

/* renamed from: com.google.android.gms.wearable.internal.n */
public class C0742n implements Creator<C2555m> {
    static void m2259a(C2555m c2555m, Parcel parcel, int i) {
        int D = C0243b.m329D(parcel);
        C0243b.m356c(parcel, 1, c2555m.BR);
        C0243b.m340a(parcel, 2, c2555m.getUri(), i, false);
        C0243b.m337a(parcel, 4, c2555m.pT(), false);
        C0243b.m348a(parcel, 5, c2555m.getData(), false);
        C0243b.m332H(parcel, D);
    }

    public /* synthetic */ Object createFromParcel(Parcel x0) {
        return dU(x0);
    }

    public C2555m dU(Parcel parcel) {
        byte[] bArr = null;
        int C = C0242a.m293C(parcel);
        int i = 0;
        Bundle bundle = null;
        Uri uri = null;
        while (parcel.dataPosition() < C) {
            Bundle bundle2;
            Uri uri2;
            int g;
            byte[] bArr2;
            int B = C0242a.m291B(parcel);
            byte[] bArr3;
            switch (C0242a.aD(B)) {
                case CompletionEvent.STATUS_FAILURE /*1*/:
                    bArr3 = bArr;
                    bundle2 = bundle;
                    uri2 = uri;
                    g = C0242a.m309g(parcel, B);
                    bArr2 = bArr3;
                    break;
                case CompletionEvent.STATUS_CONFLICT /*2*/:
                    g = i;
                    Bundle bundle3 = bundle;
                    uri2 = (Uri) C0242a.m298a(parcel, B, Uri.CREATOR);
                    bArr2 = bArr;
                    bundle2 = bundle3;
                    break;
                case ItemTouchHelper.LEFT /*4*/:
                    uri2 = uri;
                    g = i;
                    bArr3 = bArr;
                    bundle2 = C0242a.m319q(parcel, B);
                    bArr2 = bArr3;
                    break;
                case DetectedActivity.TILTING /*5*/:
                    bArr2 = C0242a.m320r(parcel, B);
                    bundle2 = bundle;
                    uri2 = uri;
                    g = i;
                    break;
                default:
                    C0242a.m302b(parcel, B);
                    bArr2 = bArr;
                    bundle2 = bundle;
                    uri2 = uri;
                    g = i;
                    break;
            }
            i = g;
            uri = uri2;
            bundle = bundle2;
            bArr = bArr2;
        }
        if (parcel.dataPosition() == C) {
            return new C2555m(i, uri, bundle, bArr);
        }
        throw new C0241a("Overread allowed size end=" + C, parcel);
    }

    public C2555m[] fX(int i) {
        return new C2555m[i];
    }

    public /* synthetic */ Object[] newArray(int x0) {
        return fX(x0);
    }
}
