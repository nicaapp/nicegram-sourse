package com.google.android.gms.wearable;

import android.net.Uri;
import android.net.Uri.Builder;
import android.os.Bundle;
import android.os.Parcel;
import android.os.Parcelable.Creator;
import android.text.TextUtils;
import android.util.Log;
import com.google.android.gms.common.internal.C0238o;
import com.google.android.gms.common.internal.safeparcel.SafeParcelable;
import com.google.android.gms.wearable.internal.DataItemAssetParcelable;
import java.security.SecureRandom;
import java.util.Collections;
import java.util.HashMap;
import java.util.Map;
import java.util.Map.Entry;
import java.util.Random;

public class PutDataRequest implements SafeParcelable {
    public static final Creator<PutDataRequest> CREATOR;
    public static final String WEAR_URI_SCHEME = "wear";
    private static final Random auZ;
    final int BR;
    private byte[] acH;
    private final Bundle ava;
    private final Uri mUri;

    static {
        CREATOR = new C0738e();
        auZ = new SecureRandom();
    }

    private PutDataRequest(int versionCode, Uri uri) {
        this(versionCode, uri, new Bundle(), null);
    }

    PutDataRequest(int versionCode, Uri uri, Bundle assets, byte[] data) {
        this.BR = versionCode;
        this.mUri = uri;
        this.ava = assets;
        this.ava.setClassLoader(DataItemAssetParcelable.class.getClassLoader());
        this.acH = data;
    }

    public static PutDataRequest create(String path) {
        return m3741k(dg(path));
    }

    public static PutDataRequest createFromDataItem(DataItem source) {
        PutDataRequest k = m3741k(source.getUri());
        for (Entry entry : source.getAssets().entrySet()) {
            if (((DataItemAsset) entry.getValue()).getId() == null) {
                throw new IllegalStateException("Cannot create an asset for a put request without a digest: " + ((String) entry.getKey()));
            }
            k.putAsset((String) entry.getKey(), Asset.createFromRef(((DataItemAsset) entry.getValue()).getId()));
        }
        k.setData(source.getData());
        return k;
    }

    public static PutDataRequest createWithAutoAppendedId(String pathPrefix) {
        StringBuilder stringBuilder = new StringBuilder(pathPrefix);
        if (!pathPrefix.endsWith("/")) {
            stringBuilder.append("/");
        }
        stringBuilder.append("PN").append(auZ.nextLong());
        return new PutDataRequest(1, dg(stringBuilder.toString()));
    }

    private static Uri dg(String str) {
        if (TextUtils.isEmpty(str)) {
            throw new IllegalArgumentException("An empty path was supplied.");
        } else if (!str.startsWith("/")) {
            throw new IllegalArgumentException("A path must start with a single / .");
        } else if (!str.startsWith("//")) {
            return new Builder().scheme(WEAR_URI_SCHEME).path(str).build();
        } else {
            throw new IllegalArgumentException("A path must start with a single / .");
        }
    }

    public static PutDataRequest m3741k(Uri uri) {
        return new PutDataRequest(1, uri);
    }

    public int describeContents() {
        return 0;
    }

    public Asset getAsset(String key) {
        return (Asset) this.ava.getParcelable(key);
    }

    public Map<String, Asset> getAssets() {
        Map hashMap = new HashMap();
        for (String str : this.ava.keySet()) {
            hashMap.put(str, (Asset) this.ava.getParcelable(str));
        }
        return Collections.unmodifiableMap(hashMap);
    }

    public byte[] getData() {
        return this.acH;
    }

    public Uri getUri() {
        return this.mUri;
    }

    public boolean hasAsset(String key) {
        return this.ava.containsKey(key);
    }

    public Bundle pT() {
        return this.ava;
    }

    public PutDataRequest putAsset(String key, Asset value) {
        C0238o.m283i(key);
        C0238o.m283i(value);
        this.ava.putParcelable(key, value);
        return this;
    }

    public PutDataRequest removeAsset(String key) {
        this.ava.remove(key);
        return this;
    }

    public PutDataRequest setData(byte[] data) {
        this.acH = data;
        return this;
    }

    public String toString() {
        return toString(Log.isLoggable(DataMap.TAG, 3));
    }

    public String toString(boolean verbose) {
        StringBuilder stringBuilder = new StringBuilder("PutDataRequest[");
        stringBuilder.append("dataSz=" + (this.acH == null ? "null" : Integer.valueOf(this.acH.length)));
        stringBuilder.append(", numAssets=" + this.ava.size());
        stringBuilder.append(", uri=" + this.mUri);
        if (verbose) {
            stringBuilder.append("]\n  assets: ");
            for (String str : this.ava.keySet()) {
                stringBuilder.append("\n    " + str + ": " + this.ava.getParcelable(str));
            }
            stringBuilder.append("\n  ]");
            return stringBuilder.toString();
        }
        stringBuilder.append("]");
        return stringBuilder.toString();
    }

    public void writeToParcel(Parcel dest, int flags) {
        C0738e.m2210a(this, dest, flags);
    }
}
