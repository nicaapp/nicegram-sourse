package com.google.android.gms.wearable;

import android.app.Service;
import android.content.Intent;
import android.os.Binder;
import android.os.Handler;
import android.os.HandlerThread;
import android.os.IBinder;
import android.util.Log;
import com.google.android.gms.common.GooglePlayServicesUtil;
import com.google.android.gms.common.data.DataHolder;
import com.google.android.gms.wearable.DataApi.DataListener;
import com.google.android.gms.wearable.MessageApi.MessageListener;
import com.google.android.gms.wearable.NodeApi.NodeListener;
import com.google.android.gms.wearable.internal.ae.C2132a;
import com.google.android.gms.wearable.internal.ah;
import com.google.android.gms.wearable.internal.ak;

public abstract class WearableListenerService extends Service implements DataListener, MessageListener, NodeListener {
    public static final String BIND_LISTENER_INTENT_ACTION = "com.google.android.gms.wearable.BIND_LISTENER";
    private String BZ;
    private IBinder LZ;
    private volatile int NX;
    private Handler avc;
    private Object avd;
    private boolean ave;

    /* renamed from: com.google.android.gms.wearable.WearableListenerService.a */
    private class C2542a extends C2132a {
        final /* synthetic */ WearableListenerService avf;

        /* renamed from: com.google.android.gms.wearable.WearableListenerService.a.1 */
        class C07311 implements Runnable {
            final /* synthetic */ DataHolder avg;
            final /* synthetic */ C2542a avh;

            C07311(C2542a c2542a, DataHolder dataHolder) {
                this.avh = c2542a;
                this.avg = dataHolder;
            }

            public void run() {
                DataEventBuffer dataEventBuffer = new DataEventBuffer(this.avg);
                try {
                    this.avh.avf.onDataChanged(dataEventBuffer);
                } finally {
                    dataEventBuffer.release();
                }
            }
        }

        /* renamed from: com.google.android.gms.wearable.WearableListenerService.a.2 */
        class C07322 implements Runnable {
            final /* synthetic */ C2542a avh;
            final /* synthetic */ ah avi;

            C07322(C2542a c2542a, ah ahVar) {
                this.avh = c2542a;
                this.avi = ahVar;
            }

            public void run() {
                this.avh.avf.onMessageReceived(this.avi);
            }
        }

        /* renamed from: com.google.android.gms.wearable.WearableListenerService.a.3 */
        class C07333 implements Runnable {
            final /* synthetic */ C2542a avh;
            final /* synthetic */ ak avj;

            C07333(C2542a c2542a, ak akVar) {
                this.avh = c2542a;
                this.avj = akVar;
            }

            public void run() {
                this.avh.avf.onPeerConnected(this.avj);
            }
        }

        /* renamed from: com.google.android.gms.wearable.WearableListenerService.a.4 */
        class C07344 implements Runnable {
            final /* synthetic */ C2542a avh;
            final /* synthetic */ ak avj;

            C07344(C2542a c2542a, ak akVar) {
                this.avh = c2542a;
                this.avj = akVar;
            }

            public void run() {
                this.avh.avf.onPeerDisconnected(this.avj);
            }
        }

        private C2542a(WearableListenerService wearableListenerService) {
            this.avf = wearableListenerService;
        }

        public void m4558Z(DataHolder dataHolder) {
            if (Log.isLoggable("WearableLS", 3)) {
                Log.d("WearableLS", "onDataItemChanged: " + this.avf.BZ + ": " + dataHolder);
            }
            this.avf.pU();
            synchronized (this.avf.avd) {
                if (this.avf.ave) {
                    dataHolder.close();
                    return;
                }
                this.avf.avc.post(new C07311(this, dataHolder));
            }
        }

        public void m4559a(ah ahVar) {
            if (Log.isLoggable("WearableLS", 3)) {
                Log.d("WearableLS", "onMessageReceived: " + ahVar);
            }
            this.avf.pU();
            synchronized (this.avf.avd) {
                if (this.avf.ave) {
                    return;
                }
                this.avf.avc.post(new C07322(this, ahVar));
            }
        }

        public void m4560a(ak akVar) {
            if (Log.isLoggable("WearableLS", 3)) {
                Log.d("WearableLS", "onPeerConnected: " + this.avf.BZ + ": " + akVar);
            }
            this.avf.pU();
            synchronized (this.avf.avd) {
                if (this.avf.ave) {
                    return;
                }
                this.avf.avc.post(new C07333(this, akVar));
            }
        }

        public void m4561b(ak akVar) {
            if (Log.isLoggable("WearableLS", 3)) {
                Log.d("WearableLS", "onPeerDisconnected: " + this.avf.BZ + ": " + akVar);
            }
            this.avf.pU();
            synchronized (this.avf.avd) {
                if (this.avf.ave) {
                    return;
                }
                this.avf.avc.post(new C07344(this, akVar));
            }
        }
    }

    public WearableListenerService() {
        this.NX = -1;
        this.avd = new Object();
    }

    private boolean bc(int i) {
        String str = GooglePlayServicesUtil.GOOGLE_PLAY_SERVICES_PACKAGE;
        String[] packagesForUid = getPackageManager().getPackagesForUid(i);
        if (packagesForUid == null) {
            return false;
        }
        for (Object equals : packagesForUid) {
            if (str.equals(equals)) {
                return true;
            }
        }
        return false;
    }

    private void pU() throws SecurityException {
        int callingUid = Binder.getCallingUid();
        if (callingUid != this.NX) {
            if (GooglePlayServicesUtil.m137b(getPackageManager(), GooglePlayServicesUtil.GOOGLE_PLAY_SERVICES_PACKAGE) && bc(callingUid)) {
                this.NX = callingUid;
                return;
            }
            throw new SecurityException("Caller is not GooglePlayServices");
        }
    }

    public final IBinder onBind(Intent intent) {
        return BIND_LISTENER_INTENT_ACTION.equals(intent.getAction()) ? this.LZ : null;
    }

    public void onCreate() {
        super.onCreate();
        if (Log.isLoggable("WearableLS", 3)) {
            Log.d("WearableLS", "onCreate: " + getPackageName());
        }
        this.BZ = getPackageName();
        HandlerThread handlerThread = new HandlerThread("WearableListenerService");
        handlerThread.start();
        this.avc = new Handler(handlerThread.getLooper());
        this.LZ = new C2542a();
    }

    public void onDataChanged(DataEventBuffer dataEvents) {
    }

    public void onDestroy() {
        synchronized (this.avd) {
            this.ave = true;
            this.avc.getLooper().quit();
        }
        super.onDestroy();
    }

    public void onMessageReceived(MessageEvent messageEvent) {
    }

    public void onPeerConnected(Node peer) {
    }

    public void onPeerDisconnected(Node peer) {
    }
}
