package com.google.android.gms.wearable;

import com.google.android.gms.common.api.Result;
import com.google.android.gms.common.api.Status;
import com.google.android.gms.common.data.C2385g;
import com.google.android.gms.common.data.DataHolder;
import com.google.android.gms.wearable.internal.C2551h;

public class DataEventBuffer extends C2385g<DataEvent> implements Result {
    private final Status CM;

    public DataEventBuffer(DataHolder dataHolder) {
        super(dataHolder);
        this.CM = new Status(dataHolder.getStatusCode());
    }

    protected /* synthetic */ Object m4814f(int i, int i2) {
        return m4815p(i, i2);
    }

    protected String gD() {
        return "path";
    }

    public Status getStatus() {
        return this.CM;
    }

    protected DataEvent m4815p(int i, int i2) {
        return new C2551h(this.II, i, i2);
    }
}
