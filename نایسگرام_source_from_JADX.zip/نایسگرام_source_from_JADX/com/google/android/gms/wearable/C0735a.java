package com.google.android.gms.wearable;

import android.net.Uri;
import android.os.Parcel;
import android.os.ParcelFileDescriptor;
import android.os.Parcelable.Creator;
import com.google.android.gms.common.internal.safeparcel.C0242a;
import com.google.android.gms.common.internal.safeparcel.C0242a.C0241a;
import com.google.android.gms.common.internal.safeparcel.C0243b;
import com.google.android.gms.drive.events.CompletionEvent;
import com.google.android.gms.location.DetectedActivity;
import org.telegram.android.support.widget.helper.ItemTouchHelper;
import org.telegram.android.time.FastDatePrinter;

/* renamed from: com.google.android.gms.wearable.a */
public class C0735a implements Creator<Asset> {
    static void m2208a(Asset asset, Parcel parcel, int i) {
        int D = C0243b.m329D(parcel);
        C0243b.m356c(parcel, 1, asset.BR);
        C0243b.m348a(parcel, 2, asset.getData(), false);
        C0243b.m344a(parcel, 3, asset.getDigest(), false);
        C0243b.m340a(parcel, 4, asset.auR, i, false);
        C0243b.m340a(parcel, 5, asset.uri, i, false);
        C0243b.m332H(parcel, D);
    }

    public /* synthetic */ Object createFromParcel(Parcel x0) {
        return dP(x0);
    }

    public Asset dP(Parcel parcel) {
        Uri uri = null;
        int C = C0242a.m293C(parcel);
        int i = 0;
        ParcelFileDescriptor parcelFileDescriptor = null;
        String str = null;
        byte[] bArr = null;
        while (parcel.dataPosition() < C) {
            int B = C0242a.m291B(parcel);
            switch (C0242a.aD(B)) {
                case CompletionEvent.STATUS_FAILURE /*1*/:
                    i = C0242a.m309g(parcel, B);
                    break;
                case CompletionEvent.STATUS_CONFLICT /*2*/:
                    bArr = C0242a.m320r(parcel, B);
                    break;
                case FastDatePrinter.SHORT /*3*/:
                    str = C0242a.m317o(parcel, B);
                    break;
                case ItemTouchHelper.LEFT /*4*/:
                    parcelFileDescriptor = (ParcelFileDescriptor) C0242a.m298a(parcel, B, ParcelFileDescriptor.CREATOR);
                    break;
                case DetectedActivity.TILTING /*5*/:
                    uri = (Uri) C0242a.m298a(parcel, B, Uri.CREATOR);
                    break;
                default:
                    C0242a.m302b(parcel, B);
                    break;
            }
        }
        if (parcel.dataPosition() == C) {
            return new Asset(i, bArr, str, parcelFileDescriptor, uri);
        }
        throw new C0241a("Overread allowed size end=" + C, parcel);
    }

    public Asset[] fS(int i) {
        return new Asset[i];
    }

    public /* synthetic */ Object[] newArray(int x0) {
        return fS(x0);
    }
}
