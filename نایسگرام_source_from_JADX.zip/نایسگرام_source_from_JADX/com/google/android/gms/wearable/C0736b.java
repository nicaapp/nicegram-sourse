package com.google.android.gms.wearable;

/* renamed from: com.google.android.gms.wearable.b */
public interface C0736b {
}
