package com.google.android.gms.wearable;

import com.google.android.gms.common.api.Result;
import com.google.android.gms.common.api.Status;
import com.google.android.gms.common.data.C2385g;
import com.google.android.gms.common.data.DataHolder;
import com.google.android.gms.wearable.internal.C2556o;

public class DataItemBuffer extends C2385g<DataItem> implements Result {
    private final Status CM;

    public DataItemBuffer(DataHolder dataHolder) {
        super(dataHolder);
        this.CM = new Status(dataHolder.getStatusCode());
    }

    protected /* synthetic */ Object m4816f(int i, int i2) {
        return m4817q(i, i2);
    }

    protected String gD() {
        return "path";
    }

    public Status getStatus() {
        return this.CM;
    }

    protected DataItem m4817q(int i, int i2) {
        return new C2556o(this.II, i, i2);
    }
}
