package com.google.android.gms.wearable;

import android.net.Uri;
import android.util.Log;
import com.google.android.gms.internal.pc;
import com.google.android.gms.internal.pc.C0548a;
import com.google.android.gms.internal.pn;

public class PutDataMapRequest {
    private final DataMap auX;
    private final PutDataRequest auY;

    private PutDataMapRequest(PutDataRequest putDataRequest, DataMap dataMap) {
        this.auY = putDataRequest;
        this.auX = new DataMap();
        if (dataMap != null) {
            this.auX.putAll(dataMap);
        }
    }

    public static PutDataMapRequest create(String path) {
        return new PutDataMapRequest(PutDataRequest.create(path), null);
    }

    public static PutDataMapRequest createFromDataMapItem(DataMapItem source) {
        return new PutDataMapRequest(PutDataRequest.m3741k(source.getUri()), source.getDataMap());
    }

    public static PutDataMapRequest createWithAutoAppendedId(String pathPrefix) {
        return new PutDataMapRequest(PutDataRequest.createWithAutoAppendedId(pathPrefix), null);
    }

    public PutDataRequest asPutDataRequest() {
        C0548a a = pc.m1756a(this.auX);
        this.auY.setData(pn.m1838f(a.awb));
        int size = a.awc.size();
        int i = 0;
        while (i < size) {
            String num = Integer.toString(i);
            Asset asset = (Asset) a.awc.get(i);
            if (num == null) {
                throw new IllegalStateException("asset key cannot be null: " + asset);
            } else if (asset == null) {
                throw new IllegalStateException("asset cannot be null: key=" + num);
            } else {
                if (Log.isLoggable(DataMap.TAG, 3)) {
                    Log.d(DataMap.TAG, "asPutDataRequest: adding asset: " + num + " " + asset);
                }
                this.auY.putAsset(num, asset);
                i++;
            }
        }
        return this.auY;
    }

    public DataMap getDataMap() {
        return this.auX;
    }

    public Uri getUri() {
        return this.auY.getUri();
    }
}
